# =========================================================================
# EJITOR 2026 - MAXIMUM AGGRESSIVE OFFLINE PROGUARD RULES
# =========================================================================

# ১. লাইন নম্বর এবং সোর্স ফাইলের নাম সম্পূর্ণ মুছে ফেলা
-renamesourcefileattribute ''
-dontkeepattributes SourceFile,LineNumberTable,LocalVariableTable,LocalVariableTypeTable

# ২. আক্রমণাত্মক অবফাসকেশন ও ক্লাস ফ্ল্যাটেনিং (সব ক্লাস ও মেথড a, b, c হবে)
-repackageclasses ''
-allowaccessmodification
-overloadaggressively
-dontusemixedcaseclassnames
-skipnonpubliclibraryclasses
-verbose
-optimizationpasses 5

# ৩. অ্যাক্টিভিটি ক্লাসের নাম ম্যানিফেস্টের জন্য রাখা, কিন্তু ভেতরের সব মেথড a, b, c করা
-keep class com.example.ejitor.MainActivity extends android.app.Activity
-keep class com.example.ejitor.details extends android.app.Activity

# ৪. EditorActivity-র শুধু প্রয়োজনীয় রিফ্লেকশন মেথডগুলো রাখা, বাকি সব অবফাসকেট করা
-keep class com.example.ejitor.EditorActivity extends android.app.Activity {
    public static com.example.ejitor.EditorActivity instance;
    private int fgColor;
    private int bgColor;
    private java.lang.String activeTool;
    private void recordHistory();
    private void updateLayersDockUI();
    private void saveProjectToDisk(...);
    private void autoSaveCurrentProject();
    private void showInAppMultiImagePicker();
    private void alignActiveLayerCenter();
    public com.example.ejitor.EditorActivity$ProjectTabSession getCurrentSession();
    public void notifyProjectModified();
    public void openColorPicker(...);
    public void triggerClickFeedback(...);
    public void showCustomNumericKeypad(...);
}

# ৫. ডাইনামিক মডিউল (editor_1 থেকে editor_200)-এর ভেতরের সব মেথড a, b, c হবে
-keep class com.example.ejitor.editor_* {
    public <init>();
    public void init(com.example.ejitor.EditorActivity);
    public void onCommand(java.lang.String, java.lang.Object[]);
}

-keep interface com.example.ejitor.EditorActivity$EditorModule { *; }

# ৬. ডেটা মডেল ও সেশন ক্লাস
-keep class com.example.ejitor.EditorActivity$ProjectTabSession { *; }
-keep class com.example.ejitor.EditorActivity$LayerItem { *; }
-keep class com.example.ejitor.EditorActivity$PolyAnchorPoint { *; }
-keep class com.example.ejitor.EditorActivity$GradStop { *; }
-keep class com.example.ejitor.EditorActivity$HistorySnapshot { *; }

# ৭. popup ও HomeStudioManager-এর শুধু বাইরের কলগুলো রাখা, বাকি সব কোড অবফাসকেট
-keep class com.example.ejitor.popup {
    public static void showStandaloneColorPicker(...);
    public static void showColorPicker(...);
    public static void showNumericKeypad(...);
}

-keepclassmembers class com.example.ejitor.HomeStudioManager {
    public <init>(android.app.Activity);
    public android.view.View buildHomeScreen();
    public void openUnifiedFilePicker();
}

# ৮. WebView জাভাস্ক্রিপ্ট ইন্টারফেস
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ৯. ভিউ ইন্টারনাল লিসেনার ওয়ার্নিং বন্ধ
-dontwarn android.view.View
-keepclassmembers class android.view.View {
    *** mListenerInfo;
}