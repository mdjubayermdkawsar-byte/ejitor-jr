package com.example.ejitor;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class editor_6 implements EditorActivity.EditorModule {

    private EditorActivity activity;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private View.OnClickListener originalImageClickListener = null;

    
    private static final String OLD_SERVER_URL = "https://api-ke-linker.vercel.app/gateway/Facebook";
    
    
    private static final String NEW_SERVER_URL = "https://api-ke-linker.vercel.app/gateway/telegram";

    
    private static final String FASTER_REMOVER_URL = "https://api-ke-linker.vercel.app/gateway/YouTube";

    
    private static final String ENHANCE_SERVER_URL = "https://api-ke-linker.vercel.app/gateway/Instagram"; 

    
    private static final String ULTRA_ENHANCE_SERVER_URL = "https://api-ke-linker.vercel.app/gateway/bot";

    @Override
    public void init(EditorActivity activity) {
        this.activity = activity;

        hookImageMenuButton();

        activity.registerLayerAction("EJITOR R.V.3.3 ", (layer, index) -> {
            processImageTask(layer, OLD_SERVER_URL, "removed", false);
        });

        activity.registerLayerAction("EJITOR R.V.3.2", (layer, index) -> {
            processImageTask(layer, NEW_SERVER_URL, "removed", false);
        });

        activity.registerLayerAction("EJITOR R.V.2.1", (layer, index) -> {
            processImageTask(layer, FASTER_REMOVER_URL, "removed", false);
        });

        activity.registerLayerAction("EJITOR E.V.5.2", (layer, index) -> {
            processImageTask(layer, ENHANCE_SERVER_URL, "enhanced", false);
        });

        activity.registerLayerAction("DEEP E.V.3.3", (layer, index) -> {
            processImageTask(layer, ULTRA_ENHANCE_SERVER_URL, "enhanced", false);
        });
    }

    private void hookImageMenuButton() {
        LinearLayout menuContainer = activity.getTopMenuContainer();
        if (menuContainer == null) return;

        for (int i = 0; i < menuContainer.getChildCount(); i++) {
            View child = menuContainer.getChildAt(i);
            if (child instanceof TextView) {
                final TextView tv = (TextView) child;
                if ("Image".equalsIgnoreCase(tv.getText().toString().trim())) {
                    try {
                        Method getListenerInfo = View.class.getDeclaredMethod("getListenerInfo");
                        getListenerInfo.setAccessible(true);
                        Object li = getListenerInfo.invoke(tv);
                        Field f = li.getClass().getDeclaredField("mOnClickListener");
                        f.setAccessible(true);
                        originalImageClickListener = (View.OnClickListener) f.get(li);
                    } catch (Exception ignored) {}

                    tv.setOnClickListener(v -> {
                        activity.triggerClickFeedback(tv);

                        if (originalImageClickListener != null) {
                            originalImageClickListener.onClick(tv);
                        }

                        injectOptionOnTopOfExistingMenu(tv);
                    });
                    break;
                }
            }
        }
    }

    private void injectOptionOnTopOfExistingMenu(View anchor) {
        anchor.postDelayed(() -> {
            try {
                Class<?> wmClass = Class.forName("android.view.WindowManagerGlobal");
                Object wm = wmClass.getMethod("getInstance").invoke(null);
                Field viewsField = wmClass.getDeclaredField("mViews");
                viewsField.setAccessible(true);
                List<View> views = (List<View>) viewsField.get(wm);

                if (views != null && !views.isEmpty()) {
                    View popupDecor = views.get(views.size() - 1);
                    LinearLayout menuLayout = findFirstLinearLayoutWithTextViews(popupDecor);

                    if (menuLayout != null && menuLayout.findViewWithTag("TAG_BG_REMOVER") == null) {
                        
                        TextView template = null;
                        for (int i = 0; i < menuLayout.getChildCount(); i++) {
                            View v = menuLayout.getChildAt(i);
                            if (v instanceof TextView && v.getVisibility() == View.VISIBLE) {
                                template = (TextView) v;
                                break;
                            }
                        }

                        TextView bgTv = createMenuButton("EJITOR R.V.3.3", "TAG_BG_REMOVER", template, popupDecor, OLD_SERVER_URL, "EJITOR R.V.3.3ᴶᴿ", false);
                        TextView bgTvNew = createMenuButton("EJITOR R.V.3.1", "TAG_BG_REMOVER_NEW", template, popupDecor, NEW_SERVER_URL, "EJITOR R.V.3.1ᴶᴿ", false);
                        TextView fasterTv = createMenuButton("EJITOR R.V.2.1", "TAG_FASTER_REMOVER", template, popupDecor, FASTER_REMOVER_URL, "EJITOR R.V.2.1ᴶᴿ", false);
                        TextView enhanceTv = createMenuButton("EDITOR E.V.5.3", "TAG_ENHANCE", template, popupDecor, ENHANCE_SERVER_URL, "EDITOR E.V.5.3ᴶᴿ", false);
                        TextView ultraEnhanceTv = createMenuButton("DEEP E.V.2.1", "TAG_ULTRA_ENHANCE", template, popupDecor, ULTRA_ENHANCE_SERVER_URL, "DEEP E.V.2.1ᴶᴿ", false);

                        menuLayout.addView(bgTv);
                        menuLayout.addView(bgTvNew);
                        menuLayout.addView(fasterTv);
                        menuLayout.addView(enhanceTv);
                        menuLayout.addView(ultraEnhanceTv);
                    }
                }
            } catch (Exception ignored) {}
        }, 120);
    }

    private TextView createMenuButton(String text, String tag, TextView template, View popupDecor, String url, String toastMsg, boolean isEnhance) {
        TextView tv = new TextView(activity);
        tv.setTag(tag);
        tv.setText(text);
        
        if (template != null) {
            tv.setTextColor(template.getCurrentTextColor());
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, template.getTextSize());
            tv.setPadding(template.getPaddingLeft(), template.getPaddingTop(), template.getPaddingRight(), template.getPaddingBottom());
            tv.setGravity(template.getGravity());
        } else {
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            tv.setPadding(dp(12), dp(8), dp(12), dp(8));
        }

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tv.setLayoutParams(params);

        tv.setOnClickListener(v -> {
            popupDecor.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK));
            popupDecor.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BACK));
            
            EditorActivity.ProjectTabSession session = activity.getCurrentSession();
            if (session != null && !session.layers.isEmpty() && session.activeLayerIndex >= 0 && session.activeLayerIndex < session.layers.size()) {
                EditorActivity.LayerItem activeLayer = session.layers.get(session.activeLayerIndex);
                processImageTask(activeLayer, url, toastMsg, isEnhance);
            } else {
                Toast.makeText(activity, "No layer selected!", Toast.LENGTH_SHORT).show();
            }
        });
        return tv;
    }

    private LinearLayout findFirstLinearLayoutWithTextViews(View root) {
        if (root instanceof LinearLayout) {
            LinearLayout ll = (LinearLayout) root;
            for (int i = 0; i < ll.getChildCount(); i++) {
                if (ll.getChildAt(i) instanceof TextView) return ll;
            }
        }
        if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for (int i = 0; i < vg.getChildCount(); i++) {
                LinearLayout found = findFirstLinearLayoutWithTextViews(vg.getChildAt(i));
                if (found != null) return found;
            }
        }
        return null;
    }

    private void refreshLayersDockSafely(EditorActivity act) {
        try {
            Method m = EditorActivity.class.getDeclaredMethod("updateLayersDockUI");
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    // =========================================================================
    // ট্রান্সপারেন্ট ব্যাকগ্রাউন্ড, লাল প্রোগ্রেস আর্ক, কালো বাটি ও সাদা টেক্সট
    // =========================================================================
    private static class CircularProgressLoadingView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint centerBowlPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arcRect = new RectF();

        private float progress = 5f;
        private ValueAnimator progressAnimator;
        private boolean isFinishing = false;

        public CircularProgressLoadingView(Context context) {
            super(context);
            init();
        }

        private void init() {
            setLayerType(LAYER_TYPE_SOFTWARE, null);

            // পেছনের ট্রান্সলুসেন্ট হালকা ট্র্যাক (কালো বাটির সাথে মিলিয়ে সফট ট্র্যাক)
            trackPaint.setStyle(Paint.Style.STROKE);
            trackPaint.setColor(Color.parseColor("#33222222"));

            // মূল ঘোরার অংশ: সম্পূর্ণ উজ্জ্বল লাল কালার (Pure Vibrant Red)
            progressPaint.setStyle(Paint.Style.STROKE);
            progressPaint.setStrokeCap(Paint.Cap.ROUND);
            progressPaint.setColor(Color.parseColor("#FF1744"));

            // বাটির মতো ভেতরের অংশটি: সম্পূর্ণ কালো রঙ (Deep Black Bowl)
            centerBowlPaint.setStyle(Paint.Style.FILL);
            centerBowlPaint.setColor(Color.parseColor("#141414"));
            centerBowlPaint.setShadowLayer(dpVal(10), 0, dpVal(4), Color.parseColor("#80000000"));

            // পার্সেন্টেজ লেখা: সম্পূর্ণ সাদা টেক্সট (Bold White Text)
            textPaint.setColor(Color.WHITE);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));

            startLoadingAnimation();
        }

        private float dpVal(float v) {
            return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
        }

        private void startLoadingAnimation() {
            progressAnimator = ValueAnimator.ofFloat(5f, 92f);
            progressAnimator.setDuration(4500);
            progressAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            progressAnimator.addUpdateListener(anim -> {
                progress = (float) anim.getAnimatedValue();
                invalidate();
            });
            progressAnimator.start();
        }

        public void playFinishAnimation(Runnable onEnd) {
            if (isFinishing) return;
            isFinishing = true;

            if (progressAnimator != null) progressAnimator.cancel();

            ValueAnimator finishAnim = ValueAnimator.ofFloat(progress, 100f);
            finishAnim.setDuration(320);
            finishAnim.setInterpolator(new AccelerateDecelerateInterpolator());
            finishAnim.addUpdateListener(anim -> {
                progress = (float) anim.getAnimatedValue();
                invalidate();
            });
            finishAnim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    postDelayed(() -> {
                        if (onEnd != null) onEnd.run();
                    }, 150);
                }
            });
            finishAnim.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (progressAnimator != null) progressAnimator.cancel();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0) return;

            float cx = w / 2f;
            float cy = h / 2f;
            // বাইরের সাদা ডিস্ক পুরোপুরি বাদ দিয়ে স্বচ্ছ রাখা হয়েছে
            float totalRadius = Math.min(cx, cy) * 0.90f;
            float strokeW = totalRadius * 0.28f;

            trackPaint.setStrokeWidth(strokeW);
            progressPaint.setStrokeWidth(strokeW);

            float arcRadius = totalRadius - (strokeW / 2f);
            arcRect.set(cx - arcRadius, cy - arcRadius, cx + arcRadius, cy + arcRadius);

            // ১. ট্র্যাক আঁকা
            canvas.drawCircle(cx, cy, arcRadius, trackPaint);

            // ২. সম্পূর্ণ লাল গ্র্যাডিয়েন্ট (ঘুরে পূর্ণ হওয়ার অংশ)
            if (progressPaint.getShader() == null) {
                SweepGradient gradient = new SweepGradient(cx, cy,
                        new int[]{Color.parseColor("#FF2A2A"), Color.parseColor("#D50000"), Color.parseColor("#FF2A2A")},
                        null);
                progressPaint.setShader(gradient);
            }

            // ৩. লাল প্রোগ্রেস আর্ক
            float sweepAngle = (progress / 100f) * 360f;
            canvas.drawArc(arcRect, -90f, sweepAngle, false, progressPaint);

            // ৪. বাটির মতো অংশটি সম্পূর্ণ কালো (Black Bowl)
            float innerRadius = totalRadius * 0.54f;
            canvas.drawCircle(cx, cy, innerRadius, centerBowlPaint);

            // ৫. মাঝখানে বড় পরিষ্কার সাদা টেক্সট (White % Text)
            textPaint.setTextSize(innerRadius * 0.54f);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            float textY = cy - (fm.ascent + fm.descent) / 2f;
            String textStr = Math.round(progress) + "%";
            canvas.drawText(textStr, cx, textY, textPaint);
        }
    }

    // স্বচ্ছ ডায়ালগে বড় সাইজের (165dp) কাস্টম লোডিং
    private static class CustomLoadingDialog extends Dialog {
        public final CircularProgressLoadingView progressView;

        public CustomLoadingDialog(Context context) {
            super(context);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            setCancelable(false);
            if (getWindow() != null) {
                getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                getWindow().setDimAmount(0.45f);
            }

            LinearLayout layout = new LinearLayout(context);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.setGravity(Gravity.CENTER);
            int pad = dp(20, context);
            layout.setPadding(pad, pad, pad, pad);

            // আগের চেয়ে বড় সাইজ (165dp x 165dp)
            progressView = new CircularProgressLoadingView(context);
            int size = dp(165, context);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(size, size);
            progressView.setLayoutParams(params);

            layout.addView(progressView);
            setContentView(layout);
        }

        private static int dp(float val, Context ctx) {
            return (int) TypedValue.applyDimension(
                    TypedValue.COMPLEX_UNIT_DIP, val, ctx.getResources().getDisplayMetrics());
        }
    }

    private void processImageTask(EditorActivity.LayerItem layer, String targetServerUrl, String successToastMsg, boolean isEnhance) {
        if (layer == null || layer.bitmap == null || layer.bitmap.isRecycled()) {
            Toast.makeText(activity, "Layer has no image!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (layer.isLocked) {
            Toast.makeText(activity, "Layer is locked!", Toast.LENGTH_SHORT).show();
            return;
        }

        final CustomLoadingDialog dialog = new CustomLoadingDialog(activity);
        dialog.show();

        new Thread(() -> {
            HttpURLConnection conn = null;
            try {
                Bitmap original = layer.bitmap;
                int origW = original.getWidth();
                int origH = original.getHeight();

                int maxDim = 800;
                Bitmap uploadBitmap = original;
                if (origW > maxDim || origH > maxDim) {
                    float ratio = Math.min((float) maxDim / origW, (float) maxDim / origH);
                    uploadBitmap = Bitmap.createScaledBitmap(original, Math.round(origW * ratio), Math.round(origH * ratio), true);
                }

                boolean hasAlpha = original.hasAlpha();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                String mimeType;
                String filename;

                if (hasAlpha) {
                    uploadBitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
                    mimeType = "image/png";
                    filename = "layer.png";
                } else {
                    uploadBitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos);
                    mimeType = "image/jpeg";
                    filename = "layer.jpg";
                }

                byte[] imageBytes = baos.toByteArray();
                baos.close();

                String boundary = "Boundary" + System.currentTimeMillis();
                String LINE_FEED = "\r\n";

                URL url = new URL(targetServerUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setUseCaches(false);
                conn.setDoOutput(true);
                conn.setDoInput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                conn.setConnectTimeout(60000);
                conn.setReadTimeout(60000);

                DataOutputStream outputStream = new DataOutputStream(conn.getOutputStream());
                outputStream.writeBytes("--" + boundary + LINE_FEED);
                outputStream.writeBytes("Content-Disposition: form-data; name=\"image\"; filename=\"" + filename + "\"" + LINE_FEED);
                outputStream.writeBytes("Content-Type: " + mimeType + LINE_FEED);
                outputStream.writeBytes(LINE_FEED);
                outputStream.write(imageBytes);
                outputStream.writeBytes(LINE_FEED);
                outputStream.writeBytes("--" + boundary + "--" + LINE_FEED);
                outputStream.flush();
                outputStream.close();

                int responseCode = conn.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream is = conn.getInputStream();
                    Bitmap processedImage = BitmapFactory.decodeStream(is);
                    is.close();

                    if (processedImage != null) {
                        if (!isEnhance) {
                            if (processedImage.getWidth() != origW || processedImage.getHeight() != origH) {
                                processedImage = Bitmap.createScaledBitmap(processedImage, origW, origH, true);
                            }
                        }

                        final Bitmap finalBitmap = processedImage;
                        mainHandler.post(() -> {
                            layer.bitmap = finalBitmap.copy(Bitmap.Config.ARGB_8888, true);
                            layer.isBlank = false;
                            layer.isShape = false;

                            activity.recordHistory();
                            refreshLayersDockSafely(activity);
                            activity.getCanvasView().invalidate();

                            // সার্ভার রেসপন্স পাওয়া মাত্র ১০০% হয়ে সুন্দরভাবে শেষ হওয়া
                            if (dialog.progressView != null) {
                                dialog.progressView.playFinishAnimation(() -> {
                                    if (!activity.isFinishing() && !activity.isDestroyed()) {
                                        dialog.dismiss();
                                    }
                                    Toast.makeText(activity, successToastMsg, Toast.LENGTH_SHORT).show();
                                });
                            } else {
                                if (!activity.isFinishing() && !activity.isDestroyed()) {
                                    dialog.dismiss();
                                }
                                Toast.makeText(activity, successToastMsg, Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else {
                        throw new Exception("Failed to decode image from server");
                    }
                } else {
                    String errDetail = "Server error " + responseCode;
                    try {
                        InputStream es = conn.getErrorStream();
                        if (es != null) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(es));
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                sb.append(line);
                            }
                            reader.close();
                            if (sb.length() > 0) errDetail = sb.toString();
                        }
                    } catch (Exception ignored) {}
                    throw new Exception(errDetail);
                }

            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (!activity.isFinishing() && !activity.isDestroyed()) {
                        dialog.dismiss();
                    }
                    Toast.makeText(activity, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                if (conn != null) {
                    conn.disconnect();
                }
            }
        }).start();
    }

    private int dp(float val) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, val, activity.getResources().getDisplayMetrics());
    }

    @Override
    public void onCommand(String command, Object... args) {
        // Handled dynamically.
    }
}