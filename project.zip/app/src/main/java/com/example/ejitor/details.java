package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class details extends Activity {

    private LinearLayout contentContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // মূল ডার্ক থিম লেআউট
        LinearLayout root = new LinearLayout(this);
        root.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#121212"));

        // ১. হেডার বার
        root.addView(createHeaderBar());

        // ২. মূল স্ক্রোলভিউ
        ScrollView scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);

        contentContainer = new LinearLayout(this);
        contentContainer.setOrientation(LinearLayout.VERTICAL);
        contentContainer.setPadding(dp(16), dp(16), dp(16), dp(45));

        // ৩. ২০টি মাস্টার কার্ড বিল্ড (১ম কার্ডের ভেতরেই লাল স্ট্রোকের ছবি ও পরিচয় অন্তর্ভুক্ত)
        buildAll20MasterCards();

        scrollView.addView(contentContainer);
        root.addView(scrollView);

        setContentView(root);
    }

    private int dp(float value) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private View createHeaderBar() {
        LinearLayout headerBar = new LinearLayout(this);
        headerBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        headerBar.setBackgroundColor(Color.parseColor("#181818"));
        headerBar.setOrientation(LinearLayout.HORIZONTAL);
        headerBar.setGravity(Gravity.CENTER_VERTICAL);
        headerBar.setPadding(dp(14), 0, dp(14), 0);

        Button backBtn = new Button(this);
        backBtn.setText("← Back");
        backBtn.setTextColor(Color.WHITE);
        backBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        backBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        GradientDrawable backBg = new GradientDrawable();
        backBg.setColor(Color.parseColor("#262626"));
        backBg.setCornerRadius(dp(4));
        backBtn.setBackground(backBg);
        backBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(75), dp(32)));
        backBtn.setOnClickListener(v -> finish());
        headerBar.addView(backBtn);

        TextView titleTv = new TextView(this);
        titleTv.setText("  Learn & Academy Hub");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        titleTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        headerBar.addView(titleTv);

        return headerBar;
    }

    // assets/owner.png থেকে ছবি লোড করে চারপাশে লাল বর্ডার যুক্ত করার নিরাপদ মেথড
    private Bitmap loadSafeOwnerAvatarWithRedStroke() {
        try {
            InputStream is = getAssets().open("owner.png");
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] data = new byte[16384];
            int nRead;
            while ((nRead = is.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }
            byte[] bytes = buffer.toByteArray();
            is.close();

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);

            int sample = 1;
            while ((opts.outWidth / sample) > 512 || (opts.outHeight / sample) > 512) {
                sample *= 2;
            }

            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            Bitmap original = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);

            if (original != null) {
                int size = Math.min(original.getWidth(), original.getHeight());
                Bitmap circularBmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(circularBmp);
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

                // গোল ছবি মাস্ক
                c.drawCircle(size / 2f, size / 2f, (size / 2f) - dp(4), p);
                p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                c.drawBitmap(original, new Rect((original.getWidth() - size) / 2, (original.getHeight() - size) / 2,
                        (original.getWidth() + size) / 2, (original.getHeight() + size) / 2), new Rect(0, 0, size, size), p);

                // লাল বর্ডার স্ট্রোক
                p.setXfermode(null);
                p.setStyle(Paint.Style.STROKE);
                p.setColor(Color.parseColor("#FF1238"));
                p.setStrokeWidth(dp(3.5f));
                c.drawCircle(size / 2f, size / 2f, (size / 2f) - dp(4), p);

                return circularBmp;
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ২০টি মাস্টার কার্ড তৈরি
    private void buildAll20MasterCards() {

        // ১. আমার পরিচয় কার্ড (ছবির পাশে লাল স্ট্রোক এবং পরিচয়ের সব তথ্য কার্ডের ভেতরে)
        contentContainer.addView(createIdentityCardWithPhoto());

        // ২. অফিশিয়াল সোশ্যাল মিডিয়া ও কমিউনিটি হাব
        contentContainer.addView(createSocialHubMasterCard());

        // ৩. ডিজাইন সেক্টরে যাত্রার শুরু (২০২৪)
        contentContainer.addView(createCustomTopicCard(
                "ডিজাইন সেক্টরে যাত্রার শুরু",
                "২০২৪ সাল ছিল আমার এই যাত্রার একটি গুরুত্বপূর্ণ অধ্যায়। আগ্রহ, শেখার ইচ্ছা এবং নিজের পরিচয়ে পরিচিত হওয়ার গল্প।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "২০২৪ সাল ছিল আমার এই ডিজাইন যাত্রার বাস্তব সূচনা এবং ভিত্তিপ্রস্তর।",
                        "শুরুর দিকে আজকের মতো অভিজ্ঞতা, পরিচিতি কিংবা প্রতিষ্ঠিত ব্র্যান্ড কিছুই ছিল না।",
                        "ছিল কেবল শেখার তীব্র আগ্রহ এবং নিজের দক্ষতাকে বাস্তব কাজে লাগানোর স্বপ্ন।",
                        "সোশ্যাল মিডিয়া পোস্টার, থাম্বনেইল ও ব্যানারের বিভিন্ন ডিজাইন দিয়ে প্রতিনিয়ত কাজ শুরু করি।",
                        "টাইপোগ্রাফি এবং অক্ষরের সুন্দর বিন্যাস নিয়ে দীর্ঘ সময় গবেষণা ও অনুশীলন করেছি।",
                        "প্রতিটি ডিজাইন আমার কাছে ছিল নতুন একটি ভুল থেকে শিক্ষা নেওয়ার সেরা সুযোগ।",
                        "একটি সাধারণ আইডিয়াকে প্রফেশনাল রূপ দেওয়ার পেছনের ভিজ্যুয়াল নিয়মগুলো বুঝতে শুরু করি।",
                        "সফটওয়্যার জানা আর ডিজাইনার হওয়ার তফাত উপলব্ধি করে কালার থিওরি রপ্ত করি।",
                        "অনলাইন টিউটোরিয়াল ও নিয়মিত অনুশীলনের মাধ্যমে নিজের দুর্বলতাগুলোকে শক্তিতে রূপ দিই।",
                        "নিজের একটি স্বতন্ত্র ক্রিয়েটিভ আইডেন্টিটি গড়ে তোলার সাধনা অব্যাহত রাখি।"
                }
        ));

        // ৪. প্রথম কাজ থেকে অভিজ্ঞতা
        contentContainer.addView(createCustomTopicCard(
                "প্রথম কাজ থেকে অভিজ্ঞতা",
                "৫০ টাকার প্রথম পারিশ্রমিক থেকে শেখা অমূল্য শিক্ষা, ক্লায়েন্টের চাহিদা বোঝা এবং কাজের প্রতি দায়বদ্ধতা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "আমার কর্মজীবনের প্রথম দিকের একটি কাজের পারিশ্রমিক ছিল মাত্র ৫০ টাকা।",
                        "টাকার অঙ্ক ছোট হলেও বাস্তব কাজের অভিজ্ঞতা অর্জনে সেটি ছিল আমার সবচেয়ে বড় অনুপ্রেরণা।",
                        "পরবর্তীতে ৫০০ টাকা, ১,০০০ টাকা এবং বিভিন্ন পরিমাণের পারিশ্রমিকের কাজ সম্পন্ন করেছি।",
                        "অর্থের চেয়ে ক্লায়েন্টের চাহিদা বোঝা এবং সময়মতো কাজ ডেলিভারি দেওয়াকে গুরুত্ব দিয়েছি।",
                        "কোনো কাজই ছোট নয়, যদি সেই কাজ থেকে নতুন কিছু শেখা যায় এবং আত্মবিশ্বাস বাড়ে।",
                        "ক্লায়েন্টের সঙ্গে পেশাদার আচরণ ও বিশ্বাসযোগ্য সম্পর্ক গড়ার কৌশল রপ্ত করেছি।",
                        "ডিজাইনের সূক্ষ্ম বিষয়গুলোতে ক্লায়েন্টের মতামতকে গুরুত্ব দিয়ে কাজের মান উন্নত করেছি।",
                        "দায়িত্বশীল ডেলিভারির মাধ্যমে ক্লায়েন্টদের দীর্ঘমেয়াদি আস্থাশীল পার্টনারে পরিণত করেছি।",
                        "নিজের পরিশ্রমের সঠিক মূল্যায়ন এবং আত্মমর্যাদার সাথে কাজ চালিয়ে যাওয়ার শিক্ষা পেয়েছি।",
                        "কঠোর পরিশ্রমই যে একজন ডিজাইনারের প্রকৃত পরিচয় গড়ে তোলে, তা বাস্তব জীবনে প্রমাণ পেয়েছি।"
                }
        ));

        // ৫. আন্তর্জাতিক ক্লায়েন্টদের সঙ্গে কাজের বাস্তব অভিজ্ঞতা
        contentContainer.addView(createCustomTopicCard(
                "আন্তর্জাতিক ক্লায়েন্টদের সঙ্গে কাজ",
                "সৌদি আরব ও বিভিন্ন দেশের ক্লায়েন্টদের কাজের অভিজ্ঞতা, প্রতিবন্ধকতা জয় এবং পেশাদারিত্ব।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "বাংলাদেশ ছাড়াও সৌদি আরবসহ মধ্যপ্রাচ্য ও বিদেশের বিভিন্ন ক্লায়েন্টের প্রজেক্টে কাজ করেছি।",
                        "আন্তর্জাতিক স্ট্যান্ডার্ডের কালার প্যালেট ও আরবি/ইংরেজি টাইপোগ্রাফির কাজ সম্পন্ন করেছি।",
                        "সময়ের পার্থক্য (Timezone) সামলে সঠিক টাইমে ফাইল ডেলিভারি দেওয়ার অভিজ্ঞতা অর্জন করেছি।",
                        "অতীতে কিছু ক্লায়েন্টের কাছ থেকে কাজের পারিশ্রমিক ও মূল্যায়ন নিয়ে তিক্ত অভিজ্ঞতাও হয়েছে।",
                        "এসব কঠিন পরিস্থিতি আমাকে বাস্তববাদী হতে শিখিয়েছে এবং কাজের শর্ত স্পষ্ট করার শিক্ষা দিয়েছে।",
                        "আন্তর্জাতিক পেমেন্ট গেটওয়ে এবং ফাইল ট্রান্সফারের টেকনিক্যাল বিষয়গুলো আয়ত্ত করেছি।",
                        "কঠিন অভিজ্ঞতাগুলোকে নিজের অগ্রযাত্রার প্রতিবন্ধকতা না বানিয়ে শিক্ষার মাধ্যম হিসেবে নিয়েছি।",
                        "ক্লায়েন্ট সন্তুষ্টিই যে ফ্রিল্যান্সিংয়ে নতুন কাজের সবচেয়ে বড় মাধ্যম, তা উপলব্ধি করেছি।",
                        "নিজের মেধা দিয়ে বিদেশের মাটিতে বিশ্বস্ত ও প্রশংসিত কাজ সম্পন্ন করতে পেরেছি।",
                        "প্রতিটি সফল আন্তর্জাতিক কাজ আমাকে আরও বড় চ্যালেঞ্জ নেওয়ার সাহস ও আত্মবিশ্বাস জুগিয়েছে।"
                }
        ));

        // ৬. JR DESIGN STORE-এর জন্ম — ২০২৪
        contentContainer.addView(createCustomTopicCard(
                "JR DESIGN STORE-এর জন্ম — ২০২৪",
                "ডিজাইনারদের জন্য একটি পূর্ণাঙ্গ ক্রিয়েটিভ ইকোসিস্টেম ও রিসোর্স হাব গড়ে তোলার রূপরেখা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "২০২৪ সালে JR DESIGN STORE-এর আনুষ্ঠানিক স্বপ্নযাত্রা শুরু হয়।",
                        "এটি শুধুমাত্র একটি ব্যবসায়িক নাম নয়, এটি আমার সৃজনশীলতা ও আত্মত্যাগের প্রতীক।",
                        "ডিজাইনাররা যেন এক জায়গায় প্রয়োজনীয় ফন্ট ও রিসোর্স সহজে পান, সেই চিন্তা থেকে জন্ম।",
                        "মোবাইল ডিজাইনারদের কাজের প্রক্রিয়া সহজ করতে প্রজেক্ট টেমপ্লেট সংগ্রহ ও তৈরি করেছি।",
                        "নতুনদের জন্য ফ্রিতে রিসোর্স সরবরাহ করে তাদের কাজের সুযোগ করে দেওয়া হয়েছে।",
                        "সময়ের অপচয় রোধ করতে গোছানো এবং কোয়ালিটি রিসোর্সের লাইব্রেরি গড়ে তুলেছি।",
                        "সোশ্যাল মিডিয়া ও টেলিগ্রামে একটি শক্তিশালী ডিজাইনার পরিবার গড়ে তোলা হয়েছে।",
                        "মানুষের ভালোবাসা ও নির্ভরযোগ্যতার ওপর ভিত্তি করে প্ল্যাটফর্মটি দিন দিন বড় হয়েছে।",
                        "প্রযুক্তির ব্যবহার করে ডিজাইনারদের কাজকে আরও স্বয়ংক্রিয় করার পরিকল্পনা হাতে নিয়েছি।",
                        "একটি সাধারণ উদ্যোগ থেকে আজ এটি হাজারো ডিজাইনারের নির্ভরযোগ্য ঠিকানা।"
                }
        ));

        // ৭. সাফল্যের গুরুত্বপূর্ণ মোড় — আগস্ট ২০২৫
        contentContainer.addView(createCustomTopicCard(
                "সাফল্যের গুরুত্বপূর্ণ মোড় — আগস্ট ২০২৫",
                "অবিরাম চেষ্টার পর ২০২৫ সালের আগস্টে পাওয়া অভাবনীয় অগ্রগতি ও মানুষের গভীর আস্থা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "২০২৫ সালের আগস্ট মাস ছিল JR DESIGN STORE-এর ইতিহাসে সবচেয়ে বড় অর্জনের সময়।",
                        "দীর্ঘদিনের নিঃস্বার্থ প্রচেষ্টার পর মানুষের অভাবনীয় ভালোবাসা ও সাড়া পেতে শুরু করি।",
                        "আমাদের শেয়ার করা রিসোর্স ব্যবহার করে বহু নতুন ডিজাইনার ভালো কাজ পেতে শুরু করে।",
                        "ধারাবাহিক কাজের ফলে প্ল্যাটফর্মটি একটি প্রভাবশালী ব্র্যান্ড হিসেবে স্বীকৃতি পায়।",
                        "আমার কাছে সফলতা মানে শুধু সংখ্যা বা ভিউ নয়; মানুষের জীবনে কার্যকর প্রভাব ফেলাই আসল।",
                        "এই অগ্রগতি আমাকে আরও বড় পরিসরে টেকনোলজি নিয়ে কাজ করার সাহস জুগিয়েছে।",
                        "কমিউনিটির প্রতিটি সদস্যের গঠনমূলক মন্তব্য ও প্রতিক্রিয়া আমাদের মান আরও বাড়িয়েছে।",
                        "সাফল্য পেয়ে থেমে না থেকে কাজের গতি আরও বাড়ানোর প্রেরণা পেয়েছি।",
                        "স্বপ্ন যে সঠিক পথে এগোচ্ছে, এই অর্জন ছিল তারই স্পষ্ট প্রমাণ।",
                        "আগামী দিনগুলোতে কমিউনিটিকে আরও উন্নত সেবা দেওয়ার অঙ্গীকার দৃঢ় হয়েছে।"
                }
        ));

        // ৮. JR DESIGN STORE — ব্র্যান্ড দর্শন ও মানদণ্ড
        contentContainer.addView(createCustomTopicCard(
                "JR DESIGN STORE — ব্র্যান্ড দর্শন",
                "Creative, Premium, Modern, Practical ও Beginner-Friendly সেবার অঙ্গীকার।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "Creative: প্রতিটি কাজে নতুনত্ব, মৌলিকত্ব এবং সৃজনশীলতার প্রতিফলন ঘটানো।",
                        "Premium: কোয়ালিটিতে কোনো ধরনের আপস না করে সেরা মানের কনটেন্ট উপহার দেওয়া।",
                        "Modern: সময়ের সাথে তাল মিলিয়ে আধুনিক ভিজ্যুয়াল ট্রেন্ড অনুসরণ করা।",
                        "Professional: পরিচ্ছন্ন, গোছানো এবং পেশাদার ব্র্যান্ড আইডেন্টিটি রক্ষা করা।",
                        "Practical: এমন রিসোর্স তৈরি করা যা ডিজাইনারদের বাস্তব প্রজেক্টে সরাসরি কাজে লাগে।",
                        "Designer-Focused: ডিজাইনারদের বাস্তব সমস্যা ও প্রয়োজনকে সর্বোচ্চ অগ্রাধিকার দেওয়া।",
                        "Beginner-Friendly: নতুনদের সহজভাবে কাজ শুরু করার পরিবেশ তৈরি করা।",
                        "Community-Oriented: পারস্পরিক সহযোগিতা ও শেখার উন্মুক্ত প্ল্যাটফর্ম তৈরি।",
                        "ভিজ্যুয়াল পরিচয়: লাল, কালো ও সাদার নান্দনিক সিগনেচার সমন্বয়।",
                        "ব্র্যান্ড স্লোগান: JR DESIGN STORE — Creativity Meets Possibility।"
                }
        ));

        // ৯. ডিজাইনারদের জন্য ২৫,০০০+ ফন্ট রিসোর্স
        contentContainer.addView(createCustomTopicCard(
                "ডিজাইন রিসোর্স ও ২৫,০০০+ ফন্ট",
                "ডিজাইনারদের সময় বাঁচাতে ফন্ট, পিএলপি ফাইল ও এক্সক্লুসিভ কালেকশন নিয়ে তৈরি সমৃদ্ধ লাইব্রেরি।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "বিশাল ২৫,০০০+ প্রিমিয়াম ও ক্লাসিক ফন্টের সুবিন্যস্ত ডিজিটাল লাইব্রেরি তৈরি করেছি।",
                        "বাংলা, ইংরেজি ও ইসলামিক ক্যালিগ্রাফি ফন্টের ক্যাটাগরিভিত্তিক সহজ ডাউনলোড সুবিধা।",
                        "মোবাইল ও কম্পিউটার উভয় ডিভাইসে ব্যবহারের উপযোগী টেক্সটাইল ফন্ট।",
                        "থাম্বনেইল ও পোস্টার ডিজাইনের জন্য প্রয়োজনীয় আকর্ষক টাইপোগ্রাফি রিসোর্স।",
                        "ফন্ট খুঁজতে গিয়ে ডিজাইনারদের মূল্যবান সময় যেন নষ্ট না হয়, তা নিশ্চিত করা হয়েছে।",
                        "ফন্ট ব্যবহারের সঠিক লাইসেন্স ও নীতিমালার প্রতি শ্রদ্ধা রাখা শেখানো হয়।",
                        "নিয়মিত নতুন রিলিজ হওয়া আধুনিক ফন্টগুলো দ্রুত কমিউনিটিতে পৌঁছে দেওয়া হয়।",
                        "হাই-কোয়ালিটি ব্যাকগ্রাউন্ড, পিএনজি এবং টেক্সচার ফাইল এক ছাদের নিচে রাখা হয়েছে।",
                        "সহজে এডিটযোগ্য প্রজেক্ট ফাইল (PLP/PSD) শেয়ারের মাধ্যমে কাজের গতি বৃদ্ধি।",
                        "দেশের সর্ববৃহৎ ও নির্ভরযোগ্য ফন্ট আর্কাইভ হিসেবে নিজেদের স্থান তৈরি করা।"
                }
        ));

        // ১০. PixelLab এবং মোবাইল ডিজাইনের শক্তি
        contentContainer.addView(createCustomTopicCard(
                "PixelLab ও মোবাইল ডিজাইন দর্শন",
                "দামি কম্পিউটার ছাড়া সাধারণ স্মার্টফোন দিয়েই আন্তর্জাতিক মানের কাজ তৈরির কৌশল।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "স্মার্টফোন দিয়েই যে প্রফেশনাল ও ক্লায়েন্ট-মানের ডিজাইন করা সম্ভব, তা প্রমাণ করেছি।",
                        "PixelLab-এর লেয়ারিং, মাস্কিং এবং কালার ফিল্টারের সর্বোচ্চ টেকনিক্যাল ব্যবহার।",
                        "রঙের ভারসাম্য, কনট্রাস্ট এবং ভিজ্যুয়াল হায়ারার্কি তৈরি করার মোবাইল কৌশল।",
                        "মোবাইল দিয়ে আকর্ষণীয় ব্যানার, লোগো, থাম্বনেইল ও সোশ্যাল মিডিয়া পোস্ট তৈরি।",
                        "যন্ত্রের সীমাবদ্ধতাকে নিজের মেধা ও শেখার ইচ্ছার সামনে বাধা হতে না দেওয়া।",
                        "সাধারণ উপকরণ ব্যবহার করেও কীভাবে দৃষ্টিনন্দন গ্রাফিক ফুটিয়ে তোলা যায় তা শেখানো।",
                        "অতিরিক্ত গ্লো বা শ্যাডো নয়, বরং পরিচ্ছন্ন ও অর্থবহ কম্পোজিশন তৈরির ওপর জোর দেওয়া।",
                        "মোবাইল ডিজাইনারদের হীনম্মন্যতা দূর করে আত্মবিশ্বাসের সাথে কাজের সুযোগ করে দেওয়া।",
                        "যেকোনো স্থান ও সময়ে বসে স্মার্টফোন দিয়ে প্রজেক্ট সম্পন্ন করার অসাধারণ স্বাধীনতা।",
                        "মোবাইল ডিজাইনিংকে একটি পূর্ণাঙ্গ ফ্রিল্যান্স ক্যারিয়ার হিসেবে গড়ে তোলার দৃষ্টান্ত।"
                }
        ));

        // ১১. কনটেন্ট ক্রিয়েশন ও মেন্টরশিপের স্বপ্ন
        contentContainer.addView(createCustomTopicCard(
                "ডিজাইন শিক্ষা ও মেন্টরশিপের স্বপ্ন",
                "অনুকরণ না করে ডিজাইনের পেছনের যুক্তি বুঝতে শেখা এবং নতুনদের বাস্তব গাইডলাইন।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "শুধু একটি ডিজাইন অনুকরণ না করে পেছনের কারণ ও লজিক বোঝার মানসিকতা তৈরি করা।",
                        "কেন নির্দিষ্ট ফন্ট বা কালার প্যালেট বেছে নেওয়া হলো, তা সহজ ভাষায় ব্যাখ্যা করা।",
                        "নতুনদের ভুলগুলো ধরিয়ে দিয়ে বাস্তবভিত্তিক সমাধান ও পরামর্শ দেওয়া।",
                        "সোশ্যাল মিডিয়ায় গঠনমূলক ও শিক্ষামূলক ডিজাইন টিউটোরিয়াল প্রকাশ করা।",
                        "কপি-পেস্ট মানসিকতা থেকে বের করে এনে নিজস্ব ক্রিয়েটিভ স্টাইল আবিষ্কারে সাহায্য করা।",
                        "আন্তর্জাতিক বাজারের ক্লায়েন্টদের রুচি ও ট্রেন্ড সম্পর্কে সঠিক ধারণা দেওয়া।",
                        "নিয়মিত ডিজাইন পর্যালোচনা ও গঠনমূলক ফিডব্যাকের মাধ্যমে মেন্টরিং করা।",
                        "নতুন ডিজাইনারদের প্রথম ক্লায়েন্ট পাওয়া ও কাজের মূল্য নির্ধারণের গাইডলাইন দেওয়া।",
                        "পরবর্তী প্রজন্মের ক্রিয়েটিভ তরুণদের জন্য একটি নিরাপদ ও দিকনির্দেশনামূলক হাব তৈরি।",
                        "ডিজাইনকে একটি সম্মানজনক ও লাভজনক পেশা হিসেবে সবার সামনে প্রতিষ্ঠিত করা।"
                }
        ));

        // ১২. JR Font Bot ও প্রযুক্তিগত অটোমেশন
        contentContainer.addView(createCustomTopicCard(
                "JR Font Bot ও প্রযুক্তিগত উদ্যোগ",
                "টেলিগ্রাম বট ও অটোমেশনের মাধ্যমে কয়েক সেকেন্ডে ফন্ট খোঁজা ও ডাউনলোডের আধুনিক সুবিধা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "টেলিগ্রাম প্ল্যাটফর্মে JR Font Bot-এর মাধ্যমে স্বয়ংক্রিয় ফন্ট ডেলিভারি ব্যবস্থা চালু।",
                        "ফন্টের ছবি দেখে কয়েক সেকেন্ডে ফন্টের নাম শনাক্ত করার বিশেষ সুবিধা।",
                        "ক্যাটাগরি অনুযায়ী হাজারো ফন্ট সার্চ করে নিমেষে সংগ্রহ করার সুযোগ।",
                        "JR BOT HOSTING-এর মতো প্রযুক্তিগত উদ্যোগের মাধ্যমে ওয়েব অটোমেশন সেবা প্রদান।",
                        "গ্রাফিক ডিজাইনের সাথে প্রোগ্রামিং ও ডিজিটাল প্রযুক্তির সমন্বয় ঘটানো।",
                        "ব্যবহারকারীদের ঝামেলাহীন ও দ্রুততম ডাউনলোড অভিজ্ঞতা নিশ্চিত করা।",
                        "ওয়েবসাইট ও ক্লাউড ডেটাবেজের মাধ্যমে সকল রিসোর্স নিরাপদ রাখা।",
                        "সার্ভারের গতি ও ডাউনলোডের নির্ভরযোগ্যতা ২৪ ঘণ্টা সচল রাখা।",
                        "ভবিষ্যতে এআই-চালিত ডিজাইন অ্যাসিস্ট্যান্ট তৈরির পরিকল্পনা বাস্তবায়ন করা।",
                        "প্রযুক্তির সঠিক ব্যবহারের মাধ্যমে ডিজাইনারদের সময়কে সর্বোচ্চ সাশ্রয় করা।"
                }
        ));

        // ১৩. কাজের দর্শন ও ৬টি ভবিষ্যৎ লক্ষ্য
        contentContainer.addView(createCustomTopicCard(
                "কাজের দর্শন ও ৬টি ভবিষ্যৎ লক্ষ্য",
                "Simplicity + Creativity + Premium Look + Practical Use এবং আগামী দিনের কর্মপরিকল্পনা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "দর্শন: সহজ উপস্থাপনা, সৃজনশীল চিন্তা, প্রিমিয়াম লুক এবং বাস্তব উপযোগিতার সমন্বয়।",
                        "অপ্রয়োজনীয় ডিজাইনের ভিড় এড়িয়ে মার্জিত ও অর্থপূর্ণ ভিজ্যুয়াল তৈরি করা।",
                        "লক্ষ্য ১: ফন্ট, প্রজেক্ট ফাইল ও ভেক্টরের দেশের সর্ববৃহৎ ক্লাউড আর্কাইভ গড়া।",
                        "লক্ষ্য ২: নতুনদের জন্য সহজবোধ্য সম্পূর্ণ বাস্তবভিত্তিক ডিজাইন মাস্টারক্লাস তৈরি।",
                        "লক্ষ্য ৩: নিজস্ব ওয়েবসাইট ও অ্যাপ্লিকেশনের মাধ্যমে অটোমেটেড রিসোর্স হাব চালু।",
                        "লক্ষ্য ৪: ডিজাইনারদের কর্মসংস্থান এবং আন্তর্জাতিক ক্লায়েন্টদের কাজের সুযোগ তৈরি।",
                        "লক্ষ্য ৫: JR DESIGN STORE-কে বিশ্বমানের একটি ক্রিয়েটিভ ব্র্যান্ডে রূপান্তর করা।",
                        "লক্ষ্য ৬: বৈশ্বিক মঞ্চে বাংলাদেশি মোবাইল ও কম্পিউটার ডিজাইনারদের সুনাম প্রতিষ্ঠা করা।",
                        "কঠোর সততা, কাজের মান ও মানুষের আস্থাকে আজীবন ধরে রাখা।",
                        "স্বপ্ন অনেক বড়, লক্ষ্য পরিষ্কার এবং চেষ্টা সর্বদা অবিচল রাখা।"
                }
        ));

        // ১৪. সফলতার আসল অর্থ ও শেষ বার্তা
        contentContainer.addView(createCustomTopicCard(
                "সফলতার অর্থ ও কৃতজ্ঞতা প্রকাশ",
                "JR DESIGN STORE — Creativity Meets Possibility. দীর্ঘস্থায়ী আস্থা অর্জনই আসল সফলতা।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "আমার কাছে সফলতা মানে শুধু অর্থ কিংবা প্রচুর পরিচিতি লাভ করা নয়।",
                        "সফলতা হলো নিজের কাজের মাধ্যমে মানুষের বাস্তব উপকারে আসা ও সমস্যা সমাধান করা।",
                        "এমন একটি ব্র্যান্ড গড়ে তোলা যা বছরের পর বছর মানুষের আস্থার প্রতীক হয়ে থাকবে।",
                        "আমার এই যাত্রায় যারা শুরু থেকে পাশে আছেন, সবার প্রতি অন্তরের অন্তঃস্থল থেকে কৃতজ্ঞতা।",
                        "আপনারা যারা কাজ দেখছেন, রিসোর্স ব্যবহার করছেন, পরামর্শ দিচ্ছেন—সবাই আমার অনুপ্রেরণা।",
                        "প্রতিটি নতুন চ্যালেঞ্জ আমাকে নতুন কিছু শেখার সুযোগ করে দেয়।",
                        "চলার পথ সহজ ছিল না, কিন্তু সততা ও পরিশ্রম আমাকে এগিয়ে নিয়েছে।",
                        "আগামী দিনের প্রতিটি পরিকল্পনা সফল করতে আপনাদের দোয়া ও সমর্থন প্রত্যাশী।",
                        "পথচলা এখানেই শেষ নয়, বরং এটি আরও বিশাল কিছু গড়ে তোলার নিরন্তর প্রচেষ্টা।",
                        "স্বাক্ষর: মেহেদী হাসান জুবায়ের (Founder & Owner, JR DESIGN STORE)।"
                }
        ));

        // ১৫. Multi-Project Tabs গাইড
        contentContainer.addView(createCustomTopicCard(
                "Multi-Project Tabs ব্যবহার নির্দেশিকা",
                "ডেস্কটপ ফটোশপের মতো একসাথে একাধিক প্রজেক্ট ওপেন রাখা ও ট্যাবে ক্লিক করে কাজ করার নিয়ম।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "File মেনু থেকে New Project দিলে ক্যানভাসে বসেই সাথে সাথে নতুন ট্যাব যুক্ত হয়।",
                        "ট্যাবের টাইটেলে ক্লিক করে যেকোনো সময় এক প্রজেক্ট থেকে অন্য প্রজেক্টে যাওয়া যায়।",
                        "প্রতিটি প্রজেক্ট মেমোরিতে আলাদা ফোল্ডারে স্বয়ংক্রিয়ভাবে সংরক্ষিত থাকে।",
                        "ট্যাবের ওপর প্রজেক্টের নাম, জুমের শতকরা হার এবং অ্যাক্টিভ লেয়ারের নাম দেখা যায়।",
                        "ট্যাবের ডানপাশের ✕ চিহ্নে ট্যাপ করে যেকোনো প্রজেক্ট নিরাপদে বন্ধ করা যায়।",
                        "অ্যাপ থেকে বের হয়ে পুনরায় প্রবেশ করলেও প্রতিটি ট্যাব হুবহু আগের অবস্থায় লোড হয়।",
                        "এক প্রজেক্টের ডিজাইন এলিমেন্ট অন্য প্রজেক্টে ওভারল্যাপ করার কোনো ভয় নেই।",
                        "মাল্টি-টাস্কিংয়ের জন্য আলাদা কোনো স্ক্রিন বা অ্যাক্টিভিটিতে যাওয়ার প্রয়োজন নেই।",
                        "স্মার্ট অবজেক্ট ওপেন করলে স্বয়ংক্রিয়ভাবে সাব-প্রজেক্টের নতুন ট্যাব তৈরি হয়।",
                        "কাজ শেষে প্রতিটি ট্যাব আলাদা ডাইমেনশনে এক্সপোর্ট করার সম্পূর্ণ সুবিধা।"
                }
        ));

        // ১৬. Multi-Artboards সিস্টেম (১-২০টি আর্টবোর্ড)
        contentContainer.addView(createCustomTopicCard(
                "Multi-Artboard (১-২০ আর্টবোর্ড) গাইড",
                "একটি ক্যানভাসেই ১ থেকে ২০টি আর্টবোর্ড পাশাপাশি তৈরি ও সোশ্যাল মিডিয়া ক্যারোসেল ডিজাইন।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "New Document পপআপে যত ইচ্ছে আর্টবোর্ড সংখ্যা ইনপুট দিন।",
                        "আর্টবোর্ডগুলো পাশাপাশি সুন্দর রিয়েল শ্যাডো সহ ক্যানভাসে সাজানো থাকে।",
                        "সোশ্যাল মিডিয়া স্লাইড, ইনস্টাগ্রাম ক্যারোসেল বা ফেসবুক পোস্টের জন্য অনন্য ফিচার।",
                        "আর্টবোর্ডের ওপর টাচ করলেই সেই আর্টবোর্ডটি অ্যাক্টিভ আর্টবোর্ড হিসেবে কাজ শুরু করে।",
                        "ফটোশপ স্টাইলে প্রতিটি আর্টবোর্ডের উপরে স্পষ্ট আর্টবোর্ড টাইটেল থাকে।",
                        "আর্টবোর্ডের সীমানার বাইরে কোনো ছবি বা অবজেক্ট গেলে তা স্বয়ংক্রিয়ভাবে হাইড থাকে।",
                        "মাল্টি-পেজ পিডিএফ এক্সপোর্ট করলে সবগুলো আর্টবোর্ড আলাদা পেজে সেভ হয়।",
                        "দুই আঙুল দিয়ে জুম আউট করে পুরো ২০টি আর্টবোর্ড এক নজরে দেখার সুবিধা।",
                        "এক আর্টবোর্ড থেকে এলিমেন্ট কপি করে অন্য আর্টবোর্ডে ড্র্যাগ করার সুযোগ।",
                        "আর্টবোর্ডের রঙ ও ব্যাকগ্রাউন্ড পছন্দমতো কাস্টমাইজ করার স্বাধীনতা।"
                }
        ));

        // ১৭. Smart Objects ও Clipping Masks
        contentContainer.addView(createCustomTopicCard(
                "Smart Objects & Clipping Masks",
                "নন-ডিস্ট্রাকটিভ এডিটিং, সাব-ক্যানভাসে এডিট ও মেইন প্রজেক্টে রিয়েলটাইম সিঙ্ক করার প্রক্রিয়া।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "লেয়ার রো-তে ২ আঙুলে ট্যাপ করে Convert to Smart Object নির্বাচন করুন।",
                        "স্মার্ট অবজেক্টে রূপান্তর হলে লেয়ারে স্পষ্ট পেন্সিল আইকন ভেসে উঠবে।",
                        "পেন্সিল আইকনে ট্যাপ করলেই স্মার্ট অবজেক্টটি নতুন সাব-ট্যাবে ওপেন হবে।",
                        "সাব-ট্যাবে এডিট করে Save Smart Object দিলে মেইন ক্যানভাসে রিয়েলটাইমে সিঙ্ক হবে।",
                        "ক্লিপিং মাস্কের সাহায্যে যেকোনো শেপ বা টেক্সটের ভেতরে ছবি মাস্ক করা যায়।",
                        "লেয়ার রো-তে ২ আঙুলে ট্যাপ করে Release Mask করে দিলে মাস্কিং খুলে যাবে।",
                        "ছবির আসল রেজোলিউশন নষ্ট না করে ছোট-বড় করার অসাধারণ নিরাপত্তা।",
                        "স্মার্ট অবজেক্টের কারণে ভারী প্রজেক্টেও অ্যাপ ল্যাগ-মুক্ত ও ফাস্ট থাকে।",
                        "একক লেয়ারে একাধিক ইফেক্ট প্রয়োগ করেও মূল সোর্স ফাইল অক্ষত রাখা যায়।",
                        "ডেস্কটপ ফটোশপের মতো প্রফেশনাল লেভেল নন-ডিস্ট্রাকটিভ ওয়ার্কফ্লো।"
                }
        ));

        // ১৮. ২০টি ব্লেন্ডিং মোড ও অপাসিটি
        contentContainer.addView(createCustomTopicCard(
                "২০টি ব্লেন্ডিং মোড ও সোয়াইপ অপাসিটি",
                "Linear Dodge (Add), Overlay, Screen মোড নির্বাচন এবং সোয়াইপ করে ০-১০০% অপাসিটি নিয়ন্ত্রণ।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "ক্লিন ফটোশপ ড্রপডাউন থেকে Normal, Multiply, Screen ইত্যাদি বেছে নিন।",
                        "লাইটিং ও গ্লো ইফেক্ট তৈরির জন্য Linear Dodge (Add) মোড অত্যন্ত কার্যকর।",
                        "ছবি মিশিয়ে সিনেমাটিক রূপ দিতে Overlay এবং Soft Light মোড ব্যবহার করুন।",
                        "কালো ব্যাকগ্রাউন্ড মুছে না ফেলে সরাসরি ব্লেন্ড করতে Screen মোড কাজ করে।",
                        "সাদা ব্যাকগ্রাউন্ড সহজেই ব্লেন্ড করার জন্য Multiply মোড সবচেয়ে সেরা।",
                        "Opacity লেখার ওপর আঙুল ডানে-বামে সোয়াইপ করলেই অপাসিটি ০-১০০% নিয়ন্ত্রিত হয়।",
                        "কোনো ধরনের বিশ্রী রেডিও বাটন নেই, পরিচ্ছন্ন টেক্সট ড্রপডাউন থেকে নির্বাচন।",
                        "প্রতিটি লেয়ারের জন্য আলাদা আলাদা অপাসিটি ও ব্লেন্ডিং কম্বিনেশন তৈরি করা যায়।",
                        "লেয়ার চেপে ধরে ড্র্যাগ করে উপরে-নিচে নিয়ে ব্লেন্ডিং ইফেক্ট পরিবর্তন করা যায়।",
                        "রিয়েলটাইম হার্ডওয়্যার অ্যাকসিলারেশন থাকায় ব্লেন্ডিংয়ে কোনো ল্যাগ হয় না।"
                }
        ));

        // ১৯. অন-ক্যানভাস ৩-পয়েন্ট লাইভ গ্রেডিয়েন্ট
        contentContainer.addView(createCustomTopicCard(
                "অন-ক্যানভাস ৩-পয়েন্ট গ্রেডিয়েন্ট",
                "ক্যানভাসে হাত দিয়ে টেনে ৩টি গোল হ্যান্ডেল ঘুরিয়ে সরাসরি লাইভ লিনিয়ার গ্রেডিয়েন্ট প্রয়োগ।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "টুলবার থেকে Gradient Tool সিলেক্ট করে ক্যানভাসে হাত দিয়ে ড্র্যাগ করুন।",
                        "ক্যানভাসে একটি লাইন ভেসে উঠবে যার ওপর ৩টি রাউন্ড কন্ট্রোল হ্যান্ডেল থাকবে।",
                        "১ম শুরুর হ্যান্ডেলটি প্রাইমারি ফোরগ্রাউন্ড কালার নিয়ন্ত্রণ করে।",
                        "২য় মাঝের হ্যান্ডেলটি মিড-টোন কালার নিয়ন্ত্রণ করে।",
                        "৩য় শেষের হ্যান্ডেলটি ব্যাকগ্রাউন্ড কালার নিয়ন্ত্রণ করে।",
                        "হ্যান্ডেলগুলো স্ক্রিনের যেকোনো কোণে ঘুরিয়ে চমৎকার গ্রেডিয়েন্ট অ্যাঙ্গেল দেওয়া যায়।",
                        "সরাসরি লেয়ার বা শেপের ওপর রিয়েলটাইমে গ্রেডিয়েন্ট ইফেক্ট দেখা যায়।",
                        "কালার সোয়াচ থেকে পছন্দমতো রঙ বেছে নিয়ে নিজস্ব গ্রেডিয়েন্ট তৈরি করা যায়।",
                        "যেকোনো পোস্টার বা থাম্বনেইলের সিনেমাটিক ব্যাকগ্রাউন্ড তৈরিতে অতুলনীয়।",
                        "হাত দিয়ে টেনে টেনে নিয়ন্ত্রণের এই অভিজ্ঞতা মোবাইল ডিজাইনিংয়ে একেবারেই নতুন।"
                }
        ));

        // ২০. ২০টি ভেক্টর শেপ ও ফাইল এক্সপোর্ট
        contentContainer.addView(createCustomTopicCard(
                "২০টি ভেক্টর শেপ ও পারফেক্ট এক্সপোর্ট",
                "ক্যানভাসে শেপ আঁকা, কর্নার রেডিয়াস পরিবর্তন এবং Downloads/EJITOR ফোল্ডারে সেভ।",
                "OPEN DETAILS PAGE",
                new String[]{
                        "Rectangle, Rounded Rect, Circle, Star, Heart সহ ২০টি ভেক্টর শেপ।",
                        "ক্যানভাসে হাত দিয়ে টেনে যেকোনো সাইজের শেপ ড্রয়িং করার সুবিধা।",
                        "অন-ক্যানভাস হ্যান্ডেল দিয়ে শেপের চার কোণা সরাসরি ড্র্যাগ করে রাউন্ড করা যায়।",
                        "শেপের ফিল কালার এবং চারপাশের স্ট্রোক কালার ইচ্ছামতো কাস্টমাইজ করা যায়।",
                        "প্রতিবার শেপ আঁকলে স্বয়ংক্রিয়ভাবে নতুন স্বতন্ত্র লেয়ার তৈরি হয়।",
                        "Downloads/EJITOR/editor_project ফোল্ডারে প্রতিটি প্রজেক্টের সব কাজ সেভ থাকে।",
                        "স্বচ্ছ ব্যাকগ্রাউন্ডের জন্য PNG এবং হাই-কোয়ালিটি JPG এক্সপোর্ট সুবিধা।",
                        "মাল্টি-আর্টবোর্ড কাজের জন্য এক ক্লিকে সম্পূর্ণ ভেক্টর মাল্টি-পেজ PDF সেভ।",
                        "১০০+ মেগাবাইটের ভারী ছবি ক্যানভাসে ইমপোর্ট করলেও কোনো ক্র্যাশ হয় না।",
                        "দুই আঙুল দিয়ে মাখনের মতো মসৃণ জুম ও প্যান করে সূক্ষ্ম কাজ করার পূর্ণ স্বাধীনতা।"
                }
        ));
    }

    // ১ম কার্ড: আমার পরিচয় কার্ড (ছবির পাশে লাল স্ট্রোক এবং পরিচয়ের সব তথ্য কার্ডের ভেতরে)
    private View createIdentityCardWithPhoto() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        bg.setCornerRadius(dp(8));
        card.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);

        // লাল বোল্ড টাইটেল
        TextView titleTv = new TextView(this);
        titleTv.setText("আমার পরিচয়");
        titleTv.setTextColor(Color.parseColor("#FF1238"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        card.addView(titleTv);

        // কার্ডের ভেতরেই লাল স্ট্রোক বর্ডারযুক্ত গোল ছবি
        LinearLayout imgHolder = new LinearLayout(this);
        imgHolder.setOrientation(LinearLayout.VERTICAL);
        imgHolder.setGravity(Gravity.CENTER_HORIZONTAL);
        imgHolder.setPadding(0, dp(12), 0, dp(10));

        ImageView profileImg = new ImageView(this);
        int imgSize = dp(96);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(imgSize, imgSize);
        profileImg.setLayoutParams(ip);
        profileImg.setScaleType(ImageView.ScaleType.CENTER_CROP);

        Bitmap avatar = loadSafeOwnerAvatarWithRedStroke();
        if (avatar != null) {
            profileImg.setImageBitmap(avatar);
        } else {
            profileImg.setBackgroundColor(Color.parseColor("#FF1238"));
        }
        imgHolder.addView(profileImg);

        TextView nameTv = new TextView(this);
        nameTv.setText("MEHEDI HASAN JUBAYER");
        nameTv.setTextColor(Color.WHITE);
        nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        nameTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        nameTv.setGravity(Gravity.CENTER);
        nameTv.setPadding(0, dp(6), 0, dp(2));
        imgHolder.addView(nameTv);

        TextView subTv = new TextView(this);
        subTv.setText("Graphic Designer | Content Creator | Mentor\nFounder & Owner of JR DESIGN STORE");
        subTv.setTextColor(Color.parseColor("#FF1238"));
        subTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        subTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        subTv.setGravity(Gravity.CENTER);
        imgHolder.addView(subTv);

        card.addView(imgHolder);

        // ডেসক্রিপশন টেক্সট
        TextView descTv = new TextView(this);
        descTv.setText("সৃজনশীলতা, স্বপ্ন ও আত্মউন্নয়নের নিরবচ্ছিন্ন গল্প। আমি মেহেদী হাসান জুবায়ের, একজন গ্রাফিক ডিজাইনার ও JR DESIGN STORE-এর প্রতিষ্ঠাতা। বিস্তারিত জানতে নিচের বাটনে ক্লিক করুন।");
        descTv.setTextColor(Color.parseColor("#CCCCCC"));
        descTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        descTv.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        descTv.setLineSpacing(dp(3), 1.25f);
        descTv.setPadding(0, dp(4), 0, dp(14));
        card.addView(descTv);

        // লাল পিল বাটন
        Button actionBtn = new Button(this);
        actionBtn.setText("OPEN DETAILS PAGE");
        actionBtn.setTextColor(Color.WHITE);
        actionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        actionBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF1238"));
        btnBg.setCornerRadius(dp(22));
        actionBtn.setBackground(btnBg);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(195), dp(42));
        actionBtn.setLayoutParams(bp);

        final String[] myIdentity12Cards = {
                "১. পুরো নাম: মেহেদী হাসান জুবায়ের (Mehedi Hasan Jubayer)।",
                "২. পেশা: প্রফেশনাল গ্রাফিক ডিজাইনার, কনটেন্ট ক্রিয়েটর এবং ডিজাইন মেন্টর।",
                "৩. অবস্থান: Founder & Owner — JR DESIGN STORE।",
                "৪. ডিজাইন বিশ্বাস: ডিজাইন শুধু সফটওয়্যার নয়, এটি দর্শককে আকৃষ্ট করার ভিজ্যুয়াল ভাষা।",
                "৫. শেখার দর্শন: ভুল থেকে অভিজ্ঞতা অর্জন করে নিজেকে প্রতিনিয়ত উন্নত করা।",
                "৬. লক্ষ্য: অন্য ডিজাইনারদের সহযোগিতা করা ও নতুনদের জন্য পথ সহজ করা।",
                "৭. সৃজনশীলতা: একটি সাধারণ আইডিয়াকে নান্দনিক ও প্রফেশনাল রূপ দেওয়া।",
                "৮. দায়িত্বশীলতা: সময়মতো ক্লায়েন্টের চাহিদামাফিক সেরা কাজের নিশ্চয়তা।",
                "৯. কমিউনিটি ভাবনা: পারস্পরিক সহযোগিতার মাধ্যমে দেশের ডিজাইন সেক্টরকে এগিয়ে নেওয়া।",
                "১০. মূলমন্ত্র: শেখার কোনো শেষ নেই, প্রতিটি দিনই নতুন কিছু জানার সুযোগ।"
        };

        actionBtn.setOnClickListener(v -> showFullScreenDetailsDialog("আমার পরিচয়", myIdentity12Cards));
        card.addView(actionBtn);

        return card;
    }

    // সোশ্যাল হাব মাস্টার কার্ড
    private View createSocialHubMasterCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        bg.setCornerRadius(dp(8));
        card.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);

        TextView titleTv = new TextView(this);
        titleTv.setText("অফিশিয়াল সোশ্যাল মিডিয়া ও কমিউনিটি হাব");
        titleTv.setTextColor(Color.parseColor("#FF1238"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        card.addView(titleTv);

        TextView descTv = new TextView(this);
        descTv.setText("আমাদের অফিশিয়াল ফেসবুক পেজ, টেলিগ্রাম চ্যানেল, সাপোর্ট গ্রুপ ও রিসোর্স হাবের সাথে সরাসরি যুক্ত থাকুন।");
        descTv.setTextColor(Color.parseColor("#CCCCCC"));
        descTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        descTv.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        descTv.setLineSpacing(dp(3), 1.25f);
        descTv.setPadding(0, dp(8), 0, dp(14));
        card.addView(descTv);

        Button actionBtn = new Button(this);
        actionBtn.setText("OPEN SOCIAL HUB");
        actionBtn.setTextColor(Color.WHITE);
        actionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        actionBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF1238"));
        btnBg.setCornerRadius(dp(22));
        actionBtn.setBackground(btnBg);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(195), dp(42));
        actionBtn.setLayoutParams(bp);

        actionBtn.setOnClickListener(v -> showFullScreenSocialHubDialog());
        card.addView(actionBtn);

        return card;
    }

    // যেকোনো বিষয়ের জন্য স্ক্রিনশট ডিজাইনের কার্ড মেকার
    private View createCustomTopicCard(final String titleText, String shortDesc, String buttonText, final String[] items10to12) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        bg.setCornerRadius(dp(8));
        card.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(14));
        card.setLayoutParams(lp);

        TextView titleTv = new TextView(this);
        titleTv.setText(titleText);
        titleTv.setTextColor(Color.parseColor("#FF1238"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleTv.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        card.addView(titleTv);

        TextView descTv = new TextView(this);
        descTv.setText(shortDesc);
        descTv.setTextColor(Color.parseColor("#CCCCCC"));
        descTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        descTv.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        descTv.setLineSpacing(dp(3), 1.25f);
        descTv.setPadding(0, dp(8), 0, dp(14));
        card.addView(descTv);

        Button actionBtn = new Button(this);
        actionBtn.setText(buttonText);
        actionBtn.setTextColor(Color.WHITE);
        actionBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        actionBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF1238"));
        btnBg.setCornerRadius(dp(22));
        actionBtn.setBackground(btnBg);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(195), dp(42));
        actionBtn.setLayoutParams(bp);

        actionBtn.setOnClickListener(v -> showFullScreenDetailsDialog(titleText, items10to12));
        card.addView(actionBtn);

        return card;
    }

    // ২য় ইমেজের সমাধান: ফুল স্ক্রিন ডায়ালগ যাতে প্রতিটি টপিকের ১০-১৫টি আলাদা সাব-কার্ড থাকবে
    private void showFullScreenDetailsDialog(String topicTitle, String[] subCards) {
        final Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout rootLayout = new LinearLayout(this);
        rootLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootLayout.setOrientation(LinearLayout.VERTICAL);
        rootLayout.setBackgroundColor(Color.parseColor("#121212"));

        // হেডার বার
        LinearLayout topBar = new LinearLayout(this);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        topBar.setBackgroundColor(Color.parseColor("#181818"));
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), 0, dp(14), 0);

        Button backBtn = new Button(this);
        backBtn.setText("← Close");
        backBtn.setTextColor(Color.WHITE);
        backBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        backBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(Color.parseColor("#262626"));
        bBg.setCornerRadius(dp(4));
        backBtn.setBackground(bBg);
        backBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(32)));
        backBtn.setOnClickListener(v -> d.dismiss());
        topBar.addView(backBtn);

        TextView title = new TextView(this);
        title.setText("  " + topicTitle);
        title.setTextColor(Color.parseColor("#FF1238"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        title.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topBar.addView(title);

        rootLayout.addView(topBar);

        // স্ক্রোলযোগ্য কনটেন্ট কন্টেইনার
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        sv.setVerticalScrollBarEnabled(false);

        LinearLayout cardList = new LinearLayout(this);
        cardList.setOrientation(LinearLayout.VERTICAL);
        cardList.setPadding(dp(16), dp(16), dp(16), dp(36));

        // ১০-১৫টি স্বতন্ত্র সাব-কার্ড যোগ করা
        for (String itemText : subCards) {
            LinearLayout subCard = new LinearLayout(this);
            subCard.setOrientation(LinearLayout.VERTICAL);
            subCard.setPadding(dp(14), dp(12), dp(14), dp(12));

            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setColor(Color.parseColor("#1A1A1A"));
            cardBg.setStroke(dp(1), Color.parseColor("#262626"));
            cardBg.setCornerRadius(dp(6));
            subCard.setBackground(cardBg);

            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.setMargins(0, 0, 0, dp(10));
            subCard.setLayoutParams(slp);

            TextView tv = new TextView(this);
            tv.setText(itemText);
            tv.setTextColor(Color.parseColor("#E0E0E0"));
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
            tv.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
            tv.setLineSpacing(dp(3), 1.25f);
            subCard.addView(tv);

            cardList.addView(subCard);
        }

        sv.addView(cardList);
        rootLayout.addView(sv);

        // নিচের ক্লোজ বাটন
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        bottomBar.setBackgroundColor(Color.parseColor("#181818"));
        bottomBar.setGravity(Gravity.CENTER);

        Button closeBtn = new Button(this);
        closeBtn.setText("Close Full Screen");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        closeBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        GradientDrawable cBg = new GradientDrawable();
        cBg.setColor(Color.parseColor("#FF1238"));
        cBg.setCornerRadius(dp(22));
        closeBtn.setBackground(cBg);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(40)));
        closeBtn.setOnClickListener(v -> d.dismiss());
        bottomBar.addView(closeBtn);

        rootLayout.addView(bottomBar);

        d.setContentView(rootLayout);
        if (d.getWindow() != null) {
            d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        d.show();
    }

    // ফুল স্ক্রিন সোশ্যাল মিডিয়া ডায়ালগ
    private void showFullScreenSocialHubDialog() {
        final Dialog d = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(this);
        root.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#121212"));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        topBar.setBackgroundColor(Color.parseColor("#181818"));
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(14), 0, dp(14), 0);

        Button backBtn = new Button(this);
        backBtn.setText("← Close");
        backBtn.setTextColor(Color.WHITE);
        backBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        backBtn.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(Color.parseColor("#262626"));
        bBg.setCornerRadius(dp(4));
        backBtn.setBackground(bBg);
        backBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(32)));
        backBtn.setOnClickListener(v -> d.dismiss());
        topBar.addView(backBtn);

        TextView title = new TextView(this);
        title.setText("  Official Community Hub");
        title.setTextColor(Color.parseColor("#FF1238"));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        title.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        topBar.addView(title);
        root.addView(topBar);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout linkList = new LinearLayout(this);
        linkList.setOrientation(LinearLayout.VERTICAL);
        linkList.setPadding(dp(16), dp(16), dp(16), dp(30));

        linkList.addView(createSocialDialogCard("ফেসবুক অফিশিয়াল পেজ (jr.d.s.page)", "নিয়মিত ডিজাইন আপডেট, নতুন রিসোর্স ও ঘোষণার জন্য আমাদের পেজ ফলো করুন।", "https://www.facebook.com/share/1Ep6UsYPM5/"));
        linkList.addView(createSocialDialogCard("টেলিগ্রাম অফিশিয়াল স্টোর (JR DESIGN STORE)", "ফ্রি ও প্রিমিয়াম ফন্ট, ব্যাকগ্রাউন্ড ও পিএলপি ফাইলের বিশাল সংগ্রহশালা।", "https://t.me/jrdesignstore50"));
        linkList.addView(createSocialDialogCard("অফিশিয়াল চ্যানেল (EJITOR Official)", "অ্যাপের নতুন আপডেট, টিউটোরিয়াল এবং রিলিজ সংক্রান্ত যাবতীয় তথ্য।", "https://t.me/ejitor_jr"));
        linkList.addView(createSocialDialogCard("কমিউনিটি ডিসকাশন ও হেল্প গ্রুপ", "যেকোনো ডিজাইন সমস্যা, পরামর্শ ও ডিজাইনারদের আড্ডার উন্মুক্ত প্ল্যাটফর্ম।", "https://t.me/ejitorcommunicatio_jr"));

        sv.addView(linkList);
        root.addView(sv);

        d.setContentView(root);
        if (d.getWindow() != null) {
            d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        d.show();
    }

    private View createSocialDialogCard(String title, String desc, final String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setStroke(dp(1), Color.parseColor("#282828"));
        bg.setCornerRadius(dp(6));
        card.setBackground(bg);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        card.setLayoutParams(lp);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        card.addView(t);

        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextColor(Color.parseColor("#AAAAAA"));
        d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        d.setTypeface(Typeface.SANS_SERIF, Typeface.NORMAL);
        d.setPadding(0, dp(4), 0, dp(10));
        card.addView(d);

        Button b = new Button(this);
        b.setText("Join / Open Link");
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setTypeface(Typeface.SANS_SERIF, Typeface.BOLD);
        GradientDrawable bBg = new GradientDrawable();
        bBg.setColor(Color.parseColor("#FF1238"));
        bBg.setCornerRadius(dp(18));
        b.setBackground(bBg);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(140), dp(36));
        b.setLayoutParams(bp);
        b.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {}
        });
        card.addView(b);

        return card;
    }
}