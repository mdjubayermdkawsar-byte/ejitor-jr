package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PointF;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

public class editor_7 implements EditorActivity.EditorModule {

    private EditorActivity activity;
    private final ExecutorService renderExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicLong renderVersion = new AtomicLong(0);

    private View.OnClickListener priorOtherModuleFilterListener = null;

    // =========================================================================
    // প্যারামিটারসমূহ
    // =========================================================================
    // Basic: Tone (-400 to +400)
    public float exposure = 0f;
    public float contrast = 0f;
    public float highlights = 0f;
    public float shadows = 0f;
    public float whites = 0f;
    public float blacks = 0f;

    // Basic: White Balance (-400 to +400)
    public float temp = 0f;
    public float tint = 0f;

    // Basic: Presence (-400 to +400)
    public float texture = 0f;
    public float clarity = 0f;
    public float dehaze = 0f;
    public float vibrance = 0f;
    public float saturation = 0f;

    // Detail
    public float hdImage = 0f;          // স্ন্যাপসিড এইচডি ইমেজ কোয়ালিটি (0 to 400)
    public float faceSmooth = 0f;       // ফেস স্মুথিং (0 to 400)
    public float structure = 0f;        // স্ন্যাপসিড আসল স্ট্রাকচার (-400 to +400)
    public float sharpening = 0f;       // নয়েজ-মুক্ত শার্পেনিং (0 to 400)
    public float highTones = 0f;        // -400 to +400
    public float midTones = 0f;         // -400 to +400
    public float lowTones = 0f;         // -400 to +400
    public float protectShadows = 0f;   // 0 to 400
    public float protectHighlights = 0f;// 0 to 400
    public float noiseReduction = 0f;   // 0 to 400

    // Effects
    public float vignette = 0f;         // -400 to +400
    public float grain = 0f;            // 0 to 400

    // Interactive Curves
    private int activeCurveChannel = 0; // 0: RGB, 1: Red, 2: Green, 3: Blue
    public final List<List<PointF>> curvePoints = new ArrayList<>();
    private final int[][] curveLUT = new int[4][256];
    private CurveGraphView curveGraphViewInstance = null;
    private TextView btnDeleteCurvePoint = null;

    // HSL Color Mixer (-400 to +400)
    public float hueRed = 0f, satRed = 0f;
    public float hueOrange = 0f, satOrange = 0f;
    public float hueYellow = 0f;
    public float hueGreen = 0f;
    public float hueAqua = 0f;
    public float hueBlue = 0f, satBlue = 0f;
    public float huePurple = 0f;
    public float hueMagenta = 0f;

    // =========================================================================
    // আধুনিক ভেক্টর আইকন হেল্পারসমূহ (100% Vector Drawables)
    // =========================================================================
    public abstract static class BaseVectorDrawable extends Drawable {
        protected final int size;
        protected final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        protected final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public BaseVectorDrawable(int size, int color) {
            this.size = size;
            strokePaint.setColor(color);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(Math.max(1.8f, size * 0.09f));
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setStrokeJoin(Paint.Join.ROUND);

            fillPaint.setColor(color);
            fillPaint.setStyle(Paint.Style.FILL);
            setBounds(0, 0, size, size);
        }

        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void setAlpha(int alpha) {
            strokePaint.setAlpha(alpha);
            fillPaint.setAlpha(alpha);
        }
        @Override public void setColorFilter(ColorFilter colorFilter) {
            strokePaint.setColorFilter(colorFilter);
            fillPaint.setColorFilter(colorFilter);
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private Drawable createSaveVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float l = b.left + size * 0.15f;
                float t = b.top + size * 0.15f;
                float r = b.right - size * 0.15f;
                float bo = b.bottom - size * 0.15f;

                Path p = new Path();
                p.moveTo(l, bo);
                p.lineTo(l, t);
                p.lineTo(r - size * 0.2f, t);
                p.lineTo(r, t + size * 0.2f);
                p.lineTo(r, bo);
                p.close();
                canvas.drawPath(p, strokePaint);

                canvas.drawRect(l + size * 0.16f, t, r - size * 0.28f, t + size * 0.26f, fillPaint);
                canvas.drawRect(l + size * 0.16f, bo - size * 0.32f, r - size * 0.16f, bo, strokePaint);
            }
        };
    }

    private Drawable createUndoVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();

                Path arc = new Path();
                RectF oval = new RectF(cx - size * 0.30f, cy - size * 0.26f, cx + size * 0.32f, cy + size * 0.36f);
                arc.addArc(oval, 180, 200);
                canvas.drawPath(arc, strokePaint);

                float ax = cx - size * 0.30f;
                float ay = cy + size * 0.05f;
                Path arrow = new Path();
                arrow.moveTo(ax - size * 0.12f, ay - size * 0.08f);
                arrow.lineTo(ax, ay + size * 0.08f);
                arrow.lineTo(ax + size * 0.14f, ay - size * 0.04f);
                canvas.drawPath(arrow, strokePaint);
            }
        };
    }

    private Drawable createRedoVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();

                Path arc = new Path();
                RectF oval = new RectF(cx - size * 0.32f, cy - size * 0.26f, cx + size * 0.30f, cy + size * 0.36f);
                arc.addArc(oval, 0, -200);
                canvas.drawPath(arc, strokePaint);

                float ax = cx + size * 0.30f;
                float ay = cy + size * 0.05f;
                Path arrow = new Path();
                arrow.moveTo(ax - size * 0.14f, ay - size * 0.04f);
                arrow.lineTo(ax, ay + size * 0.08f);
                arrow.lineTo(ax + size * 0.12f, ay - size * 0.08f);
                canvas.drawPath(arrow, strokePaint);
            }
        };
    }

    private Drawable createResetVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();
                float r = size * 0.28f;

                RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
                Path path = new Path();
                path.addArc(oval, 40, 280);
                canvas.drawPath(path, strokePaint);

                float tipX = cx + r * (float) Math.cos(Math.toRadians(40));
                float tipY = cy + r * (float) Math.sin(Math.toRadians(40));
                Path arrow = new Path();
                arrow.moveTo(tipX - size * 0.06f, tipY - size * 0.14f);
                arrow.lineTo(tipX + size * 0.06f, tipY);
                arrow.lineTo(tipX - size * 0.12f, tipY + size * 0.06f);
                canvas.drawPath(arrow, strokePaint);
            }
        };
    }

    private Drawable createCloseVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float p = size * 0.25f;
                canvas.drawLine(b.left + p, b.top + p, b.right - p, b.bottom - p, strokePaint);
                canvas.drawLine(b.right - p, b.top + p, b.left + p, b.bottom - p, strokePaint);
            }
        };
    }

    private Drawable createFolderImportIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas canvas) {
                Rect b = getBounds();
                float l = b.left + size * 0.12f;
                float t = b.top + size * 0.20f;
                float r = b.right - size * 0.12f;
                float bo = b.bottom - size * 0.18f;

                Path p = new Path();
                p.moveTo(l, bo);
                p.lineTo(l, t);
                p.lineTo(l + size * 0.28f, t);
                p.lineTo(l + size * 0.38f, t + size * 0.12f);
                p.lineTo(r, t + size * 0.12f);
                p.lineTo(r, bo);
                p.close();
                canvas.drawPath(p, strokePaint);

                float cx = b.exactCenterX();
                float cy = b.exactCenterY() + size * 0.04f;
                canvas.drawLine(cx, cy + size * 0.18f, cx, cy - size * 0.10f, strokePaint);
                Path arrow = new Path();
                arrow.moveTo(cx - size * 0.10f, cy - size * 0.02f);
                arrow.lineTo(cx, cy - size * 0.12f);
                arrow.lineTo(cx + size * 0.10f, cy - size * 0.02f);
                canvas.drawPath(arrow, strokePaint);
            }
        };
    }

    // =========================================================================
    // প্রিসেট ডেটা স্ট্রাকচার
    // =========================================================================
    public static class FilterPresetItem {
        public String name;
        public String dateStr;
        public FilterStateSnapshot state;
        public Bitmap thumbnail;

        public FilterPresetItem(String name, FilterStateSnapshot state, Bitmap thumb) {
            this.name = name;
            this.state = state;
            this.thumbnail = thumb;
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            this.dateStr = sdf.format(new Date());
        }
    }

    private static final List<FilterPresetItem> savedPresetsList = new ArrayList<>();

    public static class FilterStateSnapshot {
        public float exp, con, hl, sh, wh, bl;
        public float temp, tint, text, clar, deh, vib, sat;
        public float hdImg, fSmooth, struct, sharp, hiT, midT, lowT, pSh, pHl, nRed;
        public float vig, gr;
        public float hRed, sRed, hOra, sOra, hYel, hGre, hAqu, hBlu, sBlu, hPur, hMag;
        public List<List<PointF>> snapCurvePoints = new ArrayList<>();

        public FilterStateSnapshot() {}

        public FilterStateSnapshot(editor_7 e) {
            this.exp = e.exposure; this.con = e.contrast; this.hl = e.highlights; this.sh = e.shadows; this.wh = e.whites; this.bl = e.blacks;
            this.temp = e.temp; this.tint = e.tint; this.text = e.texture; this.clar = e.clarity; this.deh = e.dehaze; this.vib = e.vibrance; this.sat = e.saturation;
            this.hdImg = e.hdImage; this.fSmooth = e.faceSmooth; this.struct = e.structure; this.sharp = e.sharpening;
            this.hiT = e.highTones; this.midT = e.midTones; this.lowT = e.lowTones; this.pSh = e.protectShadows; this.pHl = e.protectHighlights; this.nRed = e.noiseReduction;
            this.vig = e.vignette; this.gr = e.grain;
            this.hRed = e.hueRed; this.sRed = e.satRed; this.hOra = e.hueOrange; this.sOra = e.satOrange;
            this.hYel = e.hueYellow; this.hGre = e.hueGreen;
            this.hAqu = e.hueAqua; this.hBlu = e.hueBlue; this.sBlu = e.satBlue;
            this.hPur = e.huePurple; this.hMag = e.hueMagenta;

            for (int c = 0; c < 4; c++) {
                List<PointF> copy = new ArrayList<>();
                for (PointF pt : e.curvePoints.get(c)) {
                    copy.add(new PointF(pt.x, pt.y));
                }
                this.snapCurvePoints.add(copy);
            }
        }

        public void restore(editor_7 e) {
            e.exposure = this.exp; e.contrast = this.con; e.highlights = this.hl; e.shadows = this.sh; e.whites = this.wh; e.blacks = this.bl;
            e.temp = this.temp; e.tint = this.tint; e.texture = this.text; e.clarity = this.clar; e.dehaze = this.deh; e.vibrance = this.vib; e.saturation = this.sat;
            e.hdImage = this.hdImg; e.faceSmooth = this.fSmooth; e.structure = this.struct; e.sharpening = this.sharp;
            e.highTones = this.hiT; e.midTones = this.midT; e.lowTones = this.lowT; e.protectShadows = this.pSh; e.protectHighlights = this.pHl; e.noiseReduction = this.nRed;
            e.vignette = this.vig; e.grain = this.gr;
            e.hueRed = this.hRed; e.satRed = this.sRed; e.hueOrange = this.hOra; e.satOrange = this.sOra;
            e.hueYellow = this.hYel;
            e.hueGreen = this.hGre;
            e.hueAqua = this.hAqu;
            e.hueBlue = this.hBlu; e.satBlue = this.sBlu;
            e.huePurple = this.hPur;
            e.hueMagenta = this.hMag;

            if (this.snapCurvePoints != null) {
                for (int c = 0; c < Math.min(4, this.snapCurvePoints.size()); c++) {
                    e.curvePoints.get(c).clear();
                    for (PointF pt : this.snapCurvePoints.get(c)) {
                        e.curvePoints.get(c).add(new PointF(pt.x, pt.y));
                    }
                    e.recalculateCurveLUT(c);
                }
            }
        }

        public JSONObject toJson() {
            try {
                JSONObject obj = new JSONObject();
                obj.put("exp", (double) exp); obj.put("con", (double) con); obj.put("hl", (double) hl);
                obj.put("sh", (double) sh); obj.put("wh", (double) wh); obj.put("bl", (double) bl);
                obj.put("temp", (double) temp); obj.put("tint", (double) tint); obj.put("text", (double) text);
                obj.put("clar", (double) clar); obj.put("deh", (double) deh); obj.put("vib", (double) vib); obj.put("sat", (double) sat);
                obj.put("hdImg", (double) hdImg); obj.put("fSmooth", (double) fSmooth); obj.put("struct", (double) struct); obj.put("sharp", (double) sharp);
                obj.put("hiT", (double) hiT); obj.put("midT", (double) midT); obj.put("lowT", (double) lowT);
                obj.put("pSh", (double) pSh); obj.put("pHl", (double) pHl); obj.put("nRed", (double) nRed);
                obj.put("vig", (double) vig); obj.put("gr", (double) gr);
                obj.put("hRed", (double) hRed); obj.put("sRed", (double) sRed); obj.put("hOra", (double) hOra); obj.put("sOra", (double) sOra);
                obj.put("hYel", (double) hYel); obj.put("hGre", (double) hGre);
                obj.put("hAqu", (double) hAqu); obj.put("hBlu", (double) hBlu); obj.put("sBlu", (double) sBlu);
                obj.put("hPur", (double) hPur); obj.put("hMag", (double) hMag);

                JSONArray curvesArr = new JSONArray();
                for (List<PointF> pts : snapCurvePoints) {
                    JSONArray ptArr = new JSONArray();
                    for (PointF p : pts) {
                        JSONObject ptObj = new JSONObject();
                        ptObj.put("x", (double) p.x);
                        ptObj.put("y", (double) p.y);
                        ptArr.put(ptObj);
                    }
                    curvesArr.put(ptArr);
                }
                obj.put("curves", curvesArr);
                return obj;
            } catch (Exception e) {
                return new JSONObject();
            }
        }

        public static FilterStateSnapshot fromJson(JSONObject obj) {
            FilterStateSnapshot s = new FilterStateSnapshot();
            try {
                s.exp = (float) obj.optDouble("exp", 0); s.con = (float) obj.optDouble("con", 0); s.hl = (float) obj.optDouble("hl", 0);
                s.sh = (float) obj.optDouble("sh", 0); s.wh = (float) obj.optDouble("wh", 0); s.bl = (float) obj.optDouble("bl", 0);
                s.temp = (float) obj.optDouble("temp", 0); s.tint = (float) obj.optDouble("tint", 0); s.text = (float) obj.optDouble("text", 0);
                s.clar = (float) obj.optDouble("clar", 0); s.deh = (float) obj.optDouble("deh", 0); s.vib = (float) obj.optDouble("vib", 0); s.sat = (float) obj.optDouble("sat", 0);
                s.hdImg = (float) obj.optDouble("hdImg", 0); s.fSmooth = (float) obj.optDouble("fSmooth", 0); s.struct = (float) obj.optDouble("struct", 0); s.sharp = (float) obj.optDouble("sharp", 0);
                s.hiT = (float) obj.optDouble("hiT", 0); s.midT = (float) obj.optDouble("midT", 0); s.lowT = (float) obj.optDouble("lowT", 0);
                s.pSh = (float) obj.optDouble("pSh", 0); s.pHl = (float) obj.optDouble("pHl", 0); s.nRed = (float) obj.optDouble("nRed", 0);
                s.vig = (float) obj.optDouble("vig", 0); s.gr = (float) obj.optDouble("gr", 0);
                s.hRed = (float) obj.optDouble("hRed", 0); s.sRed = (float) obj.optDouble("sRed", 0); s.hOra = (float) obj.optDouble("hOra", 0); s.sOra = (float) obj.optDouble("sOra", 0);
                s.hYel = (float) obj.optDouble("hYel", 0); s.hGre = (float) obj.optDouble("hGre", 0);
                s.hAqu = (float) obj.optDouble("hAqu", 0); s.hBlu = (float) obj.optDouble("hBlu", 0); s.sBlu = (float) obj.optDouble("sBlu", 0);
                s.hPur = (float) obj.optDouble("hPur", 0); s.hMag = (float) obj.optDouble("hMag", 0);

                JSONArray curvesArr = obj.optJSONArray("curves");
                s.snapCurvePoints = new ArrayList<>();
                if (curvesArr != null) {
                    for (int c = 0; c < curvesArr.length(); c++) {
                        JSONArray ptArr = curvesArr.optJSONArray(c);
                        List<PointF> list = new ArrayList<>();
                        if (ptArr != null) {
                            for (int i = 0; i < ptArr.length(); i++) {
                                JSONObject po = ptArr.optJSONObject(i);
                                if (po != null) {
                                    list.add(new PointF((float) po.optDouble("x", 0), (float) po.optDouble("y", 0)));
                                }
                            }
                        }
                        s.snapCurvePoints.add(list);
                    }
                }
                while (s.snapCurvePoints.size() < 4) {
                    List<PointF> list = new ArrayList<>();
                    list.add(new PointF(0, 0));
                    list.add(new PointF(255, 255));
                    s.snapCurvePoints.add(list);
                }
            } catch (Exception ignored) {}
            return s;
        }
    }

    private final List<FilterStateSnapshot> dialogUndoStack = new ArrayList<>();
    private final List<FilterStateSnapshot> dialogRedoStack = new ArrayList<>();
    private Runnable activePanelRefresher = null;

    private Bitmap originalBitmap = null;
    private Bitmap previewSourceBmp = null;
    private Bitmap previewBitmap = null;
    private CameraRawPreviewView previewView = null;
    private boolean isSideBySide = false;

    private static final int REQ_CODE_IMPORT_PRESET = 7712;

    public static class PresetPickerFragment extends Fragment {
        private editor_7 module;

        public void setModule(editor_7 m) {
            this.module = m;
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQ_CODE_IMPORT_PRESET && resultCode == Activity.RESULT_OK && data != null) {
                if (module != null && data.getData() != null) {
                    module.importPresetFromUri(data.getData());
                }
            }
        }
    }

    @Override
    public void init(EditorActivity act) {
        this.activity = act;
        initCurvePoints();
        setupFilterMenuHook();
    }

    private void initCurvePoints() {
        curvePoints.clear();
        for (int c = 0; c < 4; c++) {
            List<PointF> pts = new ArrayList<>();
            pts.add(new PointF(0, 0));
            pts.add(new PointF(255, 255));
            curvePoints.add(pts);
            recalculateCurveLUT(c);
        }
    }

    @Override
    public void onCommand(String command, Object... args) {
        if ("open_camera_raw".equalsIgnoreCase(command)) {
            openCameraRawDialog();
        } else if (command != null && command.startsWith("filter_")) {
            executeDirectFilter(command.replace("filter_", ""));
        } else if ("on_activity_result".equalsIgnoreCase(command) && args.length >= 3) {
            handleActivityResult((int) args[0], (int) args[1], (Intent) args[2]);
        }
    }

    private int dp(float val) {
        if (activity == null) return (int) val;
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, activity.getResources().getDisplayMetrics());
    }

    private void recordDialogState() {
        dialogUndoStack.add(new FilterStateSnapshot(this));
        if (dialogUndoStack.size() > 30) dialogUndoStack.remove(0);
        dialogRedoStack.clear();
    }

    private void setupFilterMenuHook() {
        if (activity == null || activity.menuContainer == null) return;

        activity.runOnUiThread(() -> new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try {
                for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
                    View v = activity.menuContainer.getChildAt(i);
                    if (v instanceof TextView) {
                        TextView tv = (TextView) v;
                        if ("Filter".equalsIgnoreCase(tv.getText().toString().trim())) {
                            try {
                                Field listenerInfoField = Class.forName("android.view.View").getDeclaredField("mListenerInfo");
                                listenerInfoField.setAccessible(true);
                                Object myListenerInfo = listenerInfoField.get(tv);
                                if (myListenerInfo != null) {
                                    Field clickListenerField = Class.forName("android.view.View$ListenerInfo").getDeclaredField("mOnClickListener");
                                    clickListenerField.setAccessible(true);
                                    View.OnClickListener l = (View.OnClickListener) clickListenerField.get(myListenerInfo);
                                    if (l != null && priorOtherModuleFilterListener == null) {
                                        priorOtherModuleFilterListener = l;
                                    }
                                }
                            } catch (Exception ignored) {}

                            tv.setOnClickListener(activity.withFeedback(this::onFilterClicked));
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }, 600));
    }

    private void onFilterClicked(View anchor) {
        if (priorOtherModuleFilterListener != null) {
            priorOtherModuleFilterListener.onClick(anchor);
            mainHandler.postDelayed(() -> {
                boolean injected = injectCameraRawIntoTopWindow();
                if (!injected) {
                    mainHandler.postDelayed(() -> {
                        boolean retry = injectCameraRawIntoTopWindow();
                        if (!retry) {
                            showFilterDropdown(anchor);
                        }
                    }, 50);
                }
            }, 30);
        } else {
            showFilterDropdown(anchor);
        }
    }

    private boolean injectCameraRawIntoTopWindow() {
        try {
            Class<?> wmgClass = Class.forName("android.view.WindowManagerGlobal");
            Method getInstance = wmgClass.getMethod("getInstance");
            Object wmg = getInstance.invoke(null);
            Field mViewsField = wmgClass.getDeclaredField("mViews");
            mViewsField.setAccessible(true);
            List<View> views = (List<View>) mViewsField.get(wmg);
            if (views == null || views.isEmpty()) return false;

            View topDecor = views.get(views.size() - 1);
            if (topDecor == null) return false;

            ViewGroup menuLayout = findMenuContainer(topDecor);
            if (menuLayout != null) {
                for (int i = 0; i < menuLayout.getChildCount(); i++) {
                    View c = menuLayout.getChildAt(i);
                    if (c instanceof TextView && "Camera Raw Filter...".equalsIgnoreCase(((TextView) c).getText().toString().trim())) {
                        return true;
                    }
                }

                TextView crTv = new TextView(activity);
                crTv.setText("Camera Raw Filter...");
                crTv.setTextColor(Color.WHITE);
                crTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                crTv.setTypeface(null, Typeface.NORMAL);
                crTv.setPadding(dp(12), dp(8), dp(12), dp(8));

                crTv.setOnClickListener(activity.withFeedback(v -> {
                    dismissTopDecorView(topDecor);
                    openCameraRawDialog();
                }));

                menuLayout.addView(crTv, 0);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private ViewGroup findMenuContainer(View v) {
        if (v instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) v;
            if (vg instanceof LinearLayout && ((LinearLayout) vg).getOrientation() == LinearLayout.VERTICAL) {
                int count = 0;
                for (int i = 0; i < vg.getChildCount(); i++) {
                    if (vg.getChildAt(i) instanceof TextView || vg.getChildAt(i) instanceof Button) count++;
                }
                if (count >= 1) return vg;
            }
            if (vg instanceof ScrollView && vg.getChildCount() > 0) {
                View child = vg.getChildAt(0);
                if (child instanceof ViewGroup) {
                    ViewGroup res = findMenuContainer(child);
                    if (res != null) return res;
                }
            }
            for (int i = 0; i < vg.getChildCount(); i++) {
                ViewGroup res = findMenuContainer(vg.getChildAt(i));
                if (res != null) return res;
            }
        }
        return null;
    }

    private void dismissTopDecorView(View topDecor) {
        try {
            topDecor.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK));
            topDecor.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BACK));
        } catch (Exception ignored) {}
    }

    private void showFilterDropdown(View anchor) {
        String[] filters = {
                "Camera Raw Filter", "Filter Gallery", "Adaptive Wide Angle",
                "Lens Correction", "Liquify", "Vanishing Point", "Sharpen ▸",
                "Distort ▸", "Noise ▸", "Pixelate ▸", "Render ▸", "Stylize ▸"
        };

        final PopupWindow popup = new PopupWindow(activity);
        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(6), dp(6), dp(6), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        l.setBackground(bg);

        ScrollView sv = new ScrollView(activity);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout inner = new LinearLayout(activity);
        inner.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < filters.length; i++) {
            final int idx = i;
            final String item = filters[i];

            TextView itemTv = new TextView(activity);
            itemTv.setText(item);
            itemTv.setTextColor(Color.WHITE);
            itemTv.setTypeface(null, Typeface.NORMAL);
            itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            itemTv.setPadding(dp(14), dp(8), dp(18), dp(8));

            itemTv.setOnClickListener(activity.withFeedback(v -> {
                popup.dismiss();
                if (idx == 0) {
                    openCameraRawDialog();
                } else {
                    handleSpecificFilterClick(item, anchor);
                }
            }));
            inner.addView(itemTv);
        }

        sv.addView(inner);
        l.addView(sv);

        popup.setContentView(l);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        int maxH = (int) (activity.getResources().getDisplayMetrics().heightPixels * 0.70f);
        popup.setHeight(maxH);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    private void handleSpecificFilterClick(String filterName, View anchor) {
        String clean = filterName.replace("▸", "").replace("...", "").trim();
        activity.dispatchModuleCommand("filter_" + clean.toLowerCase());
        activity.dispatchModuleCommand(clean.toLowerCase());

        if (clean.contains("Sharpen")) {
            showSubFilterMenu("Sharpen Options", new String[]{"Sharpen (Standard)", "Sharpen More", "High Pass Edge Sharpen"}, this::applySharpenFilter);
        } else if (clean.contains("Filter Gallery")) {
            showSubFilterMenu("Filter Gallery", new String[]{"Posterize Effect", "Invert Colors", "Sepia Classic", "Monochrome Contrast", "Vivid Cyberpunk"}, this::applyArtisticFilter);
        } else if (clean.contains("Noise")) {
            showSubFilterMenu("Noise Options", new String[]{"Add Fine Grain (20%)", "Add Heavy Grain (45%)", "Film Grain Retro"}, this::applyNoiseFilter);
        } else if (clean.contains("Pixelate")) {
            showSubFilterMenu("Pixelate Options", new String[]{"Mosaic Grid (8px)", "Mosaic Grid (16px)", "Mosaic Grid (24px)", "Pixel Art (32px)"}, this::applyPixelateFilter);
        } else if (clean.contains("Stylize")) {
            showSubFilterMenu("Stylize Options", new String[]{"Find Glowing Edges", "Emboss Relief", "Solarize Hue"}, this::applyStylizeFilter);
        } else if (clean.contains("Render")) {
            showSubFilterMenu("Render Options", new String[]{"Soft Center Light", "Vignette Light Spotlight", "Golden Flare"}, this::applyRenderFilter);
        } else if (clean.contains("Liquify") || clean.contains("Distort") || clean.contains("Lens Correction") || clean.contains("Wide Angle") || clean.contains("Vanishing")) {
            showSubFilterMenu(clean, new String[]{"Spherical Warp", "Pinch Center", "Horizontal Ripple Wave"}, this::applyDistortFilter);
        } else {
            if (priorOtherModuleFilterListener != null) {
                try {
                    priorOtherModuleFilterListener.onClick(anchor);
                } catch (Exception ignored) {}
            }
        }
    }

    private void showSubFilterMenu(String title, String[] items, final FilterSubAction action) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E1E1E"));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        layout.setBackground(bg);

        TextView tvTitle = new TextView(activity);
        tvTitle.setText(title);
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setPadding(0, 0, 0, dp(10));
        layout.addView(tvTitle);

        for (final String item : items) {
            Button btn = new Button(activity);
            btn.setText(item);
            btn.setTextColor(Color.WHITE);
            btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            btn.setBackgroundColor(Color.parseColor("#262626"));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
            lp.setMargins(0, dp(3), 0, dp(3));
            btn.setLayoutParams(lp);
            btn.setOnClickListener(v -> {
                d.dismiss();
                if (action != null) action.onApply(item);
            });
            layout.addView(btn);
        }

        d.setContentView(layout);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(dp(270), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    interface FilterSubAction {
        void onApply(String type);
    }

    private File getEjitorDirectory() {
        File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File dirUpper = new File(downloadDir, "EJITOR");
        if (dirUpper.exists() && dirUpper.isDirectory()) return dirUpper;

        File dirLower = new File(downloadDir, "ejitor");
        if (dirLower.exists() && dirLower.isDirectory()) return dirLower;

        dirUpper.mkdirs();
        return dirUpper;
    }

    private void promptSavePresetDialog() {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1F1F1F"));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.parseColor("#383838"));
        layout.setBackground(bg);

        TextView tv = new TextView(activity);
        tv.setText("Save Current Preset");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(0, 0, 0, dp(10));
        layout.addView(tv);

        final EditText etName = new EditText(activity);
        String defaultName = "Preset " + (savedPresetsList.size() + 1);
        etName.setText(defaultName);
        etName.setSelection(defaultName.length());
        etName.setTextColor(Color.WHITE);
        etName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        etName.setSingleLine(true);
        etName.setPadding(dp(10), dp(8), dp(10), dp(8));

        GradientDrawable etBg = new GradientDrawable();
        etBg.setColor(Color.parseColor("#141414"));
        etBg.setCornerRadius(dp(4));
        etBg.setStroke(dp(1), Color.parseColor("#444444"));
        etName.setBackground(etBg);
        layout.addView(etName);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, 0);

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CANCEL (SAVE DEFAULT)");
        cancelBtn.setTextColor(Color.parseColor("#BBBBBB"));
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        setButtonBg(cancelBtn, "#2C2C2C");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(34), 1.2f);
        cancelBtn.setLayoutParams(clp);
        cancelBtn.setOnClickListener(v -> {
            commitSavePreset(defaultName);
            d.dismiss();
        });
        btnRow.addView(cancelBtn);

        View gap = new View(activity);
        gap.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        btnRow.addView(gap);

        Button saveBtn = new Button(activity);
        saveBtn.setText("SAVE");
        saveBtn.setTextColor(Color.WHITE);
        saveBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        saveBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(saveBtn, "#FF1238");
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, dp(34), 0.8f);
        saveBtn.setLayoutParams(slp);

        saveBtn.setOnClickListener(v -> {
            String typed = etName.getText().toString().trim();
            commitSavePreset(typed.isEmpty() ? defaultName : typed);
            d.dismiss();
        });
        btnRow.addView(saveBtn);

        layout.addView(btnRow);

        d.setContentView(layout);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    private void commitSavePreset(String presetName) {
        Bitmap thumb = null;
        if (previewBitmap != null && !previewBitmap.isRecycled()) {
            thumb = Bitmap.createScaledBitmap(previewBitmap, dp(54), dp(54), true);
        }
        savedPresetsList.add(new FilterPresetItem(presetName, new FilterStateSnapshot(this), thumb));
        Toast.makeText(activity, "Preset '" + presetName + "' Saved!", Toast.LENGTH_SHORT).show();
        if (activePanelRefresher != null) activePanelRefresher.run();
    }

    // =========================================================================
    // ক্যামেরা র ফিল্টার মেইন ডায়ালগ
    // =========================================================================
    public void openCameraRawDialog() {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) {
            Toast.makeText(activity, "Please select an image layer first", Toast.LENGTH_SHORT).show();
            return;
        }

        EditorActivity.LayerItem activeLayer = s.layers.get(s.activeLayerIndex);
        if (activeLayer.bitmap == null || activeLayer.bitmap.isRecycled()) {
            Toast.makeText(activity, "Layer has no image data", Toast.LENGTH_SHORT).show();
            return;
        }

        resetParameters();
        initCurvePoints();
        dialogUndoStack.clear();
        dialogRedoStack.clear();

        originalBitmap = activeLayer.bitmap;

        int maxDim = 1200;
        int origW = originalBitmap.getWidth();
        int origH = originalBitmap.getHeight();
        float scale = Math.min(1.0f, (float) maxDim / Math.max(origW, origH));
        int pW = Math.max(10, Math.round(origW * scale));
        int pH = Math.max(10, Math.round(origH * scale));

        previewSourceBmp = Bitmap.createScaledBitmap(originalBitmap, pW, pH, true);
        previewBitmap = previewSourceBmp.copy(Bitmap.Config.ARGB_8888, true);

        final Dialog rawDialog = new Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        rawDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        rawDialog.setOnDismissListener(d -> {
            if (previewSourceBmp != null && !previewSourceBmp.isRecycled()) {
                previewSourceBmp.recycle();
                previewSourceBmp = null;
            }
            if (previewBitmap != null && !previewBitmap.isRecycled()) {
                previewBitmap.recycle();
                previewBitmap = null;
            }
            if (previewView != null) {
                previewView.setBitmaps(null, null);
            }
            dialogUndoStack.clear();
            dialogRedoStack.clear();
        });

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#141414"));

        // ১. টপ টাইটেল বার
        LinearLayout topBar = new LinearLayout(activity);
        topBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        topBar.setBackgroundColor(Color.parseColor("#1C1C1C"));
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(12), 0, dp(12), 0);

        TextView titleTv = new TextView(activity);
        titleTv.setText("Camera Raw Filter - " + activeLayer.name);
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        titleTv.setTypeface(null, Typeface.BOLD);
        topBar.addView(titleTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // Save Preset Button
        final TextView btnSavePreset = new TextView(activity);
        btnSavePreset.setText("Save");
        btnSavePreset.setTextColor(Color.WHITE);
        btnSavePreset.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnSavePreset.setTypeface(null, Typeface.BOLD);
        btnSavePreset.setGravity(Gravity.CENTER);
        btnSavePreset.setPadding(dp(8), dp(6), dp(8), dp(6));
        btnSavePreset.setCompoundDrawablesWithIntrinsicBounds(createSaveVectorIcon(dp(13), Color.WHITE), null, null, null);
        btnSavePreset.setCompoundDrawablePadding(dp(5));
        setButtonBg(btnSavePreset, "#2A2A2A");
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        spLp.setMargins(0, 0, dp(6), 0);
        btnSavePreset.setLayoutParams(spLp);

        btnSavePreset.setOnClickListener(v -> promptSavePresetDialog());
        topBar.addView(btnSavePreset);

        // আধুনিক Undo বাটন
        final TextView btnUndo = new TextView(activity);
        btnUndo.setText("Undo");
        btnUndo.setTextColor(Color.WHITE);
        btnUndo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnUndo.setTypeface(null, Typeface.BOLD);
        btnUndo.setGravity(Gravity.CENTER);
        btnUndo.setPadding(dp(9), dp(6), dp(9), dp(6));
        btnUndo.setCompoundDrawablesWithIntrinsicBounds(createUndoVectorIcon(dp(13), Color.WHITE), null, null, null);
        btnUndo.setCompoundDrawablePadding(dp(5));
        setButtonBg(btnUndo, "#252525");
        LinearLayout.LayoutParams uLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        uLp.setMargins(0, 0, dp(6), 0);
        btnUndo.setLayoutParams(uLp);

        btnUndo.setOnClickListener(v -> {
            if (!dialogUndoStack.isEmpty()) {
                dialogRedoStack.add(new FilterStateSnapshot(this));
                FilterStateSnapshot snap = dialogUndoStack.remove(dialogUndoStack.size() - 1);
                snap.restore(this);
                if (curveGraphViewInstance != null) {
                    curveGraphViewInstance.invalidate();
                }
                if (activePanelRefresher != null) activePanelRefresher.run();
                scheduleRender();
                Toast.makeText(activity, "Undo", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(activity, "Nothing to undo", Toast.LENGTH_SHORT).show();
            }
        });
        topBar.addView(btnUndo);

        // আধুনিক Redo বাটন
        final TextView btnRedo = new TextView(activity);
        btnRedo.setText("Redo");
        btnRedo.setTextColor(Color.WHITE);
        btnRedo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnRedo.setTypeface(null, Typeface.BOLD);
        btnRedo.setGravity(Gravity.CENTER);
        btnRedo.setPadding(dp(9), dp(6), dp(9), dp(6));
        btnRedo.setCompoundDrawablesWithIntrinsicBounds(createRedoVectorIcon(dp(13), Color.WHITE), null, null, null);
        btnRedo.setCompoundDrawablePadding(dp(5));
        setButtonBg(btnRedo, "#252525");
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rLp.setMargins(0, 0, dp(8), 0);
        btnRedo.setLayoutParams(rLp);

        btnRedo.setOnClickListener(v -> {
            if (!dialogRedoStack.isEmpty()) {
                dialogUndoStack.add(new FilterStateSnapshot(this));
                FilterStateSnapshot snap = dialogRedoStack.remove(dialogRedoStack.size() - 1);
                snap.restore(this);
                if (curveGraphViewInstance != null) {
                    curveGraphViewInstance.invalidate();
                }
                if (activePanelRefresher != null) activePanelRefresher.run();
                scheduleRender();
                Toast.makeText(activity, "Redo", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(activity, "Nothing to redo", Toast.LENGTH_SHORT).show();
            }
        });
        topBar.addView(btnRedo);

        final TextView btnY = new TextView(activity);
        btnY.setText("Y (Before/After)");
        btnY.setTextColor(Color.WHITE);
        btnY.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnY.setTypeface(null, Typeface.BOLD);
        btnY.setPadding(dp(10), dp(6), dp(10), dp(6));
        setButtonBg(btnY, isSideBySide ? "#FF1238" : "#2E2E2E");

        btnY.setOnClickListener(v -> {
            isSideBySide = !isSideBySide;
            setButtonBg(btnY, isSideBySide ? "#FF1238" : "#2E2E2E");
            if (previewView != null) {
                previewView.setSideBySideMode(isSideBySide);
            }
        });
        topBar.addView(btnY);

        final TextView btnHoldOrig = new TextView(activity);
        btnHoldOrig.setText("Hold Original");
        btnHoldOrig.setTextColor(Color.WHITE);
        btnHoldOrig.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnHoldOrig.setTypeface(null, Typeface.BOLD);
        btnHoldOrig.setPadding(dp(10), dp(6), dp(10), dp(6));
        LinearLayout.LayoutParams holdLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        holdLp.setMargins(dp(8), 0, 0, 0);
        btnHoldOrig.setLayoutParams(holdLp);
        setButtonBg(btnHoldOrig, "#2E2E2E");

        btnHoldOrig.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    setButtonBg(btnHoldOrig, "#FF1238");
                    if (previewView != null) previewView.setShowingOriginal(true);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    setButtonBg(btnHoldOrig, "#2E2E2E");
                    if (previewView != null) previewView.setShowingOriginal(false);
                    return true;
            }
            return false;
        });
        topBar.addView(btnHoldOrig);

        root.addView(topBar);

        // ২. মেইন বডি
        LinearLayout body = new LinearLayout(activity);
        body.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        body.setOrientation(LinearLayout.HORIZONTAL);

        FrameLayout previewArea = new FrameLayout(activity);
        previewArea.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.25f));
        previewArea.setBackgroundColor(Color.parseColor("#101010"));

        previewView = new CameraRawPreviewView(activity);
        previewView.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        previewView.setBitmaps(previewSourceBmp, previewBitmap);
        previewArea.addView(previewView);

        body.addView(previewArea);

        LinearLayout controlDock = new LinearLayout(activity);
        controlDock.setLayoutParams(new LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.MATCH_PARENT));
        controlDock.setBackgroundColor(Color.parseColor("#1A1A1A"));
        controlDock.setOrientation(LinearLayout.VERTICAL);

        HorizontalScrollView tabScroll = new HorizontalScrollView(activity);
        tabScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        tabScroll.setBackgroundColor(Color.parseColor("#202020"));
        tabScroll.setHorizontalScrollBarEnabled(false);

        LinearLayout tabLayout = new LinearLayout(activity);
        tabLayout.setOrientation(LinearLayout.HORIZONTAL);

        final LinearLayout panelContainer = new LinearLayout(activity);
        panelContainer.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        panelContainer.setOrientation(LinearLayout.VERTICAL);

        ScrollView contentScroll = new ScrollView(activity);
        contentScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        contentScroll.setVerticalScrollBarEnabled(true);
        contentScroll.addView(panelContainer);

        final int[] currentTabIndex = {0};

        activePanelRefresher = () -> {
            panelContainer.removeAllViews();
            if (currentTabIndex[0] == 0) panelContainer.addView(buildBasicPanel());
            else if (currentTabIndex[0] == 1) panelContainer.addView(buildInteractiveCurvePanel());
            else if (currentTabIndex[0] == 2) panelContainer.addView(buildDetailPanel());
            else if (currentTabIndex[0] == 3) panelContainer.addView(buildHslPanel());
            else if (currentTabIndex[0] == 4) panelContainer.addView(buildEffectsPanel());
            else if (currentTabIndex[0] == 5) panelContainer.addView(buildPresetsPanel());
        };

        final TextView[] tabViews = new TextView[6];

        View.OnClickListener tabClickListener = v -> {
            for (int k = 0; k < tabViews.length; k++) {
                TextView tv = tabViews[k];
                if (tv != null) {
                    boolean isSel = (tv == v);
                    if (isSel) currentTabIndex[0] = k;
                    tv.setTextColor(isSel ? Color.WHITE : Color.parseColor("#888888"));
                    tv.setTypeface(null, isSel ? Typeface.BOLD : Typeface.NORMAL);
                }
            }
            if (activePanelRefresher != null) activePanelRefresher.run();
        };

        tabViews[0] = createCategoryTab("Basic", true, tabClickListener);
        tabViews[1] = createCategoryTab("Curve", false, tabClickListener);
        tabViews[2] = createCategoryTab("Detail", false, tabClickListener);
        tabViews[3] = createCategoryTab("Color Mixer (HSL)", false, tabClickListener);
        tabViews[4] = createCategoryTab("Effects", false, tabClickListener);
        tabViews[5] = createCategoryTab("Presets", false, tabClickListener);

        for (TextView tv : tabViews) tabLayout.addView(tv);

        tabScroll.addView(tabLayout);
        controlDock.addView(tabScroll);
        controlDock.addView(contentScroll);

        body.addView(controlDock);
        root.addView(body);

        activePanelRefresher.run();

        // ৩. নিচের বার
        LinearLayout bottomBar = new LinearLayout(activity);
        bottomBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        bottomBar.setBackgroundColor(Color.parseColor("#1E1E1E"));
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(dp(12), 0, dp(12), 0);

        Button resetBtn = new Button(activity);
        resetBtn.setText("RESET ALL");
        resetBtn.setTextColor(Color.parseColor("#DDDDDD"));
        resetBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(resetBtn, "#2C2C2C");
        resetBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(85), dp(32)));

        resetBtn.setOnClickListener(v -> {
            recordDialogState();
            resetParameters();
            initCurvePoints();
            currentTabIndex[0] = 0;
            for (int k = 0; k < tabViews.length; k++) {
                tabViews[k].setTextColor(k == 0 ? Color.WHITE : Color.parseColor("#888888"));
                tabViews[k].setTypeface(null, k == 0 ? Typeface.BOLD : Typeface.NORMAL);
            }
            if (activePanelRefresher != null) activePanelRefresher.run();

            previewBitmap = previewSourceBmp.copy(Bitmap.Config.ARGB_8888, true);
            if (previewView != null) {
                previewView.updateFilteredBitmap(previewBitmap);
            }
            Toast.makeText(activity, "All Parameters Reset to 0", Toast.LENGTH_SHORT).show();
        });
        bottomBar.addView(resetBtn);

        View fillGap = new View(activity);
        fillGap.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        bottomBar.addView(fillGap);

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CANCEL");
        cancelBtn.setTextColor(Color.WHITE);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(cancelBtn, "#333333");
        cancelBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(32)));
        cancelBtn.setOnClickListener(v -> rawDialog.dismiss());
        bottomBar.addView(cancelBtn);

        Button okBtn = new Button(activity);
        okBtn.setText("APPLY");
        okBtn.setTextColor(Color.WHITE);
        okBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        okBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(okBtn, "#FF1238");
        LinearLayout.LayoutParams okLp = new LinearLayout.LayoutParams(dp(85), dp(32));
        okLp.setMargins(dp(8), 0, 0, 0);
        okBtn.setLayoutParams(okLp);

        okBtn.setOnClickListener(v -> {
            Toast.makeText(activity, "Applying Camera Raw Filter to Canvas...", Toast.LENGTH_SHORT).show();
            renderExecutor.execute(() -> {
                Bitmap fullOut = processCameraRaw(originalBitmap);
                mainHandler.post(() -> {
                    applyFilterToActiveLayer(activeLayer, fullOut);
                    rawDialog.dismiss();
                });
            });
        });
        bottomBar.addView(okBtn);

        root.addView(bottomBar);

        rawDialog.setContentView(root);
        rawDialog.show();
    }

    private TextView createCategoryTab(String text, boolean active, View.OnClickListener listener) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(active ? Color.WHITE : Color.parseColor("#888888"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tv.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
        tv.setPadding(dp(14), dp(9), dp(14), dp(9));
        tv.setOnClickListener(listener);
        return tv;
    }

    private View buildBasicPanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        layout.addView(createSectionHeader("WHITE BALANCE"));
        layout.addView(createInteractiveSliderRow("Temperature", temp, -400, 400, val -> { temp = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Tint", tint, -400, 400, val -> { tint = val; scheduleRender(); }));

        layout.addView(createSectionHeader("TONE (SNAPSEED ENGINE)"));
        layout.addView(createInteractiveSliderRow("Exposure", exposure, -400, 400, val -> { exposure = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Contrast", contrast, -400, 400, val -> { contrast = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Highlights", highlights, -400, 400, val -> { highlights = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Shadows", shadows, -400, 400, val -> { shadows = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Whites", whites, -400, 400, val -> { whites = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Blacks", blacks, -400, 400, val -> { blacks = val; scheduleRender(); }));

        layout.addView(createSectionHeader("PRESENCE"));
        layout.addView(createInteractiveSliderRow("Texture", texture, -400, 400, val -> { texture = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Clarity", clarity, -400, 400, val -> { clarity = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Dehaze", dehaze, -400, 400, val -> { dehaze = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Vibrance", vibrance, -400, 400, val -> { vibrance = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Saturation", saturation, -400, 400, val -> { saturation = val; scheduleRender(); }));

        return layout;
    }

    private View buildInteractiveCurvePanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        layout.addView(createSectionHeader("RGB TONE CURVE GRAPH"));

        curveGraphViewInstance = new CurveGraphView(activity);
        LinearLayout.LayoutParams cvp = new LinearLayout.LayoutParams(dp(260), dp(240));
        cvp.gravity = Gravity.CENTER_HORIZONTAL;
        cvp.setMargins(0, dp(6), 0, dp(8));
        curveGraphViewInstance.setLayoutParams(cvp);
        layout.addView(curveGraphViewInstance);

        LinearLayout curveActionRow = new LinearLayout(activity);
        curveActionRow.setOrientation(LinearLayout.HORIZONTAL);
        curveActionRow.setGravity(Gravity.CENTER);
        curveActionRow.setPadding(0, 0, 0, dp(8));

        btnDeleteCurvePoint = new TextView(activity);
        btnDeleteCurvePoint.setText("Delete Point");
        btnDeleteCurvePoint.setTextColor(Color.WHITE);
        btnDeleteCurvePoint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnDeleteCurvePoint.setTypeface(null, Typeface.BOLD);
        btnDeleteCurvePoint.setGravity(Gravity.CENTER);
        btnDeleteCurvePoint.setPadding(dp(10), dp(6), dp(10), dp(6));
        btnDeleteCurvePoint.setCompoundDrawablesWithIntrinsicBounds(createCloseVectorIcon(dp(12), Color.WHITE), null, null, null);
        btnDeleteCurvePoint.setCompoundDrawablePadding(dp(4));
        setButtonBg(btnDeleteCurvePoint, "#3A3A3A");
        btnDeleteCurvePoint.setEnabled(false);
        btnDeleteCurvePoint.setAlpha(0.5f);

        btnDeleteCurvePoint.setOnClickListener(v -> {
            if (curveGraphViewInstance != null) {
                curveGraphViewInstance.deleteSelectedPoint();
            }
        });
        curveActionRow.addView(btnDeleteCurvePoint);

        TextView btnResetCurve = new TextView(activity);
        btnResetCurve.setText("Reset Channel");
        btnResetCurve.setTextColor(Color.WHITE);
        btnResetCurve.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnResetCurve.setTypeface(null, Typeface.BOLD);
        btnResetCurve.setGravity(Gravity.CENTER);
        btnResetCurve.setPadding(dp(10), dp(6), dp(10), dp(6));
        btnResetCurve.setCompoundDrawablesWithIntrinsicBounds(createResetVectorIcon(dp(13), Color.WHITE), null, null, null);
        btnResetCurve.setCompoundDrawablePadding(dp(4));
        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rLp.setMargins(dp(10), 0, 0, 0);
        btnResetCurve.setLayoutParams(rLp);
        setButtonBg(btnResetCurve, "#2C2C2C");

        btnResetCurve.setOnClickListener(v -> {
            recordDialogState();
            List<PointF> pts = curvePoints.get(activeCurveChannel);
            pts.clear();
            pts.add(new PointF(0, 0));
            pts.add(new PointF(255, 255));
            recalculateCurveLUT(activeCurveChannel);
            if (curveGraphViewInstance != null) {
                curveGraphViewInstance.selectedPointIdx = -1;
                curveGraphViewInstance.invalidate();
            }
            updateDeletePointButtonState(-1);
            scheduleRender();
            Toast.makeText(activity, "Channel Curve Reset", Toast.LENGTH_SHORT).show();
        });
        curveActionRow.addView(btnResetCurve);
        layout.addView(curveActionRow);

        layout.addView(createSectionHeader("SELECT CURVE COLOR (ROUND PICKERS)"));
        LinearLayout channelRow = new LinearLayout(activity);
        channelRow.setOrientation(LinearLayout.HORIZONTAL);
        channelRow.setGravity(Gravity.CENTER);
        channelRow.setPadding(0, dp(6), 0, dp(8));

        final View[] chCircles = new View[4];
        final int[] chColors = {Color.WHITE, Color.parseColor("#FF3B30"), Color.parseColor("#34C759"), Color.parseColor("#007AFF")};

        for (int i = 0; i < 4; i++) {
            final int chIdx = i;
            final FrameLayout circleContainer = new FrameLayout(activity);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
            lp.setMargins(dp(8), 0, dp(8), 0);
            circleContainer.setLayoutParams(lp);

            View circle = new View(activity);
            FrameLayout.LayoutParams cLp = new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER);
            circle.setLayoutParams(cLp);

            GradientDrawable oval = new GradientDrawable();
            oval.setShape(GradientDrawable.OVAL);
            oval.setColor(chColors[i]);
            circle.setBackground(oval);
            circleContainer.addView(circle);

            GradientDrawable ring = new GradientDrawable();
            ring.setShape(GradientDrawable.OVAL);
            ring.setColor(Color.TRANSPARENT);
            ring.setStroke(dp(2.5f), i == activeCurveChannel ? Color.WHITE : Color.TRANSPARENT);
            circleContainer.setBackground(ring);

            circleContainer.setOnClickListener(v -> {
                activeCurveChannel = chIdx;
                for (int j = 0; j < 4; j++) {
                    GradientDrawable r = (GradientDrawable) chCircles[j].getBackground();
                    r.setStroke(dp(2.5f), j == activeCurveChannel ? Color.WHITE : Color.TRANSPARENT);
                }
                if (curveGraphViewInstance != null) {
                    curveGraphViewInstance.selectedPointIdx = -1;
                    curveGraphViewInstance.invalidate();
                }
                updateDeletePointButtonState(-1);
            });

            chCircles[i] = circleContainer;
            channelRow.addView(circleContainer);
        }

        layout.addView(channelRow);
        return layout;
    }

    private void updateDeletePointButtonState(int selectedIndex) {
        if (btnDeleteCurvePoint == null) return;
        List<PointF> pts = curvePoints.get(activeCurveChannel);
        if (selectedIndex > 0 && selectedIndex < pts.size() - 1) {
            btnDeleteCurvePoint.setEnabled(true);
            btnDeleteCurvePoint.setAlpha(1.0f);
            setButtonBg(btnDeleteCurvePoint, "#FF1238");
        } else {
            btnDeleteCurvePoint.setEnabled(false);
            btnDeleteCurvePoint.setAlpha(0.45f);
            setButtonBg(btnDeleteCurvePoint, "#3A3A3A");
        }
    }

    private View buildDetailPanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        layout.addView(createSectionHeader("HD IMAGE RETOUCH (SNAPSEED STYLE)"));
        layout.addView(createInteractiveSliderRow("HD IMAGE", hdImage, 0, 400, val -> { hdImage = val; scheduleRender(); }));

        layout.addView(createSectionHeader("SKIN & FACE RETOUCH (SNAPSEED)"));
        layout.addView(createInteractiveSliderRow("Face Smooth", faceSmooth, 0, 400, val -> { faceSmooth = val; scheduleRender(); }));

        layout.addView(createSectionHeader("DETAILS (SNAPSEED STRUCTURE)"));
        layout.addView(createInteractiveSliderRow("Structure", structure, -400, 400, val -> { structure = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Sharpening", sharpening, 0, 400, val -> { sharpening = val; scheduleRender(); }));

        layout.addView(createSectionHeader("TONAL CONTRAST (SNAPSEED)"));
        layout.addView(createInteractiveSliderRow("High Tones", highTones, -400, 400, val -> { highTones = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Mid Tones", midTones, -400, 400, val -> { midTones = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Low Tones", lowTones, -400, 400, val -> { lowTones = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Protect Shadows", protectShadows, 0, 400, val -> { protectShadows = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Protect Highlights", protectHighlights, 0, 400, val -> { protectHighlights = val; scheduleRender(); }));

        layout.addView(createSectionHeader("NOISE REDUCTION"));
        layout.addView(createInteractiveSliderRow("Luminance Smoothing", noiseReduction, 0, 400, val -> { noiseReduction = val; scheduleRender(); }));

        return layout;
    }

    private View buildHslPanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        layout.addView(createSectionHeader("COLOR HUE ADJUSTMENTS"));
        layout.addView(createInteractiveSliderRow("Reds Hue", hueRed, -180, 180, val -> { hueRed = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Oranges Hue (Skin)", hueOrange, -180, 180, val -> { hueOrange = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Yellows Hue", hueYellow, -180, 180, val -> { hueYellow = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Greens Hue", hueGreen, -180, 180, val -> { hueGreen = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Blues Hue", hueBlue, -180, 180, val -> { hueBlue = val; scheduleRender(); }));

        layout.addView(createSectionHeader("COLOR SATURATION"));
        layout.addView(createInteractiveSliderRow("Red Saturation", satRed, -400, 400, val -> { satRed = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Orange Saturation", satOrange, -400, 400, val -> { satOrange = val; scheduleRender(); }));
        layout.addView(createInteractiveSliderRow("Blue Saturation", satBlue, -400, 400, val -> { satBlue = val; scheduleRender(); }));

        return layout;
    }

    private View buildEffectsPanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        layout.addView(createSectionHeader("SNAPSEED VIGNETTE"));
        layout.addView(createInteractiveSliderRow("Vignette Amount", vignette, -400, 400, val -> { vignette = val; scheduleRender(); }));

        layout.addView(createSectionHeader("FILM GRAIN"));
        layout.addView(createInteractiveSliderRow("Grain Amount", grain, 0, 400, val -> { grain = val; scheduleRender(); }));

        return layout;
    }

    private void openSystemFilePickerForPreset() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);

            FragmentManager fm = activity.getFragmentManager();
            PresetPickerFragment fragment = (PresetPickerFragment) fm.findFragmentByTag("ejitor_preset_picker");
            if (fragment == null) {
                fragment = new PresetPickerFragment();
                fm.beginTransaction().add(fragment, "ejitor_preset_picker").commitAllowingStateLoss();
                fm.executePendingTransactions();
            }
            fragment.setModule(this);

            fragment.startActivityForResult(Intent.createChooser(intent, "Select .jr Preset"), REQ_CODE_IMPORT_PRESET);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                activity.startActivityForResult(Intent.createChooser(intent, "Select .jr Preset"), REQ_CODE_IMPORT_PRESET);
            } catch (Exception err) {
                Toast.makeText(activity, "Cannot open file picker: " + err.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CODE_IMPORT_PRESET && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                importPresetFromUri(uri);
            }
        }
    }

    public void importPresetFromUri(Uri uri) {
        try {
            InputStream is = activity.getContentResolver().openInputStream(uri);
            if (is == null) {
                Toast.makeText(activity, "Could not open file", Toast.LENGTH_SHORT).show();
                return;
            }
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();
            is.close();

            JSONObject obj = new JSONObject(sb.toString());
            FilterStateSnapshot snap = FilterStateSnapshot.fromJson(obj);
            String pName = obj.optString("presetName", "Preset " + (savedPresetsList.size() + 1));

            recordDialogState();
            snap.restore(this);

            Bitmap thumb = null;
            if (previewSourceBmp != null && !previewSourceBmp.isRecycled()) {
                Bitmap rendered = processCameraRaw(previewSourceBmp);
                if (rendered != null) {
                    thumb = Bitmap.createScaledBitmap(rendered, dp(44), dp(44), true);
                }
            }

            savedPresetsList.add(new FilterPresetItem(pName, snap, thumb));

            if (curveGraphViewInstance != null) {
                curveGraphViewInstance.invalidate();
            }
            if (activePanelRefresher != null) {
                activePanelRefresher.run();
            }
            scheduleRender();

            Toast.makeText(activity, "Imported & Applied: " + pName, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Failed to import: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void exportPresetToFile(FilterPresetItem item) {
        try {
            File ejitorDir = getEjitorDirectory();

            int n = 1;
            File targetFile;
            while (true) {
                targetFile = new File(ejitorDir, "ejitor.preset" + n + ".jr");
                if (!targetFile.exists()) break;
                n++;
            }

            JSONObject json = item.state.toJson();
            json.put("presetName", item.name);
            json.put("savedDate", item.dateStr);

            FileOutputStream fos = new FileOutputStream(targetFile);
            fos.write(json.toString().getBytes("UTF-8"));
            fos.flush();
            fos.close();

            MediaScannerConnection.scanFile(
                    activity,
                    new String[]{targetFile.getAbsolutePath()},
                    null,
                    (path, uri) -> {}
            );

            Toast.makeText(activity, "Exported: " + targetFile.getName(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Export Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private View buildPresetsPanel() {
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(12), dp(8), dp(12), dp(14));

        LinearLayout topHeaderRow = new LinearLayout(activity);
        topHeaderRow.setOrientation(LinearLayout.HORIZONTAL);
        topHeaderRow.setGravity(Gravity.CENTER_VERTICAL);
        topHeaderRow.setPadding(0, 0, 0, dp(4));

        TextView tvTitle = createSectionHeader("MY SAVED PRESETS");
        topHeaderRow.addView(tvTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView importBtn = new TextView(activity);
        importBtn.setText("Import .jr");
        importBtn.setTextColor(Color.WHITE);
        importBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        importBtn.setTypeface(null, Typeface.BOLD);
        importBtn.setGravity(Gravity.CENTER);
        importBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
        importBtn.setCompoundDrawablesWithIntrinsicBounds(createFolderImportIcon(dp(13), Color.WHITE), null, null, null);
        importBtn.setCompoundDrawablePadding(dp(5));
        setButtonBg(importBtn, "#2C2C2C");
        LinearLayout.LayoutParams ipLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30));
        importBtn.setLayoutParams(ipLp);

        importBtn.setOnClickListener(v -> openSystemFilePickerForPreset());
        topHeaderRow.addView(importBtn);

        layout.addView(topHeaderRow);

        if (savedPresetsList.isEmpty()) {
            TextView emptyTv = new TextView(activity);
            emptyTv.setText("No saved presets yet.\nClick 'Save' on the top bar to save your current adjustments with image preview.");
            emptyTv.setTextColor(Color.parseColor("#777777"));
            emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            emptyTv.setPadding(0, dp(20), 0, dp(10));
            emptyTv.setGravity(Gravity.CENTER);
            layout.addView(emptyTv);
            return layout;
        }

        for (int i = 0; i < savedPresetsList.size(); i++) {
            final int idx = i;
            final FilterPresetItem pItem = savedPresetsList.get(i);

            LinearLayout card = new LinearLayout(activity);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(8), dp(8), dp(8), dp(8));
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.setMargins(0, dp(4), 0, dp(4));
            card.setLayoutParams(clp);

            GradientDrawable cardBg = new GradientDrawable();
            cardBg.setColor(Color.parseColor("#222222"));
            cardBg.setCornerRadius(dp(6));
            cardBg.setStroke(dp(1), Color.parseColor("#333333"));
            card.setBackground(cardBg);

            ImageView thumbView = new ImageView(activity);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(dp(44), dp(44));
            tvLp.setMargins(0, 0, dp(8), 0);
            thumbView.setLayoutParams(tvLp);
            thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);

            GradientDrawable thumbBg = new GradientDrawable();
            thumbBg.setCornerRadius(dp(5));
            thumbBg.setColor(Color.parseColor("#151515"));
            thumbView.setBackground(thumbBg);
            thumbView.setClipToOutline(true);

            if (pItem.thumbnail != null && !pItem.thumbnail.isRecycled()) {
                thumbView.setImageBitmap(pItem.thumbnail);
            } else {
                thumbView.setImageDrawable(createUndoVectorIcon(dp(18), Color.parseColor("#888888")));
            }
            card.addView(thumbView);

            LinearLayout infoLayout = new LinearLayout(activity);
            infoLayout.setOrientation(LinearLayout.VERTICAL);
            infoLayout.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView nameTv = new TextView(activity);
            nameTv.setText(pItem.name);
            nameTv.setTextColor(Color.WHITE);
            nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            nameTv.setTypeface(null, Typeface.BOLD);
            infoLayout.addView(nameTv);

            TextView timeTv = new TextView(activity);
            timeTv.setText("Saved at " + pItem.dateStr);
            timeTv.setTextColor(Color.parseColor("#888888"));
            timeTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8f);
            infoLayout.addView(timeTv);

            card.addView(infoLayout);

            TextView exportBtn = new TextView(activity);
            exportBtn.setText("Save");
            exportBtn.setTextColor(Color.WHITE);
            exportBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            exportBtn.setTypeface(null, Typeface.BOLD);
            exportBtn.setGravity(Gravity.CENTER);
            exportBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
            setButtonBg(exportBtn, "#333333");
            LinearLayout.LayoutParams expLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
            expLp.setMargins(0, 0, dp(5), 0);
            exportBtn.setLayoutParams(expLp);

            exportBtn.setOnClickListener(v -> exportPresetToFile(pItem));
            card.addView(exportBtn);

            TextView applyBtn = new TextView(activity);
            applyBtn.setText("Apply");
            applyBtn.setTextColor(Color.WHITE);
            applyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            applyBtn.setTypeface(null, Typeface.BOLD);
            applyBtn.setGravity(Gravity.CENTER);
            applyBtn.setPadding(dp(12), dp(6), dp(12), dp(6));
            setButtonBg(applyBtn, "#FF1238");
            LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
            apLp.setMargins(0, 0, dp(5), 0);
            applyBtn.setLayoutParams(apLp);

            applyBtn.setOnClickListener(v -> {
                recordDialogState();
                pItem.state.restore(this);
                if (curveGraphViewInstance != null) curveGraphViewInstance.invalidate();
                scheduleRender();
                Toast.makeText(activity, pItem.name + " Applied", Toast.LENGTH_SHORT).show();
            });
            card.addView(applyBtn);

            ImageView delBtn = new ImageView(activity);
            delBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
            delBtn.setImageDrawable(createCloseVectorIcon(dp(12), Color.parseColor("#FF5555")));
            delBtn.setPadding(dp(4), dp(4), dp(4), dp(4));

            delBtn.setOnClickListener(v -> {
                savedPresetsList.remove(idx);
                if (activePanelRefresher != null) activePanelRefresher.run();
                Toast.makeText(activity, "Preset Deleted", Toast.LENGTH_SHORT).show();
            });
            card.addView(delBtn);

            layout.addView(card);
        }

        return layout;
    }

    private TextView createSectionHeader(String title) {
        TextView tv = new TextView(activity);
        tv.setText(title);
        tv.setTextColor(Color.parseColor("#9E9E9E"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(0, dp(10), 0, dp(4));
        return tv;
    }

    interface OnValueChangeListener {
        void onChange(float value);
    }

    private LinearLayout createInteractiveSliderRow(final String label, float currentVal, final float min, final float max, final OnValueChangeListener listener) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(4), 0, dp(6));

        LinearLayout labelRow = new LinearLayout(activity);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        labelRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView lbl = new TextView(activity);
        lbl.setText(label);
        lbl.setTextColor(Color.parseColor("#D4D4D4"));
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        labelRow.addView(lbl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView valTv = new TextView(activity);
        valTv.setText(String.valueOf((int) currentVal));
        valTv.setTextColor(Color.WHITE);
        valTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        valTv.setTypeface(null, Typeface.BOLD);
        valTv.setPadding(dp(7), dp(2), dp(7), dp(2));

        GradientDrawable valBg = new GradientDrawable();
        valBg.setColor(Color.parseColor("#262626"));
        valBg.setCornerRadius(dp(3));
        valTv.setBackground(valBg);

        labelRow.addView(valTv);
        row.addView(labelRow);

        final SeekBar sb = new SeekBar(activity);
        sb.setMax((int) (max - min));
        sb.setProgress((int) (currentVal - min));

        applyCustomSeekBarStyle(sb);
        row.addView(sb);

        final float[] curValHolder = new float[]{currentVal};

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    float realVal = progress + min;
                    curValHolder[0] = realVal;
                    valTv.setText(String.valueOf((int) realVal));
                    if (listener != null) listener.onChange(realVal);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {
                recordDialogState();
            }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        valTv.setOnTouchListener(new View.OnTouchListener() {
            float downX = 0f;
            float startVal = 0f;
            boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        startVal = curValHolder[0];
                        isDragging = false;
                        valTv.setTextColor(Color.parseColor("#FF1238"));
                        recordDialogState();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dX = event.getRawX() - downX;
                        if (Math.abs(dX) > dp(2) || isDragging) {
                            isDragging = true;
                            float range = max - min;
                            float deltaVal = (dX / dp(180f)) * (range * 0.25f);
                            float newVal = Math.max(min, Math.min(max, startVal + deltaVal));
                            curValHolder[0] = newVal;
                            sb.setProgress((int) (newVal - min));
                            valTv.setText(String.valueOf((int) newVal));
                            if (listener != null) listener.onChange(newVal);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        valTv.setTextColor(Color.WHITE);
                        if (!isDragging) {
                            showCustomNumberKeypadDialog(valTv, label, (int) curValHolder[0], (int) min, (int) max, (newVal) -> {
                                curValHolder[0] = newVal;
                                sb.setProgress((int) (newVal - min));
                                valTv.setText(String.valueOf((int) newVal));
                                if (listener != null) listener.onChange(newVal);
                            });
                        }
                        return true;
                }
                return false;
            }
        });

        return row;
    }

    private void showCustomNumberKeypadDialog(View anchorView, String title, int current, final int min, final int max, final DirectInputCallback callback) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(14), dp(10), dp(14), dp(12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E1E1E"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.parseColor("#383838"));
        layout.setBackground(bg);

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(6));

        TextView tvTitle = new TextView(activity);
        tvTitle.setText(title + " [" + min + " .. " + max + "]");
        tvTitle.setTextColor(Color.parseColor("#CCCCCC"));
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(tvTitle);

        ImageView closeBtn = new ImageView(activity);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(20), dp(20)));
        closeBtn.setImageDrawable(createCloseVectorIcon(dp(14), Color.WHITE));
        closeBtn.setOnClickListener(v -> d.dismiss());
        header.addView(closeBtn);
        layout.addView(header);

        LinearLayout dispContainer = new LinearLayout(activity);
        dispContainer.setOrientation(LinearLayout.HORIZONTAL);
        dispContainer.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams dpLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
        dpLp.setMargins(0, dp(4), 0, dp(8));
        dispContainer.setLayoutParams(dpLp);

        final StringBuilder inputBuffer = new StringBuilder(String.valueOf(current));
        final TextView displayTv = new TextView(activity);
        displayTv.setText(inputBuffer.toString());
        displayTv.setTextColor(Color.WHITE);
        displayTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f);
        displayTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        displayTv.setGravity(Gravity.CENTER);

        GradientDrawable dispBg = new GradientDrawable();
        dispBg.setColor(Color.parseColor("#121212"));
        dispBg.setCornerRadius(dp(4));
        dispBg.setStroke(dp(1), Color.parseColor("#FF1238"));
        displayTv.setBackground(dispBg);
        displayTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        dispContainer.addView(displayTv);

        Button acBtn = new Button(activity);
        acBtn.setText("AC");
        acBtn.setTextColor(Color.WHITE);
        acBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        acBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(acBtn, "#FF1238");
        LinearLayout.LayoutParams acLp = new LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT);
        acLp.setMargins(dp(6), 0, 0, 0);
        acBtn.setLayoutParams(acLp);

        acBtn.setOnClickListener(v -> {
            inputBuffer.setLength(0);
            inputBuffer.append("0");
            displayTv.setText("0");
        });
        dispContainer.addView(acBtn);
        layout.addView(dispContainer);

        LinearLayout keypad = new LinearLayout(activity);
        keypad.setOrientation(LinearLayout.VERTICAL);

        String[][] keys = {
                {"1", "2", "3"},
                {"4", "5", "6"},
                {"7", "8", "9"},
                {"-", "0", "DEL"}
        };

        for (String[] row : keys) {
            LinearLayout rowLayout = new LinearLayout(activity);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setWeightSum(3);
            LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
            rLp.setMargins(0, dp(2), 0, dp(2));
            rowLayout.setLayoutParams(rLp);

            for (final String key : row) {
                Button keyBtn = new Button(activity);
                keyBtn.setText(key);
                keyBtn.setTextColor(Color.WHITE);
                keyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
                keyBtn.setTypeface(null, Typeface.BOLD);
                setButtonBg(keyBtn, "#2A2A2A");

                LinearLayout.LayoutParams kLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
                kLp.setMargins(dp(2), 0, dp(2), 0);
                keyBtn.setLayoutParams(kLp);

                keyBtn.setOnClickListener(v -> {
                    if ("DEL".equals(key)) {
                        if (inputBuffer.length() > 0) {
                            inputBuffer.deleteCharAt(inputBuffer.length() - 1);
                        }
                    } else if ("-".equals(key)) {
                        if (inputBuffer.length() > 0 && inputBuffer.charAt(0) == '-') {
                            inputBuffer.deleteCharAt(0);
                        } else {
                            inputBuffer.insert(0, "-");
                        }
                    } else {
                        if (inputBuffer.toString().equals("0")) {
                            inputBuffer.setLength(0);
                        }
                        if (inputBuffer.length() < 5) {
                            inputBuffer.append(key);
                        }
                    }

                    displayTv.setText(inputBuffer.length() == 0 ? "0" : inputBuffer.toString());
                });

                rowLayout.addView(keyBtn);
            }
            keypad.addView(rowLayout);
        }
        layout.addView(keypad);

        LinearLayout actRow = new LinearLayout(activity);
        actRow.setOrientation(LinearLayout.HORIZONTAL);
        actRow.setPadding(0, dp(8), 0, 0);

        Button cancel = new Button(activity);
        cancel.setText("CANCEL");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(cancel, "#383838");
        cancel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 1f));
        cancel.setOnClickListener(v -> d.dismiss());
        actRow.addView(cancel);

        View gap = new View(activity);
        gap.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        actRow.addView(gap);

        Button ok = new Button(activity);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        ok.setTypeface(null, Typeface.BOLD);
        setButtonBg(ok, "#FF1238");
        ok.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 1f));

        ok.setOnClickListener(v -> {
            try {
                String str = inputBuffer.toString();
                if (str.isEmpty() || str.equals("-")) str = "0";
                int val = Integer.parseInt(str);
                val = Math.max(min, Math.min(max, val));
                recordDialogState();
                if (callback != null) callback.onNumberEntered(val);
            } catch (Exception ignored) {}
            d.dismiss();
        });
        actRow.addView(ok);
        layout.addView(actRow);

        d.setContentView(layout);

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

            WindowManager.LayoutParams wmlp = d.getWindow().getAttributes();
            wmlp.gravity = Gravity.TOP | Gravity.START;

            int[] loc = new int[2];
            anchorView.getLocationOnScreen(loc);
            int anchorX = loc[0];
            int anchorY = loc[1];

            DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            int dialogW = dp(230);
            int dialogH = dp(270);

            int targetX = anchorX - dialogW + anchorView.getWidth();
            int targetY = anchorY + anchorView.getHeight() + dp(4);

            if (targetX < dp(8)) targetX = dp(8);
            if (targetX + dialogW > dm.widthPixels - dp(8)) targetX = dm.widthPixels - dialogW - dp(8);

            if (targetY + dialogH > dm.heightPixels - dp(8)) {
                targetY = anchorY - dialogH - dp(4);
            }
            if (targetY < dp(8)) targetY = dp(8);

            wmlp.x = targetX;
            wmlp.y = targetY;
            d.getWindow().setAttributes(wmlp);
        }
        d.show();
    }

    interface DirectInputCallback {
        void onNumberEntered(int value);
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(6), dp(6), dp(10));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(4));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(4));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }

    private void setButtonBg(View v, String colorHex) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(colorHex));
        d.setCornerRadius(dp(4));
        v.setBackground(d);
    }

    public class CurveGraphView extends View {
        private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint curveLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int selectedPointIdx = -1;

        public CurveGraphView(Context ctx) {
            super(ctx);
            gridPaint.setColor(Color.parseColor("#333333"));
            gridPaint.setStrokeWidth(dp(1));
            gridPaint.setStyle(Paint.Style.STROKE);

            curveLinePaint.setStrokeWidth(dp(2.2f));
            curveLinePaint.setStyle(Paint.Style.STROKE);

            pointFillPaint.setColor(Color.WHITE);
            pointFillPaint.setStyle(Paint.Style.FILL);

            pointStrokePaint.setColor(Color.BLACK);
            pointStrokePaint.setStrokeWidth(dp(1.5f));
            pointStrokePaint.setStyle(Paint.Style.STROKE);
        }

        public void deleteSelectedPoint() {
            List<PointF> pts = curvePoints.get(activeCurveChannel);
            if (selectedPointIdx > 0 && selectedPointIdx < pts.size() - 1) {
                recordDialogState();
                pts.remove(selectedPointIdx);
                selectedPointIdx = -1;
                recalculateCurveLUT(activeCurveChannel);
                updateDeletePointButtonState(-1);
                invalidate();
                scheduleRender();
                Toast.makeText(getContext(), "Point Deleted", Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            canvas.drawColor(Color.parseColor("#151515"));

            for (int i = 1; i < 4; i++) {
                float gx = (w / 4f) * i;
                float gy = (h / 4f) * i;
                canvas.drawLine(gx, 0, gx, h, gridPaint);
                canvas.drawLine(0, gy, w, gy, gridPaint);
            }
            canvas.drawRect(0, 0, w, h, gridPaint);

            int[] chColors = {Color.WHITE, Color.parseColor("#FF3B30"), Color.parseColor("#34C759"), Color.parseColor("#007AFF")};
            curveLinePaint.setColor(chColors[activeCurveChannel]);

            int[] lut = curveLUT[activeCurveChannel];
            Path curvePath = new Path();
            for (int x = 0; x < 256; x++) {
                float px = (x / 255f) * w;
                float py = h - ((lut[x] / 255f) * h);
                if (x == 0) curvePath.moveTo(px, py);
                else curvePath.lineTo(px, py);
            }
            canvas.drawPath(curvePath, curveLinePaint);

            List<PointF> pts = curvePoints.get(activeCurveChannel);
            float pointRad = dp(6.5f);
            for (int i = 0; i < pts.size(); i++) {
                PointF pt = pts.get(i);
                float px = (pt.x / 255f) * w;
                float py = h - ((pt.y / 255f) * h);
                pointFillPaint.setColor((i == selectedPointIdx) ? Color.parseColor("#FF1238") : Color.WHITE);
                canvas.drawCircle(px, py, pointRad, pointFillPaint);
                canvas.drawCircle(px, py, pointRad, pointStrokePaint);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return false;

            float touchX = Math.max(0, Math.min(w, event.getX()));
            float touchY = Math.max(0, Math.min(h, event.getY()));

            float dataX = (touchX / w) * 255f;
            float dataY = ((h - touchY) / h) * 255f;

            List<PointF> pts = curvePoints.get(activeCurveChannel);
            float hitRadius = dp(24);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    selectedPointIdx = -1;
                    for (int i = 0; i < pts.size(); i++) {
                        PointF pt = pts.get(i);
                        float px = (pt.x / 255f) * w;
                        float py = h - ((pt.y / 255f) * h);
                        if (Math.hypot(touchX - px, touchY - py) < hitRadius) {
                            selectedPointIdx = i;
                            break;
                        }
                    }

                    if (selectedPointIdx == -1 && pts.size() < 8) {
                        recordDialogState();
                        PointF newPt = new PointF(dataX, dataY);
                        pts.add(newPt);
                        Collections.sort(pts, Comparator.comparingDouble(p -> p.x));
                        selectedPointIdx = pts.indexOf(newPt);
                        recalculateCurveLUT(activeCurveChannel);
                        invalidate();
                        scheduleRender();
                    }
                    updateDeletePointButtonState(selectedPointIdx);
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    invalidate();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (selectedPointIdx != -1) {
                        PointF pt = pts.get(selectedPointIdx);
                        if (selectedPointIdx == 0) {
                            pt.x = 0;
                            pt.y = Math.max(0, Math.min(255, dataY));
                        } else if (selectedPointIdx == pts.size() - 1) {
                            pt.x = 255;
                            pt.y = Math.max(0, Math.min(255, dataY));
                        } else {
                            pt.x = Math.max(pts.get(selectedPointIdx - 1).x + 4, Math.min(pts.get(selectedPointIdx + 1).x - 4, dataX));
                            pt.y = Math.max(0, Math.min(255, dataY));
                        }
                        recalculateCurveLUT(activeCurveChannel);
                        invalidate();
                        scheduleRender();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    updateDeletePointButtonState(selectedPointIdx);
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                    return true;
            }
            return super.onTouchEvent(event);
        }
    }

    private void recalculateCurveLUT(int channel) {
        List<PointF> pts = curvePoints.get(channel);
        int[] lut = curveLUT[channel];
        int n = pts.size();
        if (n < 2) return;

        if (n == 2 && pts.get(0).x == 0 && pts.get(0).y == 0 && pts.get(1).x == 255 && pts.get(1).y == 255) {
            for (int x = 0; x < 256; x++) lut[x] = x;
            return;
        }

        float[] xVal = new float[n];
        float[] yVal = new float[n];
        for (int i = 0; i < n; i++) {
            xVal[i] = pts.get(i).x;
            yVal[i] = pts.get(i).y;
        }

        float[] dx = new float[n - 1];
        float[] dy = new float[n - 1];
        float[] slope = new float[n - 1];
        for (int i = 0; i < n - 1; i++) {
            dx[i] = xVal[i + 1] - xVal[i];
            dy[i] = yVal[i + 1] - yVal[i];
            slope[i] = (dx[i] == 0) ? 0 : dy[i] / dx[i];
        }

        float[] m = new float[n];
        m[0] = slope[0];
        for (int i = 1; i < n - 1; i++) {
            m[i] = (slope[i - 1] + slope[i]) / 2f;
        }
        m[n - 1] = slope[n - 2];

        for (int i = 0; i < n - 1; i++) {
            if (slope[i] == 0) {
                m[i] = 0;
                m[i + 1] = 0;
            } else {
                float a = m[i] / slope[i];
                float b = m[i + 1] / slope[i];
                float h = (float) Math.hypot(a, b);
                if (h > 3f) {
                    float t = 3f / h;
                    m[i] = t * a * slope[i];
                    m[i + 1] = t * b * slope[i];
                }
            }
        }

        int seg = 0;
        for (int x = 0; x < 256; x++) {
            if (x <= xVal[0]) {
                lut[x] = Math.max(0, Math.min(255, Math.round(yVal[0])));
                continue;
            }
            if (x >= xVal[n - 1]) {
                lut[x] = Math.max(0, Math.min(255, Math.round(yVal[n - 1])));
                continue;
            }
            while (seg < n - 2 && x > xVal[seg + 1]) {
                seg++;
            }
            float h = dx[seg];
            if (h == 0) {
                lut[x] = Math.max(0, Math.min(255, Math.round(yVal[seg])));
            } else {
                float t = (x - xVal[seg]) / h;
                float t2 = t * t;
                float t3 = t2 * t;
                float h00 = 2 * t3 - 3 * t2 + 1;
                float h10 = t3 - 2 * t2 + t;
                float h01 = -2 * t3 + 3 * t2;
                float h11 = t3 - t2;
                float y = h00 * yVal[seg] + h10 * h * m[seg] + h01 * yVal[seg + 1] + h11 * h * m[seg + 1];
                lut[x] = Math.max(0, Math.min(255, Math.round(y)));
            }
        }
    }

    public class CameraRawPreviewView extends View {
        private Bitmap originalBmp = null;
        private Bitmap filteredBmp = null;
        private boolean isSideBySideMode = false;
        private boolean isOriginalOnly = false;

        private float scale = 1.0f;
        private float panX = 0f, panY = 0f;
        private float lastTouchX, lastTouchY;
        private int activePointerId = -1;
        private final ScaleGestureDetector scaleDetector;

        private final Paint dividerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);

        public CameraRawPreviewView(Context ctx) {
            super(ctx);
            dividerPaint.setColor(Color.parseColor("#FF1238"));
            dividerPaint.setStrokeWidth(dp(2));

            badgeTextPaint.setColor(Color.WHITE);
            badgeTextPaint.setTextSize(dp(9.5f));
            badgeTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

            badgeBgPaint.setColor(Color.parseColor("#AA000000"));
            badgeBgPaint.setStyle(Paint.Style.FILL);

            scaleDetector = new ScaleGestureDetector(ctx, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override
                public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    float prevScale = scale;
                    scale *= factor;
                    scale = Math.max(0.2f, Math.min(scale, 10.0f));

                    float focusX = detector.getFocusX();
                    float focusY = detector.getFocusY();
                    panX = focusX - (focusX - panX) * (scale / prevScale);
                    panY = focusY - (focusY - panY) * (scale / prevScale);

                    invalidate();
                    return true;
                }
            });
        }

        public void setBitmaps(Bitmap orig, Bitmap filt) {
            this.originalBmp = orig;
            this.filteredBmp = filt;
            resetView();
            invalidate();
        }

        public void updateFilteredBitmap(Bitmap filt) {
            this.filteredBmp = filt;
            invalidate();
        }

        public void setSideBySideMode(boolean enabled) {
            this.isSideBySideMode = enabled;
            invalidate();
        }

        public void setShowingOriginal(boolean showOrig) {
            this.isOriginalOnly = showOrig;
            invalidate();
        }

        private void resetView() {
            scale = 1.0f;
            panX = 0f;
            panY = 0f;
        }

        private void drawCornerBadge(Canvas c, String text, float left, float top) {
            float textW = badgeTextPaint.measureText(text);
            float padX = dp(6);
            float padY = dp(3);
            RectF badgeRect = new RectF(left, top, left + textW + padX * 2, top + dp(14) + padY);
            c.drawRoundRect(badgeRect, dp(3), dp(3), badgeBgPaint);
            c.drawText(text, left + padX, top + dp(11), badgeTextPaint);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (originalBmp == null || originalBmp.isRecycled()) return;

            int viewW = getWidth();
            int viewH = getHeight();
            if (viewW <= 0 || viewH <= 0) return;

            canvas.save();
            canvas.translate(panX, panY);
            canvas.scale(scale, scale, viewW / 2f, viewH / 2f);

            if (isOriginalOnly) {
                float bW = originalBmp.getWidth();
                float bH = originalBmp.getHeight();
                float fitScale = Math.min((viewW * 0.92f) / bW, (viewH * 0.92f) / bH);
                float drawW = bW * fitScale;
                float drawH = bH * fitScale;
                float left = (viewW - drawW) / 2f;
                float top = (viewH - drawH) / 2f;

                canvas.drawBitmap(originalBmp, null, new RectF(left, top, left + drawW, top + drawH), paint);
                drawCornerBadge(canvas, "Original (Holding)", left + dp(6), top + dp(6));
                canvas.restore();
                return;
            }

            if (!isSideBySideMode) {
                Bitmap displayBmp = (filteredBmp != null) ? filteredBmp : originalBmp;
                float bW = displayBmp.getWidth();
                float bH = displayBmp.getHeight();
                float fitScale = Math.min((viewW * 0.92f) / bW, (viewH * 0.92f) / bH);
                float drawW = bW * fitScale;
                float drawH = bH * fitScale;
                float left = (viewW - drawW) / 2f;
                float top = (viewH - drawH) / 2f;

                canvas.drawBitmap(displayBmp, null, new RectF(left, top, left + drawW, top + drawH), paint);
            } else {
                float bW = originalBmp.getWidth();
                float bH = originalBmp.getHeight();
                float gap = dp(12);
                float totalWidthNeeded = (bW * 2) + gap;

                float fitScale = Math.min((viewW * 0.94f) / totalWidthNeeded, (viewH * 0.88f) / bH);
                float singleW = bW * fitScale;
                float drawH = bH * fitScale;

                float startLeft = (viewW - (singleW * 2 + gap)) / 2f;
                float top = (viewH - drawH) / 2f;

                RectF origRect = new RectF(startLeft, top, startLeft + singleW, top + drawH);
                canvas.drawBitmap(originalBmp, null, origRect, paint);
                drawCornerBadge(canvas, "Before", startLeft + dp(6), top + dp(6));

                float rightLeft = startLeft + singleW + gap;
                RectF filtRect = new RectF(rightLeft, top, rightLeft + singleW, top + drawH);
                Bitmap rightBmp = (filteredBmp != null) ? filteredBmp : originalBmp;
                canvas.drawBitmap(rightBmp, null, filtRect, paint);
                drawCornerBadge(canvas, "After", rightLeft + dp(6), top + dp(6));

                float divX = startLeft + singleW + (gap / 2f);
                canvas.drawLine(divX, top - dp(6), divX, top + drawH + dp(6), dividerPaint);
            }

            canvas.restore();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);

            int action = event.getActionMasked();
            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    activePointerId = event.getPointerId(0);
                    lastTouchX = event.getX();
                    lastTouchY = event.getY();
                    break;

                case MotionEvent.ACTION_MOVE:
                    if (!scaleDetector.isInProgress()) {
                        int pIdx = event.findPointerIndex(activePointerId);
                        if (pIdx >= 0) {
                            float x = event.getX(pIdx);
                            float y = event.getY(pIdx);
                            panX += (x - lastTouchX);
                            panY += (y - lastTouchY);
                            lastTouchX = x;
                            lastTouchY = y;
                            invalidate();
                        }
                    }
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    int pointerIndex = event.getActionIndex();
                    int pointerId = event.getPointerId(pointerIndex);
                    if (pointerId == activePointerId) {
                        int newIndex = (pointerIndex == 0) ? 1 : 0;
                        lastTouchX = event.getX(newIndex);
                        lastTouchY = event.getY(newIndex);
                        activePointerId = event.getPointerId(newIndex);
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activePointerId = -1;
                    break;
            }
            return true;
        }
    }

    public void resetParameters() {
        temp = 0f; tint = 0f; exposure = 0f; contrast = 0f; highlights = 0f; shadows = 0f;
        whites = 0f; blacks = 0f; texture = 0f; clarity = 0f; dehaze = 0f; vibrance = 0f; saturation = 0f;
        hdImage = 0f; faceSmooth = 0f; structure = 0f; sharpening = 0f; highTones = 0f; midTones = 0f; lowTones = 0f;
        protectShadows = 0f; protectHighlights = 0f; noiseReduction = 0f;
        vignette = 0f; grain = 0f;
        hueRed = 0f; hueOrange = 0f; hueYellow = 0f; hueGreen = 0f; hueAqua = 0f; hueBlue = 0f; huePurple = 0f; hueMagenta = 0f;
        satRed = 0f; satOrange = 0f; satBlue = 0f;
        isSideBySide = false;
    }

    private boolean isAllParametersZero() {
        return temp == 0f && tint == 0f && exposure == 0f && contrast == 0f && highlights == 0f && shadows == 0f
                && whites == 0f && blacks == 0f && texture == 0f && clarity == 0f && dehaze == 0f && vibrance == 0f
                && saturation == 0f && hdImage == 0f && faceSmooth == 0f && structure == 0f && sharpening == 0f && highTones == 0f
                && midTones == 0f && lowTones == 0f && protectShadows == 0f && protectHighlights == 0f && noiseReduction == 0f
                && vignette == 0f && grain == 0f && hueRed == 0f && hueOrange == 0f && hueBlue == 0f && satRed == 0f
                && satOrange == 0f && satBlue == 0f;
    }

    public void scheduleRender() {
        final long currentVersion = renderVersion.incrementAndGet();
        renderExecutor.execute(() -> {
            if (currentVersion != renderVersion.get()) return;
            if (previewSourceBmp == null || previewSourceBmp.isRecycled()) return;

            Bitmap out = processCameraRaw(previewSourceBmp);
            if (currentVersion != renderVersion.get()) return;

            mainHandler.post(() -> {
                if (currentVersion == renderVersion.get() && previewView != null && out != null) {
                    previewBitmap = out;
                    previewView.updateFilteredBitmap(previewBitmap);
                }
            });
        });
    }

    // ========================================================================================
    // স্ন্যাপসিড আসল স্ট্রাকচার ও এইচডি ইঞ্জিন
    // ========================================================================================
    public Bitmap processCameraRaw(Bitmap src) {
        if (src == null || src.isRecycled()) return null;

        if (isAllParametersZero() && isCurvesDefault()) {
            return src.copy(Bitmap.Config.ARGB_8888, true);
        }

        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        ColorMatrix cm = new ColorMatrix();

        if (exposure != 0f) {
            float expScale = (float) Math.pow(2.0, exposure / 150.0f);
            ColorMatrix expMat = new ColorMatrix(new float[]{
                    expScale, 0, 0, 0, 0,
                    0, expScale, 0, 0, 0,
                    0, 0, expScale, 0, 0,
                    0, 0, 0, 1, 0
            });
            cm.postConcat(expMat);
        }

        if (temp != 0f || tint != 0f || hueRed != 0f || hueBlue != 0f) {
            float rTemp = 1f + ((temp + hueRed) / 300f);
            float bTemp = 1f - ((temp - hueBlue) / 300f);
            float gTint = 1f - (tint / 350f);

            ColorMatrix wbMat = new ColorMatrix(new float[]{
                    rTemp, 0, 0, 0, 0,
                    0, gTint, 0, 0, 0,
                    0, 0, bTemp, 0, 0,
                    0, 0, 0, 1, 0
            });
            cm.postConcat(wbMat);
        }

        if (saturation != 0f || vibrance != 0f) {
            float totalSat = ((saturation + 100f) / 100f) * (1f + (vibrance / 200f));
            ColorMatrix satMat = new ColorMatrix();
            satMat.setSaturation(Math.max(0f, totalSat));
            cm.postConcat(satMat);
        }

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(src, 0, 0, paint);

        int[] pixels = new int[w * h];
        result.getPixels(pixels, 0, w, 0, 0, w, h);

        float hlFactor = (highlights / 400f) * 0.85f;
        float shFactor = (shadows / 400f) * 0.85f;
        float whFactor = (whites / 400f) * 60f;
        float blFactor = (blacks / 400f) * 60f;
        float conFactor = 1f + (contrast / 400f) * 1.2f;

        float clarityNorm = clarity / 100f;
        float dehazeNorm = dehaze / 100f;

        float hiTonesNorm = highTones / 100f;
        float midTonesNorm = midTones / 100f;
        float lowTonesNorm = lowTones / 100f;
        float protShadowsNorm = Math.min(1f, protectShadows / 100f);
        float protHighlightsNorm = Math.min(1f, protectHighlights / 100f);

        int[] rgbLUT = curveLUT[0];
        int[] rLUT = curveLUT[1];
        int[] gLUT = curveLUT[2];
        int[] bLUT = curveLUT[3];
        boolean applyCurves = !isCurvesDefault();

        for (int i = 0; i < pixels.length; i++) {
            int p = pixels[i];
            int a = (p >>> 24);
            if (a == 0) continue;

            int red = (p >> 16) & 0xFF;
            int green = (p >> 8) & 0xFF;
            int blue = p & 0xFF;

            if (applyCurves) {
                red = rLUT[rgbLUT[red]];
                green = gLUT[rgbLUT[green]];
                blue = bLUT[rgbLUT[blue]];
            }

            float lum = 0.299f * red + 0.587f * green + 0.114f * blue;
            float lumNorm = lum / 255.0f;

            float toneOffset = 0f;
            if (hlFactor != 0f) {
                float hlWeight = lumNorm * lumNorm;
                toneOffset += hlFactor * 255f * hlWeight * (1.0f - protHighlightsNorm * 0.7f);
            }
            if (shFactor != 0f) {
                float shWeight = (1.0f - lumNorm) * (1.0f - lumNorm);
                toneOffset += shFactor * 255f * shWeight * (1.0f - protShadowsNorm * 0.7f);
            }

            toneOffset += whFactor * lumNorm + blFactor * (1.0f - lumNorm);

            float r = (red - 128f) * conFactor + 128f + toneOffset;
            float g = (green - 128f) * conFactor + 128f + toneOffset;
            float b = (blue - 128f) * conFactor + 128f + toneOffset;

            if (hiTonesNorm != 0 && lum > 140f) {
                float factor = ((lum - 140f) / 115f) * hiTonesNorm * (1f - (protHighlightsNorm * 0.85f));
                r += (r - lum) * factor * 0.45f; g += (g - lum) * factor * 0.45f; b += (b - lum) * factor * 0.45f;
            }
            if (midTonesNorm != 0 && lum >= 50f && lum <= 205f) {
                float factor = (1f - Math.abs(lum - 128f) / 78f) * midTonesNorm;
                r += (r - lum) * factor * 0.50f; g += (g - lum) * factor * 0.50f; b += (b - lum) * factor * 0.50f;
            }
            if (lowTonesNorm != 0 && lum < 100f) {
                float factor = ((100f - lum) / 100f) * lowTonesNorm * (1f - (protShadowsNorm * 0.85f));
                r += (r - lum) * factor * 0.35f; g += (g - lum) * factor * 0.35f; b += (b - lum) * factor * 0.35f;
            }

            if (clarityNorm != 0) {
                float midDist = 1.0f - Math.abs(lum - 128f) / 128f;
                float diff = (lum - 128f) * clarityNorm * midDist * 0.75f;
                r += diff; g += diff; b += diff;
            }

            if (dehazeNorm != 0) {
                r = (r - 18f * dehazeNorm) * (1f + dehazeNorm * 0.28f);
                g = (g - 18f * dehazeNorm) * (1f + dehazeNorm * 0.28f);
                b = (b - 18f * dehazeNorm) * (1f + dehazeNorm * 0.28f);
            }

            pixels[i] = (a << 24) |
                    (Math.max(0, Math.min(255, (int) r)) << 16) |
                    (Math.max(0, Math.min(255, (int) g)) << 8) |
                    Math.max(0, Math.min(255, (int) b));
        }

        // ফেস স্মুথিং
        if (faceSmooth > 0) {
            float blend = Math.min(1.0f, faceSmooth / 180f);
            int radius = Math.min(4, Math.max(1, (int) (faceSmooth / 60)));
            int[] smoothOut = new int[w * h];

            for (int y = radius; y < h - radius; y++) {
                int yw = y * w;
                for (int x = radius; x < w - radius; x++) {
                    int c = pixels[yw + x];
                    if ((c >>> 24) == 0) {
                        smoothOut[yw + x] = 0;
                        continue;
                    }
                    int cR = (c >> 16) & 0xFF;
                    int cG = (c >> 8) & 0xFF;
                    int cB = c & 0xFF;

                    boolean isSkin = (cR > cG) && (cG > cB) && (cR - cG >= 12) && (cR > 45);
                    if (isSkin) {
                        int rSum = 0, gSum = 0, bSum = 0, cnt = 0;
                        for (int dy = -radius; dy <= radius; dy++) {
                            int row = (y + dy) * w;
                            for (int dx = -radius; dx <= radius; dx++) {
                                int n = pixels[row + x + dx];
                                if ((n >>> 24) == 0) continue;
                                int nR = (n >> 16) & 0xFF;
                                int nG = (n >> 8) & 0xFF;
                                int nB = n & 0xFF;

                                if (Math.abs(nR - cR) + Math.abs(nG - cG) < 45) {
                                    rSum += nR; gSum += nG; bSum += nB;
                                    cnt++;
                                }
                            }
                        }
                        if (cnt > 0) {
                            int fR = (int) (cR * (1f - blend) + (rSum / cnt) * blend);
                            int fG = (int) (cG * (1f - blend) + (gSum / cnt) * blend);
                            int fB = (int) (cB * (1f - blend) + (bSum / cnt) * blend);
                            smoothOut[yw + x] = (c & 0xFF000000) | (fR << 16) | (fG << 8) | fB;
                        } else {
                            smoothOut[yw + x] = c;
                        }
                    } else {
                        smoothOut[yw + x] = c;
                    }
                }
            }
            for (int y = radius; y < h - radius; y++) {
                System.arraycopy(smoothOut, y * w + radius, pixels, y * w + radius, w - (radius * 2));
            }
        }

        // স্ন্যাপসিড স্ট্রাকচার (এইচডি হাইলাইটস)
        if (hdImage > 0 || structure != 0 || texture != 0 || sharpening > 0) {
            float[] lum = new float[w * h];
            for (int i = 0; i < pixels.length; i++) {
                int c = pixels[i];
                if ((c >>> 24) == 0) {
                    lum[i] = 0;
                } else {
                    lum[i] = 0.299f * ((c >> 16) & 0xFF) + 0.587f * ((c >> 8) & 0xFF) + 0.114f * (c & 0xFF);
                }
            }

            float[] blurFine = new float[w * h];
            float[] blurCoarse = new float[w * h];
            boxBlurFloat(lum, blurFine, w, h, 2);
            boxBlurFloat(lum, blurCoarse, w, h, 6);

            float sAmount = (structure / 400f) * 1.15f;
            float tAmount = (texture / 400f) * 0.75f;
            float hdAmount = (hdImage / 400f) * 1.10f;
            float sharpScale = (sharpening / 400f) * 0.65f;

            for (int i = 0; i < pixels.length; i++) {
                int c = pixels[i];
                int a = (c >>> 24);
                if (a == 0) continue;

                int cR = (c >> 16) & 0xFF;
                int cG = (c >> 8) & 0xFF;
                int cB = c & 0xFF;

                float lVal = lum[i];
                float fineDetail = lVal - blurFine[i];
                float coarseDetail = blurFine[i] - blurCoarse[i];

                float rawDelta = (fineDetail * 1.35f + coarseDetail * 0.85f) * (sAmount + tAmount + hdAmount);
                float compressedDelta = (float) (Math.tanh(rawDelta / 45.0) * 45.0);

                float sharpDelta = 0f;
                if (sharpScale > 0 && Math.abs(fineDetail) > 1.2f) {
                    sharpDelta = (float) (Math.tanh(fineDetail / 35.0) * 35.0) * sharpScale;
                }

                float highlightBoost = 0f;
                if (lVal > 120f && (structure > 0 || hdImage > 0)) {
                    float hlRatio = (lVal - 120f) / 135f;
                    highlightBoost = hlRatio * ((structure + hdImage) / 400f) * 22f;
                }

                float finalL = lVal + compressedDelta + sharpDelta + highlightBoost;
                finalL = Math.max(0f, Math.min(255f, finalL));

                float colorRatio = (lVal > 5f) ? (finalL / lVal) : 1.0f;

                int nR = Math.max(0, Math.min(255, Math.round(cR * colorRatio)));
                int nG = Math.max(0, Math.min(255, Math.round(cG * colorRatio)));
                int nB = Math.max(0, Math.min(255, Math.round(cB * colorRatio)));

                pixels[i] = (a << 24) | (nR << 16) | (nG << 8) | nB;
            }
        }

        // নয়েজ রিডাকশন
        if (noiseReduction > 0) {
            int radius = Math.min(3, Math.max(1, (int) (noiseReduction / 80)));
            int[] blurOut = new int[w * h];

            for (int y = radius; y < h - radius; y++) {
                int yw = y * w;
                for (int x = radius; x < w - radius; x++) {
                    int center = pixels[yw + x];
                    if ((center >>> 24) == 0) continue;
                    int cR = (center >> 16) & 0xFF;
                    int cG = (center >> 8) & 0xFF;
                    int cB = center & 0xFF;

                    int rSum = 0, gSum = 0, bSum = 0, count = 0;
                    for (int dy = -radius; dy <= radius; dy++) {
                        int row = (y + dy) * w;
                        for (int dx = -radius; dx <= radius; dx++) {
                            int neighbor = pixels[row + x + dx];
                            if ((neighbor >>> 24) == 0) continue;
                            int nR = (neighbor >> 16) & 0xFF;
                            int nG = (neighbor >> 8) & 0xFF;
                            int nB = neighbor & 0xFF;

                            if (Math.abs(nR - cR) + Math.abs(nG - cG) < 60) {
                                rSum += nR; gSum += nG; bSum += nB;
                                count++;
                            }
                        }
                    }

                    if (count > 0) {
                        float blend = Math.min(1.0f, noiseReduction / 250f);
                        int smoothR = (int) (cR * (1f - blend) + (rSum / count) * blend);
                        int smoothG = (int) (cG * (1f - blend) + (gSum / count) * blend);
                        int smoothB = (int) (cB * (1f - blend) + (bSum / count) * blend);
                        blurOut[yw + x] = (center & 0xFF000000) | (smoothR << 16) | (smoothG << 8) | smoothB;
                    } else {
                        blurOut[yw + x] = center;
                    }
                }
            }
            for (int y = radius; y < h - radius; y++) {
                System.arraycopy(blurOut, y * w + radius, pixels, y * w + radius, w - (radius * 2));
            }
        }

        result.setPixels(pixels, 0, w, 0, 0, w, h);

        if (vignette != 0) {
            Paint vigPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
            float cx = w / 2f;
            float cy = h / 2f;
            float radius = (float) Math.hypot(cx, cy);

            int vigColor = (vignette < 0) ? Color.BLACK : Color.WHITE;
            int vigAlpha = (int) (Math.abs(vignette) * 0.65f);
            vigAlpha = Math.min(255, Math.max(0, vigAlpha));

            RadialGradient grad = new RadialGradient(cx, cy, radius,
                    new int[]{Color.TRANSPARENT, Color.argb(vigAlpha, Color.red(vigColor), Color.green(vigColor), Color.blue(vigColor))},
                    new float[]{0.35f, 1.0f}, Shader.TileMode.CLAMP);

            vigPaint.setShader(grad);
            canvas.drawRect(0, 0, w, h, vigPaint);
        }

        if (grain > 0) {
            Random rnd = new Random();
            int grainCount = (int) ((w * h) * (grain / 300f));
            Paint gp = new Paint();
            gp.setColor(Color.WHITE);
            gp.setAlpha((int) (Math.min(255, grain * 0.65f)));
            for (int k = 0; k < grainCount; k++) {
                float gx = rnd.nextFloat() * w;
                float gy = rnd.nextFloat() * h;
                canvas.drawPoint(gx, gy, gp);
            }
        }

        return result;
    }

    private void boxBlurFloat(float[] src, float[] dst, int w, int h, int r) {
        float[] temp = new float[w * h];
        float div = 2 * r + 1;

        for (int y = 0; y < h; y++) {
            int row = y * w;
            float sum = (r + 1) * src[row];
            for (int i = 1; i <= r; i++) {
                sum += src[row + Math.min(w - 1, i)];
            }
            for (int x = 0; x < w; x++) {
                temp[row + x] = sum / div;
                int xL = Math.max(0, x - r);
                int xR = Math.min(w - 1, x + r + 1);
                sum += src[row + xR] - src[row + xL];
            }
        }

        for (int x = 0; x < w; x++) {
            float sum = (r + 1) * temp[x];
            for (int i = 1; i <= r; i++) {
                sum += temp[Math.min(h - 1, i) * w + x];
            }
            for (int y = 0; y < h; y++) {
                dst[y * w + x] = sum / div;
                int yT = Math.max(0, y - r);
                int yB = Math.min(h - 1, y + r + 1);
                sum += temp[yB * w + x] - temp[yT * w + x];
            }
        }
    }

    private boolean isCurvesDefault() {
        for (int c = 0; c < 4; c++) {
            List<PointF> pts = curvePoints.get(c);
            if (pts.size() != 2 || pts.get(0).x != 0 || pts.get(0).y != 0 || pts.get(1).x != 255 || pts.get(1).y != 255) {
                return false;
            }
        }
        return true;
    }

    private void applySharpenFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        Bitmap src = layer.bitmap;
        Bitmap res = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(res);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float boost = type.contains("More") ? 1.5f : 1.25f;
        ColorMatrix cm = new ColorMatrix(new float[]{
                boost, 0, 0, 0, -25,
                0, boost, 0, 0, -25,
                0, 0, boost, 0, -25,
                0, 0, 0, 1, 0
        });
        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src, 0, 0, p);

        applyFilterToActiveLayer(layer, res);
    }

    private void applyArtisticFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        Bitmap src = layer.bitmap;
        Bitmap res = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(res);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        ColorMatrix cm = new ColorMatrix();
        if (type.contains("Invert")) {
            cm.set(new float[]{
                    -1, 0, 0, 0, 255,
                    0, -1, 0, 0, 255,
                    0, 0, -1, 0, 255,
                    0, 0, 0, 1, 0
            });
        } else if (type.contains("Sepia")) {
            cm.set(new float[]{
                    0.393f, 0.769f, 0.189f, 0, 0,
                    0.349f, 0.686f, 0.168f, 0, 0,
                    0.272f, 0.534f, 0.131f, 0, 0,
                    0, 0, 0, 1, 0
            });
        } else if (type.contains("Monochrome")) {
            cm.setSaturation(0);
        } else {
            cm.setSaturation(1.9f);
        }

        p.setColorFilter(new ColorMatrixColorFilter(cm));
        c.drawBitmap(src, 0, 0, p);
        applyFilterToActiveLayer(layer, res);
    }

    private void applyNoiseFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        Bitmap src = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Random r = new Random();
        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        int amount = type.contains("Heavy") ? 55 : 30;
        for (int i = 0; i < pixels.length; i += 2) {
            int noise = r.nextInt(amount * 2) - amount;
            int col = pixels[i];
            int red = Math.max(0, Math.min(255, Color.red(col) + noise));
            int green = Math.max(0, Math.min(255, Color.green(col) + noise));
            int blue = Math.max(0, Math.min(255, Color.blue(col) + noise));
            pixels[i] = Color.argb(Color.alpha(col), red, green, blue);
        }
        src.setPixels(pixels, 0, w, 0, 0, w, h);
        applyFilterToActiveLayer(layer, src);
    }

    private void applyPixelateFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        int blockSize = 16;
        if (type.contains("8px")) blockSize = 8;
        else if (type.contains("24px")) blockSize = 24;
        else if (type.contains("32px")) blockSize = 32;

        Bitmap src = layer.bitmap;
        int w = src.getWidth();
        int h = src.getHeight();
        int downW = Math.max(1, w / blockSize);
        int downH = Math.max(1, h / blockSize);

        Bitmap small = Bitmap.createScaledBitmap(src, downW, downH, false);
        Bitmap pixelated = Bitmap.createScaledBitmap(small, w, h, false);
        applyFilterToActiveLayer(layer, pixelated);
    }

    private void applyStylizeFilter(String type) {
        applyArtisticFilter(type);
    }

    private void applyRenderFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        Bitmap src = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(src);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        RadialGradient rg = new RadialGradient(src.getWidth() / 2f, src.getHeight() / 2f,
                Math.max(src.getWidth(), src.getHeight()) / 2f,
                new int[]{Color.argb(130, 255, 255, 255), Color.TRANSPARENT},
                new float[]{0.0f, 1.0f}, Shader.TileMode.CLAMP);
        p.setShader(rg);
        c.drawRect(0, 0, src.getWidth(), src.getHeight(), p);

        applyFilterToActiveLayer(layer, src);
    }

    private void applyDistortFilter(String type) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        Bitmap src = layer.bitmap;
        int w = src.getWidth();
        int h = src.getHeight();
        Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);

        int[] srcPixels = new int[w * h];
        int[] dstPixels = new int[w * h];
        src.getPixels(srcPixels, 0, w, 0, 0, w, h);

        float cx = w / 2f;
        float cy = h / 2f;
        float maxR = Math.min(cx, cy);

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float dx = x - cx;
                float dy = y - cy;
                float dist = (float) Math.hypot(dx, dy);

                if (dist < maxR) {
                    float rNorm = dist / maxR;
                    float factor;
                    if (type.contains("Pinch")) {
                        factor = (float) Math.pow(rNorm, 0.55);
                    } else if (type.contains("Ripple")) {
                        factor = 1.0f + 0.05f * (float) Math.sin(dist / 9.0f);
                    } else {
                        factor = (float) Math.sin(rNorm * Math.PI / 2.0);
                    }

                    float srcX = cx + dx * factor;
                    float srcY = cy + dy * factor;
                    int sx = Math.max(0, Math.min(w - 1, (int) srcX));
                    int sy = Math.max(0, Math.min(h - 1, (int) srcY));
                    dstPixels[y * w + x] = srcPixels[sy * w + sx];
                } else {
                    dstPixels[y * w + x] = srcPixels[y * w + x];
                }
            }
        }

        res.setPixels(dstPixels, 0, w, 0, 0, w, h);
        applyFilterToActiveLayer(layer, res);
    }

    private void executeDirectFilter(String type) {
        if ("sharpen".equalsIgnoreCase(type)) applySharpenFilter("Sharpen");
        else if ("noise".equalsIgnoreCase(type)) applyNoiseFilter("Add Fine Grain");
        else if ("pixelate".equalsIgnoreCase(type)) applyPixelateFilter("Mosaic Grid (16px)");
    }

    private void applyFilterToActiveLayer(EditorActivity.LayerItem layer, Bitmap finalBmp) {
        if (finalBmp == null) return;
        layer.bitmap = finalBmp;
        layer.isDirty = true;
        activity.recordHistory();
        activity.notifyProjectModified();

        try {
            Field canvasViewField = activity.getClass().getDeclaredField("canvasView");
            canvasViewField.setAccessible(true);
            View canvasV = (View) canvasViewField.get(activity);
            if (canvasV != null) canvasV.invalidate();
        } catch (Exception ignored) {}

        Toast.makeText(activity, "Camera Raw Filter Applied", Toast.LENGTH_SHORT).show();
    }
}
