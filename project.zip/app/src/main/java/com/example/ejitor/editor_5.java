package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public class editor_5 {

    private EditorActivity activity;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface OnColorChangeListener {
        void onColorChange(int color);
    }

    public interface OnHueChangeListener {
        void onHueChanged(float hue, float satVal);
    }

    public interface OnSliderChangeListener {
        void onProgressChanged(float progress);
    }

    public interface OnColorPickListener {
        void onColorPicked(int color);
    }

    public interface OnNumericInputListener {
        void onValueSubmitted(float value);
    }

    public interface OnTextInputListener {
        void onTextUpdated(String text);
    }

    // টেক্সট কনফিগারেশন স্টেট
    private String currentText = "ejitor";
    private float currentTextSize = 64f;
    private float currentLetterSpacing = 0f;
    private int currentTextColor = Color.WHITE;
    private boolean isBold = false;
    private boolean isItalic = false;
    private boolean isShiftEnabled = false;

    // গ্রেডিয়েন্ট টেক্সট স্টেট
    private boolean isGradientText = false;
    private int gradientAngle = 0; // 0 - 360
    private int gradientSpacing = 100;
    private final List<Integer> currentGradStops = new ArrayList<>();
    private final List<Float> currentGradPositions = new ArrayList<>();

    // ভেক্টর-শার্প কোয়ালিটি ও ফন্ট/কালার/স্পেসিং মেটাডাটা
    public static class TextLayerMeta {
        public String text;
        public float baseSize;
        public float letterSpacing;
        public int color;
        public Typeface font;
        public boolean bold;
        public boolean italic;
        public boolean isGrad;
        public int gradAngle = 0;
        public int gradSpacing = 100;
        public List<Integer> gradColors = new ArrayList<>();
        public List<Float> gradPositions = new ArrayList<>();

        public TextLayerMeta(String text, float size, float spacing, int color, Typeface font, boolean bold, boolean italic, boolean isGrad, int angle, int gSpacing, List<Integer> gColors, List<Float> gPositions) {
            this.text = text;
            this.baseSize = size;
            this.letterSpacing = spacing;
            this.color = color;
            this.font = font;
            this.bold = bold;
            this.italic = italic;
            this.isGrad = isGrad;
            this.gradAngle = angle;
            this.gradSpacing = gSpacing;
            if (gColors != null && !gColors.isEmpty()) {
                this.gradColors.addAll(gColors);
            } else {
                this.gradColors.add(Color.parseColor("#FF1238"));
                this.gradColors.add(Color.parseColor("#FFCC00"));
            }
            if (gPositions != null && gPositions.size() == this.gradColors.size()) {
                this.gradPositions.addAll(gPositions);
            } else {
                this.gradPositions.clear();
                for (int i = 0; i < this.gradColors.size(); i++) {
                    this.gradPositions.add(i / (float) Math.max(1, this.gradColors.size() - 1));
                }
            }
        }
    }
    private static final Map<EditorActivity.LayerItem, TextLayerMeta> textLayerMetaMap = new WeakHashMap<>();

    public static class FontItem {
        public String name;
        public Typeface typeface;
        public String filePath;

        public FontItem(String name, Typeface typeface, String filePath) {
            this.name = name;
            this.typeface = typeface;
            this.filePath = filePath;
        }
    }

    private final List<FontItem> fontList = new ArrayList<>();
    private FontItem selectedFont;

    // UI ভিউ রেফারেন্সসমূহ
    private ImageView textToolLeftBtn;
    private TextView optFontBtn;
    private TextView optSizeTv;
    private TextView optSpacingTv;
    private TextView optBoldBtn;
    private TextView optItalicBtn;
    private TextView optShiftBtn;
    private View optColorSwatch;
    private Dialog floatingAlignDialog = null;

    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        initDefaultGradientStops();
        initFonts();
        hookLeftToolbarForTextTool();
        hookTopMenuBarForText();
        setupTransformQualityWatcher();
    }

    private void initDefaultGradientStops() {
        if (currentGradStops.isEmpty()) {
            currentGradStops.add(Color.parseColor("#FF1238"));
            currentGradStops.add(Color.parseColor("#FFCC00"));
            currentGradPositions.clear();
            currentGradPositions.add(0.0f);
            currentGradPositions.add(1.0f);
        }
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private void invokePrivateMethod(EditorActivity act, String name) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    private void invokePrivateSessionMethod(EditorActivity act, String name, EditorActivity.ProjectTabSession s) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name, EditorActivity.ProjectTabSession.class);
            m.setAccessible(true);
            m.invoke(act, s);
        } catch (Exception ignored) {}
    }

    private void initFonts() {
        fontList.clear();
        File fontsDir = new File(activity.getFilesDir(), "custom_fonts");
        if (fontsDir.exists()) {
            File[] files = fontsDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    if (f.getName().endsWith(".ttf") || f.getName().endsWith(".otf")) {
                        try {
                            Typeface tf = Typeface.createFromFile(f);
                            String fontName = f.getName().replace(".ttf", "").replace(".otf", "").replace("_", " ");
                            fontList.add(new FontItem(fontName, tf, f.getAbsolutePath()));
                        } catch (Exception ignored) {}
                    }
                }
            }
        }

        if (!fontList.isEmpty()) {
            selectedFont = fontList.get(0);
        } else {
            selectedFont = new FontItem("System Default", Typeface.DEFAULT, null);
        }
    }

    private void hookLeftToolbarForTextTool() {
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            try {
                if (activity.canvasView != null && activity.canvasView.getParent() != null) {
                    ViewGroup canvasFrame = (ViewGroup) activity.canvasView.getParent();
                    ViewGroup workspace = (ViewGroup) canvasFrame.getParent();
                    if (workspace != null && workspace.getChildCount() > 0) {
                        final ViewGroup leftToolbar = (ViewGroup) workspace.getChildAt(0);

                        if (leftToolbar != null && leftToolbar.findViewWithTag("btn_text_tool_tag") == null) {
                            textToolLeftBtn = new ImageView(activity);
                            textToolLeftBtn.setTag("btn_text_tool_tag");
                            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(28), dp(28));
                            p.setMargins(0, dp(2), 0, dp(2));
                            textToolLeftBtn.setLayoutParams(p);
                            textToolLeftBtn.setImageDrawable(createVectorTextIcon());
                            textToolLeftBtn.setScaleType(ImageView.ScaleType.CENTER);

                            updateLeftToolbarTextButtonState(false);
                            textToolLeftBtn.setOnClickListener(v -> activateTextToolMode());

                            for (int i = 0; i < leftToolbar.getChildCount(); i++) {
                                View child = leftToolbar.getChildAt(i);
                                if (child instanceof ImageView && child != textToolLeftBtn) {
                                    final View.OnClickListener origListener = getExistingClickListener(child);
                                    child.setOnClickListener(v -> {
                                        updateLeftToolbarTextButtonState(false);
                                        if (origListener != null) origListener.onClick(v);
                                    });
                                }
                            }

                            int targetIdx = Math.min(5, leftToolbar.getChildCount() - 2);
                            leftToolbar.addView(textToolLeftBtn, targetIdx);
                        }
                    }
                }
            } catch (Exception ignored) {}
        });
    }

    private View.OnClickListener getExistingClickListener(View v) {
        try {
            Field listenerInfoField = Class.forName("android.view.View").getDeclaredField("mListenerInfo");
            listenerInfoField.setAccessible(true);
            Object myListenerInfo = listenerInfoField.get(v);
            if (myListenerInfo != null) {
                Field clickListenerField = Class.forName("android.view.View$ListenerInfo").getDeclaredField("mOnClickListener");
                clickListenerField.setAccessible(true);
                return (View.OnClickListener) clickListenerField.get(myListenerInfo);
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void updateLeftToolbarTextButtonState(boolean selected) {
        if (textToolLeftBtn == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? Color.parseColor("#38191E") : Color.TRANSPARENT);
        bg.setStroke(dp(1.5f), selected ? Color.parseColor("#FF1238") : Color.TRANSPARENT);
        bg.setCornerRadius(dp(3));
        textToolLeftBtn.setBackground(bg);
    }

    private void hookTopMenuBarForText() {
        if (activity == null || activity.menuContainer == null) return;
        activity.runOnUiThread(() -> {
            if (activity.menuContainer.findViewWithTag("menu_top_text_tag") == null) {
                TextView textMenuTv = new TextView(activity);
                textMenuTv.setTag("menu_top_text_tag");
                textMenuTv.setText("Text");
                textMenuTv.setTextColor(Color.parseColor("#D4D4D4"));
                textMenuTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
                textMenuTv.setPadding(dp(9), dp(6), dp(9), dp(6));
                textMenuTv.setOnClickListener(v -> activateTextToolMode());
                activity.menuContainer.addView(textMenuTv);
            }
        });
    }

    public void activateTextToolMode() {
        if (activity == null || activity.optionControlsBar == null) return;

        try {
            if (textToolLeftBtn != null && textToolLeftBtn.getParent() instanceof ViewGroup) {
                ViewGroup leftTb = (ViewGroup) textToolLeftBtn.getParent();
                for (int i = 0; i < leftTb.getChildCount(); i++) {
                    View c = leftTb.getChildAt(i);
                    if (c instanceof ImageView && c != textToolLeftBtn) {
                        c.setBackgroundColor(Color.TRANSPARENT);
                    }
                }
            }
        } catch (Exception ignored) {}

        updateLeftToolbarTextButtonState(true);
        populateTextToolOptionsBar();
        Toast.makeText(activity, "Text Tool Active", Toast.LENGTH_SHORT).show();
    }

    private void populateTextToolOptionsBar() {
        activity.optionControlsBar.removeAllViews();

        TextView newTextBtn = createOptionPillBtn("+ New Text", v -> openTextInputOnlyDialog(false));
        newTextBtn.setBackgroundColor(Color.parseColor("#FF1238"));
        activity.optionControlsBar.addView(newTextBtn);

        TextView selectTextBtn = createOptionPillBtn("Select Text", v -> showSelectTextLayerDialog());
        activity.optionControlsBar.addView(selectTextBtn);

        optFontBtn = createOptionPillBtn(selectedFont.name + " ▾", v -> showFontDropdownUnderButton(optFontBtn));
        activity.optionControlsBar.addView(optFontBtn);

        TextView optImportBtn = createOptionPillBtn("+ Import", v -> launchFontFilePicker(optFontBtn));
        optImportBtn.setBackgroundColor(Color.parseColor("#333333"));
        activity.optionControlsBar.addView(optImportBtn);

        optSizeTv = createOptionPillBtn("Size: " + (int) currentTextSize + " px", v -> showDraggableSizeDialog());
        activity.optionControlsBar.addView(optSizeTv);

        optSpacingTv = createOptionPillBtn("Spacing: " + (int) currentLetterSpacing + " px", v -> showDraggableSpacingDialog());
        activity.optionControlsBar.addView(optSpacingTv);

        optBoldBtn = createOptionPillBtn(" B ", v -> {
            isBold = !isBold;
            optBoldBtn.setBackgroundColor(Color.parseColor(isBold ? "#FF1238" : "#252525"));
            applyActiveTextLayerUpdate();
        });
        optBoldBtn.setTypeface(null, Typeface.BOLD);
        optBoldBtn.setBackgroundColor(Color.parseColor(isBold ? "#FF1238" : "#252525"));
        activity.optionControlsBar.addView(optBoldBtn);

        optItalicBtn = createOptionPillBtn(" I ", v -> {
            isItalic = !isItalic;
            optItalicBtn.setBackgroundColor(Color.parseColor(isItalic ? "#FF1238" : "#252525"));
            applyActiveTextLayerUpdate();
        });
        optItalicBtn.setTypeface(null, Typeface.ITALIC);
        optItalicBtn.setBackgroundColor(Color.parseColor(isItalic ? "#FF1238" : "#252525"));
        activity.optionControlsBar.addView(optItalicBtn);

        TextView alignBtn = createOptionPillBtn("Align ▾", v -> showFloatingAlignDialog());
        activity.optionControlsBar.addView(alignBtn);

        TextView clrLbl = new TextView(activity);
        clrLbl.setText(" Color: ");
        clrLbl.setTextColor(Color.parseColor("#CCCCCC"));
        clrLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        activity.optionControlsBar.addView(clrLbl);

        optColorSwatch = new View(activity);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(18), dp(18));
        cp.setMargins(dp(2), 0, dp(6), 0);
        optColorSwatch.setLayoutParams(cp);
        updateColorPreview(optColorSwatch, currentTextColor);
        optColorSwatch.setOnClickListener(v -> showRectangularColorPickerWithFeatures(optColorSwatch));
        activity.optionControlsBar.addView(optColorSwatch);

        TextView editBtn = createOptionPillBtn("Edit Text", v -> openTextInputOnlyDialog(true));
        activity.optionControlsBar.addView(editBtn);

        TextView toolLabel = new TextView(activity);
        toolLabel.setText("  [TEXT]");
        toolLabel.setTextColor(Color.parseColor("#777777"));
        toolLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        activity.optionControlsBar.addView(toolLabel);

        optShiftBtn = createOptionPillBtn("Shift: OFF", null);
        optShiftBtn.setOnClickListener(v -> {
            isShiftEnabled = !isShiftEnabled;
            optShiftBtn.setText(isShiftEnabled ? "Shift: ON" : "Shift: OFF");
            optShiftBtn.setBackgroundColor(Color.parseColor(isShiftEnabled ? "#FF1238" : "#252525"));
            try {
                Field f = EditorActivity.class.getDeclaredField("maintainAspectRatio");
                f.setAccessible(true);
                f.setBoolean(activity, isShiftEnabled);
            } catch (Exception ignored) {}
            Toast.makeText(activity, "Shift (Aspect Ratio): " + (isShiftEnabled ? "ON" : "OFF"), Toast.LENGTH_SHORT).show();
        });
        activity.optionControlsBar.addView(optShiftBtn);
    }

    private TextView createOptionPillBtn(String text, View.OnClickListener l) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setIncludeFontPadding(false);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(2), dp(6), dp(2));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#252525"));
        gd.setStroke(dp(1), Color.parseColor("#383838"));
        gd.setCornerRadius(dp(3));
        tv.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
        lp.setMargins(dp(2), 0, dp(2), 0);
        tv.setLayoutParams(lp);
        if (l != null) tv.setOnClickListener(l);
        return tv;
    }

    public TextView createCustomDialogPillButton(String text, String bgHex, View.OnClickListener l) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setSingleLine(true);
        tv.setIncludeFontPadding(false);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(6), dp(2), dp(6), dp(2));
        setButtonBg(tv, bgHex);
        if (l != null) tv.setOnClickListener(l);
        return tv;
    }

    // =========================================================================
    // ড্র্যাগেবল ক্যালকুলেটর কিবোর্ড (ক্লিকে পজিশন হওয়া ও ছোট সাইজ)
    // =========================================================================
    private void showCustomNumericKeypad(final View anchorView, String title, final float min, final float max, float initialVal, final OnNumericInputListener listener) {
        final Dialog kd = new Dialog(activity);
        kd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        kd.setCancelable(false);
        kd.setCanceledOnTouchOutside(false);

        if (kd.getWindow() != null) {
            kd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            kd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            kd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final int targetWidth = dp(215);

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(8), dp(10), dp(10));
        root.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(6));

        TextView titleTv = new TextView(activity);
        titleTv.setText(title + " [" + (int)min + ".." + (int)max + "]");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setSingleLine(true);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> kd.dismiss());
        header.addView(closeX);
        root.addView(header);

        kd.show();
        final WindowManager.LayoutParams wmlp = kd.getWindow().getAttributes();
        wmlp.gravity = Gravity.TOP | Gravity.START;
        wmlp.width = targetWidth;
        wmlp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (anchorView != null) {
            int[] loc = new int[2];
            anchorView.getLocationOnScreen(loc);
            wmlp.x = Math.max(dp(10), loc[0] - dp(20));
            wmlp.y = Math.max(dp(10), loc[1] + anchorView.getHeight() + dp(4));
        } else {
            wmlp.x = dp(80);
            wmlp.y = dp(60);
        }
        kd.getWindow().setAttributes(wmlp);

        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        kd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        LinearLayout displayRow = new LinearLayout(activity);
        displayRow.setOrientation(LinearLayout.HORIZONTAL);
        displayRow.setGravity(Gravity.CENTER_VERTICAL);
        displayRow.setPadding(0, 0, 0, dp(6));

        final TextView displayTv = new TextView(activity);
        displayTv.setText(String.valueOf((int) initialVal));
        displayTv.setTextColor(Color.WHITE);
        displayTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        displayTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        displayTv.setGravity(Gravity.CENTER);

        GradientDrawable dispBg = new GradientDrawable();
        dispBg.setColor(Color.parseColor("#141414"));
        dispBg.setStroke(dp(1.2f), Color.parseColor("#FF1238"));
        dispBg.setCornerRadius(dp(3));
        displayTv.setBackground(dispBg);

        LinearLayout.LayoutParams dispLp = new LinearLayout.LayoutParams(0, dp(34), 1.8f);
        dispLp.setMargins(0, 0, dp(6), 0);
        displayTv.setLayoutParams(dispLp);
        displayRow.addView(displayTv);

        Button acBtn = new Button(activity);
        acBtn.setText("AC");
        acBtn.setTextColor(Color.WHITE);
        acBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        acBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(acBtn, "#FF1238");
        acBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(34), 1f));
        acBtn.setOnClickListener(v -> displayTv.setText("0"));
        displayRow.addView(acBtn);

        root.addView(displayRow);

        String[][] keys = {
                {"1", "2", "3"},
                {"4", "5", "6"},
                {"7", "8", "9"},
                {"-", "0", "BKSP"}
        };

        for (String[] row : keys) {
            LinearLayout kRow = new LinearLayout(activity);
            kRow.setOrientation(LinearLayout.HORIZONTAL);
            kRow.setPadding(0, dp(1.5f), 0, dp(1.5f));

            for (final String k : row) {
                View keyView;
                if (k.equals("BKSP")) {
                    ImageView iv = new ImageView(activity);
                    iv.setImageDrawable(createVectorBackspaceIcon());
                    iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    keyView = iv;
                } else {
                    TextView tv = new TextView(activity);
                    tv.setText(k);
                    tv.setTextColor(Color.WHITE);
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
                    tv.setTypeface(null, Typeface.BOLD);
                    tv.setGravity(Gravity.CENTER);
                    keyView = tv;
                }

                GradientDrawable kBg = new GradientDrawable();
                kBg.setColor(Color.parseColor("#262626"));
                kBg.setCornerRadius(dp(3));
                keyView.setBackground(kBg);

                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, dp(30), 1f);
                kp.setMargins(dp(1.5f), 0, dp(1.5f), 0);
                keyView.setLayoutParams(kp);

                keyView.setOnClickListener(v -> {
                    String cur = displayTv.getText().toString();
                    if (k.equals("BKSP")) {
                        if (cur.length() > 1) {
                            displayTv.setText(cur.substring(0, cur.length() - 1));
                        } else {
                            displayTv.setText("0");
                        }
                    } else if (k.equals("-")) {
                        if (cur.startsWith("-")) {
                            displayTv.setText(cur.substring(1));
                        } else {
                            displayTv.setText("-" + (cur.equals("0") ? "" : cur));
                        }
                    } else {
                        if (cur.equals("0") || cur.equals("-0")) {
                            displayTv.setText(cur.startsWith("-") ? "-" + k : k);
                        } else {
                            if (cur.length() < 7) displayTv.setText(cur + k);
                        }
                    }
                });
                kRow.addView(keyView);
            }
            root.addView(kRow);
        }

        LinearLayout actionRow = new LinearLayout(activity);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(6), 0, 0);

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CANCEL");
        cancelBtn.setTextColor(Color.WHITE);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        cancelBtn.setTypeface(null, Typeface.BOLD);
        cancelBtn.setSingleLine(true);
        setButtonBg(cancelBtn, "#2C2C2C");
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(30), 1f);
        cLp.setMargins(0, 0, dp(4), 0);
        cancelBtn.setLayoutParams(cLp);
        cancelBtn.setOnClickListener(v -> kd.dismiss());
        actionRow.addView(cancelBtn);

        Button okBtn = new Button(activity);
        okBtn.setText("OK");
        okBtn.setTextColor(Color.WHITE);
        okBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        okBtn.setTypeface(null, Typeface.BOLD);
        okBtn.setSingleLine(true);
        setButtonBg(okBtn, "#FF1238");
        LinearLayout.LayoutParams okLp = new LinearLayout.LayoutParams(0, dp(30), 1f);
        okLp.setMargins(dp(4), 0, 0, 0);
        okBtn.setLayoutParams(okLp);

        okBtn.setOnClickListener(v -> {
            try {
                String str = displayTv.getText().toString();
                if (str.equals("-") || str.isEmpty()) str = "0";
                float val = Float.parseFloat(str);
                val = Math.max(min, Math.min(max, val));
                if (listener != null) listener.onValueSubmitted(val);
            } catch (Exception ignored) {}
            kd.dismiss();
        });
        actionRow.addView(okBtn);

        root.addView(actionRow);
        kd.setContentView(root);
    }

 // =========================================================================
    // আপডেটকৃত কাস্টম কীবোর্ড (উপরে সংখ্যা রো + উপরে কার চিহ্ন ও পূর্ণ বাংলা বর্ণমালা)
    // =========================================================================
    private void showCustomEnglishKeyboard(final View anchorView, final TextView targetDisplay, final OnTextInputListener listener) {
        final Dialog ed = new Dialog(activity);
        ed.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ed.setCancelable(false);
        ed.setCanceledOnTouchOutside(false);

        if (ed.getWindow() != null) {
            ed.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            ed.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            ed.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final int targetWidth = dp(290);

        final LinearLayout board = new LinearLayout(activity);
        board.setLayoutParams(new LinearLayout.LayoutParams(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        board.setOrientation(LinearLayout.VERTICAL);
        board.setPadding(dp(8), dp(6), dp(8), dp(8));
        board.setBackground(createDialogBg());

        // হেডার (ড্র্যাগ করে কীবোর্ড সরানো যাবে)
        LinearLayout topHeader = new LinearLayout(activity);
        topHeader.setOrientation(LinearLayout.HORIZONTAL);
        topHeader.setGravity(Gravity.CENTER_VERTICAL);
        topHeader.setPadding(0, 0, 0, dp(4));

        final TextView modeTitle = new TextView(activity);
        modeTitle.setText("English Keyboard [Drag ⤹]");
        modeTitle.setTextColor(Color.parseColor("#AAAAAA"));
        modeTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        modeTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topHeader.addView(modeTitle);

        ImageView closeIcon = new ImageView(activity);
        closeIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
        closeIcon.setImageDrawable(createCloseVectorDrawable());
        closeIcon.setOnClickListener(v -> ed.dismiss());
        topHeader.addView(closeIcon);
        board.addView(topHeader);

        ed.show();
        final WindowManager.LayoutParams wmlp = ed.getWindow().getAttributes();
        wmlp.gravity = Gravity.TOP | Gravity.START;
        wmlp.width = targetWidth;
        wmlp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (anchorView != null) {
            int[] loc = new int[2];
            anchorView.getLocationOnScreen(loc);
            wmlp.x = Math.max(dp(10), loc[0] - dp(10));
            wmlp.y = Math.max(dp(10), loc[1] + anchorView.getHeight() + dp(4));
        } else {
            wmlp.x = dp(80);
            wmlp.y = dp(60);
        }
        ed.getWindow().setAttributes(wmlp);

        topHeader.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        ed.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final LinearLayout keysContainer = new LinearLayout(activity);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        board.addView(keysContainer);

        final boolean[] isBangla = {false};

        // ১ নম্বর ইমেজ ফিক্স: উপরে ১-০ সংখ্যা রো সহ ইংরেজি কীবোর্ড
        final String[][] englishWithNumbers = {
                {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
                {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"},
                {"A", "S", "D", "F", "G", "H", "J", "K", "L"},
                {"Z", "X", "C", "V", "B", "N", "M", "BKSP"}
        };

        // ২ নম্বর ইমেজ ফিক্স: উপরে সকল কার চিহ্ন এবং ক্রমানুসারে সম্পূর্ণ বাংলা বর্ণমালা
        final String[][] completeBanglaKeys = {
                {"া", "ি", "ী", "ু", "ূ", "ৃ", "ে", "ৈ", "ো", "ৌ", "্"}, // কার চিহ্ন সবার উপরে
                {"অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ"}, // পূর্ণ স্বরবর্ণ
                {"ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"},
                {"ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"},
                {"প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"},
                {"স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ", "BKSP"}
        };

        final Runnable renderKeyboard = () -> {
            keysContainer.removeAllViews();
            String[][] activeKeys = isBangla[0] ? completeBanglaKeys : englishWithNumbers;
            modeTitle.setText((isBangla[0] ? "বাংলা কীবোর্ড" : "English Keyboard") + " [Drag ⤹]");

            for (String[] row : activeKeys) {
                LinearLayout r = new LinearLayout(activity);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER);
                r.setPadding(0, dp(1), 0, dp(1));

                for (final String key : row) {
                    View keyView;
                    if (key.equals("BKSP")) {
                        ImageView iv = new ImageView(activity);
                        iv.setImageDrawable(createVectorBackspaceIcon());
                        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                        keyView = iv;
                    } else {
                        TextView tv = new TextView(activity);
                        tv.setText(key);
                        tv.setTextColor(Color.WHITE);
                        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, isBangla[0] ? 11f : 10f);
                        tv.setTypeface(null, Typeface.BOLD);
                        tv.setGravity(Gravity.CENTER);
                        keyView = tv;
                    }

                    GradientDrawable kBg = new GradientDrawable();
                    kBg.setColor(key.equals("BKSP") ? Color.parseColor("#38191E") : Color.parseColor("#262626"));
                    kBg.setCornerRadius(dp(3));
                    keyView.setBackground(kBg);

                    int keyW = key.equals("BKSP") ? dp(30) : dp(23);
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(keyW, dp(26));
                    p.setMargins(dp(1), 0, dp(1), 0);
                    keyView.setLayoutParams(p);

                    keyView.setOnClickListener(v -> {
                        String cur = targetDisplay.getText().toString();
                        if (key.equals("BKSP")) {
                            if (!cur.isEmpty()) {
                                cur = cur.substring(0, cur.length() - 1);
                            }
                        } else {
                            cur = cur + (isBangla[0] ? key : key.toLowerCase());
                        }
                        targetDisplay.setText(cur);
                        if (listener != null) listener.onTextUpdated(cur);
                    });
                    r.addView(keyView);
                }
                keysContainer.addView(r);
            }
        };
        renderKeyboard.run();

        // বটম অ্যাকশন রো (ভেক্টর পৃথিবী আইকন + Clear + Space + DONE)
        LinearLayout bottomRow = new LinearLayout(activity);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.setPadding(0, dp(4), 0, 0);

        ImageView globeBtn = new ImageView(activity);
        globeBtn.setImageDrawable(createVectorGlobeIcon());
        globeBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        setButtonBg(globeBtn, "#333333");
        LinearLayout.LayoutParams gLp = new LinearLayout.LayoutParams(dp(32), dp(28));
        gLp.setMargins(0, 0, dp(4), 0);
        globeBtn.setLayoutParams(gLp);
        globeBtn.setOnClickListener(v -> {
            isBangla[0] = !isBangla[0];
            renderKeyboard.run();
        });
        bottomRow.addView(globeBtn);

        Button clearBtn = new Button(activity);
        clearBtn.setText("Clear");
        clearBtn.setTextColor(Color.WHITE);
        clearBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        clearBtn.setSingleLine(true);
        setButtonBg(clearBtn, "#2C2C2C");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(50), dp(28));
        clp.setMargins(0, 0, dp(4), 0);
        clearBtn.setLayoutParams(clp);
        clearBtn.setOnClickListener(v -> {
            targetDisplay.setText("");
            if (listener != null) listener.onTextUpdated("");
        });
        bottomRow.addView(clearBtn);

        Button spaceBtn = new Button(activity);
        spaceBtn.setText("Space");
        spaceBtn.setTextColor(Color.WHITE);
        spaceBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        spaceBtn.setSingleLine(true);
        setButtonBg(spaceBtn, "#252525");
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(0, dp(28), 1f);
        spLp.setMargins(0, 0, dp(4), 0);
        spaceBtn.setLayoutParams(spLp);
        spaceBtn.setOnClickListener(v -> {
            String cur = targetDisplay.getText().toString() + " ";
            targetDisplay.setText(cur);
            if (listener != null) listener.onTextUpdated(cur);
        });
        bottomRow.addView(spaceBtn);

        Button doneBtn = new Button(activity);
        doneBtn.setText("DONE");
        doneBtn.setTextColor(Color.WHITE);
        doneBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        doneBtn.setTypeface(null, Typeface.BOLD);
        doneBtn.setSingleLine(true);
        setButtonBg(doneBtn, "#FF1238");
        doneBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(56), dp(28)));
        doneBtn.setOnClickListener(v -> ed.dismiss());
        bottomRow.addView(doneBtn);

        board.addView(bottomRow);
        ed.setContentView(board);
    }

    // =========================================================================
    // ড্র্যাগেবল সাইজ ডায়ালগ
    // =========================================================================
    private void showDraggableSizeDialog() {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            d.getWindow().setGravity(Gravity.CENTER);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(14));
        box.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView lbl = new TextView(activity);
        lbl.setText("Text Size (px)");
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(lbl);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> d.dismiss());
        header.addView(closeX);
        box.addView(header);

        final WindowManager.LayoutParams wmlp = d.getWindow().getAttributes();
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        d.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        LinearLayout inputRow = new LinearLayout(activity);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(0, dp(4), 0, dp(8));

        final TextView minusBtn = createStepperPillButton("-", null);
        inputRow.addView(minusBtn);

        final TextView sizeTvBox = new TextView(activity);
        sizeTvBox.setText(String.valueOf((int) currentTextSize));
        sizeTvBox.setTextColor(Color.WHITE);
        sizeTvBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        sizeTvBox.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        sizeTvBox.setGravity(Gravity.CENTER);
        sizeTvBox.setBackground(createInputBg());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(70), dp(32));
        sp.setMargins(dp(6), 0, dp(6), 0);
        sizeTvBox.setLayoutParams(sp);
        inputRow.addView(sizeTvBox);

        final TextView plusBtn = createStepperPillButton("+", null);
        inputRow.addView(plusBtn);

        TextView pxTv = new TextView(activity);
        pxTv.setText(" px");
        pxTv.setTextColor(Color.parseColor("#AAAAAA"));
        pxTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        inputRow.addView(pxTv);
        box.addView(inputRow);

        final SeekBar sb = new SeekBar(activity);
        sb.setMax(400);
        sb.setProgress((int) currentTextSize);
        applyCustomSeekBarStyle(sb);
        sb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(sb);

        final Runnable updateSizeViews = () -> {
            sizeTvBox.setText(String.valueOf((int) currentTextSize));
            sb.setProgress((int) currentTextSize);
            if (optSizeTv != null) optSizeTv.setText("Size: " + (int) currentTextSize + " px");
            applyActiveTextLayerUpdate();
        };

        minusBtn.setOnClickListener(v -> {
            currentTextSize = Math.max(8, currentTextSize - 1);
            updateSizeViews.run();
        });

        plusBtn.setOnClickListener(v -> {
            currentTextSize = Math.min(600, currentTextSize + 1);
            updateSizeViews.run();
        });

        sizeTvBox.setOnClickListener(v -> showCustomNumericKeypad(sizeTvBox, "Size", 8, 600, currentTextSize, val -> {
            currentTextSize = val;
            updateSizeViews.run();
        }));

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentTextSize = Math.max(8, progress);
                    sizeTvBox.setText(String.valueOf((int) currentTextSize));
                    if (optSizeTv != null) optSizeTv.setText("Size: " + (int) currentTextSize + " px");
                    applyActiveTextLayerUpdate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        d.setContentView(box);
        d.show();
    }

    // =========================================================================
    // ড্র্যাগেবল স্পেসিং ডায়ালগ
    // =========================================================================
    private void showDraggableSpacingDialog() {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            d.getWindow().setGravity(Gravity.CENTER);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(14));
        box.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView lbl = new TextView(activity);
        lbl.setText("Letter Spacing (px)");
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        lbl.setTypeface(null, Typeface.BOLD);
        lbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(lbl);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> d.dismiss());
        header.addView(closeX);
        box.addView(header);

        final WindowManager.LayoutParams wmlp = d.getWindow().getAttributes();
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        d.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        LinearLayout inputRow = new LinearLayout(activity);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setPadding(0, dp(4), 0, dp(8));

        final TextView minusBtn = createStepperPillButton("-", null);
        inputRow.addView(minusBtn);

        final TextView spTvBox = new TextView(activity);
        spTvBox.setText(String.valueOf((int) currentLetterSpacing));
        spTvBox.setTextColor(Color.WHITE);
        spTvBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        spTvBox.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        spTvBox.setGravity(Gravity.CENTER);
        spTvBox.setBackground(createInputBg());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(70), dp(32));
        sp.setMargins(dp(6), 0, dp(6), 0);
        spTvBox.setLayoutParams(sp);
        inputRow.addView(spTvBox);

        final TextView plusBtn = createStepperPillButton("+", null);
        inputRow.addView(plusBtn);

        TextView pxTv = new TextView(activity);
        pxTv.setText(" px");
        pxTv.setTextColor(Color.parseColor("#AAAAAA"));
        pxTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        inputRow.addView(pxTv);
        box.addView(inputRow);

        final SeekBar sb = new SeekBar(activity);
        sb.setMax(100);
        sb.setProgress((int) Math.max(0, currentLetterSpacing));
        applyCustomSeekBarStyle(sb);
        sb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(sb);

        final Runnable updateSpacingViews = () -> {
            spTvBox.setText(String.valueOf((int) currentLetterSpacing));
            sb.setProgress((int) Math.max(0, currentLetterSpacing));
            if (optSpacingTv != null) optSpacingTv.setText("Spacing: " + (int) currentLetterSpacing + " px");
            applyActiveTextLayerUpdate();
        };

        minusBtn.setOnClickListener(v -> {
            currentLetterSpacing = Math.max(-50, currentLetterSpacing - 1);
            updateSpacingViews.run();
        });

        plusBtn.setOnClickListener(v -> {
            currentLetterSpacing = Math.min(200, currentLetterSpacing + 1);
            updateSpacingViews.run();
        });

        spTvBox.setOnClickListener(v -> showCustomNumericKeypad(spTvBox, "Spacing", -50, 200, currentLetterSpacing, val -> {
            currentLetterSpacing = val;
            updateSpacingViews.run();
        }));

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentLetterSpacing = progress;
                    spTvBox.setText(String.valueOf((int) currentLetterSpacing));
                    if (optSpacingTv != null) optSpacingTv.setText("Spacing: " + (int) currentLetterSpacing + " px");
                    applyActiveTextLayerUpdate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        d.setContentView(box);
        d.show();
    }

    private TextView createStepperPillButton(String text, View.OnClickListener l) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        setButtonBg(tv, "#FF1238");
        tv.setLayoutParams(new LinearLayout.LayoutParams(dp(30), dp(30)));
        if (l != null) tv.setOnClickListener(l);
        return tv;
    }

    // =========================================================================
    // চারকোনা কালার বক্স ও কালার পিকার
    // =========================================================================
    private void showRectangularColorPickerWithFeatures(final View previewTargetView) {
        final Dialog cd = new Dialog(activity);
        cd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        cd.setCancelable(false);
        cd.setCanceledOnTouchOutside(false);

        if (cd.getWindow() != null) {
            cd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            cd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            cd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final WindowManager.LayoutParams wmlp = cd.getWindow().getAttributes();
        wmlp.width = dp(260);
        wmlp.height = dp(350);

        final FrameLayout rootFrame = new FrameLayout(activity);
        rootFrame.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        box.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(6));

        final ImageView menuBtn = new ImageView(activity);
        menuBtn.setImageDrawable(createVectorMenuIcon());
        menuBtn.setScaleType(ImageView.ScaleType.CENTER);
        LinearLayout.LayoutParams mLp = new LinearLayout.LayoutParams(dp(26), dp(26));
        mLp.setMargins(0, 0, dp(6), 0);
        menuBtn.setLayoutParams(mLp);
        header.addView(menuBtn);

        TextView titleTv = new TextView(activity);
        titleTv.setText("Fill / Foreground");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        final View bigColorPreview = new View(activity);
        bigColorPreview.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));
        header.addView(bigColorPreview);
        box.addView(header);

        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        cd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final float[] hsv = new float[3];
        Color.colorToHSV(currentTextColor, hsv);
        final int[] curAlpha = {Color.alpha(currentTextColor)};
        final int[] workingColor = {currentTextColor};

        final Runnable updatePreviewDrawable = () -> {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(workingColor[0]);
            d.setStroke(dp(1.5f), Color.WHITE);
            bigColorPreview.setBackground(d);
        };
        updatePreviewDrawable.run();

        final TextView hexBoxTv = new TextView(activity);
        hexBoxTv.setTextColor(Color.WHITE);
        hexBoxTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        hexBoxTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hexBoxTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(26));
        hexLp.setMargins(0, 0, 0, dp(6));
        hexBoxTv.setLayoutParams(hexLp);

        GradientDrawable hexBg = new GradientDrawable();
        hexBg.setColor(Color.parseColor("#121212"));
        hexBg.setStroke(dp(1.2f), Color.parseColor("#D4A054"));
        hexBg.setCornerRadius(dp(4));
        hexBoxTv.setBackground(hexBg);

        final Runnable updateHexText = () -> {
            int c = workingColor[0];
            int a = Color.alpha(c);
            int r = Color.red(c);
            int g = Color.green(c);
            int b = Color.blue(c);
            hexBoxTv.setText(String.format("#%08X - (%d,%d,%d,%d)", c, r, g, b, a));
        };
        updateHexText.run();
        box.addView(hexBoxTv);

        final RectColorBoxView rectColorBox = new RectColorBoxView(activity);
        LinearLayout.LayoutParams rBoxLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(95));
        rBoxLp.setMargins(0, 0, 0, dp(6));
        rectColorBox.setLayoutParams(rBoxLp);
        rectColorBox.setColorHSV(hsv);
        box.addView(rectColorBox);

        final GradientSliderView satSlider = new GradientSliderView(activity);
        final GradientSliderView valSlider = new GradientSliderView(activity);
        final GradientSliderView alphaSlider = new GradientSliderView(activity);

        satSlider.setProgress(hsv[1]);
        valSlider.setProgress(hsv[2]);
        alphaSlider.setProgress(curAlpha[0] / 255f);

        final Runnable updateSliderGradients = () -> {
            float[] tempHSV = new float[]{hsv[0], 0f, hsv[2]};
            int colWhite = Color.HSVToColor(tempHSV);
            tempHSV[1] = 1f;
            int colSat = Color.HSVToColor(tempHSV);
            satSlider.setGradientColors(colWhite, colSat);

            tempHSV[1] = hsv[1];
            tempHSV[2] = 0f;
            int colBlack = Color.HSVToColor(tempHSV);
            tempHSV[2] = 1f;
            int colBright = Color.HSVToColor(tempHSV);
            valSlider.setGradientColors(colBlack, colBright);

            int colOpaque = Color.HSVToColor(255, hsv);
            alphaSlider.setGradientColors(Color.TRANSPARENT, colOpaque);
        };
        updateSliderGradients.run();

        rectColorBox.setOnHueChangeListener((newHue, newSatVal) -> {
            hsv[0] = newHue;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
        });

        satSlider.setOnSliderChangeListener(prog -> {
            hsv[1] = prog;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
            rectColorBox.setColorHSV(hsv);
        });

        valSlider.setOnSliderChangeListener(prog -> {
            hsv[2] = prog;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
            rectColorBox.setColorHSV(hsv);
        });

        alphaSlider.setOnSliderChangeListener(prog -> {
            curAlpha[0] = Math.round(prog * 255f);
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
        });

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14));
        slp.setMargins(0, dp(3), 0, dp(3));
        satSlider.setLayoutParams(slp);
        valSlider.setLayoutParams(slp);
        alphaSlider.setLayoutParams(slp);

        box.addView(satSlider);
        box.addView(valSlider);
        box.addView(alphaSlider);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(8), 0, 0);

        Button apply = new Button(activity);
        apply.setText("APPLY");
        apply.setTextColor(Color.WHITE);
        apply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        apply.setTypeface(null, Typeface.BOLD);
        setButtonBg(apply, "#FF1238");
        apply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 1.2f));

        apply.setOnClickListener(v -> {
            isGradientText = false;
            currentTextColor = workingColor[0];
            if (previewTargetView != null) updateColorPreview(previewTargetView, currentTextColor);
            if (optColorSwatch != null) updateColorPreview(optColorSwatch, currentTextColor);
            applyActiveTextLayerUpdate();
            Toast.makeText(activity, "Color Applied Live", Toast.LENGTH_SHORT).show();
        });
        btnRow.addView(apply);

        View g = new View(activity); g.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(1))); btnRow.addView(g);

        Button cancel = new Button(activity);
        cancel.setText("CLOSE");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(cancel, "#2C2C2C");
        cancel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 0.8f));
        cancel.setOnClickListener(v -> cd.dismiss());
        btnRow.addView(cancel);

        box.addView(btnRow);
        rootFrame.addView(box);

        menuBtn.setOnClickListener(v -> {
            final PopupWindow menuPopup = new PopupWindow(activity);
            LinearLayout menuL = new LinearLayout(activity);
            menuL.setOrientation(LinearLayout.VERTICAL);
            menuL.setPadding(dp(8), dp(6), dp(8), dp(6));
            menuL.setBackground(createDialogBg());

            String[] items = {"Save Color", "Open Saved Palette", "Gradient Mode", "Gradient Templates"};
            for (int i = 0; i < items.length; i++) {
                final int idx = i;
                TextView itv = new TextView(activity);
                itv.setText(items[i]);
                itv.setTextColor(Color.WHITE);
                itv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                itv.setPadding(dp(10), dp(8), dp(10), dp(8));
                itv.setOnClickListener(view -> {
                    menuPopup.dismiss();
                    if (idx == 0) {
                        saveSolidColorToUnifiedPalette(workingColor[0]);
                        Toast.makeText(activity, "Color Saved to Palette!", Toast.LENGTH_SHORT).show();
                    } else if (idx == 1) {
                        showUnifiedSavedPaletteDialog();
                    } else if (idx == 2) {
                        cd.dismiss();
                        showInteractiveGradientEditor();
                    } else if (idx == 3) {
                        showGradientTemplatesDialog();
                    }
                });
                menuL.addView(itv);
            }
            menuPopup.setContentView(menuL);
            menuPopup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setFocusable(true);
            menuPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            menuPopup.showAsDropDown(menuBtn, 0, dp(4));
        });

        final ImageView resizeHandle = new ImageView(activity);
        resizeHandle.setImageDrawable(createVectorResizeIcon());
        resizeHandle.setScaleType(ImageView.ScaleType.CENTER);
        FrameLayout.LayoutParams rzLp = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.BOTTOM | Gravity.END);
        resizeHandle.setLayoutParams(rzLp);

        resizeHandle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.width, event.getRawY() - wmlp.height});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] tag = (float[]) v.getTag();
                    if (tag != null) {
                        int newW = Math.max(dp(200), (int) (event.getRawX() - tag[0]));
                        int newH = Math.max(dp(280), (int) (event.getRawY() - tag[1]));
                        wmlp.width = newW;
                        wmlp.height = newH;
                        cd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });
        rootFrame.addView(resizeHandle);

        cd.setContentView(rootFrame);
        cd.show();
    }

    public class RectColorBoxView extends View {
        private final Paint rectPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointerBorder = new Paint(Paint.ANTI_ALIAS_FLAG);

        private float pointerX = dp(10);
        private float pointerY = dp(10);
        private OnHueChangeListener hueListener;

        public RectColorBoxView(Context context) {
            super(context);
            pointerPaint.setColor(Color.WHITE);
            pointerPaint.setStyle(Paint.Style.FILL);
            pointerBorder.setColor(Color.BLACK);
            pointerBorder.setStyle(Paint.Style.STROKE);
            pointerBorder.setStrokeWidth(dp(1.8f));
        }

        public void setOnHueChangeListener(OnHueChangeListener l) {
            this.hueListener = l;
        }

        public void setColorHSV(float[] hsv) {
            if (getWidth() > 0) {
                pointerX = (hsv[0] / 360f) * getWidth();
                pointerY = (1.0f - hsv[2]) * getHeight();
            }
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            int[] colors = new int[]{Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED};
            LinearGradient lg = new LinearGradient(0, 0, w, 0, colors, null, Shader.TileMode.CLAMP);
            rectPaint.setShader(lg);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            canvas.drawRoundRect(0, 0, w, h, dp(6), dp(6), rectPaint);

            float px = Math.max(dp(6), Math.min(w - dp(6), pointerX));
            float py = Math.max(dp(6), Math.min(h - dp(6), pointerY));
            canvas.drawCircle(px, py, dp(6.5f), pointerPaint);
            canvas.drawCircle(px, py, dp(6.5f), pointerBorder);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

            float x = Math.max(0, Math.min(getWidth(), event.getX()));
            float y = Math.max(0, Math.min(getHeight(), event.getY()));
            pointerX = x;
            pointerY = y;

            float hue = (x / getWidth()) * 360f;
            float val = 1.0f - (y / getHeight());

            if (hueListener != null) hueListener.onHueChanged(hue, val);
            invalidate();
            return true;
        }
    }

    public class GradientSliderView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbStroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        private float progress = 1.0f;
        private int colorStart = Color.WHITE;
        private int colorEnd = Color.RED;
        private OnSliderChangeListener listener;

        public GradientSliderView(Context context) {
            super(context);
            thumbPaint.setColor(Color.WHITE);
            thumbPaint.setStyle(Paint.Style.FILL);
            thumbStroke.setColor(Color.parseColor("#333333"));
            thumbStroke.setStyle(Paint.Style.STROKE);
            thumbStroke.setStrokeWidth(dp(1.2f));
        }

        public void setProgress(float p) {
            this.progress = Math.max(0f, Math.min(1f, p));
            invalidate();
        }

        public void setGradientColors(int start, int end) {
            this.colorStart = start;
            this.colorEnd = end;
            updateShader();
            invalidate();
        }

        public void setOnSliderChangeListener(OnSliderChangeListener l) {
            this.listener = l;
        }

        private void updateShader() {
            if (getWidth() > 0) {
                LinearGradient lg = new LinearGradient(0, 0, getWidth(), 0, colorStart, colorEnd, Shader.TileMode.CLAMP);
                trackPaint.setShader(lg);
            }
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            updateShader();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            canvas.drawRoundRect(0, 0, w, h, dp(3), dp(3), trackPaint);

            float tx = progress * (w - dp(12)) + dp(6);
            canvas.drawCircle(tx, h / 2f, dp(6), thumbPaint);
            canvas.drawCircle(tx, h / 2f, dp(6), thumbStroke);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            int w = getWidth();
            float x = Math.max(dp(6), Math.min(w - dp(6), event.getX()));
            progress = (x - dp(6)) / (w - dp(12));
            invalidate();
            if (listener != null) listener.onProgressChanged(progress);
            return true;
        }
    }

    // =========================================================================
    // Saved Palette (সলিড ও গ্রেডিয়েন্ট সেভ ও সার্চ)
    // =========================================================================
    private void saveSolidColorToUnifiedPalette(int color) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("type", "solid");
            obj.put("color", color);
            obj.put("hex", String.format("#%08X", color));
            arr.put(obj);
            sp.edit().putString("palette_items", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void saveGradientToUnifiedPalette(List<Integer> colors, List<Float> positions, int angle, int spacing) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("type", "gradient");
            obj.put("angle", angle);
            obj.put("spacing", spacing);
            JSONArray cArr = new JSONArray();
            for (int c : colors) cArr.put(c);
            obj.put("colors", cArr);

            JSONArray pArr = new JSONArray();
            for (float p : positions) pArr.put((double) p);
            obj.put("positions", pArr);

            obj.put("hex", "Grad (" + colors.size() + " stops)");
            arr.put(obj);
            sp.edit().putString("palette_items", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void showUnifiedSavedPaletteDialog() {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            final JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));

            final Dialog d = new Dialog(activity);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            d.setCancelable(false);

            LinearLayout box = new LinearLayout(activity);
            box.setLayoutParams(new LinearLayout.LayoutParams(dp(260), dp(350)));
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(16), dp(12), dp(16), dp(14));
            box.setBackground(createDialogBg());

            LinearLayout header = new LinearLayout(activity);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.setPadding(0, 0, 0, dp(8));

            TextView title = new TextView(activity);
            title.setText("Saved Colors Palette");
            title.setTextColor(Color.WHITE);
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            title.setTypeface(null, Typeface.BOLD);
            title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            header.addView(title);

            ImageView closeX = new ImageView(activity);
            closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
            closeX.setImageDrawable(createCloseVectorDrawable());
            closeX.setOnClickListener(v -> d.dismiss());
            header.addView(closeX);
            box.addView(header);

            final TextView searchBox = new TextView(activity);
            searchBox.setHint("Search color / hex...");
            searchBox.setHintTextColor(Color.parseColor("#777777"));
            searchBox.setTextColor(Color.WHITE);
            searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            searchBox.setBackground(createInputBg());
            searchBox.setPadding(dp(8), dp(6), dp(8), dp(6));
            searchBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
            box.addView(searchBox);

            ScrollView sv = new ScrollView(activity);
            LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            svLp.setMargins(0, dp(6), 0, dp(6));
            sv.setLayoutParams(svLp);

            final LinearLayout list = new LinearLayout(activity);
            list.setOrientation(LinearLayout.VERTICAL);
            sv.addView(list);
            box.addView(sv);

            final Runnable renderList = () -> {
                list.removeAllViews();
                String query = searchBox.getText().toString().trim().toLowerCase();

                if (arr.length() == 0) {
                    TextView emptyTv = new TextView(activity);
                    emptyTv.setText("No saved colors or gradients yet.");
                    emptyTv.setTextColor(Color.parseColor("#777777"));
                    emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
                    emptyTv.setGravity(Gravity.CENTER);
                    emptyTv.setPadding(0, dp(30), 0, 0);
                    list.addView(emptyTv);
                    return;
                }

                for (int i = 0; i < arr.length(); i++) {
                    try {
                        final JSONObject item = arr.getJSONObject(i);
                        String hexLabel = item.optString("hex", "#FFFFFF");
                        if (!query.isEmpty() && !hexLabel.toLowerCase().contains(query)) continue;

                        LinearLayout row = new LinearLayout(activity);
                        row.setOrientation(LinearLayout.HORIZONTAL);
                        row.setGravity(Gravity.CENTER_VERTICAL);
                        row.setPadding(dp(8), dp(6), dp(8), dp(6));

                        GradientDrawable rowBg = new GradientDrawable();
                        rowBg.setColor(Color.parseColor("#222222"));
                        rowBg.setCornerRadius(dp(4));
                        rowBg.setStroke(dp(1), Color.parseColor("#333333"));
                        row.setBackground(rowBg);

                        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36));
                        rLp.setMargins(0, 0, 0, dp(4));
                        row.setLayoutParams(rLp);

                        View preview = new View(activity);
                        preview.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(24)));

                        if ("gradient".equals(item.optString("type"))) {
                            JSONArray cArr = item.getJSONArray("colors");
                            int[] colors = new int[cArr.length()];
                            for (int c = 0; c < cArr.length(); c++) colors[c] = cArr.getInt(c);
                            GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
                            gd.setCornerRadius(dp(3));
                            gd.setStroke(dp(1), Color.WHITE);
                            preview.setBackground(gd);
                        } else {
                            int c = item.optInt("color", Color.WHITE);
                            updateColorPreview(preview, c);
                        }
                        row.addView(preview);

                        TextView labelTv = new TextView(activity);
                        labelTv.setText("  " + hexLabel);
                        labelTv.setTextColor(Color.WHITE);
                        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
                        labelTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                        labelTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                        row.addView(labelTv);

                        row.setOnClickListener(v -> {
                            if ("gradient".equals(item.optString("type"))) {
                                try {
                                    JSONArray cArr = item.getJSONArray("colors");
                                    currentGradStops.clear();
                                    for (int c = 0; c < cArr.length(); c++) currentGradStops.add(cArr.getInt(c));
                                    
                                    currentGradPositions.clear();
                                    JSONArray pArr = item.optJSONArray("positions");
                                    if (pArr != null && pArr.length() == currentGradStops.size()) {
                                        for (int p = 0; p < pArr.length(); p++) currentGradPositions.add((float) pArr.getDouble(p));
                                    } else {
                                        for (int p = 0; p < currentGradStops.size(); p++) currentGradPositions.add(p / (float) Math.max(1, currentGradStops.size() - 1));
                                    }

                                    gradientAngle = item.optInt("angle", 0);
                                    gradientSpacing = item.optInt("spacing", 100);
                                    isGradientText = true;
                                    applyActiveTextLayerUpdate();
                                    Toast.makeText(activity, "Gradient Applied Live!", Toast.LENGTH_SHORT).show();
                                } catch (Exception ignored) {}
                            } else {
                                int c = item.optInt("color", Color.WHITE);
                                isGradientText = false;
                                currentTextColor = c;
                                if (optColorSwatch != null) updateColorPreview(optColorSwatch, currentTextColor);
                                applyActiveTextLayerUpdate();
                                Toast.makeText(activity, "Color Applied Live!", Toast.LENGTH_SHORT).show();
                            }
                            d.dismiss();
                        });

                        list.addView(row);
                    } catch (Exception ignored) {}
                }
            };
            renderList.run();

            searchBox.setOnClickListener(v -> showCustomEnglishKeyboard(searchBox, searchBox, text -> renderList.run()));

            Button closeBtn = new Button(activity);
            closeBtn.setText("CLOSE");
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            setButtonBg(closeBtn, "#2C2C2C");
            closeBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30)));
            closeBtn.setOnClickListener(v -> d.dismiss());
            box.addView(closeBtn);

            d.setContentView(box);
            if (d.getWindow() != null) {
                d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
            d.show();
        } catch (Exception ignored) {}
    }

    // =========================================================================
    // ৩টি বা ততোধিক স্টপের নির্ভুল রেন্ডারিং নিশ্চিতকারী মডেল
    // =========================================================================
    public static class StopPointItem {
        public int color;
        public float position;
        public int originalIndex;

        public StopPointItem(int color, float position, int originalIndex) {
            this.color = color;
            this.position = position;
            this.originalIndex = originalIndex;
        }
    }

    // =========================================================================
    // নাড়া-চাড়া করে সরাসরি গ্রেডিয়েন্ট পয়েন্ট কন্ট্রোল করার ইন্টারেক্টিভ ভিউ
    // =========================================================================
    public class InteractiveGradientTrackView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinSelectedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public List<Integer> stops;
        public List<Float> positions;
        public int selectedIndex = 0;
        public Runnable onGradientChanged;

        private int activeTouchIndex = -1;

        public InteractiveGradientTrackView(Context context, List<Integer> s, List<Float> p, Runnable changed) {
            super(context);
            this.stops = s;
            this.positions = p;
            this.onGradientChanged = changed;

            pinStrokePaint.setColor(Color.WHITE);
            pinStrokePaint.setStyle(Paint.Style.STROKE);
            pinStrokePaint.setStrokeWidth(dp(2));

            pinSelectedPaint.setColor(Color.parseColor("#FF1238"));
            pinSelectedPaint.setStyle(Paint.Style.STROKE);
            pinSelectedPaint.setStrokeWidth(dp(3));
        }

        private void updateShader() {
            int w = getWidth();
            if (w <= 0 || stops.size() < 2) return;

            List<StopPointItem> sorted = new ArrayList<>();
            for (int i = 0; i < stops.size(); i++) {
                float pos = (i < positions.size()) ? positions.get(i) : (i / (float) (stops.size() - 1));
                sorted.add(new StopPointItem(stops.get(i), pos, i));
            }
            Collections.sort(sorted, (a, b) -> Float.compare(a.position, b.position));

            int[] cArr = new int[sorted.size()];
            float[] pArr = new float[sorted.size()];
            for (int i = 0; i < sorted.size(); i++) {
                cArr[i] = sorted.get(i).color;
                pArr[i] = Math.max(0f, Math.min(1f, sorted.get(i).position));
                if (i > 0 && pArr[i] < pArr[i - 1]) {
                    pArr[i] = pArr[i - 1];
                }
            }

            LinearGradient lg = new LinearGradient(dp(12), 0, w - dp(12), 0, cArr, pArr, Shader.TileMode.CLAMP);
            trackPaint.setShader(lg);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            updateShader();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            updateShader();

            float barTop = dp(4);
            float barBottom = h - dp(18);
            canvas.drawRoundRect(dp(12), barTop, w - dp(12), barBottom, dp(6), dp(6), trackPaint);

            float trackWidth = w - dp(24);
            for (int i = 0; i < stops.size(); i++) {
                float px = dp(12) + positions.get(i) * trackWidth;
                float py = barBottom + dp(8);

                pinFillPaint.setColor(stops.get(i));
                canvas.drawCircle(px, py, dp(7), pinFillPaint);

                if (i == selectedIndex) {
                    canvas.drawCircle(px, py, dp(8.5f), pinSelectedPaint);
                } else {
                    canvas.drawCircle(px, py, dp(7), pinStrokePaint);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            int w = getWidth();
            float trackWidth = w - dp(24);
            float touchX = event.getX();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    activeTouchIndex = -1;
                    float minD = dp(24);
                    for (int i = 0; i < stops.size(); i++) {
                        float px = dp(12) + positions.get(i) * trackWidth;
                        float d = Math.abs(px - touchX);
                        if (d < minD) {
                            minD = d;
                            activeTouchIndex = i;
                            selectedIndex = i;
                        }
                    }
                    invalidate();
                    if (onGradientChanged != null) onGradientChanged.run();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (activeTouchIndex >= 0 && activeTouchIndex < positions.size()) {
                        float newP = (touchX - dp(12)) / trackWidth;
                        newP = Math.max(0f, Math.min(1f, newP));
                        positions.set(activeTouchIndex, newP);
                        invalidate();
                        if (onGradientChanged != null) onGradientChanged.run();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeTouchIndex = -1;
                    invalidate();
                    return true;
            }
            return super.onTouchEvent(event);
        }
    }

    // =========================================================================
    // ১ নম্বর ইমেজ অনুযায়ী ইন্টারেক্টিভ গ্রেডিয়েন্ট (Angle ও Spacing স্লাইডার)
    // =========================================================================
    private void showInteractiveGradientEditor() {
        final Dialog gd = new Dialog(activity);
        gd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        gd.setCancelable(false);
        gd.setCanceledOnTouchOutside(false);

        if (gd.getWindow() != null) {
            gd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            gd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            gd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            WindowManager.LayoutParams wmlp = gd.getWindow().getAttributes();
            wmlp.width = dp(295);
            wmlp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            gd.getWindow().setAttributes(wmlp);
        }

        final LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(295), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(activity);
        title.setText("Interactive Gradient");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(title);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> gd.dismiss());
        header.addView(closeX);
        box.addView(header);

        final WindowManager.LayoutParams wmlp = gd.getWindow().getAttributes();
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        gd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final List<Integer> workingStops = new ArrayList<>(currentGradStops);
        final List<Float> workingPositions = new ArrayList<>(currentGradPositions);

        if (workingStops.size() < 2) {
            workingStops.clear();
            workingStops.add(Color.parseColor("#FF1238"));
            workingStops.add(Color.parseColor("#FFCC00"));
            workingPositions.clear();
            workingPositions.add(0.0f);
            workingPositions.add(1.0f);
        }

        final Runnable applyLiveGradientToText = () -> {
            isGradientText = true;
            currentGradStops.clear();
            currentGradStops.addAll(workingStops);
            currentGradPositions.clear();
            currentGradPositions.addAll(workingPositions);
            applyActiveTextLayerUpdate();
        };

        final InteractiveGradientTrackView trackView = new InteractiveGradientTrackView(activity, workingStops, workingPositions, null);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        tlp.setMargins(0, 0, 0, dp(8));
        trackView.setLayoutParams(tlp);
        box.addView(trackView);

        // পয়েন্ট কন্ট্রোল রো
        LinearLayout pointControlRow = new LinearLayout(activity);
        pointControlRow.setOrientation(LinearLayout.HORIZONTAL);
        pointControlRow.setGravity(Gravity.CENTER_VERTICAL);
        pointControlRow.setPadding(0, 0, 0, dp(8));

        final View activeStopSwatch = new View(activity);
        activeStopSwatch.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(26)));
        updateColorPreview(activeStopSwatch, workingStops.get(trackView.selectedIndex));
        pointControlRow.addView(activeStopSwatch);

        final TextView pointLabelTv = new TextView(activity);
        pointLabelTv.setText(" Point " + (trackView.selectedIndex + 1) + " Color");
        pointLabelTv.setTextColor(Color.WHITE);
        pointLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        pointLabelTv.setTypeface(null, Typeface.BOLD);
        pointLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pointControlRow.addView(pointLabelTv);

        final TextView delPointBtn = createCustomDialogPillButton("✕ Delete", "#38191E", null);
        delPointBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(58), dp(28)));
        delPointBtn.setVisibility(workingStops.size() > 2 ? View.VISIBLE : View.GONE);
        pointControlRow.addView(delPointBtn);

        TextView addPointBtn = createCustomDialogPillButton("+ Add Point", "#FF1238", null);
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(dp(75), dp(28));
        apLp.setMargins(dp(4), 0, 0, 0);
        addPointBtn.setLayoutParams(apLp);
        pointControlRow.addView(addPointBtn);

        box.addView(pointControlRow);

        final Runnable updateSelectedPointUI = () -> {
            int sel = trackView.selectedIndex;
            if (sel >= 0 && sel < workingStops.size()) {
                updateColorPreview(activeStopSwatch, workingStops.get(sel));
                pointLabelTv.setText(" Point " + (sel + 1) + " Color");
                delPointBtn.setVisibility(workingStops.size() > 2 ? View.VISIBLE : View.GONE);
            }
        };

        trackView.onGradientChanged = () -> {
            updateSelectedPointUI.run();
            applyLiveGradientToText.run();
        };

        activeStopSwatch.setOnClickListener(v -> {
            int sel = trackView.selectedIndex;
            showStandaloneColorPicker(workingStops.get(sel), col -> {
                workingStops.set(sel, col);
                updateColorPreview(activeStopSwatch, col);
                trackView.invalidate();
                applyLiveGradientToText.run();
            });
        });

        addPointBtn.setOnClickListener(v -> {
            int lastCol = workingStops.get(workingStops.size() - 1);
            float newPos = 0.5f;
            workingStops.add(lastCol);
            workingPositions.add(newPos);
            trackView.selectedIndex = workingStops.size() - 1;
            trackView.invalidate();
            updateSelectedPointUI.run();
            applyLiveGradientToText.run();
        });

        delPointBtn.setOnClickListener(v -> {
            if (workingStops.size() > 2) {
                int sel = trackView.selectedIndex;
                workingStops.remove(sel);
                workingPositions.remove(sel);
                trackView.selectedIndex = Math.max(0, sel - 1);
                trackView.invalidate();
                updateSelectedPointUI.run();
                applyLiveGradientToText.run();
            }
        });

        // রো ১: Reverse & Save বাটন
        LinearLayout toolsRow1 = new LinearLayout(activity);
        toolsRow1.setOrientation(LinearLayout.HORIZONTAL);
        toolsRow1.setGravity(Gravity.CENTER_VERTICAL);
        toolsRow1.setPadding(0, 0, 0, dp(6));

        TextView reverseBtn = createCustomDialogPillButton("⇄ Reverse", "#2C2C2C", v -> {
            Collections.reverse(workingStops);
            for (int i = 0; i < workingPositions.size(); i++) {
                workingPositions.set(i, 1.0f - workingPositions.get(i));
            }
            trackView.invalidate();
            updateSelectedPointUI.run();
            applyLiveGradientToText.run();
        });
        LinearLayout.LayoutParams rvLp = new LinearLayout.LayoutParams(0, dp(28), 1f);
        rvLp.setMargins(0, 0, dp(4), 0);
        reverseBtn.setLayoutParams(rvLp);
        toolsRow1.addView(reverseBtn);

        TextView saveGradBtn = createCustomDialogPillButton("Save to Palette", "#2C2C2C", v -> {
            saveGradientToUnifiedPalette(workingStops, workingPositions, gradientAngle, gradientSpacing);
            Toast.makeText(activity, "Gradient Saved to Palette!", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams sgLp = new LinearLayout.LayoutParams(0, dp(28), 1f);
        saveGradBtn.setLayoutParams(sgLp);
        toolsRow1.addView(saveGradBtn);

        box.addView(toolsRow1);

        // ১ নম্বর ইমেজ ফিক্স: ANGLE স্লাইডার (০° - ৩৬০°)
        LinearLayout angleHeader = new LinearLayout(activity);
        angleHeader.setOrientation(LinearLayout.HORIZONTAL);
        angleHeader.setPadding(0, dp(2), 0, dp(1));

        final TextView angleLbl = new TextView(activity);
        angleLbl.setText("Gradient Angle: " + gradientAngle + "°");
        angleLbl.setTextColor(Color.WHITE);
        angleLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        angleLbl.setTypeface(null, Typeface.BOLD);
        angleLbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        angleHeader.addView(angleLbl);
        box.addView(angleHeader);

        final SeekBar angleSeekBar = new SeekBar(activity);
        angleSeekBar.setMax(360);
        angleSeekBar.setProgress(gradientAngle);
        applyCustomSeekBarStyle(angleSeekBar);
        box.addView(angleSeekBar);

        angleLbl.setOnClickListener(v -> showCustomNumericKeypad(angleLbl, "Angle", 0, 360, gradientAngle, val -> {
            gradientAngle = (int) val;
            angleSeekBar.setProgress(gradientAngle);
            angleLbl.setText("Gradient Angle: " + gradientAngle + "°");
            applyLiveGradientToText.run();
        }));

        angleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    gradientAngle = progress;
                    angleLbl.setText("Gradient Angle: " + gradientAngle + "°");
                    applyLiveGradientToText.run();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // ১ নম্বর ইমেজ ফিক্স: SPACING স্লাইডার (১০% - ৩০০%)
        LinearLayout spacingHeader = new LinearLayout(activity);
        spacingHeader.setOrientation(LinearLayout.HORIZONTAL);
        spacingHeader.setPadding(0, dp(6), 0, dp(1));

        final TextView spacingLbl = new TextView(activity);
        spacingLbl.setText("Gradient Spacing: " + gradientSpacing + "%");
        spacingLbl.setTextColor(Color.WHITE);
        spacingLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        spacingLbl.setTypeface(null, Typeface.BOLD);
        spacingLbl.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        spacingHeader.addView(spacingLbl);
        box.addView(spacingHeader);

        final SeekBar spacingSeekBar = new SeekBar(activity);
        spacingSeekBar.setMax(290); // 10 to 300
        spacingSeekBar.setProgress(Math.max(0, gradientSpacing - 10));
        applyCustomSeekBarStyle(spacingSeekBar);
        box.addView(spacingSeekBar);

        spacingLbl.setOnClickListener(v -> showCustomNumericKeypad(spacingLbl, "Gradient Spacing", 10, 300, gradientSpacing, val -> {
            gradientSpacing = (int) val;
            spacingSeekBar.setProgress(Math.max(0, gradientSpacing - 10));
            spacingLbl.setText("Gradient Spacing: " + gradientSpacing + "%");
            applyLiveGradientToText.run();
        }));

        spacingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    gradientSpacing = progress + 10;
                    spacingLbl.setText("Gradient Spacing: " + gradientSpacing + "%");
                    applyLiveGradientToText.run();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(10), 0, 0);

        Button applyGradBtn = new Button(activity);
        applyGradBtn.setText("APPLY");
        applyGradBtn.setTextColor(Color.WHITE);
        applyGradBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        applyGradBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(applyGradBtn, "#FF1238");
        applyGradBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 1.2f));

        applyGradBtn.setOnClickListener(v -> {
            applyLiveGradientToText.run();
            Toast.makeText(activity, "Gradient Applied Live", Toast.LENGTH_SHORT).show();
            gd.dismiss();
        });
        btnRow.addView(applyGradBtn);

        View g = new View(activity); g.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(1))); btnRow.addView(g);

        Button closeBtn = new Button(activity);
        closeBtn.setText("CLOSE");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(closeBtn, "#2C2C2C");
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(32), 0.8f));
        closeBtn.setOnClickListener(v -> gd.dismiss());
        btnRow.addView(closeBtn);

        box.addView(btnRow);

        gd.setContentView(box);
        gd.show();
    }

    // =========================================================================
    // ২ নম্বর ইমেজ ফিক্স: Pick Color ডায়ালগে মোট ৩টি স্লাইডার (সাদা, কালো ও আলফা)
    // =========================================================================
    private void showStandaloneColorPicker(int initialColor, OnColorPickListener listener) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(250), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        box.setBackground(createDialogBg());

        TextView title = new TextView(activity);
        title.setText("Pick Color");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(6));
        box.addView(title);

        final View preview = new View(activity);
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22));
        pvLp.setMargins(0, 0, 0, dp(6));
        preview.setLayoutParams(pvLp);
        updateColorPreview(preview, initialColor);
        box.addView(preview);

        final int[] picked = {initialColor};
        final float[] hsv = new float[3];
        Color.colorToHSV(initialColor, hsv);
        final int[] curAlpha = {Color.alpha(initialColor)};

        final RectColorBoxView rectBox = new RectColorBoxView(activity);
        rectBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(75)));
        rectBox.setColorHSV(hsv);
        box.addView(rectBox);

        // ২ নম্বর ইমেজ সমাধান: ৩টি স্লাইডার (Saturation, Value/Brightness এবং Alpha)
        final GradientSliderView satSlider = new GradientSliderView(activity);
        final GradientSliderView valSlider = new GradientSliderView(activity);
        final GradientSliderView alphaSlider = new GradientSliderView(activity);

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(13));
        slp.setMargins(0, dp(2.5f), 0, dp(2.5f));
        satSlider.setLayoutParams(slp);
        valSlider.setLayoutParams(slp);
        alphaSlider.setLayoutParams(slp);

        satSlider.setProgress(hsv[1]);
        valSlider.setProgress(hsv[2]);
        alphaSlider.setProgress(curAlpha[0] / 255f);

        final Runnable updateSliderColors = () -> {
            float[] tempHSV = new float[]{hsv[0], 0f, hsv[2]};
            int colWhite = Color.HSVToColor(tempHSV);
            tempHSV[1] = 1f;
            int colSat = Color.HSVToColor(tempHSV);
            satSlider.setGradientColors(colWhite, colSat);

            tempHSV[1] = hsv[1];
            tempHSV[2] = 0f;
            int colBlack = Color.HSVToColor(tempHSV);
            tempHSV[2] = 1f;
            int colBright = Color.HSVToColor(tempHSV);
            valSlider.setGradientColors(colBlack, colBright);

            int colOpaque = Color.HSVToColor(255, hsv);
            alphaSlider.setGradientColors(Color.TRANSPARENT, colOpaque);
        };
        updateSliderColors.run();

        rectBox.setOnHueChangeListener((newHue, newSatVal) -> {
            hsv[0] = newHue;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(preview, picked[0]);
            updateSliderColors.run();
        });

        satSlider.setOnSliderChangeListener(prog -> {
            hsv[1] = prog;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(preview, picked[0]);
            updateSliderColors.run();
            rectBox.setColorHSV(hsv);
        });

        valSlider.setOnSliderChangeListener(prog -> {
            hsv[2] = prog;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(preview, picked[0]);
            updateSliderColors.run();
            rectBox.setColorHSV(hsv);
        });

        alphaSlider.setOnSliderChangeListener(prog -> {
            curAlpha[0] = Math.round(prog * 255f);
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(preview, picked[0]);
            updateSliderColors.run();
        });

        box.addView(satSlider);
        box.addView(valSlider);
        box.addView(alphaSlider);

        Button ok = new Button(activity);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        ok.setTypeface(null, Typeface.BOLD);
        setButtonBg(ok, "#FF1238");
        LinearLayout.LayoutParams okLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        okLp.setMargins(0, dp(6), 0, 0);
        ok.setLayoutParams(okLp);
        ok.setOnClickListener(v -> {
            if (listener != null) listener.onColorPicked(picked[0]);
            d.dismiss();
        });
        box.addView(ok);

        d.setContentView(box);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.show();
    }

    // =========================================================================
    // ড্র্যাগেবল Gradient Templates ডায়ালগ (নাম ও সার্চসহ)
    // =========================================================================
    public static class TemplateViewModel {
        public String name;
        public int[] colors;

        public TemplateViewModel(String name, int[] colors) {
            this.name = name;
            this.colors = colors;
        }
    }

    private void showGradientTemplatesDialog() {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(320), dp(360)));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(12), dp(14), dp(12));
        box.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(activity);
        title.setText("Gradient Templates");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(title);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> d.dismiss());
        header.addView(closeX);
        box.addView(header);

        final WindowManager.LayoutParams wmlp = d.getWindow().getAttributes();
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        d.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final TextView searchBox = new TextView(activity);
        searchBox.setHint("Search by name (e.g. Gold, Sunset, Neon)...");
        searchBox.setHintTextColor(Color.parseColor("#777777"));
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        searchBox.setBackground(createInputBg());
        searchBox.setPadding(dp(8), dp(6), dp(8), dp(6));
        searchBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
        box.addView(searchBox);

        ScrollView sv = new ScrollView(activity);
        LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        svLp.setMargins(0, dp(6), 0, dp(6));
        sv.setLayoutParams(svLp);

        final LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        box.addView(sv);

        final List<TemplateViewModel> templates = loadGradientTemplatesFromClass();

        final Runnable renderTemplates = () -> {
            list.removeAllViews();
            String query = searchBox.getText().toString().trim().toLowerCase();

            if (templates.isEmpty()) {
                TextView emptyTv = new TextView(activity);
                emptyTv.setText("No templates found in gradient.java");
                emptyTv.setTextColor(Color.parseColor("#777777"));
                emptyTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
                emptyTv.setGravity(Gravity.CENTER);
                emptyTv.setPadding(0, dp(40), 0, 0);
                list.addView(emptyTv);
                return;
            }

            for (int i = 0; i < templates.size(); i++) {
                final TemplateViewModel item = templates.get(i);
                if (!query.isEmpty() && !item.name.toLowerCase().contains(query)) continue;

                LinearLayout row = new LinearLayout(activity);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(3), 0, dp(3));

                TextView nameTv = new TextView(activity);
                nameTv.setText(item.name);
                nameTv.setTextColor(Color.WHITE);
                nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
                nameTv.setTypeface(null, Typeface.BOLD);
                nameTv.setSingleLine(true);
                nameTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(dp(105), ViewGroup.LayoutParams.WRAP_CONTENT);
                nLp.setMargins(0, 0, dp(6), 0);
                nameTv.setLayoutParams(nLp);
                row.addView(nameTv);

                View gradView = new View(activity);
                LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(0, dp(26), 1f);
                glp.setMargins(0, 0, dp(6), 0);
                gradView.setLayoutParams(glp);

                GradientDrawable gdDrawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, item.colors);
                gdDrawable.setCornerRadius(dp(3));
                gdDrawable.setStroke(dp(1), Color.parseColor("#444444"));
                gradView.setBackground(gdDrawable);
                row.addView(gradView);

                TextView useBtn = createCustomDialogPillButton("Apply", "#2A2A2A", v -> {
                    isGradientText = true;
                    currentGradStops.clear();
                    currentGradPositions.clear();
                    for (int c = 0; c < item.colors.length; c++) {
                        currentGradStops.add(item.colors[c]);
                        currentGradPositions.add(c / (float) Math.max(1, item.colors.length - 1));
                    }
                    applyActiveTextLayerUpdate();
                    Toast.makeText(activity, item.name + " Applied Live!", Toast.LENGTH_SHORT).show();
                    d.dismiss();
                });
                useBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(60), dp(28)));
                row.addView(useBtn);
                list.addView(row);
            }
        };
        renderTemplates.run();

        searchBox.setOnClickListener(v -> showCustomEnglishKeyboard(searchBox, searchBox, text -> renderTemplates.run()));

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CLOSE");
        cancelBtn.setTextColor(Color.WHITE);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(cancelBtn, "#2C2C2C");
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(30));
        cancelBtn.setLayoutParams(cLp);
        cancelBtn.setOnClickListener(v -> d.dismiss());
        box.addView(cancelBtn);

        d.setContentView(box);
        d.show();

        if (d.getWindow() != null) {
            d.getWindow().setLayout(dp(320), dp(360));
        }
    }

    private List<TemplateViewModel> loadGradientTemplatesFromClass() {
        List<TemplateViewModel> list = new ArrayList<>();
        try {
            Class<?> gClass = Class.forName("com.example.ejitor.gradient");
            try {
                Method m = gClass.getMethod("getNamedTemplates");
                Object res = m.invoke(null);
                if (res instanceof List) {
                    List<?> l = (List<?>) res;
                    for (Object o : l) {
                        Field nameF = o.getClass().getField("name");
                        Field colF = o.getClass().getField("colors");
                        String n = (String) nameF.get(o);
                        int[] c = (int[]) colF.get(o);
                        list.add(new TemplateViewModel(n, c));
                    }
                }
            } catch (Exception ignored) {
                Method mOld = gClass.getMethod("getTemplates");
                Object resOld = mOld.invoke(null);
                if (resOld instanceof List) {
                    List<int[]> l = (List<int[]>) resOld;
                    for (int i = 0; i < l.size(); i++) {
                        list.add(new TemplateViewModel("Template " + (i + 1), l.get(i)));
                    }
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    private void showFontDropdownUnderButton(View anchor) {
        final PopupWindow popup = new PopupWindow(activity);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.setBackground(createDialogBg());

        LinearLayout topRow = new LinearLayout(activity);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(activity);
        title.setText("Select Font");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topRow.addView(title);

        Button importBtn = new Button(activity);
        importBtn.setText("+ Import");
        importBtn.setTextColor(Color.WHITE);
        importBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        importBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(importBtn, "#FF1238");
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(76), dp(28));
        importBtn.setLayoutParams(ip);
        importBtn.setOnClickListener(v -> {
            popup.dismiss();
            launchFontFilePicker(optFontBtn);
        });
        topRow.addView(importBtn);

        root.addView(topRow);

        final TextView searchBox = new TextView(activity);
        searchBox.setHint("Search font...");
        searchBox.setHintTextColor(Color.parseColor("#666666"));
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        searchBox.setBackground(createInputBg());
        searchBox.setPadding(dp(8), dp(4), dp(8), dp(4));
        searchBox.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(32)));
        root.addView(searchBox);

        ScrollView sv = new ScrollView(activity);
        sv.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(230)));
        final LinearLayout fontListLayout = new LinearLayout(activity);
        fontListLayout.setOrientation(LinearLayout.VERTICAL);
        sv.addView(fontListLayout);
        root.addView(sv);

        final Runnable renderList = () -> {
            fontListLayout.removeAllViews();
            String q = searchBox.getText().toString().trim().toLowerCase();

            for (final FontItem fi : fontList) {
                if (!q.isEmpty() && !fi.name.toLowerCase().contains(q)) continue;

                TextView itemTv = new TextView(activity);
                itemTv.setText(fi.name);
                itemTv.setTextColor(fi == selectedFont ? Color.parseColor("#FF1238") : Color.WHITE);
                itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
                if (fi.typeface != null) itemTv.setTypeface(fi.typeface);
                itemTv.setPadding(dp(8), dp(8), dp(8), dp(8));

                itemTv.setOnClickListener(v -> {
                    selectedFont = fi;
                    if (optFontBtn != null) {
                        optFontBtn.setText(fi.name + " ▾");
                        if (fi.typeface != null) optFontBtn.setTypeface(fi.typeface);
                    }
                    applyActiveTextLayerUpdate();
                    popup.dismiss();
                });
                fontListLayout.addView(itemTv);
            }
        };
        renderList.run();

        searchBox.setOnClickListener(v -> showCustomEnglishKeyboard(searchBox, searchBox, text -> renderList.run()));

        popup.setContentView(root);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, 0);
    }

    // =========================================================================
    // ড্র্যাগেবল Relative Position
    // =========================================================================
    private void showFloatingAlignDialog() {
        if (floatingAlignDialog != null && floatingAlignDialog.isShowing()) {
            floatingAlignDialog.dismiss();
            return;
        }

        floatingAlignDialog = new Dialog(activity);
        floatingAlignDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        floatingAlignDialog.setCancelable(false);
        floatingAlignDialog.setCanceledOnTouchOutside(false);

        if (floatingAlignDialog.getWindow() != null) {
            floatingAlignDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            floatingAlignDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            floatingAlignDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            floatingAlignDialog.getWindow().setGravity(Gravity.TOP | Gravity.START);
        }

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(240), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(14));
        root.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(8));

        TextView title = new TextView(activity);
        title.setText("Relative Position");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(title);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> floatingAlignDialog.dismiss());
        header.addView(closeX);
        root.addView(header);

        final WindowManager.LayoutParams wmlp = floatingAlignDialog.getWindow().getAttributes();
        wmlp.x = dp(80);
        wmlp.y = dp(70);

        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        floatingAlignDialog.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        LinearLayout row1 = new LinearLayout(activity);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setWeightSum(3);
        LinearLayout.LayoutParams rLp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        rLp1.setMargins(0, 0, 0, dp(4));
        row1.setLayoutParams(rLp1);

        row1.addView(createAlignGridBtn(createVectorAlignLeftIcon(), "Left", v -> performAlign(1)));
        row1.addView(createAlignGridBtn(createVectorAlignCenterHIcon(), "Center", v -> performAlign(0)));
        row1.addView(createAlignGridBtn(createVectorAlignRightIcon(), "Right", v -> performAlign(2)));
        root.addView(row1);

        LinearLayout row2 = new LinearLayout(activity);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setWeightSum(3);
        LinearLayout.LayoutParams rLp2 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
        rLp2.setMargins(0, 0, 0, dp(6));
        row2.setLayoutParams(rLp2);

        row2.addView(createAlignGridBtn(createVectorAlignTopIcon(), "Top", v -> performAlign(3)));
        row2.addView(createAlignGridBtn(createVectorAlignCenterVIcon(), "Middle", v -> performAlign(4)));
        row2.addView(createAlignGridBtn(createVectorAlignBottomIcon(), "Bottom", v -> performAlign(5)));
        root.addView(row2);

        LinearLayout btnCenterBoth = createAlignGridBtn(createVectorAlignCenterBothIcon(), "Center Both", v -> performAlign(6));
        btnCenterBoth.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        setButtonBg(btnCenterBoth, "#FF1238");
        root.addView(btnCenterBoth);

        floatingAlignDialog.setContentView(root);
        floatingAlignDialog.show();
    }

    private LinearLayout createAlignGridBtn(Drawable vectorIcon, String label, View.OnClickListener l) {
        LinearLayout b = new LinearLayout(activity);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(4), 0, dp(4), 0);
        setButtonBg(b, "#2A2A2A");

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(lp);

        if (vectorIcon != null) {
            ImageView iv = new ImageView(activity);
            iv.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
            iv.setImageDrawable(vectorIcon);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            b.addView(iv);
        }

        TextView tv = new TextView(activity);
        tv.setText(" " + label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setSingleLine(true);
        tv.setIncludeFontPadding(false);
        b.addView(tv);

        if (l != null) b.setOnClickListener(l);
        return b;
    }

    private void performAlign(int mode) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        if (layer.bitmap == null) return;

        float layerW = layer.bitmap.getWidth() * layer.scaleX;
        float layerH = layer.bitmap.getHeight() * layer.scaleY;
        float offset = s.currentActiveArtboard * (s.canvasWidth + dp(16f));

        switch (mode) {
            case 0:
                layer.x = offset + (s.canvasWidth - layerW) / 2f;
                break;
            case 1:
                layer.x = offset;
                break;
            case 2:
                layer.x = offset + s.canvasWidth - layerW;
                break;
            case 3:
                layer.y = 0;
                break;
            case 4:
                layer.y = (s.canvasHeight - layerH) / 2f;
                break;
            case 5:
                layer.y = s.canvasHeight - layerH;
                break;
            case 6:
                layer.x = offset + (s.canvasWidth - layerW) / 2f;
                layer.y = (s.canvasHeight - layerH) / 2f;
                break;
        }

        layer.isDirty = true;
        if (activity.canvasView != null) activity.canvasView.invalidate();
        activity.recordHistory();
    }

    // =========================================================================
    // এডিট টেক্সট ডায়ালগ (আসল সিস্টেম কিবোর্ড ব্যবহৃত হবে)
    // =========================================================================
    private void openTextInputOnlyDialog(final boolean isEditingExisting) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setGravity(Gravity.CENTER);
        }

        if (isEditingExisting) {
            EditorActivity.ProjectTabSession s = activity.getCurrentSession();
            if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
                TextLayerMeta meta = textLayerMetaMap.get(layer);
                if (meta != null && meta.text != null && !meta.text.isEmpty()) {
                    currentText = meta.text;
                } else if (layer.name != null && layer.name.startsWith("Text (") && layer.name.endsWith(")")) {
                    currentText = layer.name.substring(6, layer.name.length() - 1);
                }
            }
        }

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(18));
        root.setBackground(createDialogBg());

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(12));

        TextView titleTv = new TextView(activity);
        titleTv.setText(isEditingExisting ? "Edit Text" : "Add Text");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        closeX.setOnClickListener(v -> dialog.dismiss());
        header.addView(closeX);
        root.addView(header);

        final EditText inputEt = new EditText(activity);
        inputEt.setText(currentText);
        inputEt.setTextColor(Color.WHITE);
        inputEt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        inputEt.setHint("Enter text here...");
        inputEt.setHintTextColor(Color.parseColor("#666666"));
        inputEt.setPadding(dp(12), dp(10), dp(12), dp(10));
        inputEt.setBackground(createInputBg());
        inputEt.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));
        root.addView(inputEt);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnRow.setPadding(0, dp(14), 0, 0);

        Button btnCancel = new Button(activity);
        btnCancel.setText("Cancel");
        btnCancel.setTextColor(Color.parseColor("#E0E0E0"));
        btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        setButtonBg(btnCancel, "#262626");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(70), dp(32));
        cp.setMargins(0, 0, dp(8), 0);
        btnCancel.setLayoutParams(cp);
        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnRow.addView(btnCancel);

        Button btnOk = new Button(activity);
        btnOk.setText(isEditingExisting ? "UPDATE" : "ADD TEXT");
        btnOk.setTextColor(Color.WHITE);
        btnOk.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnOk.setTypeface(null, Typeface.BOLD);
        setButtonBg(btnOk, "#FF1238");
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(dp(85), dp(32)));

        btnOk.setOnClickListener(v -> {
            String txt = inputEt.getText().toString().trim();
            if (!txt.isEmpty()) {
                currentText = txt;
                if (isEditingExisting) {
                    EditorActivity.ProjectTabSession s = activity.getCurrentSession();
                    if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
                        TextLayerMeta meta = textLayerMetaMap.get(layer);
                        if (meta != null) {
                            meta.text = currentText;
                            layer.name = "Text (" + currentText + ")";
                            Bitmap sharp = renderUltraSharpTextBitmap(meta.text, meta.baseSize, meta.letterSpacing, meta.color, meta.font, meta.bold, meta.italic, meta.isGrad, meta.gradAngle, meta.gradSpacing, meta.gradColors, meta.gradPositions);
                            layer.bitmap = sharp;
                            layer.isDirty = true;
                            if (activity.canvasView != null) activity.canvasView.invalidate();
                            activity.recordHistory();
                            dialog.dismiss();
                            Toast.makeText(activity, "Text Updated", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                }
                addTextLayerToCanvas(currentText, currentTextSize, currentLetterSpacing, currentTextColor, selectedFont.typeface, isBold, isItalic);
                dialog.dismiss();
            } else {
                Toast.makeText(activity, "Please enter some text", Toast.LENGTH_SHORT).show();
            }
        });
        btnRow.addView(btnOk);

        root.addView(btnRow);
        dialog.setContentView(root);
        dialog.show();
    }

    // =========================================================================
    // 2.5x Super-Sampled Vector Sharp Text (যেকোনো সংখ্যক স্টপের নিখুঁত রেন্ডারিং)
    // =========================================================================
    private void addTextLayerToCanvas(String text, float size, float spacing, int color, Typeface font, boolean bold, boolean italic) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null) return;

        Bitmap textBmp = renderUltraSharpTextBitmap(text, size, spacing, color, font, bold, italic, isGradientText, gradientAngle, gradientSpacing, currentGradStops, currentGradPositions);

        float initialScale = 1f / 2.5f;
        float displayW = textBmp.getWidth() * initialScale;
        float displayH = textBmp.getHeight() * initialScale;

        float posX = (s.canvasWidth - displayW) / 2f;
        float posY = (s.canvasHeight - displayH) / 2f;

        EditorActivity.LayerItem textLayer = new EditorActivity.LayerItem("Text (" + text + ")", textBmp, posX, posY, false);
        textLayer.scaleX = initialScale;
        textLayer.scaleY = initialScale;
        textLayer.isBlank = false;
        textLayer.isDirty = true;

        textLayerMetaMap.put(textLayer, new TextLayerMeta(text, size, spacing, color, font, bold, italic, isGradientText, gradientAngle, gradientSpacing, currentGradStops, currentGradPositions));

        synchronized (s.layers) {
            s.layers.add(textLayer);
            s.activeLayerIndex = s.layers.size() - 1;
        }

        invokePrivateMethod(activity, "recordHistory");
        invokePrivateMethod(activity, "updateLayersDockUI");
        invokePrivateSessionMethod(activity, "saveProjectToDisk", s);
        if (activity.canvasView != null) activity.canvasView.invalidate();
        Toast.makeText(activity, "Text Added (Ultra HD Sharp)", Toast.LENGTH_SHORT).show();
    }

    private Bitmap renderUltraSharpTextBitmap(String text, float size, float spacing, int color, Typeface font, boolean bold, boolean italic, boolean isGrad, int angle, int gradSpread, List<Integer> gradColorsList, List<Float> gradPositionsList) {
        float superSample = 2.5f;
        float renderSize = dp(size) * superSample;

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG | Paint.DEV_KERN_TEXT_FLAG | Paint.FILTER_BITMAP_FLAG);
        paint.setTextSize(renderSize);
        paint.setDither(true);

        if (spacing != 0) {
            paint.setLetterSpacing(spacing / 35f);
        } else {
            paint.setLetterSpacing(0f);
        }

        int style = Typeface.NORMAL;
        if (bold && italic) style = Typeface.BOLD_ITALIC;
        else if (bold) style = Typeface.BOLD;
        else if (italic) style = Typeface.ITALIC;

        if (font != null) {
            paint.setTypeface(Typeface.create(font, style));
        }

        Paint.FontMetricsInt fmi = paint.getFontMetricsInt();
        int textWidth = (int) Math.ceil(paint.measureText(text));
        int textHeight = fmi.bottom - fmi.top;

        int pad = Math.max(16, (int) (renderSize * 0.12f));
        int w = Math.max(10, textWidth + pad * 2);
        int h = Math.max(10, textHeight + pad * 2);

        if (isGrad && gradColorsList != null && gradColorsList.size() >= 2) {
            List<StopPointItem> sorted = new ArrayList<>();
            for (int i = 0; i < gradColorsList.size(); i++) {
                float pos = (gradPositionsList != null && i < gradPositionsList.size()) ? gradPositionsList.get(i) : (i / (float)(gradColorsList.size() - 1));
                sorted.add(new StopPointItem(gradColorsList.get(i), pos, i));
            }
            Collections.sort(sorted, (a, b) -> Float.compare(a.position, b.position));

            int[] colArr = new int[sorted.size()];
            float[] posArr = new float[sorted.size()];
            for (int i = 0; i < sorted.size(); i++) {
                colArr[i] = sorted.get(i).color;
                posArr[i] = Math.max(0f, Math.min(1f, sorted.get(i).position));
                if (i > 0 && posArr[i] < posArr[i - 1]) {
                    posArr[i] = posArr[i - 1];
                }
            }

            float spreadFactor = Math.max(0.1f, gradSpread / 100f);
            float effW = Math.max(1f, (float) textWidth * spreadFactor);
            float effH = Math.max(1f, (float) textHeight * spreadFactor);

            double rad = Math.toRadians(angle);
            float x0 = pad;
            float y0 = pad;
            float x1 = pad + (float) (Math.cos(rad) * effW);
            float y1 = pad + (float) (Math.sin(rad) * effH);

            LinearGradient lg = new LinearGradient(x0, y0, x1, y1, colArr, posArr, Shader.TileMode.CLAMP);
            paint.setShader(lg);
        } else {
            paint.setShader(null);
            paint.setColor(color);
        }

        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bmp.setDensity(Bitmap.DENSITY_NONE);
        Canvas c = new Canvas(bmp);

        int baselineY = pad - fmi.top;
        c.drawText(text, pad, baselineY, paint);
        return bmp;
    }

    private void setupTransformQualityWatcher() {
        if (activity == null) return;
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    EditorActivity.ProjectTabSession s = activity.getCurrentSession();
                    if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
                        TextLayerMeta meta = textLayerMetaMap.get(layer);
                        if (meta != null && layer.bitmap != null) {
                            if (layer.scaleX > 1.2f) {
                                float newBaseSize = meta.baseSize * (layer.scaleX * 2.5f);
                                Bitmap sharp = renderUltraSharpTextBitmap(meta.text, newBaseSize, meta.letterSpacing, meta.color, meta.font, meta.bold, meta.italic, meta.isGrad, meta.gradAngle, meta.gradSpacing, meta.gradColors, meta.gradPositions);
                                layer.bitmap = sharp;
                                layer.scaleX = 1f / 2.5f;
                                layer.scaleY = 1f / 2.5f;
                                layer.isDirty = true;
                                if (activity.canvasView != null) activity.canvasView.invalidate();
                            }
                        }
                    }
                } catch (Exception ignored) {}
                mainHandler.postDelayed(this, 1000);
            }
        });
    }

    private void applyActiveTextLayerUpdate() {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        EditorActivity.LayerItem layer = s.layers.get(s.activeLayerIndex);
        TextLayerMeta meta = textLayerMetaMap.get(layer);
        if (meta == null && layer.name != null && layer.name.startsWith("Text (")) {
            String raw = layer.name.substring(6, layer.name.length() - 1);
            meta = new TextLayerMeta(raw, currentTextSize, currentLetterSpacing, currentTextColor, selectedFont.typeface, isBold, isItalic, isGradientText, gradientAngle, gradientSpacing, currentGradStops, currentGradPositions);
            textLayerMetaMap.put(layer, meta);
        }

        if (meta != null) {
            meta.font = selectedFont.typeface;
            meta.color = currentTextColor;
            meta.bold = isBold;
            meta.italic = isItalic;
            meta.baseSize = currentTextSize;
            meta.letterSpacing = currentLetterSpacing;
            meta.isGrad = isGradientText;
            meta.gradAngle = gradientAngle;
            meta.gradSpacing = gradientSpacing;
            meta.gradColors.clear();
            meta.gradColors.addAll(currentGradStops);
            meta.gradPositions.clear();
            meta.gradPositions.addAll(currentGradPositions);

            Bitmap sharp = renderUltraSharpTextBitmap(meta.text, meta.baseSize, meta.letterSpacing, meta.color, meta.font, meta.bold, meta.italic, meta.isGrad, meta.gradAngle, meta.gradSpacing, meta.gradColors, meta.gradPositions);
            layer.bitmap = sharp;
            layer.isDirty = true;
            if (activity.canvasView != null) activity.canvasView.invalidate();
            activity.recordHistory();
        }
    }

    private void showSelectTextLayerDialog() {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.layers.isEmpty()) {
            Toast.makeText(activity, "No layers available", Toast.LENGTH_SHORT).show();
            return;
        }

        final List<Integer> textLayerIndices = new ArrayList<>();
        for (int i = 0; i < s.layers.size(); i++) {
            if (textLayerMetaMap.containsKey(s.layers.get(i)) || s.layers.get(i).name.toLowerCase().contains("text")) {
                textLayerIndices.add(i);
            }
        }

        if (textLayerIndices.isEmpty()) {
            Toast.makeText(activity, "No text layer found. Click '+ New Text' to create one.", Toast.LENGTH_SHORT).show();
            return;
        }

        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(220), dp(250)));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(createDialogBg());

        TextView title = new TextView(activity);
        title.setText("Select Text Layer");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(10));
        box.addView(title);

        for (final int idx : textLayerIndices) {
            EditorActivity.LayerItem item = s.layers.get(idx);
            Button btn = new Button(activity);
            btn.setText(item.name);
            btn.setTextColor(Color.WHITE);
            btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            setButtonBg(btn, (s.activeLayerIndex == idx) ? "#FF1238" : "#2A2A2A");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32));
            lp.setMargins(0, 0, 0, dp(4));
            btn.setLayoutParams(lp);

            btn.setOnClickListener(v -> {
                s.activeLayerIndex = idx;
                TextLayerMeta meta = textLayerMetaMap.get(item);
                if (meta != null) {
                    currentText = meta.text;
                    currentTextSize = meta.baseSize;
                    currentLetterSpacing = meta.letterSpacing;
                    currentTextColor = meta.color;
                    isBold = meta.bold;
                    isItalic = meta.italic;
                    isGradientText = meta.isGrad;
                    gradientAngle = meta.gradAngle;
                    gradientSpacing = meta.gradSpacing;
                    currentGradStops.clear();
                    currentGradStops.addAll(meta.gradColors);
                    currentGradPositions.clear();
                    currentGradPositions.addAll(meta.gradPositions);
                    if (optFontBtn != null && meta.font != null) {
                        optFontBtn.setText(selectedFont.name + " ▾");
                        optFontBtn.setTypeface(meta.font);
                    }
                    if (optSizeTv != null) optSizeTv.setText("Size: " + (int) currentTextSize + " px");
                    if (optSpacingTv != null) optSpacingTv.setText("Spacing: " + (int) currentLetterSpacing + " px");
                    if (optColorSwatch != null) updateColorPreview(optColorSwatch, currentTextColor);
                }
                invokePrivateMethod(activity, "updateLayersDockUI");
                if (activity.canvasView != null) activity.canvasView.invalidate();
                d.dismiss();
                Toast.makeText(activity, "Selected: " + item.name, Toast.LENGTH_SHORT).show();
            });
            box.addView(btn);
        }

        d.setContentView(box);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        d.show();
    }

    public static class FontPickerFragment extends Fragment {
        private TextView targetBtn;
        private editor_5 instance;

        public void setup(editor_5 inst, TextView b) {
            this.instance = inst;
            this.targetBtn = b;
        }

        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            try {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                String[] mimeTypes = {"font/*", "application/x-font-ttf", "application/x-font-otf", "application/octet-stream"};
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, "Select Fonts (.ttf or .otf)"), 9005);
            } catch (Exception e) {
                if (getActivity() != null) {
                    Toast.makeText(getActivity(), "File Picker Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 9005 && resultCode == Activity.RESULT_OK && data != null && instance != null) {
                List<Uri> uris = new ArrayList<>();
                if (data.getClipData() != null) {
                    ClipData cd = data.getClipData();
                    for (int i = 0; i < cd.getItemCount(); i++) {
                        uris.add(cd.getItemAt(i).getUri());
                    }
                } else if (data.getData() != null) {
                    uris.add(data.getData());
                }
                instance.importMultipleFonts(uris, targetBtn);
            }
            if (getActivity() != null && getFragmentManager() != null) {
                getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
            }
        }
    }

    private void launchFontFilePicker(TextView targetBtn) {
        try {
            FontPickerFragment frag = new FontPickerFragment();
            frag.setup(this, targetBtn);
            activity.getFragmentManager().beginTransaction().add(frag, "font_picker_frag_" + System.currentTimeMillis()).commitAllowingStateLoss();
        } catch (Exception e) {
            Toast.makeText(activity, "File Picker Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void importMultipleFonts(List<Uri> uris, TextView targetBtn) {
        int count = 0;
        File fontsDir = new File(activity.getFilesDir(), "custom_fonts");
        if (!fontsDir.exists()) fontsDir.mkdirs();

        for (Uri uri : uris) {
            try {
                String displayName = "font_" + System.currentTimeMillis() + "_" + count + ".ttf";
                Cursor cursor = null;
                try {
                    cursor = activity.getContentResolver().query(uri, null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (nameIndex != -1) {
                            displayName = cursor.getString(nameIndex);
                        }
                    }
                } catch (Exception ignored) {} finally {
                    if (cursor != null) cursor.close();
                }

                File dest = new File(fontsDir, displayName);
                InputStream is = activity.getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(dest);
                byte[] buf = new byte[8192];
                int len;
                while (is != null && (len = is.read(buf)) > 0) {
                    fos.write(buf, 0, len);
                }
                if (is != null) is.close();
                fos.close();

                Typeface tf = Typeface.createFromFile(dest);
                String fontTitle = displayName.replace(".ttf", "").replace(".otf", "").replace("_", " ");
                FontItem newItem = new FontItem(fontTitle, tf, dest.getAbsolutePath());
                fontList.add(newItem);
                selectedFont = newItem;
                count++;
            } catch (Exception ignored) {}
        }

        if (count > 0) {
            if (targetBtn != null && selectedFont != null) {
                targetBtn.setText(selectedFont.name + " ▾");
                targetBtn.setTypeface(selectedFont.typeface);
            }
            applyActiveTextLayerUpdate();
            Toast.makeText(activity, count + " Font(s) Imported Successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(activity, "Failed to import fonts", Toast.LENGTH_SHORT).show();
        }
    }

    private Drawable createDialogBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void updateColorPreview(View v, int color) {
        if (v == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setStroke(dp(1), Color.WHITE);
        gd.setCornerRadius(dp(3));
        v.setBackground(gd);
    }

    private void setButtonBg(View v, String hex) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hex));
        gd.setCornerRadius(dp(4));
        v.setBackground(gd);
    }

    private BitmapDrawable createVectorTextIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.8f));
        c.drawLine(dp(3), dp(4), dp(17), dp(4), p);
        c.drawLine(dp(10), dp(4), dp(10), dp(17), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createCloseVectorDrawable() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    // পিওর ভেক্টর পৃথিবী (Globe) আইকন
    private Drawable createVectorGlobeIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.3f));

        c.drawCircle(dp(9), dp(9), dp(7.5f), p);
        c.drawLine(dp(1.5f), dp(9), dp(16.5f), dp(9), p);
        c.drawLine(dp(9), dp(1.5f), dp(9), dp(16.5f), p);
        RectF oval = new RectF(dp(5f), dp(1.5f), dp(13f), dp(16.5f));
        c.drawOval(oval, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    // পিওর ভেক্টর ব্যাকস্পেস আইকন
    private Drawable createVectorBackspaceIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.3f));
        p.setStrokeJoin(Paint.Join.ROUND);

        Path path = new Path();
        path.moveTo(dp(6), dp(2));
        path.lineTo(dp(17), dp(2));
        path.lineTo(dp(17), dp(14));
        path.lineTo(dp(6), dp(14));
        path.lineTo(dp(1.5f), dp(8));
        path.close();
        c.drawPath(path, p);

        c.drawLine(dp(9), dp(5), dp(14), dp(11), p);
        c.drawLine(dp(14), dp(5), dp(9), dp(11), p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorMenuIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(2f));
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(dp(2), dp(4), dp(16), dp(4), p);
        c.drawLine(dp(2), dp(9), dp(16), dp(9), p);
        c.drawLine(dp(2), dp(14), dp(16), dp(14), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorResizeIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#AAAAAA"));
        p.setStrokeWidth(dp(1.5f));
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(dp(12), dp(4), dp(4), dp(12), p);
        c.drawLine(dp(13), dp(8), dp(8), dp(13), p);
        c.drawLine(dp(13), dp(12), dp(12), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignLeftIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.8f));
        c.drawLine(dp(2), dp(2), dp(2), dp(14), p);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(5), dp(4), dp(14), dp(7.5f)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(5), dp(9.5f), dp(11), dp(13)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignCenterHIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#FF1238"));
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(8), dp(1.5f), dp(8), dp(14.5f), p);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(2.5f), dp(4), dp(13.5f), dp(7.5f)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(4.5f), dp(9.5f), dp(11.5f), dp(13)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignRightIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.8f));
        c.drawLine(dp(14), dp(2), dp(14), dp(14), p);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(2), dp(4), dp(11), dp(7.5f)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(5), dp(9.5f), dp(11), dp(13)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignTopIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.8f));
        c.drawLine(dp(2), dp(2), dp(14), dp(2), p);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(4), dp(5), dp(7.5f), dp(14)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(9.5f), dp(5), dp(13), dp(11)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignCenterVIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#FF1238"));
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(1.5f), dp(8), dp(14.5f), dp(8), p);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(4), dp(2.5f), dp(7.5f), dp(13.5f)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(9.5f), dp(4.5f), dp(13), dp(11.5f)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignBottomIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.8f));
        c.drawLine(dp(2), dp(14), dp(14), dp(14), p);
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(dp(4), dp(2), dp(7.5f), dp(11)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(9.5f), dp(5), dp(13), dp(11)), dp(1), dp(1), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createVectorAlignCenterBothIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(8), dp(2), dp(8), dp(14), p);
        c.drawLine(dp(2), dp(8), dp(14), dp(8), p);
        p.setStyle(Paint.Style.STROKE);
        c.drawCircle(dp(8), dp(8), dp(4.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createInputBg() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor("#121212"));
        d.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        d.setCornerRadius(dp(4));
        return d;
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(8), dp(6), dp(10));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }
}
