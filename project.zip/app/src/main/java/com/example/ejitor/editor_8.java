package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class editor_8 implements EditorActivity.EditorModule {

    public static editor_8 instance;
    private EditorActivity activity;

    // ব্রাশ সেটিংস (১০০০ লিমিট সাপোর্ট)
    public float brushSize = 30f;
    public float brushOpacity = 1.0f;
    public float brushHardness = 1.0f; // -1000 to +1000 সাপোর্ট
    public float brushSpacing = -60f;  // -100 to +100 সাপোর্ট (ডিফল্ট -৬০% যাতে একদম মসৃণ থাকে)
    public float brushScatter = 0f;
    public float brushAngle = 0f;      // 0 to 360
    public float brushRoundness = 1.0f;// 0.1 to 1.0
    public boolean brushPressureEnabled = false;

    // ব্রাশ মোড: 0 = Normal, 1 = Eraser, 2 = Blur
    public int brushMode = 0;

    public String currentBrushType = "Hard Round 24";
    public int brushColor = Color.parseColor("#FF1238");
    public Bitmap currentCustomTip = null;

    private Paint brushPaint;
    private Paint stampPaint;
    private final Path strokePath = new Path();
    private float lastLocalX, lastLocalY;
    private boolean isDrawing = false;
    public boolean isBrushActive = false;

    private ImageView brushToolBtn = null;
    private LinearLayout leftToolbarRef = null;

    // মেমোরি ও ল্যাগ অপ্টিমাইজেশনের ক্যাশড অবজেক্ট
    private final Matrix reusableMatrix = new Matrix();
    private final Random reusableRandom = new Random();

    private static final int REQ_CODE_CUSTOM_BRUSH = 8841;
    private Dialog activeBrushDialog = null;

    // =========================================================================
    // পিউর ভেক্টর ড্রয়েবল আইকনসমূহ (১০০% ভেক্টর, নো ইমোজি)
    // =========================================================================
    public abstract static class BaseVectorDrawable extends Drawable {
        protected final int size;
        protected final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        protected final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public BaseVectorDrawable(int size, int color) {
            this.size = size;
            strokePaint.setColor(color);
            strokePaint.setStyle(Paint.Style.STROKE);
            strokePaint.setStrokeWidth(Math.max(1.8f, size * 0.09f));
            strokePaint.setStrokeCap(Paint.Cap.ROUND);
            strokePaint.setStrokeJoin(Paint.Join.ROUND);

            fillPaint.setColor(color);
            fillPaint.setStyle(Paint.Style.FILL);
            setBounds(0, 0, size, size);
        }

        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public void setAlpha(int alpha) {
            strokePaint.setAlpha(alpha);
            fillPaint.setAlpha(alpha);
        }
        @Override public void setColorFilter(ColorFilter colorFilter) {
            strokePaint.setColorFilter(colorFilter);
            fillPaint.setColorFilter(colorFilter);
        }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private Drawable createCloseVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                float pad = size * 0.25f;
                c.drawLine(b.left + pad, b.top + pad, b.right - pad, b.bottom - pad, strokePaint);
                c.drawLine(b.right - pad, b.top + pad, b.left + pad, b.bottom - pad, strokePaint);
            }
        };
    }

    private Drawable createAddVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();
                float arm = size * 0.32f;
                c.drawLine(cx - arm, cy, cx + arm, cy, strokePaint);
                c.drawLine(cx, cy - arm, cx, cy + arm, strokePaint);
            }
        };
    }

    private Drawable createMinusVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();
                float arm = size * 0.32f;
                c.drawLine(cx - arm, cy, cx + arm, cy, strokePaint);
            }
        };
    }

    private Drawable createFolderVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                float l = b.left + size * 0.14f;
                float t = b.top + size * 0.22f;
                float r = b.right - size * 0.14f;
                float bo = b.bottom - size * 0.20f;

                Path p = new Path();
                p.moveTo(l, bo);
                p.lineTo(l, t);
                p.lineTo(l + size * 0.28f, t);
                p.lineTo(l + size * 0.38f, t + size * 0.12f);
                p.lineTo(r, t + size * 0.12f);
                p.lineTo(r, bo);
                p.close();
                c.drawPath(p, strokePaint);
            }
        };
    }

    private Drawable createArrowDownVectorIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                float cx = b.exactCenterX();
                float cy = b.exactCenterY();
                Path p = new Path();
                p.moveTo(cx - size * 0.25f, cy - size * 0.12f);
                p.lineTo(cx, cy + size * 0.16f);
                p.lineTo(cx + size * 0.25f, cy - size * 0.12f);
                c.drawPath(p, strokePaint);
            }
        };
    }

    private Drawable createResizeGripIcon(int size, int color) {
        return new BaseVectorDrawable(size, color) {
            @Override
            public void draw(Canvas c) {
                Rect b = getBounds();
                c.drawLine(b.right - size * 0.7f, b.bottom - size * 0.1f, b.right - size * 0.1f, b.bottom - size * 0.7f, strokePaint);
                c.drawLine(b.right - size * 0.4f, b.bottom - size * 0.1f, b.right - size * 0.1f, b.bottom - size * 0.4f, strokePaint);
            }
        };
    }

    // =========================================================================
    // হেডলেস ফ্র্যাগমেন্ট (কাস্টম ব্রাশ ফটো পিকার রেজাল্ট গ্যারান্টেড হ্যান্ডলার)
    // =========================================================================
    public static class CustomBrushPickerFragment extends Fragment {
        private editor_8 module;

        public void setModule(editor_8 m) {
            this.module = m;
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQ_CODE_CUSTOM_BRUSH && resultCode == Activity.RESULT_OK && data != null) {
                if (module != null && data.getData() != null) {
                    module.promptCustomBrushCreationDialog(data.getData());
                }
            }
        }
    }

    // =========================================================================
    // ব্রাশ ও ফোল্ডার ডেটা স্ট্রাকচার
    // =========================================================================
    public static class BrushPreset {
        public String name;
        public int sizeNumber;
        public float defaultSize;
        public float hardness;
        public float opacity;
        public float spacing;
        public float angle;
        public float roundness;
        public Bitmap tipBitmap;
        public int mode = 0; // 0 = Normal, 1 = Eraser, 2 = Blur

        public BrushPreset(String name, int sizeNumber, float defaultSize, float hardness, float opacity,
                           float spacing, float angle, float roundness, Bitmap tip) {
            this(name, sizeNumber, defaultSize, hardness, opacity, spacing, angle, roundness, tip, 0);
        }

        public BrushPreset(String name, int sizeNumber, float defaultSize, float hardness, float opacity,
                           float spacing, float angle, float roundness, Bitmap tip, int mode) {
            this.name = name;
            this.sizeNumber = sizeNumber;
            this.defaultSize = defaultSize;
            this.hardness = hardness;
            this.opacity = opacity;
            this.spacing = spacing;
            this.angle = angle;
            this.roundness = roundness;
            this.tipBitmap = tip;
            this.mode = mode;
        }
    }

    public static class BrushFolder {
        public String name;
        public boolean isCustom = false;
        public List<BrushPreset> brushes = new ArrayList<>();
        public BrushFolder(String name, boolean isCustom) {
            this.name = name;
            this.isCustom = isCustom;
        }
    }

    private final List<BrushFolder> brushFolders = new ArrayList<>();

    @Override
    public void init(EditorActivity activity) {
        this.activity = activity;
        instance = this;

        initPaint();
        initAllBrushes();
        loadSavedCustomBrushes();
        setupToolbarAndCanvas();
    }

    private void initPaint() {
        brushPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        brushPaint.setStyle(Paint.Style.STROKE);
        brushPaint.setStrokeJoin(Paint.Join.ROUND);
        brushPaint.setStrokeCap(Paint.Cap.ROUND);

        stampPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        updatePaintSettings();
    }

    public void updatePaintSettings() {
        if (brushPaint == null) return;
        brushPaint.setColor(brushColor);
        brushPaint.setAlpha((int) (brushOpacity * 255));
        brushPaint.setStrokeWidth(brushSize);

        if (brushMode == 1) { // Eraser Mode
            brushPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        } else {
            brushPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OVER));
        }

        if (brushHardness < 0.98f && currentCustomTip == null) {
            float blurRadius = Math.max(1.0f, (1.0f - brushHardness) * (brushSize * 0.25f));
            brushPaint.setMaskFilter(new BlurMaskFilter(blurRadius, BlurMaskFilter.Blur.NORMAL));
        } else {
            brushPaint.setMaskFilter(null);
        }

        if (stampPaint != null) {
            if (brushMode == 1) {
                stampPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                stampPaint.setColorFilter(null);
            } else {
                stampPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_OVER));
                stampPaint.setColorFilter(new PorterDuffColorFilter(brushColor, PorterDuff.Mode.SRC_IN));
            }
            stampPaint.setAlpha((int) (brushOpacity * 255));
        }
    }

    private void initAllBrushes() {
        brushFolders.clear();

        // ফোল্ডার ১: Default (১০টি ব্রাশ - প্রি-সেট স্পেসিং স্মুথ করা হয়েছে)
        BrushFolder fDefault = new BrushFolder("Default", false);
        fDefault.brushes.add(new BrushPreset("Soft Round", 12, 12f, 0.15f, 1f, -60f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Hard Round", 24, 24f, 1.0f, 1f, -70f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Fine Soft", 12, 12f, 0.25f, 1f, -60f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Medium Hard", 24, 24f, 0.75f, 1f, -70f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Airbrush Soft", 76, 76f, 0.05f, 0.75f, -50f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Airbrush Hard", 80, 80f, 0.85f, 0.9f, -60f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Large Round", 105, 105f, 0.45f, 1f, -60f, 0f, 1f, null));
        fDefault.brushes.add(new BrushPreset("Chisel Flat", 87, 87f, 0.9f, 1f, -60f, 45f, 0.35f, null));
        fDefault.brushes.add(new BrushPreset("Calligraphy Nib", 99, 99f, 0.95f, 1f, -70f, 30f, 0.25f, null));
        fDefault.brushes.add(new BrushPreset("Square Block", 20, 20f, 1.0f, 1f, -60f, 0f, 1f, createSquareTip(40)));
        brushFolders.add(fDefault);

        // ফোল্ডার ২: Eraser Brushes (১০টি ইরেজার ব্রাশ)
        BrushFolder fEraser = new BrushFolder("Eraser Brushes", false);
        fEraser.brushes.add(new BrushPreset("Soft Eraser", 20, 30f, 0.1f, 1f, -60f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Hard Eraser", 30, 30f, 1.0f, 1f, -70f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Precision Clean", 10, 15f, 1.0f, 1f, -70f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Medium Fade", 45, 45f, 0.5f, 1f, -60f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Flat Blade Eraser", 60, 60f, 0.9f, 1f, -60f, 45f, 0.3f, null, 1));
        fEraser.brushes.add(new BrushPreset("Air Eraser", 80, 80f, 0.05f, 0.6f, -50f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Heavy Cut", 100, 100f, 1.0f, 1f, -70f, 0f, 1f, null, 1));
        fEraser.brushes.add(new BrushPreset("Square Eraser", 40, 40f, 1.0f, 1f, -60f, 0f, 1f, createSquareTip(40), 1));
        fEraser.brushes.add(new BrushPreset("Oval Soft", 50, 50f, 0.3f, 1f, -60f, 30f, 0.5f, null, 1));
        fEraser.brushes.add(new BrushPreset("Jumbo Eraser", 150, 150f, 0.8f, 1f, -60f, 0f, 1f, null, 1));
        brushFolders.add(fEraser);

        // ফোল্ডার ৩: Blur Brushes (১টি পারফেক্ট গাউসিয়ান ব্লার ব্রাশ)
        BrushFolder fBlur = new BrushFolder("Blur Brushes", false);
        fBlur.brushes.add(new BrushPreset("Gaussian Blur", 50, 50f, 0f, 1.0f, -50f, 0f, 1f, null, 2));
        brushFolders.add(fBlur);

        // ফোল্ডার ৪: Noksha & Ornamental (২০টি ব্রাশ)
        BrushFolder fNoksha = new BrushFolder("Noksha & Icons", false);
        String[] nokshaNames = {"Mandala", "Starburst", "Floral Leaf", "Vine Branch", "Snowflake",
                "Heart Stamp", "Butterfly", "Royal Crown", "Rose Flower", "Diamond Gem",
                "Sunburst", "Tribal Motif", "Sparkle Star", "Feather Plume", "Paisley",
                "Swirl Flourish", "Splatter Dot", "Grunge Blot", "Cloud Poff", "Bokeh Circle"};
        int[] nokshaSizes = {76, 80, 60, 55, 50, 48, 65, 55, 65, 45, 85, 45, 40, 75, 70, 60, 65, 80, 90, 70};

        for (int i = 0; i < 20; i++) {
            Bitmap tipBmp = createNokshaVectorBitmap(i, 80);
            fNoksha.brushes.add(new BrushPreset(nokshaNames[i], nokshaSizes[i], nokshaSizes[i], 1.0f, 1f, 35f, 0f, 1f, tipBmp));
        }
        brushFolders.add(fNoksha);

        // ফোল্ডার ৫: Typography & Lettering (১০টি ব্রাশ)
        BrushFolder fTypo = new BrushFolder("Typography", false);
        String[] typoNames = {"Gothic Flat", "Ribbon Script", "Parallel Pen", "Inking Dip", "Dry Ink",
                "Calligraphy Oval", "Chalk Script", "Marker Bold", "Signature Quill", "Poster Nib"};
        int[] typoSizes = {87, 99, 100, 87, 90, 75, 65, 80, 40, 95};
        float[] typoAngles = {45f, 35f, 30f, 40f, 50f, 25f, 0f, 60f, 45f, 30f};
        float[] typoRounds = {0.2f, 0.25f, 0.15f, 0.3f, 0.35f, 0.4f, 0.8f, 0.4f, 0.25f, 0.2f};

        for (int i = 0; i < 10; i++) {
            Bitmap tipBmp = createTypoVectorBitmap(i, 80);
            fTypo.brushes.add(new BrushPreset(typoNames[i], typoSizes[i], typoSizes[i], 0.95f, 1f, -65f, typoAngles[i], typoRounds[i], tipBmp));
        }
        brushFolders.add(fTypo);

        // ফোল্ডার ৬: Custom (My Brushes)
        BrushFolder fCustom = new BrushFolder("Custom (My Brushes)", false);
        brushFolders.add(fCustom);
    }

    private Bitmap createNokshaVectorBitmap(int type, int s) {
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        float cx = s / 2f, cy = s / 2f, r = s * 0.42f;

        switch (type % 6) {
            case 0:
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s * 0.05f);
                c.drawCircle(cx, cy, r, p);
                c.drawCircle(cx, cy, r * 0.5f, p);
                for (int a = 0; a < 360; a += 30) {
                    double rad = Math.toRadians(a);
                    c.drawLine(cx, cy, (float) (cx + r * Math.cos(rad)), (float) (cy + r * Math.sin(rad)), p);
                }
                break;
            case 1:
                p.setStyle(Paint.Style.FILL);
                for (int a = 0; a < 360; a += 45) {
                    double rad = Math.toRadians(a);
                    float px = (float) (cx + r * 0.6f * Math.cos(rad));
                    float py = (float) (cy + r * 0.6f * Math.sin(rad));
                    c.drawCircle(px, py, r * 0.35f, p);
                }
                c.drawCircle(cx, cy, r * 0.3f, p);
                break;
            case 2:
                p.setStyle(Paint.Style.FILL);
                Path h = new Path();
                h.moveTo(cx, cy + r * 0.8f);
                h.cubicTo(cx - r, cy, cx - r, cy - r * 0.7f, cx, cy - r * 0.2f);
                h.cubicTo(cx + r, cy - r * 0.7f, cx + r, cy, cx, cy + r * 0.8f);
                c.drawPath(h, p);
                break;
            case 3:
                p.setStyle(Paint.Style.FILL);
                Path lf = new Path();
                lf.moveTo(cx - r * 0.7f, cy + r * 0.7f);
                lf.quadTo(cx - r * 0.6f, cy - r * 0.6f, cx + r * 0.7f, cy - r * 0.7f);
                lf.quadTo(cx + r * 0.6f, cy + r * 0.6f, cx - r * 0.7f, cy + r * 0.7f);
                c.drawPath(lf, p);
                break;
            case 4:
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, r * 0.4f, p);
                Random rnd = new Random(type * 77L);
                for (int k = 0; k < 12; k++) {
                    float sx = cx + (rnd.nextFloat() * 2f - 1f) * r * 0.8f;
                    float sy = cy + (rnd.nextFloat() * 2f - 1f) * r * 0.8f;
                    c.drawCircle(sx, sy, r * (0.05f + rnd.nextFloat() * 0.15f), p);
                }
                break;
            default:
                p.setStyle(Paint.Style.FILL);
                Path d = new Path();
                d.moveTo(cx, cy - r);
                d.lineTo(cx + r, cy);
                d.lineTo(cx, cy + r);
                d.lineTo(cx - r, cy);
                d.close();
                c.drawPath(d, p);
                break;
        }
        return b;
    }

    private Bitmap createSquareTip(int s) {
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        c.drawRect(s * 0.1f, s * 0.1f, s * 0.9f, s * 0.9f, p);
        return b;
    }

    private Bitmap createTypoVectorBitmap(int idx, int s) {
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);

        c.save();
        c.rotate(35f + idx * 5f, s / 2f, s / 2f);
        RectF r = new RectF(s * 0.15f, s * 0.40f, s * 0.85f, s * 0.60f);
        c.drawRoundRect(r, s * 0.04f, s * 0.04f, p);
        c.restore();
        return b;
    }

    private void setupToolbarAndCanvas() {
        if (activity == null || activity.canvasView == null) return;

        activity.canvasView.post(() -> {
            try {
                ViewGroup canvasFrame = (ViewGroup) activity.canvasView.getParent();
                ViewGroup workspace = (ViewGroup) canvasFrame.getParent();
                leftToolbarRef = (LinearLayout) workspace.getChildAt(0);

                if (leftToolbarRef != null) {
                    if (leftToolbarRef.findViewWithTag("ejitor_brush_btn") == null) {
                        brushToolBtn = new ImageView(activity);
                        brushToolBtn.setTag("ejitor_brush_btn");
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(28), dp(28));
                        lp.setMargins(0, dp(2), 0, dp(2));
                        brushToolBtn.setLayoutParams(lp);
                        brushToolBtn.setImageDrawable(createVectorBrushIcon());
                        brushToolBtn.setScaleType(ImageView.ScaleType.CENTER);
                        setButtonHighlight(false);

                        brushToolBtn.setOnClickListener(v -> activateBrushTool());

                        int insertIndex = Math.max(0, leftToolbarRef.getChildCount() - 2);
                        leftToolbarRef.addView(brushToolBtn, insertIndex);
                    }
                    hookOtherToolButtons();
                }
                activity.canvasView.setOnTouchListener((v, event) -> handleCanvasTouch(event));
            } catch (Exception ignored) {}
        });
    }

    private void hookOtherToolButtons() {
        if (leftToolbarRef == null) return;
        for (int i = 0; i < leftToolbarRef.getChildCount(); i++) {
            final View child = leftToolbarRef.getChildAt(i);
            if (child instanceof ImageView && child != brushToolBtn) {
                final View.OnClickListener originalClickListener = getExistingClickListener(child);
                child.setOnClickListener(v -> {
                    deactivateBrush();
                    if (originalClickListener != null) originalClickListener.onClick(v);
                });
            }
        }
    }

    private View.OnClickListener getExistingClickListener(View view) {
        try {
            Field listenerInfoField = View.class.getDeclaredField("mListenerInfo");
            listenerInfoField.setAccessible(true);
            Object listenerInfo = listenerInfoField.get(view);
            if (listenerInfo != null) {
                Field clickListenerField = listenerInfo.getClass().getDeclaredField("mOnClickListener");
                clickListenerField.setAccessible(true);
                return (View.OnClickListener) clickListenerField.get(listenerInfo);
            }
        } catch (Exception ignored) {}
        return null;
    }

    public void activateBrushTool() {
        isBrushActive = true;
        setButtonHighlight(true);

        if (leftToolbarRef != null) {
            for (int i = 0; i < leftToolbarRef.getChildCount(); i++) {
                View child = leftToolbarRef.getChildAt(i);
                if (child instanceof ImageView && child != brushToolBtn) {
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(Color.TRANSPARENT);
                    bg.setStroke(dp(1.5f), Color.TRANSPARENT);
                    bg.setCornerRadius(dp(3));
                    child.setBackground(bg);
                }
            }
        }

        try {
            Field activeToolField = EditorActivity.class.getDeclaredField("activeTool");
            activeToolField.setAccessible(true);
            activeToolField.set(activity, "brush");
        } catch (Exception ignored) {}

        updateBrushOptionControlsBar();
        activity.canvasView.invalidate();
    }

    public void deactivateBrush() {
        if (!isBrushActive) return;
        isBrushActive = false;
        setButtonHighlight(false);
        isDrawing = false;
        strokePath.reset();
    }

    private void setButtonHighlight(boolean selected) {
        if (brushToolBtn == null) return;
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? Color.parseColor("#38191E") : Color.TRANSPARENT);
        bg.setStroke(dp(1.5f), selected ? Color.parseColor("#FF1238") : Color.TRANSPARENT);
        bg.setCornerRadius(dp(3));
        brushToolBtn.setBackground(bg);
    }

    private EditorActivity.LayerItem getOrCreateSinglePaintLayer(EditorActivity.ProjectTabSession s) {
        if (s == null) return null;
        if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            EditorActivity.LayerItem active = s.layers.get(s.activeLayerIndex);
            if (!active.isLocked && active.bitmap != null && !active.isShape) {
                if (!active.bitmap.isMutable()) {
                    active.bitmap = active.bitmap.copy(Bitmap.Config.ARGB_8888, true);
                }
                active.isBlank = false;
                return active;
            }
        }

        for (int i = 0; i < s.layers.size(); i++) {
            EditorActivity.LayerItem l = s.layers.get(i);
            if ("Paint Layer".equalsIgnoreCase(l.name) && !l.isLocked && l.bitmap != null) {
                s.activeLayerIndex = i;
                return l;
            }
        }

        Bitmap newBmp = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
        EditorActivity.LayerItem paintLayer = new EditorActivity.LayerItem("Paint Layer", newBmp, 0, 0, false);
        paintLayer.isBlank = false;
        paintLayer.isDirty = true;
        synchronized (s.layers) {
            s.layers.add(paintLayer);
            s.activeLayerIndex = s.layers.size() - 1;
        }
        activity.notifyProjectModified();
        return paintLayer;
    }

    private boolean isEditorActiveToolBrush() {
        try {
            Field f = EditorActivity.class.getDeclaredField("activeTool");
            f.setAccessible(true);
            return "brush".equals(f.get(activity));
        } catch (Exception e) {
            return isBrushActive;
        }
    }

    // =========================================================================
    // স্পর্শ ইনপুট ও স্মুথ ব্রাশ ড্রয়িং ইঞ্জিন
    // =========================================================================
    private boolean handleCanvasTouch(MotionEvent event) {
        if (!isBrushActive || !isEditorActiveToolBrush()) {
            if (isBrushActive) deactivateBrush();
            return false;
        }

        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null) return false;

        int pointerCount = event.getPointerCount();

        // ক্যানভাস জুমিং ও প্যানিং পূর্ণ সাপোর্ট
        if (pointerCount >= 2) {
            if (isDrawing) {
                isDrawing = false;
                strokePath.reset();
                activity.canvasView.invalidate();
            }
            activity.canvasView.onTouchEvent(event);
            return true;
        }

        EditorActivity.LayerItem layer = getOrCreateSinglePaintLayer(s);
        if (layer == null || layer.bitmap == null) return true;

        Matrix inv = new Matrix();
        Matrix m = new Matrix();
        m.postScale(layer.scaleX, layer.scaleY);
        m.postRotate(layer.rotation, (layer.bitmap.getWidth() * layer.scaleX) / 2f, (layer.bitmap.getHeight() * layer.scaleY) / 2f);
        m.postTranslate(layer.x, layer.y);
        m.invert(inv);

        Canvas layerCanvas = new Canvas(layer.bitmap);

        float curX = event.getX();
        float curY = event.getY();
        float cX = (curX - s.panX) / s.scale;
        float cY = (curY - s.panY) / s.scale;
        float[] pts = new float[]{cX, cY};
        inv.mapPoints(pts);
        float lx = pts[0];
        float ly = pts[1];

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                isDrawing = true;
                lastLocalX = lx;
                lastLocalY = ly;

                updatePaintSettings();
                drawBrushStampOrPoint(layerCanvas, layer.bitmap, lx, ly, event.getPressure());
                layer.isDirty = true;
                activity.canvasView.invalidate();
                return true;

            case MotionEvent.ACTION_MOVE:
                if (isDrawing) {
                    int historySize = event.getHistorySize();
                    for (int h = 0; h < historySize; h++) {
                        float hX = (event.getHistoricalX(h) - s.panX) / s.scale;
                        float hY = (event.getHistoricalY(h) - s.panY) / s.scale;
                        float[] hPts = new float[]{hX, hY};
                        inv.mapPoints(hPts);
                        interpolateBetweenPoints(layerCanvas, layer.bitmap, lastLocalX, lastLocalY, hPts[0], hPts[1], event.getHistoricalPressure(h));
                        lastLocalX = hPts[0];
                        lastLocalY = hPts[1];
                    }
                    interpolateBetweenPoints(layerCanvas, layer.bitmap, lastLocalX, lastLocalY, lx, ly, event.getPressure());
                    lastLocalX = lx;
                    lastLocalY = ly;

                    layer.isDirty = true;
                    activity.canvasView.invalidate();
                    return true;
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (isDrawing) {
                    isDrawing = false;
                    strokePath.reset();
                    layer.isDirty = true;
                    activity.recordHistory();
                    activity.canvasView.invalidate();
                    activity.autoSaveCurrentProject();
                    return true;
                }
                break;
        }
        return true;
    }

    private void interpolateBetweenPoints(Canvas canvas, Bitmap baseBitmap, float x0, float y0, float x1, float dy1, float pressure) {
        float dx = x1 - x0;
        float dy = dy1 - y0;
        float dist = (float) Math.hypot(dx, dy);

        // স্পেসিং শূন্য বা মাইনাস হলে কন্টিনিউয়াস স্মুথ ড্রয়িং (খাঁজকাটা পুরোপুরি দূর)
        boolean isStandardRound = (currentCustomTip == null && brushScatter == 0f && brushRoundness >= 0.95f && brushAngle == 0f);

        if (brushSpacing <= 0f && isStandardRound && brushMode != 2) {
            float currentSize = brushSize;
            if (brushPressureEnabled) {
                currentSize = Math.max(dp(2), brushSize * (pressure > 0 ? pressure : 0.7f));
            }
            brushPaint.setStrokeWidth(currentSize);
            brushPaint.setStyle(Paint.Style.STROKE);
            brushPaint.setStrokeCap(Paint.Cap.ROUND);
            brushPaint.setStrokeJoin(Paint.Join.ROUND);

            if (dist > 0) {
                canvas.drawLine(x0, y0, x1, dy1, brushPaint);
            } else {
                brushPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(x1, dy1, currentSize / 2f, brushPaint);
                brushPaint.setStyle(Paint.Style.STROKE);
            }
            return;
        }

        if (dist <= 0) {
            drawBrushStampOrPoint(canvas, baseBitmap, x1, dy1, pressure);
            return;
        }

        // -১০০ থেকে +১০০ স্পেসিং ক্যালকুলেশন
        float spacingFactor;
        if (brushSpacing <= 0) {
            // -১০০ এ ০.০১ (১% স্পেসিং, কোনো ফাঁক থাকবে না), ০ এ ০.০৮ (৮% স্পেসিং)
            spacingFactor = 0.01f + ((brushSpacing + 100f) / 100f) * 0.07f;
        } else {
            // ০ এ ০.০৮, +১০০ এ ১.৫০ (১৫০% স্পেসিং, প্রচুর ফাঁক ফাঁক)
            spacingFactor = 0.08f + (brushSpacing / 100f) * 1.42f;
        }

        float step = Math.max(1.0f, brushSize * spacingFactor);
        int count = Math.max(1, (int) Math.ceil(dist / step));
        count = Math.min(count, 120);

        for (int i = 0; i <= count; i++) {
            float t = (float) i / count;
            float px = x0 + dx * t;
            float py = y0 + dy * t;

            if (brushScatter > 0f) {
                float scatterMax = brushSize * brushScatter * 0.5f;
                px += (reusableRandom.nextFloat() * 2f - 1f) * scatterMax;
                py += (reusableRandom.nextFloat() * 2f - 1f) * scatterMax;
            }

            drawBrushStampOrPoint(canvas, baseBitmap, px, py, pressure);
        }
    }

    private void drawBrushStampOrPoint(Canvas canvas, Bitmap baseBitmap, float x, float y, float pressure) {
        float currentSize = brushSize;
        if (brushPressureEnabled) {
            currentSize = Math.max(dp(2), brushSize * (pressure > 0 ? pressure : 0.7f));
        }

        // পারফেক্ট গাউসিয়ান ব্লার
        if (brushMode == 2 && baseBitmap != null) {
            applyPureGaussianBlur(baseBitmap, x, y, currentSize);
            return;
        }

        if (currentCustomTip != null) {
            reusableMatrix.reset();
            float scaleW = currentSize / currentCustomTip.getWidth();
            float scaleH = (currentSize * brushRoundness) / currentCustomTip.getHeight();
            reusableMatrix.postScale(scaleW, scaleH);
            reusableMatrix.postRotate(brushAngle, currentSize / 2f, (currentSize * brushRoundness) / 2f);
            reusableMatrix.postTranslate(x - currentSize / 2f, y - (currentSize * brushRoundness) / 2f);
            canvas.drawBitmap(currentCustomTip, reusableMatrix, stampPaint);
        } else {
            if (brushRoundness < 0.98f || brushAngle != 0f) {
                canvas.save();
                canvas.translate(x, y);
                canvas.rotate(brushAngle);
                canvas.scale(1f, brushRoundness);
                brushPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(0, 0, currentSize / 2f, brushPaint);
                brushPaint.setStyle(Paint.Style.STROKE);
                canvas.restore();
            } else {
                // drawPoint এর বদলে স্মুথ drawCircle (GPU ক্লিপিং এবং দাগি পড়া দূর করে)
                brushPaint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(x, y, currentSize / 2f, brushPaint);
                brushPaint.setStyle(Paint.Style.STROKE);
            }
        }
    }

    // ১০০% পিউর গাউসিয়ান ব্লার মেথড
    private void applyPureGaussianBlur(Bitmap src, float cx, float cy, float radius) {
        int r = (int) (radius / 2f);
        if (r <= 2) return;

        int left = Math.max(0, (int) (cx - r));
        int top = Math.max(0, (int) (cy - r));
        int right = Math.min(src.getWidth(), (int) (cx + r));
        int bottom = Math.min(src.getHeight(), (int) (cy + r));
        int width = right - left;
        int height = bottom - top;

        if (width <= 4 || height <= 4) return;

        try {
            float blurPower = (1000f - brushHardness) / 200f;
            int downscale = Math.max(2, (int) (2 + blurPower * 2));

            Bitmap crop = Bitmap.createBitmap(src, left, top, width, height);
            Bitmap small = Bitmap.createScaledBitmap(crop, Math.max(1, width / downscale), Math.max(1, height / downscale), true);
            Bitmap blurred = Bitmap.createScaledBitmap(small, width, height, true);

            Canvas c = new Canvas(src);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            p.setAlpha((int) (brushOpacity * 255));

            c.save();
            Path path = new Path();
            path.addCircle(cx, cy, r, Path.Direction.CW);
            c.clipPath(path);
            c.drawBitmap(blurred, left, top, p);
            c.restore();
        } catch (Exception ignored) {}
    }

    public void createCustomBrushFromBitmap(Bitmap srcBmp, String brushName, String folderName) {
        if (srcBmp == null) return;

        int maxDim = 256;
        int w = srcBmp.getWidth();
        int h = srcBmp.getHeight();
        float scale = Math.min(1.0f, (float) maxDim / Math.max(w, h));
        int targetW = Math.max(10, Math.round(w * scale));
        int targetH = Math.max(10, Math.round(h * scale));

        Bitmap scaled = Bitmap.createScaledBitmap(srcBmp, targetW, targetH, true);
        Bitmap customTipBmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);

        int[] pixels = new int[targetW * targetH];
        scaled.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH);

        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int a = (c >>> 24);
            int r = (c >> 16) & 0xFF;
            int g = (c >> 8) & 0xFF;
            int b = c & 0xFF;

            int lum = (int) (0.299f * r + 0.587f * g + 0.114f * b);

            if (lum >= 230) {
                pixels[i] = 0x00FFFFFF;
            } else {
                float darkness = (230 - lum) / 230.0f;
                int alpha = Math.min(255, Math.max(0, (int) (darkness * (a / 255.0f) * 255)));
                pixels[i] = (alpha << 24) | 0x00FFFFFF;
            }
        }

        customTipBmp.setPixels(pixels, 0, targetW, 0, 0, targetW, targetH);

        String finalName = (brushName == null || brushName.trim().isEmpty())
                ? "Custom Tip " + (targetW / 2)
                : brushName.trim();

        BrushPreset newCustomPreset = new BrushPreset(finalName, targetW / 2, targetW / 2f, 1.0f, 1.0f,
                -50f, 0f, 1f, customTipBmp);

        BrushFolder targetFolder = null;
        for (BrushFolder bf : brushFolders) {
            if (bf.name.equalsIgnoreCase(folderName) || bf.name.toLowerCase().contains("custom")) {
                targetFolder = bf;
                break;
            }
        }
        if (targetFolder == null) {
            targetFolder = brushFolders.get(brushFolders.size() - 1);
        }

        targetFolder.brushes.add(newCustomPreset);
        currentBrushType = newCustomPreset.name;
        currentCustomTip = customTipBmp;
        brushSize = newCustomPreset.defaultSize;
        brushMode = 0;

        saveCustomBrushToStorage(newCustomPreset);

        updatePaintSettings();
        updateBrushOptionControlsBar();
        Toast.makeText(activity, "Brush created in " + targetFolder.name + "!", Toast.LENGTH_SHORT).show();

        if (activeBrushDialog != null && activeBrushDialog.isShowing()) {
            activeBrushDialog.dismiss();
            showBrushChangeDialog();
        }
    }

    private void saveCustomBrushToStorage(BrushPreset preset) {
        if (activity == null || preset.tipBitmap == null) return;
        try {
            File dir = new File(activity.getFilesDir(), "custom_brushes");
            if (!dir.exists()) dir.mkdirs();

            String fileName = "brush_" + System.currentTimeMillis() + ".png";
            File file = new File(dir, fileName);
            FileOutputStream fos = new FileOutputStream(file);
            preset.tipBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();

            SharedPreferences sp = activity.getSharedPreferences("ejitor_custom_brushes", Context.MODE_PRIVATE);
            String existing = sp.getString("brush_list", "");
            String entry = preset.name + "|" + preset.sizeNumber + "|" + preset.defaultSize + "|" + file.getAbsolutePath();
            String updated = existing.isEmpty() ? entry : existing + "##" + entry;
            sp.edit().putString("brush_list", updated).apply();
        } catch (Exception ignored) {}
    }

    private void loadSavedCustomBrushes() {
        if (activity == null) return;
        try {
            BrushFolder targetFolder = null;
            for (BrushFolder bf : brushFolders) {
                if (bf.name.toLowerCase().contains("custom")) {
                    targetFolder = bf;
                    break;
                }
            }
            if (targetFolder == null) return;

            SharedPreferences sp = activity.getSharedPreferences("ejitor_custom_brushes", Context.MODE_PRIVATE);
            String list = sp.getString("brush_list", "");
            if (list.isEmpty()) return;

            String[] entries = list.split("##");
            for (String entry : entries) {
                String[] parts = entry.split("\\|");
                if (parts.length >= 4) {
                    String name = parts[0];
                    int sizeNum = Integer.parseInt(parts[1]);
                    float defSize = Float.parseFloat(parts[2]);
                    String path = parts[3];

                    File f = new File(path);
                    if (f.exists()) {
                        Bitmap tip = BitmapFactory.decodeFile(f.getAbsolutePath());
                        if (tip != null) {
                            targetFolder.brushes.add(new BrushPreset(name, sizeNum, defSize, 1.0f, 1.0f, -50f, 0f, 1f, tip));
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    private void openGalleryForCustomBrush() {
        try {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");

            FragmentManager fm = activity.getFragmentManager();
            CustomBrushPickerFragment fragment = (CustomBrushPickerFragment) fm.findFragmentByTag("brush_picker_frag");
            if (fragment == null) {
                fragment = new CustomBrushPickerFragment();
                fm.beginTransaction().add(fragment, "brush_picker_frag").commitAllowingStateLoss();
                fm.executePendingTransactions();
            }
            fragment.setModule(this);

            fragment.startActivityForResult(Intent.createChooser(intent, "Select B&W Image for Brush"), REQ_CODE_CUSTOM_BRUSH);
        } catch (Exception e) {
            Toast.makeText(activity, "Cannot open gallery: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void promptCustomBrushCreationDialog(Uri uri) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1F1F1F"));
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), Color.parseColor("#383838"));
        layout.setBackground(bg);

        TextView tv = new TextView(activity);
        tv.setText("Save Custom Brush");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(0, 0, 0, dp(10));
        layout.addView(tv);

        final EditText et = new EditText(activity);
        et.setText("My Custom Tip");
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        et.setSingleLine(true);
        et.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable etBg = new GradientDrawable();
        etBg.setColor(Color.parseColor("#141414"));
        etBg.setCornerRadius(dp(4));
        etBg.setStroke(dp(1), Color.parseColor("#444444"));
        et.setBackground(etBg);
        layout.addView(et);

        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(12), 0, 0);

        TextView cancelBtn = createOptionPill("Cancel", v -> d.dismiss());
        row.addView(cancelBtn);

        View gap = new View(activity);
        gap.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        row.addView(gap);

        TextView okBtn = createOptionPill("Create Brush", v -> {
            try {
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = 1;
                InputStream is = activity.getContentResolver().openInputStream(uri);
                Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
                if (is != null) is.close();
                createCustomBrushFromBitmap(bmp, et.getText().toString(), "Custom (My Brushes)");
            } catch (Exception e) {
                Toast.makeText(activity, "Failed to load image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            d.dismiss();
        });
        okBtn.setBackgroundColor(Color.parseColor("#FF1238"));
        row.addView(okBtn);

        layout.addView(row);
        d.setContentView(layout);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    // =========================================================================
    // Photopea স্টাইল ব্রাশ প্যানেল
    // =========================================================================
    public void showBrushChangeDialog() {
        if (activity == null) return;
        final Dialog d = new Dialog(activity);
        this.activeBrushDialog = d;
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final Window window = d.getWindow();
        if (window == null) return;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        window.setFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH, WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);

        final FrameLayout rootFrame = new FrameLayout(activity);
        final LinearLayout mainLayout = new LinearLayout(activity);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(dp(10), dp(8), dp(10), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#2A2A2A"));
        bg.setCornerRadius(dp(6));
        bg.setStroke(dp(1), Color.parseColor("#383838"));
        mainLayout.setBackground(bg);
        rootFrame.addView(mainLayout, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // অস্থায়ী মানসমূহ
        final float[] tempSize = {brushSize};
        final float[] tempOpacity = {brushOpacity};
        final float[] tempHardness = {brushHardness};
        final float[] tempAngle = {brushAngle};
        final float[] tempRoundness = {brushRoundness};
        final float[] tempSpacing = {brushSpacing};
        final int[] tempMode = {brushMode};
        final String[] tempBrushType = {currentBrushType};
        final Bitmap[] tempCustomTip = {currentCustomTip};

        // ১. হেডার
        final LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(4));

        TextView titleTv = new TextView(activity);
        titleTv.setText("Brush Preset Picker");
        titleTv.setTextColor(Color.parseColor("#CCCCCC"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        TextView newFolderBtn = createOptionPill("+ Folder", v -> promptNewFolderDialog(d));
        header.addView(newFolderBtn);

        View g1 = new View(activity);
        g1.setLayoutParams(new LinearLayout.LayoutParams(dp(4), 1));
        header.addView(g1);

        TextView addBrushBtn = createOptionPill("+ Custom", v -> openGalleryForCustomBrush());
        setButtonBg(addBrushBtn, "#FF1238");
        header.addView(addBrushBtn);

        mainLayout.addView(header);

        ScrollView scrollArea = new ScrollView(activity);
        scrollArea.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        scrollArea.setFillViewport(true);

        LinearLayout contentContainer = new LinearLayout(activity);
        contentContainer.setOrientation(LinearLayout.VERTICAL);

        // ২. উপরের কন্ট্রোলার
        LinearLayout topControls = new LinearLayout(activity);
        topControls.setOrientation(LinearLayout.HORIZONTAL);
        topControls.setGravity(Gravity.CENTER_VERTICAL);
        topControls.setPadding(0, dp(2), 0, dp(4));

        final View livePreviewStrokeView = new View(activity) {
            private final Paint lp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
            private final Matrix pMatrix = new Matrix();

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                int w = getWidth();
                int h = getHeight();
                if (w <= 0 || h <= 0) return;

                lp.reset();
                lp.setAntiAlias(true);
                lp.setColor(brushColor);
                lp.setAlpha((int) (tempOpacity[0] * 255));

                float previewBrushSize = Math.max(dp(3), Math.min(dp(20), tempSize[0] * 0.28f));

                if (tempHardness[0] < 0.98f && tempCustomTip[0] == null) {
                    float blur = Math.max(1.0f, (1.0f - Math.max(0f, tempHardness[0])) * (previewBrushSize * 0.45f));
                    lp.setMaskFilter(new BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL));
                } else {
                    lp.setMaskFilter(null);
                }

                float startX = dp(14);
                float endX = w - dp(14);
                float totalLength = endX - startX;

                float pSpacingFactor;
                if (tempSpacing[0] <= 0) {
                    pSpacingFactor = 0.01f + ((tempSpacing[0] + 100f) / 100f) * 0.07f;
                } else {
                    pSpacingFactor = 0.08f + (tempSpacing[0] / 100f) * 1.42f;
                }
                float step = Math.max(dp(0.8f), previewBrushSize * pSpacingFactor);

                int steps = Math.max(1, (int) Math.ceil(totalLength / step));
                steps = Math.min(steps, 150);

                for (int i = 0; i <= steps; i++) {
                    float t = (float) i / steps;
                    float px = startX + t * totalLength;
                    float py = (h / 2f) + (float) Math.sin(t * Math.PI * 2.0) * dp(5.5f);

                    if (tempCustomTip[0] != null) {
                        pMatrix.reset();
                        float scaleW = previewBrushSize / tempCustomTip[0].getWidth();
                        float scaleH = (previewBrushSize * tempRoundness[0]) / tempCustomTip[0].getHeight();
                        pMatrix.postScale(scaleW, scaleH);
                        pMatrix.postRotate(tempAngle[0], previewBrushSize / 2f, (previewBrushSize * tempRoundness[0]) / 2f);
                        pMatrix.postTranslate(px - previewBrushSize / 2f, py - (previewBrushSize * tempRoundness[0]) / 2f);

                        Paint cp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        cp.setColorFilter(new PorterDuffColorFilter(brushColor, PorterDuff.Mode.SRC_IN));
                        cp.setAlpha((int) (tempOpacity[0] * 255));
                        canvas.drawBitmap(tempCustomTip[0], pMatrix, cp);
                    } else {
                        canvas.save();
                        canvas.translate(px, py);
                        canvas.rotate(tempAngle[0]);
                        canvas.scale(1f, tempRoundness[0]);
                        lp.setStyle(Paint.Style.FILL);
                        canvas.drawCircle(0, 0, previewBrushSize / 2f, lp);
                        canvas.restore();
                    }
                }
            }
        };

        final AngleRoundnessCompassView compassView = new AngleRoundnessCompassView(activity, tempAngle[0], tempRoundness[0], (ang, rnd) -> {
            tempAngle[0] = ang;
            tempRoundness[0] = rnd;
            livePreviewStrokeView.invalidate();
        });
        topControls.addView(compassView, new LinearLayout.LayoutParams(dp(76), dp(76)));

        LinearLayout sliderSection = new LinearLayout(activity);
        sliderSection.setOrientation(LinearLayout.VERTICAL);
        sliderSection.setPadding(dp(8), 0, 0, 0);
        sliderSection.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        sliderSection.addView(createStepSliderRow("Size", tempSize[0], 1, 1000, 1, " px", value -> {
            tempSize[0] = value;
            livePreviewStrokeView.invalidate();
        }));

        sliderSection.addView(createStepSliderRow("Opacity", tempOpacity[0] * 100f, 1, 100, 1, " %", value -> {
            tempOpacity[0] = value / 100f;
            livePreviewStrokeView.invalidate();
        }));

        // হার্ডনেস -১০০০ থেকে +১০০০ সাপোর্ট
        sliderSection.addView(createStepSliderRow("Hardness", tempHardness[0] * 1000f, -1000, 1000, 10, "", value -> {
            tempHardness[0] = value / 1000f;
            livePreviewStrokeView.invalidate();
        }));

        topControls.addView(sliderSection);
        contentContainer.addView(topControls);

        LinearLayout previewCard = new LinearLayout(activity);
        previewCard.setOrientation(LinearLayout.VERTICAL);
        previewCard.setPadding(dp(6), dp(3), dp(6), dp(3));
        setButtonBg(previewCard, "#1E1E1E");
        LinearLayout.LayoutParams pclp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38));
        pclp.setMargins(0, 0, 0, dp(4));
        previewCard.setLayoutParams(pclp);
        previewCard.addView(livePreviewStrokeView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        contentContainer.addView(previewCard);

        final LinearLayout advanceSettingsLayout = new LinearLayout(activity);
        advanceSettingsLayout.setOrientation(LinearLayout.VERTICAL);
        advanceSettingsLayout.setVisibility(View.GONE);

        // স্পেসিং স্লাইডার: -১০০% থেকে +১০০%
        advanceSettingsLayout.addView(createStepSliderRow("Spacing", tempSpacing[0], -100, 100, 1, " %", val -> {
            tempSpacing[0] = val;
            livePreviewStrokeView.invalidate();
        }));
        advanceSettingsLayout.addView(createStepSliderRow("Angle", tempAngle[0], 0, 360, 5, "°", val -> {
            tempAngle[0] = val;
            compassView.setValues(tempAngle[0], tempRoundness[0]);
            livePreviewStrokeView.invalidate();
        }));
        advanceSettingsLayout.addView(createStepSliderRow("Roundness", tempRoundness[0] * 100f, 10, 100, 5, " %", val -> {
            tempRoundness[0] = val / 100f;
            compassView.setValues(tempAngle[0], tempRoundness[0]);
            livePreviewStrokeView.invalidate();
        }));

        TextView toggleSettingsBtn = createOptionPill("  Brush Settings (Spacing / Angle / Roundness) ▾  ", v -> {
            boolean visible = advanceSettingsLayout.getVisibility() == View.VISIBLE;
            advanceSettingsLayout.setVisibility(visible ? View.GONE : View.VISIBLE);
        });
        setButtonBg(toggleSettingsBtn, "#333333");
        contentContainer.addView(toggleSettingsBtn);
        contentContainer.addView(advanceSettingsLayout);

        // ৩. ফোল্ডারসমূহ
        final List<View> brushItemViews = new ArrayList<>();

        for (final BrushFolder folder : brushFolders) {
            final LinearLayout folderBar = new LinearLayout(activity);
            folderBar.setOrientation(LinearLayout.HORIZONTAL);
            folderBar.setGravity(Gravity.CENTER_VERTICAL);
            folderBar.setPadding(dp(8), dp(5), dp(8), dp(5));
            setButtonBg(folderBar, "#333333");
            LinearLayout.LayoutParams fblp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            fblp.setMargins(0, dp(3), 0, 0);
            folderBar.setLayoutParams(fblp);

            ImageView folderIcon = new ImageView(activity);
            folderIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(14), dp(14)));
            folderIcon.setImageDrawable(createFolderVectorIcon(dp(14), Color.parseColor("#D4D4D4")));
            folderBar.addView(folderIcon);

            TextView fNameTv = new TextView(activity);
            fNameTv.setText(" " + folder.name);
            fNameTv.setTextColor(Color.WHITE);
            fNameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            fNameTv.setTypeface(null, Typeface.BOLD);
            fNameTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            folderBar.addView(fNameTv);

            final ImageView arrIcon = new ImageView(activity);
            arrIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(12), dp(12)));
            arrIcon.setImageDrawable(createArrowDownVectorIcon(dp(12), Color.parseColor("#AAAAAA")));
            folderBar.addView(arrIcon);

            contentContainer.addView(folderBar);

            final GridLayout grid = new GridLayout(activity);
            grid.setColumnCount(7);
            grid.setPadding(dp(4), dp(4), dp(4), dp(4));
            setButtonBg(grid, "#202020");

            if (!"Default".equalsIgnoreCase(folder.name)) {
                grid.setVisibility(View.GONE);
                arrIcon.setRotation(-90);
            }

            for (final BrushPreset preset : folder.brushes) {
                final LinearLayout itemCell = new LinearLayout(activity);
                itemCell.setOrientation(LinearLayout.VERTICAL);
                itemCell.setGravity(Gravity.CENTER);
                itemCell.setPadding(dp(2), dp(2), dp(2), dp(2));

                final boolean isSelected = preset.name.equalsIgnoreCase(tempBrushType[0]);
                applyGridItemSelection(itemCell, isSelected);

                GridLayout.LayoutParams glp = new GridLayout.LayoutParams();
                glp.width = dp(34);
                glp.height = dp(40);
                glp.setMargins(dp(2), dp(2), dp(2), dp(2));
                itemCell.setLayoutParams(glp);

                View tipView = new View(activity) {
                    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                    @Override
                    protected void onDraw(Canvas canvas) {
                        super.onDraw(canvas);
                        int w = getWidth();
                        int h = getHeight();
                        if (preset.tipBitmap != null) {
                            p.setColorFilter(new PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN));
                            RectF r = new RectF(dp(2), dp(2), w - dp(2), h - dp(2));
                            canvas.drawBitmap(preset.tipBitmap, null, r, p);
                        } else {
                            p.setColor(Color.WHITE);
                            p.setColorFilter(null);
                            if (preset.hardness < 0.9f) {
                                p.setMaskFilter(new BlurMaskFilter(dp(2f), BlurMaskFilter.Blur.NORMAL));
                            } else {
                                p.setMaskFilter(null);
                            }
                            canvas.drawCircle(w / 2f, h / 2f, Math.min(w, h) * 0.35f, p);
                        }
                    }
                };
                itemCell.addView(tipView, new LinearLayout.LayoutParams(dp(18), dp(18)));

                TextView numTv = new TextView(activity);
                numTv.setText(String.valueOf(preset.sizeNumber));
                numTv.setTextColor(Color.parseColor("#AAAAAA"));
                numTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 7.5f);
                numTv.setGravity(Gravity.CENTER);
                itemCell.addView(numTv);

                itemCell.setOnClickListener(v -> {
                    tempBrushType[0] = preset.name;
                    tempCustomTip[0] = preset.tipBitmap;
                    tempSize[0] = preset.defaultSize;
                    tempHardness[0] = preset.hardness;
                    tempOpacity[0] = preset.opacity;
                    tempAngle[0] = preset.angle;
                    tempRoundness[0] = preset.roundness;
                    tempSpacing[0] = preset.spacing;
                    tempMode[0] = preset.mode;

                    compassView.setValues(tempAngle[0], tempRoundness[0]);
                    livePreviewStrokeView.invalidate();

                    for (View cell : brushItemViews) {
                        applyGridItemSelection((LinearLayout) cell, false);
                    }
                    applyGridItemSelection(itemCell, true);
                });

                brushItemViews.add(itemCell);
                grid.addView(itemCell);
            }

            folderBar.setOnClickListener(v -> {
                boolean vis = grid.getVisibility() == View.VISIBLE;
                grid.setVisibility(vis ? View.GONE : View.VISIBLE);
                arrIcon.setRotation(vis ? -90 : 0);
            });

            contentContainer.addView(grid);
        }

        scrollArea.addView(contentContainer);
        mainLayout.addView(scrollArea);

        // ৪. নিচের অ্যাকশন বার
        LinearLayout bottomRow = new LinearLayout(activity);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.setPadding(0, dp(6), 0, 0);

        TextView cancelBtn = createOptionPill("Cancel", v -> d.dismiss());
        bottomRow.addView(cancelBtn);

        View fill = new View(activity);
        fill.setLayoutParams(new LinearLayout.LayoutParams(0, 1, 1f));
        bottomRow.addView(fill);

        TextView okBtn = createOptionPill("OK", v -> {
            brushSize = tempSize[0];
            brushOpacity = tempOpacity[0];
            brushHardness = tempHardness[0];
            brushAngle = tempAngle[0];
            brushRoundness = tempRoundness[0];
            brushSpacing = tempSpacing[0];
            brushMode = tempMode[0];
            currentBrushType = tempBrushType[0];
            currentCustomTip = tempCustomTip[0];

            updatePaintSettings();
            updateBrushOptionControlsBar();
            d.dismiss();
            Toast.makeText(activity, "Brush Applied", Toast.LENGTH_SHORT).show();
        });
        setButtonBg(okBtn, "#FF1238");
        bottomRow.addView(okBtn);

        mainLayout.addView(bottomRow);

        // ৫. রিসাইজ হ্যান্ডেল
        final ImageView resizeGrip = new ImageView(activity);
        FrameLayout.LayoutParams rglp = new FrameLayout.LayoutParams(dp(18), dp(18));
        rglp.gravity = Gravity.BOTTOM | Gravity.END;
        resizeGrip.setLayoutParams(rglp);
        resizeGrip.setImageDrawable(createResizeGripIcon(dp(18), Color.parseColor("#777777")));
        rootFrame.addView(resizeGrip);

        d.setContentView(rootFrame);

        // সেভ করা ডায়ালগ সাইজ লোড ও পার্মানেন্টলি রিমেম্বার
        final SharedPreferences dSp = activity.getSharedPreferences("ejitor_dialog_prefs", Context.MODE_PRIVATE);
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        int screenH = dm.heightPixels;
        int screenW = dm.widthPixels;

        int defW = Math.min(dp(310), (int) (screenW * 0.90f));
        int defH = Math.min(dp(350), (int) (screenH * 0.85f));

        final WindowManager.LayoutParams wmlp = window.getAttributes();
        wmlp.width = dSp.getInt("dlg_w", defW);
        wmlp.height = dSp.getInt("dlg_h", defH);
        wmlp.gravity = Gravity.CENTER;
        window.setAttributes(wmlp);

        // হেডার ধরে ড্র্যাগ এবং মুভ
        header.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float downRawX, downRawY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = wmlp.x;
                        initialY = wmlp.y;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wmlp.x = initialX + (int) (event.getRawX() - downRawX);
                        wmlp.y = initialY + (int) (event.getRawY() - downRawY);
                        window.setAttributes(wmlp);
                        return true;
                }
                return false;
            }
        });

        // রিসাইজ হ্যান্ডেল
        resizeGrip.setOnTouchListener(new View.OnTouchListener() {
            private int initialW, initialH;
            private float downRawX, downRawY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialW = wmlp.width;
                        initialH = wmlp.height;
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int newW = Math.max(dp(240), initialW + (int) (event.getRawX() - downRawX));
                        int newH = Math.max(dp(220), initialH + (int) (event.getRawY() - downRawY));
                        wmlp.width = newW;
                        wmlp.height = newH;
                        window.setAttributes(wmlp);
                        dSp.edit().putInt("dlg_w", newW).putInt("dlg_h", newH).apply();
                        return true;
                }
                return false;
            }
        });

        d.show();
    }

    interface OnValueChangeListener {
        void onChange(float value);
    }

    private LinearLayout createStepSliderRow(final String label, float currentVal, final float min, final float max, final float step, final String unit, final OnValueChangeListener listener) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(1), 0, dp(2));

        LinearLayout labelRow = new LinearLayout(activity);
        labelRow.setOrientation(LinearLayout.HORIZONTAL);
        labelRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView lbl = new TextView(activity);
        lbl.setText(label + ":");
        lbl.setTextColor(Color.WHITE);
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        labelRow.addView(lbl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView valTv = new TextView(activity);
        valTv.setText(((int) currentVal) + unit);
        valTv.setTextColor(Color.WHITE);
        valTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        valTv.setTypeface(null, Typeface.BOLD);
        valTv.setPadding(dp(7), dp(1), dp(7), dp(1));
        setButtonBg(valTv, "#1C1C1C");
        labelRow.addView(valTv);
        row.addView(labelRow);

        LinearLayout controlRow = new LinearLayout(activity);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);
        controlRow.setGravity(Gravity.CENTER_VERTICAL);

        final float[] valHolder = {currentVal};

        ImageView minusBtn = new ImageView(activity);
        minusBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
        minusBtn.setImageDrawable(createMinusVectorIcon(dp(14), Color.WHITE));
        minusBtn.setScaleType(ImageView.ScaleType.CENTER);
        setButtonBg(minusBtn, "#333333");
        controlRow.addView(minusBtn);

        final SeekBar sb = new SeekBar(activity);
        sb.setMax((int) (max - min));
        sb.setProgress((int) (currentVal - min));
        applyCustomSeekBarStyle(sb);
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sblp.setMargins(dp(4), 0, dp(4), 0);
        sb.setLayoutParams(sblp);
        controlRow.addView(sb);

        ImageView plusBtn = new ImageView(activity);
        plusBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
        plusBtn.setImageDrawable(createAddVectorIcon(dp(14), Color.WHITE));
        plusBtn.setScaleType(ImageView.ScaleType.CENTER);
        setButtonBg(plusBtn, "#333333");
        controlRow.addView(plusBtn);

        row.addView(controlRow);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    valHolder[0] = progress + min;
                    valTv.setText(((int) valHolder[0]) + unit);
                    if (listener != null) listener.onChange(valHolder[0]);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        minusBtn.setOnClickListener(v -> {
            float newVal = Math.max(min, valHolder[0] - step);
            valHolder[0] = newVal;
            sb.setProgress((int) (newVal - min));
            valTv.setText(((int) newVal) + unit);
            if (listener != null) listener.onChange(newVal);
        });

        plusBtn.setOnClickListener(v -> {
            float newVal = Math.min(max, valHolder[0] + step);
            valHolder[0] = newVal;
            sb.setProgress((int) (newVal - min));
            valTv.setText(((int) newVal) + unit);
            if (listener != null) listener.onChange(newVal);
        });

        return row;
    }

    private void applyGridItemSelection(LinearLayout cell, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(selected ? "#3F3F3F" : "#242424"));
        bg.setStroke(dp(1.2f), Color.parseColor(selected ? "#FF1238" : "#303030"));
        bg.setCornerRadius(dp(3));
        cell.setBackground(bg);
    }

    private void promptNewFolderDialog(final Dialog parentDialog) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        setButtonBg(l, "#1F1F1F");

        TextView t = new TextView(activity);
        t.setText("New Brush Folder");
        t.setTextColor(Color.WHITE);
        t.setTypeface(null, Typeface.BOLD);
        l.addView(t);

        final EditText et = new EditText(activity);
        et.setText("Folder " + (brushFolders.size() + 1));
        et.setTextColor(Color.WHITE);
        et.setSingleLine(true);
        et.setPadding(dp(8), dp(6), dp(8), dp(6));
        setButtonBg(et, "#141414");
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.setMargins(0, dp(8), 0, dp(10));
        et.setLayoutParams(elp);
        l.addView(et);

        TextView addBtn = createOptionPill("Create", v -> {
            String name = et.getText().toString().trim();
            if (!name.isEmpty()) {
                brushFolders.add(new BrushFolder(name, true));
                d.dismiss();
                parentDialog.dismiss();
                showBrushChangeDialog();
                Toast.makeText(activity, "Folder Created: " + name, Toast.LENGTH_SHORT).show();
            }
        });
        setButtonBg(addBtn, "#FF1238");
        l.addView(addBtn);

        d.setContentView(l);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    public interface OnAngleRoundnessListener {
        void onUpdate(float angle, float roundness);
    }

    private class AngleRoundnessCompassView extends View {
        private float angle = 0f;
        private float roundness = 1.0f;
        private final OnAngleRoundnessListener listener;

        private final Paint outerCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint crosshairPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ellipsePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private static final int TOUCH_NONE = 0;
        private static final int TOUCH_ANGLE = 1;
        private static final int TOUCH_ROUNDNESS = 2;
        private int activeTouchMode = TOUCH_NONE;

        public AngleRoundnessCompassView(Context context, float initialAngle, float initialRoundness, OnAngleRoundnessListener listener) {
            super(context);
            this.angle = initialAngle;
            this.roundness = initialRoundness;
            this.listener = listener;

            outerCirclePaint.setColor(Color.parseColor("#444444"));
            outerCirclePaint.setStyle(Paint.Style.STROKE);
            outerCirclePaint.setStrokeWidth(dp(1.2f));

            crosshairPaint.setColor(Color.parseColor("#555555"));
            crosshairPaint.setStrokeWidth(dp(1));

            ellipsePaint.setColor(Color.parseColor("#888888"));
            ellipsePaint.setStyle(Paint.Style.STROKE);
            ellipsePaint.setStrokeWidth(dp(1.5f));

            handlePaint.setColor(Color.WHITE);
            handlePaint.setStyle(Paint.Style.FILL);

            arrowPaint.setColor(Color.parseColor("#CCCCCC"));
            arrowPaint.setStyle(Paint.Style.FILL);
        }

        public void setValues(float ang, float rnd) {
            this.angle = ang;
            this.roundness = rnd;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            float cx = w / 2f;
            float cy = h / 2f;
            float maxR = Math.min(cx, cy) - dp(8);

            canvas.drawCircle(cx, cy, maxR, outerCirclePaint);
            canvas.drawLine(cx, cy - maxR, cx, cy + maxR, crosshairPaint);
            canvas.drawLine(cx - maxR, cy, cx + maxR, cy, crosshairPaint);

            canvas.save();
            canvas.rotate(angle, cx, cy);
            RectF ellipseRect = new RectF(cx - maxR, cy - (maxR * roundness), cx + maxR, cy + (maxR * roundness));
            canvas.drawOval(ellipseRect, ellipsePaint);

            canvas.drawCircle(cx, cy - (maxR * roundness), dp(3.5f), handlePaint);
            canvas.drawCircle(cx, cy + (maxR * roundness), dp(3.5f), handlePaint);
            canvas.restore();

            float arrowRad = (float) Math.toRadians(angle);
            float ax = cx + (float) Math.cos(arrowRad) * maxR;
            float ay = cy + (float) Math.sin(arrowRad) * maxR;

            Path arrowPath = new Path();
            float tipLen = dp(5);
            arrowPath.moveTo(ax + (float) Math.cos(arrowRad) * tipLen, ay + (float) Math.sin(arrowRad) * tipLen);
            arrowPath.lineTo(ax - (float) Math.sin(arrowRad) * tipLen, ay + (float) Math.cos(arrowRad) * tipLen);
            arrowPath.lineTo(ax + (float) Math.sin(arrowRad) * tipLen, ay - (float) Math.cos(arrowRad) * tipLen);
            arrowPath.close();
            canvas.drawPath(arrowPath, arrowPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            float maxR = Math.min(cx, cy) - dp(8);

            float dx = event.getX() - cx;
            float dy = event.getY() - cy;
            float dist = (float) Math.hypot(dx, dy);

            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    if (dist >= maxR * 0.70f) {
                        activeTouchMode = TOUCH_ANGLE;
                    } else {
                        activeTouchMode = TOUCH_ROUNDNESS;
                    }
                    updateValuesByMode(dx, dy, dist, maxR);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (activeTouchMode != TOUCH_NONE) {
                        updateValuesByMode(dx, dy, dist, maxR);
                        return true;
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeTouchMode = TOUCH_NONE;
                    return true;
            }
            return super.onTouchEvent(event);
        }

        private void updateValuesByMode(float dx, float dy, float dist, float maxR) {
            if (activeTouchMode == TOUCH_ANGLE) {
                double deg = Math.toDegrees(Math.atan2(dy, dx));
                if (deg < 0) deg += 360;
                angle = (float) deg;
            } else if (activeTouchMode == TOUCH_ROUNDNESS) {
                roundness = Math.max(0.10f, Math.min(1.0f, dist / maxR));
            }
            if (listener != null) listener.onUpdate(angle, roundness);
            invalidate();
        }
    }

    private void openBrushColorPicker() {
        try {
            Class<?> pClass = Class.forName("com.example.ejitor.popup");
            Method m = pClass.getMethod("showStandaloneColorPicker", Activity.class, int.class, popup.OnColorPickListener.class);
            m.invoke(null, activity, brushColor, (popup.OnColorPickListener) col -> {
                brushColor = col;
                updatePaintSettings();
                updateBrushOptionControlsBar();
            });
            return;
        } catch (Throwable ignored) {}

        final Dialog cd = new Dialog(activity);
        cd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        setButtonBg(l, "#1C1C1C");

        TextView t = new TextView(activity);
        t.setText("Pick Brush Color");
        t.setTextColor(Color.WHITE);
        t.setPadding(0, 0, 0, dp(10));
        l.addView(t);

        int[] colors = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.WHITE, Color.BLACK};
        LinearLayout row = new LinearLayout(activity);
        for (int c : colors) {
            View v = new View(activity);
            v.setLayoutParams(new LinearLayout.LayoutParams(dp(26), dp(26)));
            v.setBackgroundColor(c);
            v.setOnClickListener(view -> {
                brushColor = c;
                updatePaintSettings();
                updateBrushOptionControlsBar();
                cd.dismiss();
            });
            row.addView(v);
        }
        l.addView(row);
        cd.setContentView(l);
        cd.show();
    }

    private void updateBrushOptionControlsBar() {
        if (activity == null || activity.optionControlsBar == null) return;
        activity.optionControlsBar.removeAllViews();

        String toolText = (brushMode == 1) ? "Eraser ▾" : (brushMode == 2 ? "Blur ▾" : "Brush ▾");
        TextView brushBtn = createOptionPill(toolText, v -> showBrushChangeDialog());
        setButtonBg(brushBtn, "#FF1238");
        activity.optionControlsBar.addView(brushBtn);

        TextView sizePill = createOptionPill("Size: " + (int) brushSize + "px", v -> showBrushChangeDialog());
        activity.optionControlsBar.addView(sizePill);

        TextView opPill = createOptionPill("Op: " + (int) (brushOpacity * 100) + "%", v -> showBrushChangeDialog());
        activity.optionControlsBar.addView(opPill);

        if (brushMode == 0) {
            TextView colorBtn = createOptionPill("Color", v -> openBrushColorPicker());
            activity.optionControlsBar.addView(colorBtn);

            View colorPreview = new View(activity);
            LinearLayout.LayoutParams cpLp = new LinearLayout.LayoutParams(dp(16), dp(16));
            cpLp.setMargins(dp(2), 0, dp(4), 0);
            colorPreview.setLayoutParams(cpLp);
            GradientDrawable cpDr = new GradientDrawable();
            cpDr.setColor(brushColor);
            cpDr.setStroke(dp(1), Color.WHITE);
            cpDr.setCornerRadius(dp(2));
            colorPreview.setBackground(cpDr);
            activity.optionControlsBar.addView(colorPreview);
        }
    }

    private TextView createOptionPill(String text, View.OnClickListener l) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(dp(7), dp(2), dp(7), dp(2));
        setButtonBg(tv, "#252525");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
        lp.setMargins(dp(2), 0, dp(2), 0);
        tv.setLayoutParams(lp);
        if (l != null) tv.setOnClickListener(l);
        return tv;
    }

    private void setButtonBg(View v, String colorHex) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(colorHex));
        d.setStroke(dp(1), Color.parseColor("#383838"));
        d.setCornerRadius(dp(3));
        v.setBackground(d);
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(6), dp(6), dp(6));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));

        android.graphics.drawable.ClipDrawable clipProgress = new android.graphics.drawable.ClipDrawable(
                progressTrack, Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL);

        android.graphics.drawable.LayerDrawable layerDrawable = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{bgTrack, clipProgress});
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(14), dp(14));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }

    // ২য় ইমেজের হুবহু ভেক্টর পেইন্টব্রাশ আউটলাইন আইকন
    private BitmapDrawable createVectorBrushIcon() {
        int s = dp(22);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.8f));
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);

        float f = s / 100f;

        // ১. ব্রাশের হ্যান্ডেল (Handle)
        Path handle = new Path();
        handle.moveTo(13f * f, 10f * f);
        handle.cubicTo(32f * f, 24f * f, 54f * f, 44f * f, 71f * f, 64f * f);
        handle.cubicTo(69f * f, 71f * f, 64f * f, 76f * f, 58f * f, 77f * f);
        handle.cubicTo(48f * f, 60f * f, 24f * f, 33f * f, 10f * f, 13f * f);
        handle.quadTo(9f * f, 9f * f, 13f * f, 10f * f);
        handle.close();
        c.drawPath(handle, p);

        // ২. ব্রাশের কার্ভড ব্রিসল ও টিপ (Bristle with curved tip)
        Path bristle = new Path();
        bristle.moveTo(58f * f, 77f * f);
        bristle.cubicTo(60f * f, 88f * f, 70f * f, 93f * f, 78f * f, 91f * f);
        bristle.cubicTo(85f * f, 90f * f, 90f * f, 83f * f, 93f * f, 72f * f);
        bristle.cubicTo(91f * f, 77f * f, 85f * f, 79f * f, 81f * f, 77f * f);
        bristle.cubicTo(77f * f, 75f * f, 74f * f, 69f * f, 71f * f, 64f * f);
        c.drawPath(bristle, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private int dp(float val) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, activity.getResources().getDisplayMetrics());
    }

    private void handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CODE_CUSTOM_BRUSH && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            promptCustomBrushCreationDialog(data.getData());
        }
    }

    @Override
    public void onCommand(String command, Object... args) {
        if ("SET_COLOR".equalsIgnoreCase(command) && args.length > 0 && args[0] instanceof Integer) {
            brushColor = (Integer) args[0];
            updatePaintSettings();
            updateBrushOptionControlsBar();
        } else if ("on_activity_result".equalsIgnoreCase(command) && args.length >= 3) {
            if (args[0] instanceof Integer && args[1] instanceof Integer && args[2] instanceof Intent) {
                handleActivityResult((int) args[0], (int) args[1], (Intent) args[2]);
            }
        }
    }
}