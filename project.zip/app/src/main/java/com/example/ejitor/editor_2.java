package com.example.ejitor;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.http.SslError;
import android.os.Build;
import android.os.Message;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class editor_2 {

    private EditorActivity activity;

    // ওয়েব মাল্টি-সিলেকশন স্টেট
    private final java.util.ArrayList<String> selectedWebImagesList = new java.util.ArrayList<>();
    private boolean isWebMultiSelectMode = false;
    private String lastSelectedWebImageUrl = "";

    // গুগল ও পিন্টারেস্ট একসাথে ওপেন ও ফ্লোটিং রাখার জন্য ইন্ডিপেন্ডেন্ট ম্যাপ
    private final Map<String, Dialog> activeDialogsMap = new HashMap<>();
    private final Map<String, View> floatingBubblesMap = new HashMap<>();
    private final Map<String, Integer> currentZoomMap = new HashMap<>();

    // কম্পিউটার ডেক্সটপ ইউজার এজেন্ট
    private static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";

    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        hookImageMenu();
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    // --- রিফ্লেকশন মেথডসমূহ ---
    private void invokePrivateVoidMethod(String methodName) {
        if (activity == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(methodName);
            m.setAccessible(true);
            m.invoke(activity);
        } catch (Exception ignored) {}
    }

    private void invokePrivateMethod(EditorActivity act, String name) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    private void invokePrivateSessionMethod(EditorActivity act, String name, EditorActivity.ProjectTabSession s) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name, EditorActivity.ProjectTabSession.class);
            m.setAccessible(true);
            m.invoke(act, s);
        } catch (Exception ignored) {}
    }

    private void hookImageMenu() {
        if (activity == null || activity.menuContainer == null) return;

        for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
            View child = activity.menuContainer.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if ("Image".equalsIgnoreCase(tv.getText().toString().trim())) {
                    tv.setOnClickListener(this::showImageMenuDropdown);
                    break;
                }
            }
        }
    }

    private void showImageMenuDropdown(View anchor) {
        final PopupWindow popup = new PopupWindow(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(8), dp(6), dp(8), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        layout.setBackground(bg);

        String[] imgItems = {"Open Image", "Google", "Pinterest"};
        for (int i = 0; i < imgItems.length; i++) {
            final int idx = i;
            TextView itemTv = new TextView(activity);
            itemTv.setText(imgItems[i]);
            itemTv.setTextColor(Color.WHITE);
            itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            itemTv.setPadding(dp(14), dp(8), dp(14), dp(8));

            itemTv.setOnClickListener(v -> {
                popup.dismiss();
                if (idx == 0) {
                    invokePrivateVoidMethod("showInAppMultiImagePicker");
                } else if (idx == 1) {
                    openWebImageSearchDialog("Google", "https://images.google.com");
                } else if (idx == 2) {
                    openWebImageSearchDialog("Pinterest", "https://www.pinterest.com");
                }
            });
            layout.addView(itemTv);
        }

        popup.setContentView(layout);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    // গুগল ও পিন্টারেস্ট ডেক্সটপ ডায়ালগ (একসাথে একাধিক চালানো যাবে)
    private void openWebImageSearchDialog(final String serviceName, String defaultStartUrl) {
        final String key = serviceName.toLowerCase();

        // অলরেডি ব্যাকগ্রাউন্ডে মিনিমাইজ বা চালু থাকলে সরাসরি রিস্টোর করা হবে
        if (activeDialogsMap.containsKey(key)) {
            Dialog existing = activeDialogsMap.get(key);
            if (existing != null) {
                removeFloatingBubble(key);
                existing.show();
                return;
            }
        }

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        activeDialogsMap.put(key, dialog);

        final SharedPreferences sp = activity.getSharedPreferences("ejitor_web_search", Context.MODE_PRIVATE);
        final String savedQueryKey = "query_" + key;
        final String savedUrlKey = "url_" + key;
        final String savedZoomKey = "zoom_" + key;

        // সেভ করা জুম লেভেল লোড (ডিফল্ট ১০০%)
        int savedZoom = sp.getInt(savedZoomKey, 100);
        currentZoomMap.put(key, savedZoom);

        String savedQuery = sp.getString(savedQueryKey, "");
        String startUrl = sp.getString(savedUrlKey, defaultStartUrl);

        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        final int defaultW = (int) (dm.widthPixels * 0.96);
        final int defaultH = (int) (dm.heightPixels * 0.92);

        final LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(dp(10), dp(8), dp(10), dp(4));

        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setColor(Color.BLACK);
        rootBg.setStroke(dp(1), Color.parseColor("#2C2C2C"));
        rootBg.setCornerRadius(dp(10));
        root.setBackground(rootBg);

        // হেডার
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(4), 0, dp(4), dp(6));

        // প্লাস আইকন (ক্লিক করলে গোল ফ্লোটিং আইকনে মিনিমাইজ হবে)
        ImageView dragIcon = new ImageView(activity);
        dragIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        dragIcon.setImageDrawable(createVectorDragIcon());
        dragIcon.setPadding(dp(2), dp(2), dp(2), dp(2));
        dragIcon.setOnClickListener(v -> showFloatingBubble(dialog, serviceName));
        header.addView(dragIcon);

        // টাইটেল
        TextView titleTv = new TextView(activity);
        titleTv.setText("  " + serviceName + " Images");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeBtn = new ImageView(activity);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
        closeBtn.setImageDrawable(createVectorCloseIcon());
        closeBtn.setOnClickListener(v -> {
            removeFloatingBubble(key);
            activeDialogsMap.remove(key);
            dialog.dismiss();
        });
        header.addView(closeBtn);
        root.addView(header);

        header.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (dialog.getWindow() == null) return false;
                WindowManager.LayoutParams wlp = dialog.getWindow().getAttributes();
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX() - wlp.x;
                        startY = event.getRawY() - wlp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wlp.x = (int) (event.getRawX() - startX);
                        wlp.y = (int) (event.getRawY() - startY);
                        dialog.getWindow().setAttributes(wlp);
                        return true;
                }
                return false;
            }
        });

        LinearLayout searchBar = new LinearLayout(activity);
        searchBar.setOrientation(LinearLayout.HORIZONTAL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(0, 0, 0, dp(6));

        ImageView menuBtn = new ImageView(activity);
        menuBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(24), dp(28)));
        menuBtn.setImageDrawable(createVectorMenuIcon());
        menuBtn.setPadding(dp(3), dp(4), dp(3), dp(4));
        searchBar.addView(menuBtn);

        final ImageView backNavBtn = new ImageView(activity);
        backNavBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(28)));
        backNavBtn.setImageDrawable(createVectorBackNavIcon());
        backNavBtn.setPadding(dp(3), dp(4), dp(3), dp(4));
        searchBar.addView(backNavBtn);

        final EditText searchInput = new EditText(activity);
        searchInput.setHint("Search " + serviceName + " HD...");
        searchInput.setHintTextColor(Color.parseColor("#666666"));
        searchInput.setTextColor(Color.WHITE);
        searchInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        searchInput.setSingleLine(true);
        searchInput.setText(savedQuery);
        searchInput.setPadding(dp(8), dp(4), dp(8), dp(4));

        GradientDrawable sbBg = new GradientDrawable();
        sbBg.setColor(Color.parseColor("#141414"));
        sbBg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        sbBg.setCornerRadius(dp(4));
        searchInput.setBackground(sbBg);
        searchInput.setLayoutParams(new LinearLayout.LayoutParams(0, dp(30), 1f));
        searchBar.addView(searchInput);

        View sp1 = new View(activity);
        sp1.setLayoutParams(new LinearLayout.LayoutParams(dp(5), dp(1)));
        searchBar.addView(sp1);

        Button searchBtn = new Button(activity);
        searchBtn.setText("SEARCH");
        searchBtn.setTextColor(Color.WHITE);
        searchBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        searchBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable sBg = new GradientDrawable();
        sBg.setColor(Color.parseColor("#FF1238"));
        sBg.setCornerRadius(dp(15));
        searchBtn.setBackground(sBg);
        searchBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(58), dp(28)));
        searchBar.addView(searchBtn);

        View sp2 = new View(activity);
        sp2.setLayoutParams(new LinearLayout.LayoutParams(dp(5), dp(1)));
        searchBar.addView(sp2);

        final Button selectBtn = new Button(activity);
        selectBtn.setText("SELECT");
        selectBtn.setTextColor(Color.WHITE);
        selectBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        selectBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable selBg = new GradientDrawable();
        selBg.setColor(Color.parseColor("#FF1238"));
        selBg.setCornerRadius(dp(15));
        selectBtn.setBackground(selBg);
        selectBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(62), dp(28)));
        searchBar.addView(selectBtn);

        root.addView(searchBar);

        final WebView webView = new WebView(activity);
        webView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        final WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setLoadsImagesAutomatically(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setSupportZoom(true);
        ws.setSupportMultipleWindows(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(true);

        // দ্রুত লোডিং ও ক্যাশিং অপ্টিমাইজেশন
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setBlockNetworkImage(false);

        // 5000 ডেক্সটপ ভিউ সেটিংস
        ws.setUserAgentString(DESKTOP_UA);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setTextZoom(100);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cm.setAcceptThirdPartyCookies(webView, true);
        }

        backNavBtn.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
        });

        final String forceDesktop5000Script =
                "(function() {" +
                "  var meta = document.querySelector('meta[name=\"viewport\"]');" +
                "  if (!meta) {" +
                "    meta = document.createElement('meta');" +
                "    meta.name = 'viewport';" +
                "    document.head.appendChild(meta);" +
                "  }" +
                "  meta.setAttribute('content', 'width=5000, initial-scale=0.1, user-scalable=yes');" +
                "  document.documentElement.style.minWidth = '5000px';" +
                "  document.documentElement.style.width = '5000px';" +
                "  document.body.style.minWidth = '5000px';" +
                "  document.body.style.width = '5000px';" +
                "  window.dispatchEvent(new Event('resize'));" +
                "  var style = document.getElementById('ejitor_desktop_fix_5000');" +
                "  if (!style) {" +
                "    style = document.createElement('style');" +
                "    style.id = 'ejitor_desktop_fix_5000';" +
                "    style.innerHTML = '" +
                "      div[data-test-id=\"help-button\"], div[aria-label*=\"Feedback\"], " +
                "      div[data-test-id=\"full-page-signup\"], div[data-test-id=\"header-spacer\"] { display: none !important; }" +
                "      header, div[role=\"navigation\"] { max-width: 5000px !important; }" +
                "      body { margin: 0 !important; padding: 0 !important; }" +
                "    ';" +
                "    document.head.appendChild(style);" +
                "  }" +
                "})();";

        final String googleSignInWatcherScript =
                "(function() {" +
                "  if (window.ejitorGoogleWatcher) return;" +
                "  window.ejitorGoogleWatcher = true;" +
                "  document.addEventListener('click', function(e) {" +
                "    var target = e.target.closest('button, div[role=\"button\"], a');" +
                "    if (target) {" +
                "      var txt = (target.innerText || target.textContent || '').toLowerCase();" +
                "      if (txt.includes('continue with google') || txt.includes('sign in with google') || txt.includes('log in with google')) {" +
                "        if (window.EjitorBridge && window.EjitorBridge.onGoogleContinueClicked) {" +
                "          window.EjitorBridge.onGoogleContinueClicked();" +
                "        }" +
                "      }" +
                "    }" +
                "  }, true);" +
                "})();";

        // হাই-কোয়ালিটি / অরিজিনাল HD ইমেজ সিলেকশন
        final String selectModeScript =
                "(function() {" +
                "  window.ejitorSelectMode = true;" +
                "  window.ejitorSelectedMap = window.ejitorSelectedMap || {};" +
                "  function getHighResUrl(target) {" +
                "    var a = target.closest('a');" +
                "    if (a && a.href) {" +
                "      var m = a.href.match(/[?&]imgurl=([^&]+)/);" +
                "      if (m && m[1]) {" +
                "        try { return decodeURIComponent(m[1]); } catch(e){}" +
                "      }" +
                "    }" +
                "    var img = (target.tagName === 'IMG') ? target : target.querySelector('img');" +
                "    if (!img) return null;" +
                "    var src = img.getAttribute('data-src') || img.src || img.currentSrc;" +
                "    if (!src) return null;" +
                "    if (src.indexOf('pinimg.com') !== -1) {" +
                "      src = src.replace(/\\/(170x|236x|474x|736x)\\//, '/originals/');" +
                "    }" +
                "    return src;" +
                "  }" +
                "  if (!window.ejitorListenerBound) {" +
                "    window.ejitorListenerBound = true;" +
                "    document.addEventListener('click', function(e) {" +
                "      if (window.ejitorSelectMode) {" +
                "        var target = e.target;" +
                "        if (target.tagName === 'A' || target.closest('a')) {" +
                "          e.preventDefault(); e.stopPropagation();" +
                "        }" +
                "        var img = (target.tagName === 'IMG') ? target : target.querySelector('img');" +
                "        if (img) {" +
                "          e.preventDefault(); e.stopPropagation();" +
                "          var hdUrl = getHighResUrl(target);" +
                "          if (!hdUrl) return;" +
                "          if (window.ejitorSelectedMap[hdUrl]) {" +
                "            delete window.ejitorSelectedMap[hdUrl];" +
                "            img.style.outline = 'none';" +
                "          } else {" +
                "            window.ejitorSelectedMap[hdUrl] = true;" +
                "            img.style.outline = '4px solid #FF1238';" +
                "            img.style.outlineOffset = '-4px';" +
                "          }" +
                "          var list = Object.keys(window.ejitorSelectedMap);" +
                "          if (window.EjitorBridge) window.EjitorBridge.onSelectionChanged(JSON.stringify(list));" +
                "        }" +
                "      }" +
                "    }, true);" +
                "  }" +
                "})();";

        selectedWebImagesList.clear();
        isWebMultiSelectMode = false;

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void onSelectionChanged(String jsonArray) {
                activity.runOnUiThread(() -> {
                    try {
                        org.json.JSONArray arr = new org.json.JSONArray(jsonArray);
                        selectedWebImagesList.clear();
                        for (int i = 0; i < arr.length(); i++) {
                            selectedWebImagesList.add(arr.getString(i));
                        }
                        if (isWebMultiSelectMode) {
                            selectBtn.setText(selectedWebImagesList.isEmpty() ? "IMPORT" : "IMPORT (" + selectedWebImagesList.size() + ")");
                        }
                    } catch (Exception ignored) {}
                });
            }

            @JavascriptInterface
            public void onGoogleContinueClicked() {
                activity.runOnUiThread(() -> showDeviceGoogleAccountsDialog(webView));
            }
        }, "EjitorBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView popupWebView = new WebView(activity);
                WebSettings popupSettings = popupWebView.getSettings();
                popupSettings.setJavaScriptEnabled(true);
                popupSettings.setDomStorageEnabled(true);
                popupSettings.setUserAgentString(DESKTOP_UA);

                CookieManager.getInstance().setAcceptThirdPartyCookies(popupWebView, true);

                final Dialog authDialog = new Dialog(activity);
                authDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                authDialog.setContentView(popupWebView);
                if (authDialog.getWindow() != null) {
                    authDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                    authDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.BLACK));
                }
                authDialog.show();

                popupWebView.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, String url) {
                        if (url != null && url.contains("pinterest.com") && !url.contains("accounts.google.com")) {
                            authDialog.dismiss();
                            webView.loadUrl(url);
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onPageFinished(WebView v, String url) {
                        super.onPageFinished(v, url);
                        if (url != null && url.contains("pinterest.com") && !url.contains("accounts.google.com") && !url.contains("google.com/signin")) {
                            authDialog.dismiss();
                            webView.reload();
                        }
                    }
                });

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null) return false;
                if (url.startsWith("intent:") || url.startsWith("market:") || url.startsWith("pinterest:")) {
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                sp.edit().putString(savedUrlKey, url).apply();

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    webView.evaluateJavascript(forceDesktop5000Script, null);
                    webView.evaluateJavascript(googleSignInWatcherScript, null);
                    // বর্তমান জুম স্কেল বজায় রাখা
                    int curZoom = currentZoomMap.get(key) != null ? currentZoomMap.get(key) : 100;
                    if (curZoom != 100) {
                        webView.evaluateJavascript("document.body.style.zoom = '" + (curZoom / 100f) + "';", null);
                    }
                    if (isWebMultiSelectMode) {
                        webView.evaluateJavascript(selectModeScript, null);
                    }
                } else {
                    webView.loadUrl("javascript:" + forceDesktop5000Script);
                    webView.loadUrl("javascript:" + googleSignInWatcherScript);
                    if (isWebMultiSelectMode) {
                        webView.loadUrl("javascript:" + selectModeScript);
                    }
                }
            }
        });

        webView.loadUrl(startUrl);

        searchBtn.setOnClickListener(v -> {
            String q = searchInput.getText().toString().trim();
            if (!q.isEmpty()) {
                sp.edit().putString(savedQueryKey, q).apply();
                try {
                    String enc = URLEncoder.encode(q, "UTF-8");
                    String targetUrl = serviceName.contains("Google") ?
                            "https://www.google.com/search?tbm=isch&q=" + enc :
                            "https://www.pinterest.com/search/pins/?q=" + enc;
                    sp.edit().putString(savedUrlKey, targetUrl).apply();
                    webView.loadUrl(targetUrl);
                } catch (Exception ignored) {}
            }
        });

        selectBtn.setOnClickListener(v -> {
            if (!isWebMultiSelectMode) {
                isWebMultiSelectMode = true;
                selectBtn.setText("IMPORT (0)");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    webView.evaluateJavascript(selectModeScript, null);
                } else {
                    webView.loadUrl("javascript:" + selectModeScript);
                }
                Toast.makeText(activity, "Tap HD images to select, then click IMPORT", Toast.LENGTH_SHORT).show();
            } else {
                if (!selectedWebImagesList.isEmpty()) {
                    importMultipleImagesToCanvas(new ArrayList<>(selectedWebImagesList));
                    selectedWebImagesList.clear();
                    isWebMultiSelectMode = false;
                    selectBtn.setText("SELECT");
                } else {
                    Toast.makeText(activity, "Please tap images to select first", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // মেনু বাটন (লাইভ জুম কন্ট্রোলার পপ-আপ সহ)
        menuBtn.setOnClickListener(v -> {
            final PopupWindow menuPopup = new PopupWindow(activity);
            LinearLayout menuL = new LinearLayout(activity);
            menuL.setOrientation(LinearLayout.VERTICAL);
            menuL.setBackgroundColor(Color.parseColor("#1C1C1C"));
            menuL.setPadding(dp(8), dp(6), dp(8), dp(6));

            String[] items = {
                    "Zoom Controller...",
                    "Sign in with Google",
                    isWebMultiSelectMode ? "Cancel Select Mode" : "Multi-Select Mode",
                    "Import All Selected",
                    "Clear Selection"
            };

            for (int i = 0; i < items.length; i++) {
                final int idx = i;
                TextView tv = new TextView(activity);
                tv.setText(items[i]);
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                tv.setPadding(dp(12), dp(8), dp(12), dp(8));
                tv.setOnClickListener(v1 -> {
                    menuPopup.dismiss();
                    if (idx == 0) {
                        showLiveZoomDialog(webView, key);
                    } else if (idx == 1) {
                        showDeviceGoogleAccountsDialog(webView);
                    } else if (idx == 2) {
                        isWebMultiSelectMode = !isWebMultiSelectMode;
                        selectBtn.setText(isWebMultiSelectMode ? "IMPORT (" + selectedWebImagesList.size() + ")" : "SELECT");
                        if (isWebMultiSelectMode) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                webView.evaluateJavascript(selectModeScript, null);
                            } else {
                                webView.loadUrl("javascript:" + selectModeScript);
                            }
                        }
                    } else if (idx == 3) {
                        if (!selectedWebImagesList.isEmpty()) {
                            importMultipleImagesToCanvas(new ArrayList<>(selectedWebImagesList));
                            selectedWebImagesList.clear();
                            selectBtn.setText("SELECT");
                        } else {
                            Toast.makeText(activity, "No images selected", Toast.LENGTH_SHORT).show();
                        }
                    } else if (idx == 4) {
                        selectedWebImagesList.clear();
                        selectBtn.setText(isWebMultiSelectMode ? "IMPORT (0)" : "SELECT");
                        webView.reload();
                    }
                });
                menuL.addView(tv);
            }

            menuPopup.setContentView(menuL);
            menuPopup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setFocusable(true);
            menuPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            menuPopup.showAsDropDown(menuBtn, 0, dp(4));
        });

        webView.setOnLongClickListener(v -> {
            WebView.HitTestResult result = webView.getHitTestResult();
            if (result.getType() == WebView.HitTestResult.IMAGE_TYPE ||
                result.getType() == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                String imgUrl = result.getExtra();
                if (imgUrl != null && !imgUrl.isEmpty()) {
                    imgUrl = resolveHdImageUrl(imgUrl);
                    lastSelectedWebImageUrl = imgUrl;
                    showImportConfirmDialog(imgUrl);
                    return true;
                }
            }
            return false;
        });

        root.addView(webView);

        LinearLayout bottomBar = new LinearLayout(activity);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(0, dp(2), dp(2), dp(2));

        ImageView resizeHandle = new ImageView(activity);
        resizeHandle.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
        resizeHandle.setImageDrawable(createVectorResizeGrip());

        resizeHandle.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            int startW, startH;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (dialog.getWindow() == null) return false;
                WindowManager.LayoutParams wlp = dialog.getWindow().getAttributes();
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX();
                        startY = event.getRawY();
                        startW = wlp.width;
                        startH = wlp.height;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dX = event.getRawX() - startX;
                        float dY = event.getRawY() - startY;
                        wlp.width = Math.max(dp(260), (int) (startW + dX));
                        wlp.height = Math.max(dp(300), (int) (startH + dY));
                        dialog.getWindow().setAttributes(wlp);
                        return true;
                }
                return false;
            }
        });
        bottomBar.addView(resizeHandle);
        root.addView(bottomBar);

        dialog.setContentView(root);
        dialog.show();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(defaultW, defaultH);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            dialog.getWindow().setGravity(Gravity.CENTER);
        }
    }

    // editor_4.java থেকে হুবহু কাস্টম স্টাইলের স্লিম সাদা/লাল স্লাইডার মেথড
    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(8), dp(6), dp(14));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }

    // লাইভ জুম কন্ট্রোলার পপ-আপ (জুম সবসময় সেভ থাকবে)
    private void showLiveZoomDialog(final WebView webView, final String serviceKey) {
        final Dialog zoomDialog = new Dialog(activity);
        zoomDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final SharedPreferences sp = activity.getSharedPreferences("ejitor_web_search", Context.MODE_PRIVATE);
        final String savedZoomKey = "zoom_" + serviceKey;

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);

        // হেডার
        LinearLayout headerRow = new LinearLayout(activity);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);
        headerRow.setPadding(0, 0, 0, dp(12));

        TextView headTitle = new TextView(activity);
        headTitle.setText("Zoom Controller");
        headTitle.setTextColor(Color.WHITE);
        headTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        headTitle.setTypeface(null, Typeface.BOLD);
        headTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        headerRow.addView(headTitle);

        ImageView closeBtn = new ImageView(activity);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(15), dp(15)));
        closeBtn.setImageDrawable(createVectorCloseIcon());
        closeBtn.setOnClickListener(v -> zoomDialog.dismiss());
        headerRow.addView(closeBtn);
        box.addView(headerRow);

        int initialZoom = currentZoomMap.get(serviceKey) != null ? currentZoomMap.get(serviceKey) : sp.getInt(savedZoomKey, 100);
        final int minZoom = 20;
        final int maxZoom = 300;

        // টপ রো (লেবেল, এডিটটেক্সট বক্স, ইউনিট এবং রিসেট বাটন)
        LinearLayout topRow = new LinearLayout(activity);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(0, 0, 0, dp(8));

        TextView labelTv = new TextView(activity);
        labelTv.setText("Zoom Level:");
        labelTv.setTextColor(Color.parseColor("#AAAAAA"));
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        labelTv.setLayoutParams(new LinearLayout.LayoutParams(dp(85), ViewGroup.LayoutParams.WRAP_CONTENT));
        topRow.addView(labelTv);

        final EditText valBox = new EditText(activity);
        valBox.setText(String.valueOf(initialZoom));
        valBox.setTextColor(Color.WHITE);
        valBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        valBox.setGravity(Gravity.CENTER);
        valBox.setSingleLine(true);
        valBox.setInputType(InputType.TYPE_CLASS_NUMBER);
        valBox.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(28)));

        GradientDrawable valBg = new GradientDrawable();
        valBg.setColor(Color.parseColor("#121212"));
        valBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        valBg.setCornerRadius(dp(3));
        valBox.setBackground(valBg);
        topRow.addView(valBox);

        TextView unitTv = new TextView(activity);
        unitTv.setText("  %");
        unitTv.setTextColor(Color.parseColor("#888888"));
        unitTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        topRow.addView(unitTv);

        View spacer = new View(activity);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(0, dp(1), 1f));
        topRow.addView(spacer);

        Button resetBtn = new Button(activity);
        resetBtn.setText("100%");
        resetBtn.setTextColor(Color.parseColor("#E0E0E0"));
        resetBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        GradientDrawable rBg = new GradientDrawable();
        rBg.setColor(Color.parseColor("#262626"));
        rBg.setStroke(dp(1), Color.parseColor("#383838"));
        rBg.setCornerRadius(dp(4));
        resetBtn.setBackground(rBg);
        resetBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(50), dp(28)));
        topRow.addView(resetBtn);

        box.addView(topRow);

        // editor_4.java স্টাইলের কাস্টম স্লাইডার
        final SeekBar seekBar = new SeekBar(activity);
        seekBar.setMax(maxZoom - minZoom);
        seekBar.setProgress(Math.max(0, initialZoom - minZoom));
        applyCustomSeekBarStyle(seekBar);
        box.addView(seekBar);

        // লাইভ জুম কার্যকর ও পার্মানেন্টলি সেভ করার হেল্পার
        final Runnable applyZoom = () -> {
            int z = currentZoomMap.get(serviceKey) != null ? currentZoomMap.get(serviceKey) : 100;
            // পার্মানেন্ট সেভ
            sp.edit().putInt(savedZoomKey, z).apply();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                webView.evaluateJavascript("document.body.style.zoom = '" + (z / 100f) + "';", null);
            } else {
                webView.loadUrl("javascript:document.body.style.zoom = '" + (z / 100f) + "';");
            }
        };

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    int z = minZoom + progress;
                    valBox.setText(String.valueOf(z));
                    currentZoomMap.put(serviceKey, z);
                    applyZoom.run();
                }
            }

            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        valBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    String str = cs.toString().trim();
                    if (!str.isEmpty()) {
                        int z = Integer.parseInt(str);
                        z = Math.max(minZoom, Math.min(maxZoom, z));
                        if (seekBar.getProgress() != (z - minZoom)) {
                            seekBar.setProgress(z - minZoom);
                            currentZoomMap.put(serviceKey, z);
                            applyZoom.run();
                        }
                    }
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        resetBtn.setOnClickListener(v -> {
            seekBar.setProgress(100 - minZoom);
            valBox.setText("100");
            currentZoomMap.put(serviceKey, 100);
            applyZoom.run();
        });

        zoomDialog.setContentView(box);
        if (zoomDialog.getWindow() != null) {
            zoomDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            zoomDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            zoomDialog.getWindow().setLayout(dp(310), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        zoomDialog.show();
    }

    // মিনিমাইজ করে রিয়েলস্টিক গোল ফ্লোটিং ভেক্টর আইকন দেখানো (দুটো আলাদা থাকবে)
    private void showFloatingBubble(final Dialog dialog, final String serviceName) {
        if (activity == null) return;
        final String key = serviceName.toLowerCase();
        dialog.hide(); // ডায়ালগ ব্যাকগ্রাউন্ডে স্টেটসহ বজায় থাকবে

        final ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
        removeFloatingBubble(key);

        final int size = dp(46);
        final FrameLayout bubble = new FrameLayout(activity);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.leftMargin = dp(16);

        // Pinterest এবং Google একসাথে মিনিমাইজ থাকলে যেন একটির উপর আরেকটি না বসে আলাদা পজিশনে থাকে
        if (key.contains("pinterest")) {
            lp.topMargin = dp(80);
        } else {
            lp.topMargin = dp(140);
        }
        bubble.setLayoutParams(lp);

        ImageView iconView = new ImageView(activity);
        FrameLayout.LayoutParams imgLp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        iconView.setLayoutParams(imgLp);

        // রিয়েলস্টিক ভেক্টর আইকন সেট করা
        if (key.contains("pinterest")) {
            iconView.setImageDrawable(createRealisticPinterestIcon());
        } else {
            iconView.setImageDrawable(createRealisticGoogleIcon());
        }
        bubble.addView(iconView);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bubble.setElevation(dp(12));
        }

        bubble.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            float initX, initY;
            boolean isDrag = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX();
                        startY = event.getRawY();
                        initX = v.getX();
                        initY = v.getY();
                        isDrag = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - startX;
                        float dy = event.getRawY() - startY;
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isDrag = true;
                        }
                        v.setX(initX + dx);
                        v.setY(initY + dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDrag) {
                            // ক্লিকে গোল আইকনটি বন্ধ হয়ে ডায়ালগটি আবার ভেসে উঠবে
                            removeFloatingBubble(key);
                            dialog.show();
                        }
                        return true;
                }
                return false;
            }
        });

        floatingBubblesMap.put(key, bubble);
        decorView.addView(bubble);
    }

    private void removeFloatingBubble(String serviceKey) {
        if (activity != null && floatingBubblesMap.containsKey(serviceKey)) {
            View bubble = floatingBubblesMap.get(serviceKey);
            if (bubble != null) {
                ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
                decorView.removeView(bubble);
            }
            floatingBubblesMap.remove(serviceKey);
        }
    }

    // --- রিয়েলস্টিক ভেক্টর আইকন ড্রয়িং মেথডসমূহ ---

    // ১. রিয়েলস্টিক Pinterest ভেক্টর আইকন
    private BitmapDrawable createRealisticPinterestIcon() {
        int w = dp(46);
        Bitmap bmp = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);

        // লাল গোল ব্যাকগ্রাউন্ড
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.parseColor("#E60023"));
        canvas.drawCircle(w / 2f, w / 2f, w / 2f, bgPaint);

        // সাদা বর্ডার
        Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(dp(2));
        strokePaint.setColor(Color.WHITE);
        canvas.drawCircle(w / 2f, w / 2f, (w / 2f) - dp(1), strokePaint);

        // Pinterest অফিসিয়াল স্টাইলাইজড 'P'
        Paint pPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        pPaint.setColor(Color.WHITE);
        pPaint.setStyle(Paint.Style.STROKE);
        pPaint.setStrokeCap(Paint.Cap.ROUND);
        pPaint.setStrokeJoin(Paint.Join.ROUND);

        // P এর মূল লম্বা স্টেম
        pPaint.setStrokeWidth(dp(4.2f));
        Path stem = new Path();
        stem.moveTo(w * 0.46f, w * 0.28f);
        stem.quadTo(w * 0.44f, w * 0.55f, w * 0.38f, w * 0.76f);
        canvas.drawPath(stem, pPaint);

        // P এর বাঁকানো লুপ
        pPaint.setStrokeWidth(dp(3.8f));
        Path loop = new Path();
        loop.moveTo(w * 0.42f, w * 0.45f);
        loop.cubicTo(w * 0.40f, w * 0.24f, w * 0.68f, w * 0.22f, w * 0.68f, w * 0.42f);
        loop.cubicTo(w * 0.68f, w * 0.58f, w * 0.45f, w * 0.60f, w * 0.44f, w * 0.47f);
        canvas.drawPath(loop, pPaint);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    // ২. অফিশিয়াল ও নিখুঁত Google 4-Color 'G' ভেক্টর আইকন (Image 2 Fix)
    private BitmapDrawable createRealisticGoogleIcon() {
        int w = dp(46);
        Bitmap bmp = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);

        // সাদা গোল ব্যাকগ্রাউন্ড
        Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.WHITE);
        canvas.drawCircle(w / 2f, w / 2f, w / 2f, bgPaint);

        // হালকা বর্ডার
        Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderPaint.setStyle(Paint.Style.STROKE);
        borderPaint.setStrokeWidth(dp(1.5f));
        borderPaint.setColor(Color.parseColor("#E0E0E0"));
        canvas.drawCircle(w / 2f, w / 2f, (w / 2f) - dp(1), borderPaint);

        // গুগলের ৪ কালার অফিশিয়াল 'G' জ্যামিতি
        float cx = w / 2f;
        float cy = w / 2f;
        float r = w * 0.28f;
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);

        float strokeW = dp(4.6f);
        Paint gPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gPaint.setStyle(Paint.Style.STROKE);
        gPaint.setStrokeWidth(strokeW);
        gPaint.setStrokeCap(Paint.Cap.BUTT);

        // ১. রেড আর্চ (টপ অংশ: ২২৫° থেকে ৩১৫° পর্যন্ত)
        gPaint.setColor(Color.parseColor("#EA4335"));
        canvas.drawArc(oval, 225, 90, false, gPaint);

        // ২. ইয়েলো আর্চ (লেফট অংশ: ১৪০° থেকে ২২৫° পর্যন্ত)
        gPaint.setColor(Color.parseColor("#FBBC05"));
        canvas.drawArc(oval, 140, 85, false, gPaint);

        // ৩. গ্রিন আর্চ (বটম অংশ: ৪৫° থেকে ১৪০° পর্যন্ত)
        gPaint.setColor(Color.parseColor("#34A853"));
        canvas.drawArc(oval, 45, 95, false, gPaint);

        // ৪. ব্লু আর্চ (ডানপাশের নিচের বাঁক: ০° থেকে ৪৫° পর্যন্ত)
        gPaint.setColor(Color.parseColor("#4285F4"));
        canvas.drawArc(oval, 0, 45, false, gPaint);

        // ৫. ব্লু হরাইজন্টাল ক্রসবার (মাঝের বার যা G এর ভেতর প্রবেশ করেছে)
        Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setColor(Color.parseColor("#4285F4"));
        barPaint.setStyle(Paint.Style.STROKE);
        barPaint.setStrokeWidth(strokeW);
        barPaint.setStrokeCap(Paint.Cap.BUTT);
        canvas.drawLine(cx - dp(1f), cy, cx + r, cy, barPaint);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private String resolveHdImageUrl(String url) {
        if (url == null) return "";
        try {
            if (url.contains("pinimg.com")) {
                return url.replaceAll("/(170x|236x|474x|736x)/", "/originals/");
            }
            if (url.contains("imgurl=")) {
                int start = url.indexOf("imgurl=") + 7;
                int end = url.indexOf("&", start);
                if (end == -1) end = url.length();
                String raw = url.substring(start, end);
                return URLDecoder.decode(raw, "UTF-8");
            }
        } catch (Exception ignored) {}
        return url;
    }

    private void showDeviceGoogleAccountsDialog(final WebView mainWebView) {
        ArrayList<String> accountsList = new ArrayList<>();
        try {
            AccountManager am = AccountManager.get(activity);
            Account[] accounts = am.getAccountsByType("com.google");
            if (accounts != null && accounts.length > 0) {
                for (Account a : accounts) {
                    if (a.name != null && a.name.contains("@")) {
                        accountsList.add(a.name);
                    }
                }
            }
        } catch (Exception ignored) {}

        final Dialog accDialog = new Dialog(activity);
        accDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(16));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);

        TextView head = new TextView(activity);
        head.setText("Choose an account");
        head.setTextColor(Color.WHITE);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        head.setTypeface(null, Typeface.BOLD);
        head.setPadding(0, 0, 0, dp(4));
        box.addView(head);

        TextView sub = new TextView(activity);
        sub.setText("to continue to Pinterest");
        sub.setTextColor(Color.parseColor("#888888"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        sub.setPadding(0, 0, 0, dp(12));
        box.addView(sub);

        ScrollView sv = new ScrollView(activity);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);

        if (!accountsList.isEmpty()) {
            for (final String email : accountsList) {
                LinearLayout row = new LinearLayout(activity);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(8), dp(10), dp(8), dp(10));

                GradientDrawable rowBg = new GradientDrawable();
                rowBg.setColor(Color.parseColor("#262626"));
                rowBg.setCornerRadius(dp(6));
                row.setBackground(rowBg);

                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.setMargins(0, 0, 0, dp(6));
                row.setLayoutParams(rp);

                TextView icon = new TextView(activity);
                icon.setText("G");
                icon.setTextColor(Color.parseColor("#FF1238"));
                icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
                icon.setTypeface(null, Typeface.BOLD);
                icon.setPadding(dp(4), 0, dp(10), 0);
                row.addView(icon);

                TextView emailTv = new TextView(activity);
                emailTv.setText(email);
                emailTv.setTextColor(Color.WHITE);
                emailTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
                row.addView(emailTv);

                row.setOnClickListener(v -> {
                    accDialog.dismiss();
                    autoFillEmailOrOAuth(mainWebView, email);
                });

                list.addView(row);
            }
        }

        TextView otherAcc = new TextView(activity);
        otherAcc.setText("+ Use another account");
        otherAcc.setTextColor(Color.parseColor("#007AFF"));
        otherAcc.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        otherAcc.setPadding(dp(8), dp(10), dp(8), dp(8));
        otherAcc.setOnClickListener(v -> {
            accDialog.dismiss();
            mainWebView.loadUrl("https://accounts.google.com/signin");
        });
        list.addView(otherAcc);

        sv.addView(list);
        box.addView(sv);

        accDialog.setContentView(box);
        if (accDialog.getWindow() != null) {
            accDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            accDialog.getWindow().setLayout(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        accDialog.show();
    }

    private void autoFillEmailOrOAuth(WebView wv, String email) {
        Toast.makeText(activity, "Selected: " + email, Toast.LENGTH_SHORT).show();
        final String fillScript =
                "(function() {" +
                "  var input = document.querySelector('input[type=\"email\"], #email, input[name=\"id\"]');" +
                "  if (input) {" +
                "    input.value = '" + email + "';" +
                "    input.dispatchEvent(new Event('input', { bubbles: true }));" +
                "    input.dispatchEvent(new Event('change', { bubbles: true }));" +
                "    var nextBtn = document.querySelector('button[type=\"submit\"], button.red, div[data-test-id*=\"register\"] button');" +
                "    if (nextBtn) nextBtn.click();" +
                "  } else {" +
                "    window.location.href = 'https://accounts.google.com/o/oauth2/auth?login_hint=" + email + "';" +
                "  }" +
                "})();";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            wv.evaluateJavascript(fillScript, null);
        } else {
            wv.loadUrl("javascript:" + fillScript);
        }
    }

    private void importMultipleImagesToCanvas(final ArrayList<String> urls) {
        if (urls.isEmpty()) return;
        Toast.makeText(activity, "Downloading " + urls.size() + " HD image(s)...", Toast.LENGTH_SHORT).show();
        for (String u : urls) {
            downloadAndImportImage(u);
        }
    }

    private void showImportConfirmDialog(String imgUrl) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(18), dp(20), dp(18));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);

        TextView tv = new TextView(activity);
        tv.setText("Import this HD image to Project Canvas?");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setPadding(0, 0, 0, dp(16));
        box.addView(tv);

        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);

        Button cancel = new Button(activity);
        cancel.setText("Cancel");
        cancel.setTextColor(Color.parseColor("#E0E0E0"));
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        GradientDrawable canBg = new GradientDrawable();
        canBg.setColor(Color.parseColor("#2A2A2A"));
        canBg.setCornerRadius(dp(18));
        cancel.setBackground(canBg);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(36)));
        cancel.setOnClickListener(v -> d.dismiss());
        row.addView(cancel);

        View spacer = new View(activity);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(dp(12), dp(1)));
        row.addView(spacer);

        Button imp = new Button(activity);
        imp.setText("IMPORT HD");
        imp.setTextColor(Color.WHITE);
        imp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        imp.setTypeface(null, Typeface.BOLD);
        GradientDrawable impBg = new GradientDrawable();
        impBg.setColor(Color.parseColor("#FF1238"));
        impBg.setCornerRadius(dp(18));
        imp.setBackground(impBg);
        imp.setLayoutParams(new LinearLayout.LayoutParams(dp(95), dp(36)));
        imp.setOnClickListener(v -> {
            d.dismiss();
            downloadAndImportImage(imgUrl);
        });
        row.addView(imp);

        box.addView(row);
        d.setContentView(box);
        d.show();
    }

    private void downloadAndImportImage(String rawUrlStr) {
        new Thread(() -> {
            try {
                final String targetUrl = resolveHdImageUrl(rawUrlStr);
                Bitmap bmp = null;

                if (targetUrl.startsWith("data:image")) {
                    int commaIdx = targetUrl.indexOf(",");
                    if (commaIdx != -1) {
                        byte[] decoded = Base64.decode(targetUrl.substring(commaIdx + 1), Base64.DEFAULT);
                        bmp = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                    }
                } else {
                    bmp = fetchBitmapWithFallbacks(targetUrl);
                }

                if (bmp != null) {
                    final Bitmap finalBmp = bmp;
                    activity.runOnUiThread(() -> {
                        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
                        if (s != null) {
                            EditorActivity.LayerItem item = new EditorActivity.LayerItem(
                                    "Web HD Image " + (s.layers.size() + 1), finalBmp, s.canvasWidth / 5f, s.canvasHeight / 5f, false);
                            item.isBlank = false;
                            synchronized (s.layers) {
                                s.layers.add(item);
                                s.activeLayerIndex = s.layers.size() - 1;
                            }
                            invokePrivateMethod(activity, "recordHistory");
                            invokePrivateMethod(activity, "updateLayersDockUI");
                            invokePrivateSessionMethod(activity, "saveProjectToDisk", s);
                            if (activity.canvasView != null) activity.canvasView.invalidate();
                            Toast.makeText(activity, "Imported in HD Quality (" + finalBmp.getWidth() + "x" + finalBmp.getHeight() + ")", Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    activity.runOnUiThread(() -> Toast.makeText(activity, "Failed to download image", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private Bitmap fetchBitmapWithFallbacks(String urlStr) {
        Bitmap b = fetchBitmapFromNetwork(urlStr);
        if (b == null && urlStr.contains("/originals/")) {
            String fallback = urlStr.replace("/originals/", "/736x/");
            b = fetchBitmapFromNetwork(fallback);
        }
        return b;
    }

    private Bitmap fetchBitmapFromNetwork(String path) {
        try {
            URL url = new URL(path);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-Agent", DESKTOP_UA);
            conn.setRequestProperty("Referer", path.contains("pinterest") ? "https://www.pinterest.com/" : "https://www.google.com/");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(true);
            int code = conn.getResponseCode();
            if (code == HttpURLConnection.HTTP_OK) {
                InputStream is = new BufferedInputStream(conn.getInputStream(), 32768);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                is.close();
                return bmp;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private BitmapDrawable createVectorMenuIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.6f));
        c.drawLine(dp(2), dp(4), dp(14), dp(4), p);
        c.drawLine(dp(2), dp(8), dp(14), dp(8), p);
        c.drawLine(dp(2), dp(12), dp(14), dp(12), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createVectorBackNavIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.6f));
        c.drawLine(dp(12), dp(8), dp(4), dp(8), p);
        c.drawLine(dp(4), dp(8), dp(8), dp(4), p);
        c.drawLine(dp(4), dp(8), dp(8), dp(12), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createVectorDragIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#888888"));
        p.setStrokeWidth(dp(1.4f));
        c.drawLine(dp(8), dp(2), dp(8), dp(14), p);
        c.drawLine(dp(2), dp(8), dp(14), dp(8), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createVectorCloseIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createVectorResizeGrip() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#888888"));
        p.setStrokeWidth(dp(1.2f));
        c.drawLine(dp(14), dp(6), dp(6), dp(14), p);
        c.drawLine(dp(14), dp(10), dp(10), dp(14), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }
}