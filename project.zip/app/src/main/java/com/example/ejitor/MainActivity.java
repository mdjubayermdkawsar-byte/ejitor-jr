package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    private HomeStudioManager homeStudioManager;
    private static final int REQUEST_FILE_PICKER = 1001;

    private static final String FIREBASE_USERS_URL = "https://ejitor-apk-default-rtdb.firebaseio.com/users";
    private static final String GATEWAY_API_URL = "https://api-ke-linker.vercel.app/gateway/goggle";

    private final Handler liveCheckHandler = new Handler(Looper.getMainLooper());
    private Runnable liveCheckRunnable;
    private Dialog currentAuthDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } catch (Exception ignored) {}

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window window = getWindow();
        if (window != null) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.setNavigationBarColor(0xFF141414);
            }
        }

        homeStudioManager = new HomeStudioManager(this);
        setContentView(homeStudioManager.buildHomeScreen());

        checkDeviceVerificationAndStatus();
        startLiveAdminStatusWatcher();
    }

    private int dp(float val) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, val, dm);
    }

    private void startLiveAdminStatusWatcher() {
        final String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        liveCheckRunnable = new Runnable() {
            @Override
            public void run() {
                final SharedPreferences sp = getSharedPreferences("ejitor_auth_prefs", Context.MODE_PRIVATE);
                boolean isRegistered = sp.getBoolean("is_registered", false);

                if (isRegistered) {
                    new Thread(() -> {
                        try {
                            URL url = new URL(FIREBASE_USERS_URL + "/" + deviceId + ".json");
                            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                            conn.setRequestMethod("GET");
                            conn.setConnectTimeout(4000);
                            conn.setReadTimeout(4000);

                            if (conn.getResponseCode() == 200) {
                                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                                StringBuilder sb = new StringBuilder();
                                String line;
                                while ((line = br.readLine()) != null) sb.append(line);
                                br.close();

                                String res = sb.toString().trim();

                                if (res.equals("null") || res.isEmpty()) {
                                    runOnUiThread(() -> {
                                        sp.edit().clear().apply();
                                        Toast.makeText(MainActivity.this, "Your account was removed by Admin! Please register again.", Toast.LENGTH_LONG).show();
                                        showVerificationLoginDialog();
                                    });
                                } else {
                                    JSONObject obj = new JSONObject(res);
                                    String st = obj.optString("status", "active");
                                    if ("banned".equalsIgnoreCase(st) || "suspended".equalsIgnoreCase(st)) {
                                        runOnUiThread(() -> {
                                            Toast.makeText(MainActivity.this, "Device is " + st.toUpperCase() + " by Admin!", Toast.LENGTH_LONG).show();
                                            finish();
                                        });
                                    }
                                }
                            }
                        } catch (Exception ignored) {}
                    }).start();
                }

                liveCheckHandler.postDelayed(this, 6000);
            }
        };

        liveCheckHandler.postDelayed(liveCheckRunnable, 3000);
    }

    private void checkDeviceVerificationAndStatus() {
        final SharedPreferences sp = getSharedPreferences("ejitor_auth_prefs", Context.MODE_PRIVATE);
        final String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        new Thread(() -> {
            try {
                URL url = new URL(FIREBASE_USERS_URL + "/" + deviceId + ".json");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                if (conn.getResponseCode() == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();

                    String respStr = sb.toString().trim();
                    if (!respStr.equals("null") && !respStr.isEmpty()) {
                        JSONObject res = new JSONObject(respStr);
                        String status = res.optString("status", "active");
                        if ("banned".equalsIgnoreCase(status) || "suspended".equalsIgnoreCase(status)) {
                            runOnUiThread(() -> {
                                Toast.makeText(MainActivity.this, "Your device is " + status.toUpperCase() + " by administrator!", Toast.LENGTH_LONG).show();
                                finish();
                            });
                            return;
                        } else {
                            sp.edit().putBoolean("is_registered", true).apply();
                            return;
                        }
                    } else {
                        sp.edit().clear().apply();
                    }
                }
            } catch (Exception ignored) {}

            runOnUiThread(() -> {
                if (!sp.getBoolean("is_registered", false)) {
                    showVerificationLoginDialog();
                }
            });
        }).start();
    }

    private void showVerificationLoginDialog() {
        if (currentAuthDialog != null && currentAuthDialog.isShowing()) return;

        final Dialog d = new Dialog(this);
        this.currentAuthDialog = d;
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(dp(26), dp(22), dp(26), dp(22));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#141417"));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1.2f), Color.parseColor("#2E2E36"));
        box.setBackground(bg);

        ImageView shieldIcon = new ImageView(this);
        shieldIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        shieldIcon.setImageDrawable(createShieldVectorIcon());
        box.addView(shieldIcon);

        TextView title = new TextView(this);
        title.setText("EJITOR PRO STUDIO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, dp(8), 0, dp(2));
        box.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Security & Hardware Verification");
        sub.setTextColor(Color.parseColor("#8E8E93"));
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        sub.setPadding(0, 0, 0, dp(14));
        box.addView(sub);

        LinearLayout inputGroup = new LinearLayout(this);
        inputGroup.setOrientation(LinearLayout.VERTICAL);
        inputGroup.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final EditText nameInput = createModernInput("Your Full Name");
        inputGroup.addView(nameInput);

        View g1 = new View(this);
        g1.setLayoutParams(new LinearLayout.LayoutParams(1, dp(8)));
        inputGroup.addView(g1);

        final EditText emailInput = createModernInput("Email Address");
        inputGroup.addView(emailInput);

        View g2 = new View(this);
        g2.setLayoutParams(new LinearLayout.LayoutParams(1, dp(8)));
        inputGroup.addView(g2);

        final EditText phoneInput = createModernInput("Phone Number (+880...)");
        inputGroup.addView(phoneInput);

        box.addView(inputGroup);

        final ProgressBar progressBar = new ProgressBar(this);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams pbp = new LinearLayout.LayoutParams(dp(26), dp(26));
        pbp.setMargins(0, dp(10), 0, 0);
        progressBar.setLayoutParams(pbp);
        box.addView(progressBar);

        final Button verifyBtn = new Button(this);
        verifyBtn.setText("VERIFY & ACCESS STUDIO");
        verifyBtn.setTextColor(Color.WHITE);
        verifyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        verifyBtn.setTypeface(null, Typeface.BOLD);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF1238"));
        btnBg.setCornerRadius(dp(8));
        verifyBtn.setBackground(btnBg);

        LinearLayout.LayoutParams vbp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        vbp.setMargins(0, dp(16), 0, 0);
        verifyBtn.setLayoutParams(vbp);

        verifyBtn.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            String email = emailInput.getText().toString().trim();
            String phone = phoneInput.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                return;
            }

            verifyBtn.setEnabled(false);
            progressBar.setVisibility(View.VISIBLE);

            submitVerificationDataToServer(name, email, phone, d, verifyBtn, progressBar);
        });

        box.addView(verifyBtn);

        d.setContentView(box);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(dp(325), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        d.show();
    }

    private EditText createModernInput(String hint) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setHintTextColor(Color.parseColor("#4A4A52"));
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        et.setSingleLine(true);
        et.setPadding(dp(12), dp(10), dp(12), dp(10));

        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#0C0C0E"));
        gd.setStroke(dp(1), Color.parseColor("#26262D"));
        gd.setCornerRadius(dp(6));
        et.setBackground(gd);
        return et;
    }

    private Drawable createShieldVectorIcon() {
        int s = dp(44);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        p.setColor(Color.parseColor("#1F1517"));
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(s / 2f, s / 2f, s / 2f, p);

        p.setColor(Color.parseColor("#FF1238"));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.4f));
        c.drawCircle(s / 2f, s / 2f, s / 2f - dp(1), p);

        Path sh = new Path();
        sh.moveTo(s * 0.5f, s * 0.24f);
        sh.lineTo(s * 0.72f, s * 0.34f);
        sh.quadTo(s * 0.72f, s * 0.60f, s * 0.5f, s * 0.76f);
        sh.quadTo(s * 0.28f, s * 0.60f, s * 0.28f, s * 0.34f);
        sh.close();

        p.setStyle(Paint.Style.FILL);
        c.drawPath(sh, p);

        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(2f));
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);

        Path chk = new Path();
        chk.moveTo(s * 0.40f, s * 0.48f);
        chk.lineTo(s * 0.48f, s * 0.56f);
        chk.lineTo(s * 0.62f, s * 0.42f);
        c.drawPath(chk, p);

        return new BitmapDrawable(getResources(), bmp);
    }

    private void submitVerificationDataToServer(String name, String email, String phone, Dialog d, Button btn, ProgressBar pb) {
        new Thread(() -> {
            boolean success = false;
            try {
                String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                String model = Build.MANUFACTURER + " " + Build.MODEL;

                JSONObject payload = new JSONObject();
                payload.put("userId", name);
                payload.put("name", name);
                payload.put("email", email);
                payload.put("phone", phone);
                payload.put("device_id", deviceId);
                payload.put("device_model", model);
                payload.put("status", "active");
                payload.put("signedUpVia", "goggle");
                payload.put("timestamp", System.currentTimeMillis());

                URL fbUrl = new URL(FIREBASE_USERS_URL + "/" + deviceId + ".json");
                HttpURLConnection fbConn = (HttpURLConnection) fbUrl.openConnection();
                fbConn.setRequestMethod("PUT");
                fbConn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                fbConn.setDoOutput(true);
                OutputStream osFb = fbConn.getOutputStream();
                osFb.write(payload.toString().getBytes("UTF-8"));
                osFb.flush();
                osFb.close();
                int fbCode = fbConn.getResponseCode();

                try {
                    URL gwUrl = new URL(GATEWAY_API_URL);
                    HttpURLConnection gwConn = (HttpURLConnection) gwUrl.openConnection();
                    gwConn.setRequestMethod("POST");
                    gwConn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    gwConn.setDoOutput(true);
                    OutputStream osGw = gwConn.getOutputStream();
                    osGw.write(payload.toString().getBytes("UTF-8"));
                    osGw.flush();
                    osGw.close();
                    gwConn.getResponseCode();
                } catch (Exception ignored) {}

                if (fbCode >= 200 && fbCode < 300) {
                    success = true;
                }
            } catch (Exception e) {
                success = true;
            }

            final boolean isOk = success;
            runOnUiThread(() -> {
                pb.setVisibility(View.GONE);
                btn.setEnabled(true);

                if (isOk) {
                    SharedPreferences sp = getSharedPreferences("ejitor_auth_prefs", Context.MODE_PRIVATE);
                    sp.edit()
                            .putBoolean("is_registered", true)
                            .putString("user_name", name)
                            .putString("user_email", email)
                            .putString("user_phone", phone)
                            .apply();

                    Toast.makeText(MainActivity.this, "Device verified successfully!", Toast.LENGTH_SHORT).show();
                    d.dismiss();
                    currentAuthDialog = null;
                }
            });
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideTimeBarSafe();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (liveCheckRunnable != null) {
            liveCheckHandler.removeCallbacks(liveCheckRunnable);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideTimeBarSafe();
        }
    }

    private void hideTimeBarSafe() {
        try {
            Window window = getWindow();
            if (window != null) {
                window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
                View decorView = window.getDecorView();
                if (decorView != null) {
                    decorView.setSystemUiVisibility(
                            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    );
                }
            }
        } catch (Exception ignored) {}
    }

    public void openFilePicker() {
        if (homeStudioManager != null) {
            homeStudioManager.openUnifiedFilePicker();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_FILE_PICKER && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri fileUri = data.getData();
            try {
                Intent intent = new Intent(this, EditorActivity.class);
                intent.putExtra("project_name", "Imported Project");
                intent.putExtra("width", 1080);
                intent.putExtra("height", 1080);
                intent.putExtra("artboards", 1);
                intent.putExtra("bg", 0xFFFFFFFF);
                intent.setData(fileUri);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Failed to open file: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}