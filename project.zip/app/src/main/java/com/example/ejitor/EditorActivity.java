package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class EditorActivity extends Activity {

    public static EditorActivity instance;

    public String projectName = "Untitled-1";
    public int canvasWidth = 1080;
    public int canvasHeight = 1080;
    public int artboardCount = 1;
    public int artboardBgColor = Color.WHITE;

    private static final float ARTBOARD_GAP_DP = 16f;

    private final ArrayList<Object> loadedModules = new ArrayList<>();
    private final ExecutorService saveExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingAutoSaveTask = null;

    public LinearLayout menuContainer;
    public LinearLayout rightLayersDock;
    public LinearLayout optionControlsBar;
    public StudioCanvasView canvasView;
    public View fgSwatchView, bgSwatchView;

    private boolean isExiting = false;

    // Cache Vector Icons to eliminate allocation spikes
    private BitmapDrawable cachedDragDotsIcon;
    private BitmapDrawable cachedEyeOpenIcon;
    private BitmapDrawable cachedEyeClosedIcon;
    private BitmapDrawable cachedLockOpenIcon;
    private BitmapDrawable cachedLockClosedIcon;

    private static final int REQ_PICK_PROJECT_TO_TAB = 5001;

    public interface EditorModule {
        void init(EditorActivity activity);
        void onCommand(String command, Object... args);
    }

    public interface LayerActionListener {
        void onAction(LayerItem layer, int index);
    }

    public static class DynamicLayerAction {
        public String title;
        public LayerActionListener listener;
        public DynamicLayerAction(String title, LayerActionListener listener) {
            this.title = title;
            this.listener = listener;
        }
    }

    private final List<DynamicLayerAction> registeredLayerActions = new ArrayList<>();

    public static class GradStop {
        public float pos;
        public int color;
        public GradStop(float pos, int color) { this.pos = pos; this.color = color; }
    }

    public static class LayerItem {
        public String id;
        public String name;
        public Bitmap bitmap;
        public Bitmap thumbBitmap;
        public float x, y;
        public float scaleX = 1f, scaleY = 1f;
        public float rotation = 0f;
        public float opacity = 1f;
        public boolean isVisible = true;
        public boolean isLocked = false;
        public String blendMode = "Normal";
        public boolean isSmartObject = false;
        public boolean isClippingMask = false;
        public boolean isShape = false;
        public boolean isBlank = false;
        public String imageFileName = null;
        public boolean isDirty = true;

        public boolean isPolygonShape = false;
        public final ArrayList<PolyAnchorPoint> polygonAnchors = new ArrayList<>();
        public boolean polygonHasFill = false;
        public boolean polygonHasStroke = true;
        public boolean polygonIsMerged = false;

        public String shapeType = "rectangle";
        public int shapeFill = Color.parseColor("#007AFF");
        public int shapeStroke = Color.parseColor("#FF1238");
        public float shapeStrokeW = 3f;
        public float radiusTL = 0f, radiusTR = 0f, radiusBR = 0f, radiusBL = 0f;

        public LayerItem(String name, Bitmap bitmap, float x, float y, boolean isLocked) {
            this.id = "layer_" + System.currentTimeMillis() + "_" + (int)(Math.random() * 10000);
            this.name = name;
            this.bitmap = bitmap;
            this.x = x;
            this.y = y;
            this.isLocked = isLocked;
            this.isDirty = true;
            updateThumb();
        }

        public void updateThumb() {
            if (this.bitmap != null && !this.bitmap.isRecycled()) {
                try {
                    int tw = 48;
                    int th = Math.max(1, (int) (48f * ((float) this.bitmap.getHeight() / Math.max(1, this.bitmap.getWidth()))));
                    if (this.thumbBitmap != null && !this.thumbBitmap.isRecycled()) {
                        this.thumbBitmap.recycle();
                    }
                    this.thumbBitmap = Bitmap.createScaledBitmap(this.bitmap, tw, Math.min(th, 48), false);
                } catch (Exception ignored) {}
            }
        }

        public LayerItem copy() {
            return copy(false);
        }

        public LayerItem copy(boolean deepCloneBitmap) {
            Bitmap bmpRef = this.bitmap;
            if (deepCloneBitmap && this.bitmap != null && !this.bitmap.isRecycled()) {
                try {
                    bmpRef = this.bitmap.copy(Bitmap.Config.ARGB_8888, true);
                } catch (OutOfMemoryError e) {
                    System.gc();
                    bmpRef = this.bitmap;
                }
            }
            LayerItem l = new LayerItem(this.name, bmpRef, this.x, this.y, this.isLocked);
            l.id = this.id;
            l.scaleX = this.scaleX;
            l.scaleY = this.scaleY;
            l.rotation = this.rotation;
            l.opacity = this.opacity;
            l.isVisible = this.isVisible;
            l.blendMode = this.blendMode;
            l.isSmartObject = this.isSmartObject;
            l.isClippingMask = this.isClippingMask;
            l.isShape = this.isShape;
            l.isBlank = this.isBlank;
            l.imageFileName = this.imageFileName;
            l.isDirty = this.isDirty;

            l.isPolygonShape = this.isPolygonShape;
            l.polygonHasFill = this.polygonHasFill;
            l.polygonHasStroke = this.polygonHasStroke;
            l.polygonIsMerged = this.polygonIsMerged;
            synchronized (this.polygonAnchors) {
                for (PolyAnchorPoint ap : this.polygonAnchors) {
                    l.polygonAnchors.add(ap.copy());
                }
            }

            l.shapeType = this.shapeType;
            l.shapeFill = this.shapeFill;
            l.shapeStroke = this.shapeStroke;
            l.shapeStrokeW = this.shapeStrokeW;
            l.radiusTL = this.radiusTL;
            l.radiusTR = this.radiusTR;
            l.radiusBR = this.radiusBR;
            l.radiusBL = this.radiusBL;
            l.thumbBitmap = this.thumbBitmap;
            return l;
        }
    }

    public static class ProjectTabSession {
        public String projectName;
        public int canvasWidth, canvasHeight, artboardCount, artboardBgColor;
        public int currentActiveArtboard = 0;
        public final ArrayList<LayerItem> layers = new ArrayList<>();
        public int activeLayerIndex = 0;
        public float scale = 0.50f;
        public float panX = 0f, panY = 0f;
        public boolean isSmartObjectChild = false;
        public LayerItem parentSmartLayerRef = null;

        public boolean hasGradientLine = false;
        public float gradStartX, gradStartY, gradEndX, gradEndY;
        public ArrayList<GradStop> gradStops = new ArrayList<>();
        public GradStop activeGradStop = null;
        public String gradientType = "Linear"; // Linear, Radial, Angle, Reflected, Diamond

        public ProjectTabSession(String name, int w, int h, int count, int bg) {
            this.projectName = name;
            this.canvasWidth = w;
            this.canvasHeight = h;
            this.artboardCount = count;
            this.artboardBgColor = bg;
            GradStop s1 = new GradStop(0.0f, Color.parseColor("#FF1238"));
            GradStop s2 = new GradStop(1.0f, Color.BLACK);
            gradStops.add(s1);
            gradStops.add(s2);
            activeGradStop = s1;
        }
    }

    public static class HistorySnapshot {
        public final ArrayList<LayerItem> layers = new ArrayList<>();
        public int activeLayerIndex;
        public int artboardCount;
        public int artboardBgColor;
        public int canvasWidth;
        public int canvasHeight;
        public Path selectionPath;

        public HistorySnapshot(ProjectTabSession s, Path currentSelection) {
            this.activeLayerIndex = s.activeLayerIndex;
            this.artboardCount = s.artboardCount;
            this.artboardBgColor = s.artboardBgColor;
            this.canvasWidth = s.canvasWidth;
            this.canvasHeight = s.canvasHeight;
            synchronized (s.layers) {
                for (LayerItem l : s.layers) {
                    this.layers.add(l.copy(false));
                }
            }
            if (currentSelection != null) {
                this.selectionPath = new Path(currentSelection);
            }
        }
    }

    public static class PolyAnchorPoint {
        public float x, y;
        public float hInX, hInY;
        public float hOutX, hOutY;
        public boolean hasHandles = false;

        public PolyAnchorPoint(float x, float y) {
            this.x = x; this.y = y;
            this.hInX = x; this.hInY = y;
            this.hOutX = x; this.hOutY = y;
        }

        public PolyAnchorPoint copy() {
            PolyAnchorPoint p = new PolyAnchorPoint(this.x, this.y);
            p.hInX = this.hInX; p.hInY = this.hInY;
            p.hOutX = this.hOutX; p.hOutY = this.hOutY;
            p.hasHandles = this.hasHandles;
            return p;
        }
    }

    private final ArrayList<ProjectTabSession> openTabs = new ArrayList<>();
    private int currentTabIdx = 0;

    private String activeTool = "move";
    private int selectionMode = 0;
    private int lassoSubTool = 0;
    private final ArrayList<PolyAnchorPoint> polyAnchors = new ArrayList<>();
    private String anchorMode = "Free";

    private float polyLineWidth = 2.0f;
    private boolean polyStrokeEnabled = true;
    private int polyStrokeColor = Color.parseColor("#FF1238");
    private boolean polyFillEnabled = false;
    private int polyFillColor = Color.parseColor("#007AFF");
    private boolean polyMergePath = false;

    private String activeShapeType = "rectangle";
    private int shapeFillColor = Color.parseColor("#007AFF");
    private int shapeStrokeColor = Color.parseColor("#FF1238");
    private float shapeStrokeWidth = 3f;
    private float shapeRadiusTL = 0f, shapeRadiusTR = 0f, shapeRadiusBR = 0f, shapeRadiusBL = 0f;
    private boolean linkCorners = true;
    private boolean shapeLock = false;

    private boolean showTransformControls = true;
    private boolean maintainAspectRatio = false;
    private boolean snappingEnabled = true;

    private Path activeSelectionPath = null;
    private RectF selectionBounds = null;

    private int fgColor = Color.BLACK;
    private int bgColor = Color.WHITE;

    private final ArrayList<Integer> savedColorPresets = new ArrayList<>();

    private final ArrayList<HistorySnapshot> undoHistory = new ArrayList<>();
    private final ArrayList<HistorySnapshot> redoHistory = new ArrayList<>();

    public static LayerItem clipboardLayer = null;
    public static final ArrayList<LayerItem> clipboardArtboardLayers = new ArrayList<>();
    public static int clipboardArtboardWidth = 1080;
    public static int clipboardArtboardHeight = 1080;
    public static int clipboardArtboardBgColor = Color.WHITE;

    private LinearLayout layersListContainer;
    private LinearLayout tabStripLayout;
    private TextView activeToolLabelTv;
    private TextView pNameHeaderTv;

    private static final int REQ_IMPORT_MULTI_IMAGE = 2002;
    private static final int REQ_OPEN_PROJECT_FILE = 2003;

    public interface OnNumericInputListener {
        void onValueSubmitted(float value);
    }

    public static EditorActivity getInstance() {
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        initDefaultColorPresets();
        initCachedIcons();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Intent intent = getIntent();
        Uri targetFileUri = null;
        if (intent != null) {
            projectName = intent.getStringExtra("project_name");
            if (projectName == null || projectName.trim().isEmpty() || projectName.equals("Imported Project")) {
                projectName = "Project-" + (System.currentTimeMillis() % 100000);
            }
            canvasWidth = Math.max(100, intent.getIntExtra("width", 1080));
            canvasHeight = Math.max(100, intent.getIntExtra("height", 1080));
            artboardCount = Math.max(1, intent.getIntExtra("artboards", 1));
            artboardBgColor = intent.getIntExtra("bg", Color.WHITE);

            if (intent.getData() != null) {
                targetFileUri = intent.getData();
            } else if (intent.getStringExtra("file_uri") != null) {
                try { targetFileUri = Uri.parse(intent.getStringExtra("file_uri")); } catch (Exception ignored) {}
            }
        }

        ProjectTabSession firstTab = null;

        if (targetFileUri != null) {
            String pStr = targetFileUri.getPath() != null ? targetFileUri.getPath().toLowerCase() : "";

            if (pStr.endsWith(".jr") || isZipUri(targetFileUri)) {
                firstTab = parseJrProjectFile(targetFileUri);
            } else if (pStr.endsWith(".pdf") || isPdfUri(targetFileUri)) {
                firstTab = parsePdfFile(targetFileUri);
            } else if (pStr.endsWith(".psd") || isPsdUri(targetFileUri)) {
                firstTab = parsePsdFile(targetFileUri);
            }

            if (firstTab == null) {
                Bitmap directBmp = decodeSafeBitmap(targetFileUri, 2048);
                if (directBmp != null) {
                    firstTab = new ProjectTabSession(projectName, directBmp.getWidth(), directBmp.getHeight(), 1, Color.TRANSPARENT);
                    firstTab.layers.clear();
                    LayerItem baseImg = new LayerItem("Layer 1", directBmp, 0, 0, false);
                    baseImg.isBlank = false;
                    firstTab.layers.add(baseImg);
                    firstTab.activeLayerIndex = 0;
                }
            }
        }

        if (firstTab == null) {
            firstTab = new ProjectTabSession(projectName, canvasWidth, canvasHeight, artboardCount, artboardBgColor);
            if (!loadProjectFromDisk(firstTab)) {
                initDefaultTabLayers(firstTab);
            }
        }

        this.projectName = firstTab.projectName;
        this.canvasWidth = firstTab.canvasWidth;
        this.canvasHeight = firstTab.canvasHeight;
        this.artboardCount = firstTab.artboardCount;
        this.artboardBgColor = firstTab.artboardBgColor;

        openTabs.add(firstTab);
        currentTabIdx = 0;
        recordHistory();

        setContentView(buildDesktopStudioLayout());
        loadModules1to200();

        if (canvasView != null) {
            canvasView.post(new Runnable() {
                int attempts = 0;
                @Override
                public void run() {
                    if (canvasView.getWidth() > 0 && canvasView.getHeight() > 0) {
                        canvasView.autoCenterArtboard(canvasView.getWidth(), canvasView.getHeight());
                    } else if (attempts++ < 10) {
                        canvasView.postDelayed(this, 80);
                    }
                }
            });
        }
    }

    private void initCachedIcons() {
        cachedDragDotsIcon = createVectorDragDotsIcon();
        cachedEyeOpenIcon = createVectorEyeIcon(true);
        cachedEyeClosedIcon = createVectorEyeIcon(false);
        cachedLockOpenIcon = createVectorLockIcon(false);
        cachedLockClosedIcon = createVectorLockIcon(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!isExiting) {
            autoSaveCurrentProject();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!isExiting) {
            saveProjectToDiskImmediate(getCurrentSession());
        }
        if (instance == this) {
            instance = null;
        }
    }

    @Override
    public void onBackPressed() {
        exitWithoutLoading();
    }

    public void exitWithoutLoading() {
        if (isExiting) return;
        isExiting = true;
        final ProjectTabSession s = getCurrentSession();
        if (s != null) {
            syncWithHomePreferences(s.projectName, s.canvasWidth, s.canvasHeight, s.artboardCount, s.artboardBgColor);
            if (pendingAutoSaveTask != null) {
                mainHandler.removeCallbacks(pendingAutoSaveTask);
            }
            saveProjectInternal(s);
        }
        finish();
    }

    private void initDefaultColorPresets() {
        savedColorPresets.add(Color.BLACK);
        savedColorPresets.add(Color.WHITE);
        savedColorPresets.add(Color.parseColor("#FF1238"));
        savedColorPresets.add(Color.parseColor("#007AFF"));
        savedColorPresets.add(Color.parseColor("#34C759"));
        savedColorPresets.add(Color.parseColor("#FFCC00"));
        savedColorPresets.add(Color.parseColor("#AF52DE"));
        savedColorPresets.add(Color.parseColor("#FF9500"));
    }

    public LinearLayout getTopMenuContainer() { return menuContainer; }
    public LinearLayout getLayersDock() { return rightLayersDock; }
    public LinearLayout getOptionControlsBar() { return optionControlsBar; }
    public StudioCanvasView getCanvasView() { return canvasView; }

    public void triggerClickFeedback(View v) {
        if (v == null) return;
        final Drawable originalBg = v.getBackground();
        GradientDrawable feedback = new GradientDrawable();
        feedback.setColor(Color.parseColor("#4A1520"));
        feedback.setCornerRadius(dp(3));
        v.setBackground(feedback);
        v.postDelayed(() -> {
            try {
                v.setBackground(originalBg);
            } catch (Exception ignored) {}
        }, 300);
    }

    public View.OnClickListener withFeedback(View.OnClickListener listener) {
        return v -> {
            triggerClickFeedback(v);
            if (listener != null) listener.onClick(v);
        };
    }

    public void addTopMenuItem(String title, View.OnClickListener listener) {
        if (menuContainer != null) {
            menuContainer.addView(createMenuItem(title, listener));
        }
    }

    public void registerLayerAction(String title, LayerActionListener listener) {
        registeredLayerActions.add(new DynamicLayerAction(title, listener));
    }

    public void notifyProjectModified() {
        recordHistory();
        updateLayersDockUI();
        if (canvasView != null) canvasView.invalidate();
        autoSaveCurrentProject();
    }

    private void loadModules1to200() {
        new Thread(() -> {
            final List<Object> newlyLoaded = new ArrayList<>();
            for (int i = 1; i <= 200; i++) {
                final String className = "com.example.ejitor.editor_" + i;
                try {
                    Class<?> clazz = Class.forName(className);
                    final Object moduleInstance = clazz.newInstance();
                    newlyLoaded.add(moduleInstance);
                } catch (Exception ignored) {}
            }
            runOnUiThread(() -> {
                for (Object moduleInstance : newlyLoaded) {
                    loadedModules.add(moduleInstance);
                    if (moduleInstance instanceof EditorModule) {
                        ((EditorModule) moduleInstance).init(EditorActivity.this);
                    } else {
                        try {
                            Method initMethod = moduleInstance.getClass().getMethod("init", EditorActivity.class);
                            initMethod.invoke(moduleInstance, EditorActivity.this);
                        } catch (Exception e) {
                            try {
                                Method attachMethod = moduleInstance.getClass().getMethod("onAttach", Activity.class);
                                attachMethod.invoke(moduleInstance, EditorActivity.this);
                            } catch (Exception ignored) {}
                        }
                    }
                }
            });
        }).start();
    }

    public void dispatchModuleCommand(String command, Object... args) {
        for (Object mod : loadedModules) {
            try {
                if (mod instanceof EditorModule) {
                    ((EditorModule) mod).onCommand(command, args);
                } else {
                    Method m = mod.getClass().getMethod("onCommand", String.class, Object[].class);
                    m.invoke(mod, command, args);
                }
            } catch (Exception ignored) {}
        }
        notifyProjectModified();
    }

    public void dispatchModuleCommand(String command) {
        dispatchModuleCommand(command, new Object[0]);
    }

    public ProjectTabSession getCurrentSession() {
        if (currentTabIdx >= 0 && currentTabIdx < openTabs.size()) return openTabs.get(currentTabIdx);
        return openTabs.isEmpty() ? null : openTabs.get(0);
    }

    private int dp(float value) {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private void initDefaultTabLayers(ProjectTabSession session) {
        session.layers.clear();
        Bitmap bgBmp = Bitmap.createBitmap(session.canvasWidth, session.canvasHeight, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bgBmp);
        c.drawColor(session.artboardBgColor == Color.TRANSPARENT ? Color.TRANSPARENT : session.artboardBgColor);
        LayerItem bgLayer = new LayerItem("Background", bgBmp, 0, 0, false);
        bgLayer.isBlank = false;
        session.layers.add(bgLayer);
        session.activeLayerIndex = 0;
        recordHistory();
    }

    public void recordHistory() {
        try {
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            HistorySnapshot snap = new HistorySnapshot(s, activeSelectionPath);
            undoHistory.add(snap);
            if (undoHistory.size() > 10) undoHistory.remove(0);
            redoHistory.clear();
            autoSaveCurrentProject();
        } catch (OutOfMemoryError oom) {
            undoHistory.clear();
            System.gc();
        } catch (Exception ignored) {}
    }

    public void performUndo() {
        try {
            if (undoHistory.size() > 1) {
                HistorySnapshot currentState = undoHistory.remove(undoHistory.size() - 1);
                redoHistory.add(currentState);
                HistorySnapshot prevState = undoHistory.get(undoHistory.size() - 1);
                restoreState(prevState);
                Toast.makeText(this, "Undo", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Nothing to undo", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {}
    }

    public void performRedo() {
        try {
            if (!redoHistory.isEmpty()) {
                HistorySnapshot nextState = redoHistory.remove(redoHistory.size() - 1);
                undoHistory.add(nextState);
                restoreState(nextState);
                Toast.makeText(this, "Redo", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Nothing to redo", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception ignored) {}
    }

    private void restoreState(HistorySnapshot state) {
        ProjectTabSession s = getCurrentSession();
        if (s == null) return;
        s.artboardCount = state.artboardCount;
        s.artboardBgColor = state.artboardBgColor;
        s.canvasWidth = state.canvasWidth;
        s.canvasHeight = state.canvasHeight;
        synchronized (s.layers) {
            s.layers.clear();
            for (LayerItem l : state.layers) s.layers.add(l.copy(false));
        }
        s.activeLayerIndex = Math.min(state.activeLayerIndex, Math.max(0, s.layers.size() - 1));
        activeSelectionPath = (state.selectionPath != null) ? new Path(state.selectionPath) : null;
        if (activeSelectionPath != null) {
            selectionBounds = new RectF();
            activeSelectionPath.computeBounds(selectionBounds, true);
        } else {
            selectionBounds = null;
        }

        syncPolygonFromActiveLayer();
        updateLayersDockUI();
        if (canvasView != null) canvasView.invalidate();
        autoSaveCurrentProject();
    }

    private void addNewBlankLayer() {
        try {
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            Bitmap b = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
            float abOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
            LayerItem nl = new LayerItem("Layer " + (s.layers.size() + 1), b, abOffset, 0, false);
            nl.isBlank = true;
            synchronized (s.layers) {
                s.layers.add(nl);
                s.activeLayerIndex = s.layers.size() - 1;
            }
            recordHistory();
            updateLayersDockUI();
            canvasView.invalidate();
        } catch (Exception ignored) {}
    }

    private void duplicateActiveLayer() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem dup = s.layers.get(s.activeLayerIndex).copy(true);
            dup.name = dup.name + " copy";
            dup.x += dp(15);
            dup.y += dp(15);
            synchronized (s.layers) {
                s.layers.add(dup);
                s.activeLayerIndex = s.layers.size() - 1;
            }
            recordHistory();
            updateLayersDockUI();
            canvasView.invalidate();
        }
    }

    private void deleteActiveLayer() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.layers.size() > 1 && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            synchronized (s.layers) {
                int currentIndex = s.activeLayerIndex;
                LayerItem removed = s.layers.remove(currentIndex);
                if (removed != null && removed.thumbBitmap != null && !removed.thumbBitmap.isRecycled()) {
                    removed.thumbBitmap.recycle();
                }
                // Fix: ডিলিট করার পর সিলেকশন উপরে যাবে না, সংলগ্ন লেয়ারে থাকবে
                s.activeLayerIndex = Math.max(0, Math.min(currentIndex - 1, s.layers.size() - 1));
            }
            syncPolygonFromActiveLayer();
            recordHistory();
            updateLayersDockUI();
            canvasView.invalidate();
            autoSaveCurrentProject();
        }
    }

    public void moveLayerToPosition(int fromIndex, int toIndex) {
        ProjectTabSession s = getCurrentSession();
        if (s == null || s.layers == null) return;
        if (fromIndex < 0 || fromIndex >= s.layers.size()) return;
        if (toIndex < 0) toIndex = 0;
        if (toIndex >= s.layers.size()) toIndex = s.layers.size() - 1;
        if (fromIndex == toIndex) return;

        synchronized (s.layers) {
            LayerItem item = s.layers.remove(fromIndex);
            s.layers.add(toIndex, item);
            s.activeLayerIndex = toIndex;
        }
        syncPolygonFromActiveLayer();
        recordHistory();
        updateLayersDockUI();
        if (canvasView != null) canvasView.invalidate();
    }

    public File getProjectFolder(String pName) {
        String safeName = (pName != null && !pName.trim().isEmpty()) ? pName.replaceAll("[^a-zA-Z0-9._-]", "_") : "Project_001";
        File baseDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
        if (!baseDir.exists()) baseDir.mkdirs();
        try { new File(baseDir, ".nomedia").createNewFile(); } catch (Exception ignored) {}

        File projDir = new File(baseDir, "ejitor_project");
        if (!projDir.exists()) projDir.mkdirs();
        try { new File(projDir, ".nomedia").createNewFile(); } catch (Exception ignored) {}

        File dir = new File(projDir, safeName);
        if (!dir.exists()) dir.mkdirs();
        try { new File(dir, ".nomedia").createNewFile(); } catch (Exception ignored) {}

        File layersDir = new File(dir, "layers");
        if (!layersDir.exists()) layersDir.mkdirs();
        try { new File(layersDir, ".nomedia").createNewFile(); } catch (Exception ignored) {}

        return dir;
    }

    public void autoSaveCurrentProject() {
        final ProjectTabSession s = getCurrentSession();
        if (s == null) return;

        if (pendingAutoSaveTask != null) {
            mainHandler.removeCallbacks(pendingAutoSaveTask);
        }

        pendingAutoSaveTask = () -> saveExecutor.execute(() -> saveProjectInternal(s));
        mainHandler.postDelayed(pendingAutoSaveTask, 800);
    }

    public void saveProjectToDisk(ProjectTabSession s) {
        autoSaveCurrentProject();
    }

    public void saveProjectToDiskImmediate(ProjectTabSession s) {
        if (s == null) return;
        saveExecutor.execute(() -> saveProjectInternal(s));
    }

    private synchronized void saveProjectInternal(ProjectTabSession s) {
        if (s == null) return;
        final ArrayList<LayerItem> layersSnapshot = new ArrayList<>();
        synchronized (s.layers) {
            for (LayerItem l : s.layers) layersSnapshot.add(l.copy(false));
        }

        final String pName = s.projectName;
        final int cW = s.canvasWidth, cH = s.canvasHeight, abCount = s.artboardCount, bgCol = s.artboardBgColor;

        try {
            File folder = getProjectFolder(pName);
            File layersDir = new File(folder, "layers");
            if (!layersDir.exists()) layersDir.mkdirs();

            Set<String> activeLayerFiles = new HashSet<>();

            JSONObject json = new JSONObject();
            json.put("format_version", 3);
            json.put("name", pName);
            json.put("title", pName);
            json.put("width", cW);
            json.put("height", cH);
            json.put("artboards", abCount);
            json.put("bg", bgCol);

            json.put("hasGradientLine", s.hasGradientLine);
            json.put("gradStartX", s.gradStartX);
            json.put("gradStartY", s.gradStartY);
            json.put("gradEndX", s.gradEndX);
            json.put("gradEndY", s.gradEndY);
            json.put("gradientType", s.gradientType != null ? s.gradientType : "Linear");

            JSONArray gradStopsArr = new JSONArray();
            if (s.gradStops != null) {
                for (GradStop gs : s.gradStops) {
                    JSONObject gso = new JSONObject();
                    gso.put("pos", gs.pos);
                    gso.put("color", gs.color);
                    gradStopsArr.put(gso);
                }
            }
            json.put("gradStops", gradStopsArr);

            JSONArray layerArray = new JSONArray();
            for (int i = 0; i < layersSnapshot.size(); i++) {
                LayerItem l = layersSnapshot.get(i);
                JSONObject lj = new JSONObject();
                lj.put("id", l.id);
                lj.put("name", l.name);
                lj.put("x", l.x);
                lj.put("y", l.y);
                lj.put("scaleX", l.scaleX);
                lj.put("scaleY", l.scaleY);
                lj.put("rotation", l.rotation);
                lj.put("opacity", l.opacity);
                lj.put("visible", l.isVisible);
                lj.put("locked", l.isLocked);
                lj.put("blend", l.blendMode);
                lj.put("isShape", l.isShape);
                lj.put("shapeType", l.shapeType);
                lj.put("isSmartObject", l.isSmartObject);
                lj.put("isClippingMask", l.isClippingMask);
                lj.put("isBlank", l.isBlank);

                lj.put("isPolygonShape", l.isPolygonShape);
                lj.put("polygonHasFill", l.polygonHasFill);
                lj.put("polygonHasStroke", l.polygonHasStroke);
                lj.put("polygonIsMerged", l.polygonIsMerged);
                lj.put("shapeFill", l.shapeFill);
                lj.put("shapeStroke", l.shapeStroke);
                lj.put("shapeStrokeW", l.shapeStrokeW);

                lj.put("radiusTL", l.radiusTL);
                lj.put("radiusTR", l.radiusTR);
                lj.put("radiusBR", l.radiusBR);
                lj.put("radiusBL", l.radiusBL);

                JSONArray paArr = new JSONArray();
                for (PolyAnchorPoint ap : l.polygonAnchors) {
                    JSONObject po = new JSONObject();
                    po.put("x", ap.x); po.put("y", ap.y);
                    po.put("hInX", ap.hInX); po.put("hInY", ap.hInY);
                    po.put("hOutX", ap.hOutX); po.put("hOutY", ap.hOutY);
                    po.put("hasHandles", ap.hasHandles);
                    paArr.put(po);
                }
                lj.put("polygonAnchors", paArr);

                String bmpFileName = "layer_" + l.id + ".png";
                lj.put("file", bmpFileName);
                activeLayerFiles.add(bmpFileName);
                layerArray.put(lj);

                File layerFile = new File(layersDir, bmpFileName);
                if ((!layerFile.exists() || l.isDirty) && l.bitmap != null && !l.bitmap.isRecycled() && !l.isBlank) {
                    File tempSaveFile = new File(layersDir, bmpFileName + ".saving");
                    FileOutputStream lFos = new FileOutputStream(tempSaveFile);
                    boolean ok = l.bitmap.compress(Bitmap.CompressFormat.PNG, 95, lFos);
                    lFos.flush();
                    lFos.close();

                    if (ok && tempSaveFile.length() > 0) {
                        if (layerFile.exists()) layerFile.delete();
                        tempSaveFile.renameTo(layerFile);
                    } else {
                        tempSaveFile.delete();
                    }
                    l.isDirty = false;
                }
            }
            json.put("layers", layerArray);

            File metaFile = new File(folder, "project.json");
            FileOutputStream mFos = new FileOutputStream(metaFile);
            mFos.write(json.toString().getBytes("UTF-8"));
            mFos.flush();
            mFos.close();

            try {
                Bitmap thumb = renderFastThumbnail(s, 240, 160);
                if (thumb != null) {
                    File thumbFile = new File(folder, "thumbnail.jpg");
                    FileOutputStream tFos = new FileOutputStream(thumbFile);
                    thumb.compress(Bitmap.CompressFormat.JPEG, 85, tFos);
                    tFos.flush();
                    tFos.close();
                    thumb.recycle();
                }
            } catch (Exception ignored) {}

            File[] existingFiles = layersDir.listFiles();
            if (existingFiles != null) {
                for (File f : existingFiles) {
                    if (f.isFile() && f.getName().startsWith("layer_") && !activeLayerFiles.contains(f.getName())) {
                        f.delete();
                    }
                }
            }

            syncWithHomePreferences(pName, cW, cH, abCount, bgCol);

        } catch (Exception ignored) {}
    }

    private Bitmap renderFastThumbnail(ProjectTabSession s, int maxW, int maxH) {
        try {
            int w = Math.max(10, s.canvasWidth);
            int h = Math.max(10, s.canvasHeight);
            float scale = Math.min((float) maxW / w, (float) maxH / h);
            int rw = Math.max(1, (int) (w * scale));
            int rh = Math.max(1, (int) (h * scale));

            Bitmap thumb = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(thumb);
            c.scale(scale, scale);
            c.drawColor(s.artboardBgColor == Color.TRANSPARENT ? Color.WHITE : s.artboardBgColor);

            synchronized (s.layers) {
                drawLayersWithClippingMask(c, s.layers, 0);
            }
            return thumb;
        } catch (Exception e) {
            return null;
        }
    }

    private void syncWithHomePreferences(String title, int w, int h, int artboards, int bg) {
        try {
            SharedPreferences sp = getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONArray newArr = new JSONArray();

            JSONObject currentObj = new JSONObject();
            currentObj.put("title", title);
            currentObj.put("width", w);
            currentObj.put("height", h);
            currentObj.put("artboards", artboards);
            currentObj.put("bg", bg);
            currentObj.put("date", new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date()));

            newArr.put(currentObj);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!o.optString("title").equalsIgnoreCase(title)) {
                    newArr.put(o);
                }
            }
            sp.edit().putString("saved_projects", newArr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public boolean loadProjectFromDisk(ProjectTabSession s) {
        try {
            File folder = getProjectFolder(s.projectName);
            File meta = new File(folder, "project.json");
            if (!meta.exists()) {
                meta = new File(folder, "project_data.json");
            }
            if (!meta.exists()) return false;

            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(meta), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();

            JSONObject json = new JSONObject(sb.toString());
            s.canvasWidth = json.optInt("width", s.canvasWidth);
            s.canvasHeight = json.optInt("height", s.canvasHeight);
            s.artboardCount = json.optInt("artboards", s.artboardCount);
            s.artboardBgColor = json.optInt("bg", s.artboardBgColor);

            s.hasGradientLine = json.optBoolean("hasGradientLine", false);
            s.gradStartX = (float) json.optDouble("gradStartX", s.canvasWidth * 0.2f);
            s.gradStartY = (float) json.optDouble("gradStartY", s.canvasHeight * 0.8f);
            s.gradEndX = (float) json.optDouble("gradEndX", s.canvasWidth * 0.8f);
            s.gradEndY = (float) json.optDouble("gradEndY", s.canvasHeight * 0.2f);
            s.gradientType = json.optString("gradientType", "Linear");

            if (json.has("gradStops")) {
                JSONArray gradStopsArr = json.getJSONArray("gradStops");
                s.gradStops.clear();
                for (int k = 0; k < gradStopsArr.length(); k++) {
                    JSONObject gso = gradStopsArr.getJSONObject(k);
                    s.gradStops.add(new GradStop((float) gso.getDouble("pos"), gso.getInt("color")));
                }
                if (!s.gradStops.isEmpty()) s.activeGradStop = s.gradStops.get(0);
            }

            JSONArray arr = json.getJSONArray("layers");
            File layersDir = new File(folder, "layers");

            synchronized (s.layers) {
                s.layers.clear();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);
                    String fileName = obj.getString("file");

                    File imgFile = new File(layersDir, fileName);
                    if (!imgFile.exists()) imgFile = new File(folder, fileName);

                    Bitmap bmp = null;
                    if (imgFile.exists() && imgFile.length() > 0) {
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        opts.inMutable = true;
                        bmp = BitmapFactory.decodeFile(imgFile.getAbsolutePath(), opts);
                    }
                    if (bmp == null) {
                        bmp = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
                    }

                    LayerItem item = new LayerItem(obj.getString("name"), bmp, (float) obj.getDouble("x"), (float) obj.getDouble("y"), obj.getBoolean("locked"));
                    item.id = obj.optString("id", item.id);
                    item.scaleX = (float) obj.optDouble("scaleX", 1f);
                    item.scaleY = (float) obj.optDouble("scaleY", 1f);
                    item.rotation = (float) obj.optDouble("rotation", 0f);
                    item.opacity = (float) obj.optDouble("opacity", 1f);
                    item.isVisible = obj.getBoolean("visible");
                    item.blendMode = obj.optString("blend", "Normal");
                    item.isShape = obj.optBoolean("isShape", false);
                    item.shapeType = obj.optString("shapeType", "rectangle");
                    item.isSmartObject = obj.optBoolean("isSmartObject", false);
                    item.isClippingMask = obj.optBoolean("isClippingMask", false);
                    item.isBlank = obj.optBoolean("isBlank", false);
                    item.isDirty = false;

                    item.isPolygonShape = obj.optBoolean("isPolygonShape", false);
                    item.polygonHasFill = obj.optBoolean("polygonHasFill", false);
                    item.polygonHasStroke = obj.optBoolean("polygonHasStroke", true);
                    item.polygonIsMerged = obj.optBoolean("polygonIsMerged", false);
                    item.shapeFill = obj.optInt("shapeFill", item.shapeFill);
                    item.shapeStroke = obj.optInt("shapeStroke", item.shapeStroke);
                    item.shapeStrokeW = (float) obj.optDouble("shapeStrokeW", item.shapeStrokeW);

                    item.radiusTL = (float) obj.optDouble("radiusTL", 0);
                    item.radiusTR = (float) obj.optDouble("radiusTR", 0);
                    item.radiusBR = (float) obj.optDouble("radiusBR", 0);
                    item.radiusBL = (float) obj.optDouble("radiusBL", 0);

                    if (obj.has("polygonAnchors")) {
                        JSONArray paArr = obj.getJSONArray("polygonAnchors");
                        item.polygonAnchors.clear();
                        for (int k = 0; k < paArr.length(); k++) {
                            JSONObject po = paArr.getJSONObject(k);
                            PolyAnchorPoint ap = new PolyAnchorPoint((float) po.getDouble("x"), (float) po.getDouble("y"));
                            ap.hInX = (float) po.optDouble("hInX", ap.x);
                            ap.hInY = (float) po.optDouble("hInY", ap.y);
                            ap.hOutX = (float) po.optDouble("hOutX", ap.x);
                            ap.hOutY = (float) po.optDouble("hOutY", ap.y);
                            ap.hasHandles = po.optBoolean("hasHandles", false);
                            item.polygonAnchors.add(ap);
                        }
                    }

                    s.layers.add(item);
                }
                s.activeLayerIndex = Math.max(0, s.layers.size() - 1);
            }
            syncPolygonFromActiveLayer();
            return !s.layers.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private View buildDesktopStudioLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#121212"));

        root.addView(createTopMenuBar());

        optionControlsBar = new LinearLayout(this);
        optionControlsBar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)));
        optionControlsBar.setBackgroundColor(Color.parseColor("#181818"));
        optionControlsBar.setOrientation(LinearLayout.HORIZONTAL);
        optionControlsBar.setGravity(Gravity.CENTER_VERTICAL);
        optionControlsBar.setPadding(dp(8), 0, dp(8), 0);
        root.addView(optionControlsBar);

        updateOptionControlsBar();
        root.addView(createMultiTabStrip());

        LinearLayout workspace = new LinearLayout(this);
        workspace.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        workspace.setOrientation(LinearLayout.HORIZONTAL);

        workspace.addView(createLeftToolbar());

        FrameLayout canvasFrame = new FrameLayout(this);
        canvasFrame.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        canvasFrame.setBackgroundColor(Color.parseColor("#141414"));

        canvasView = new StudioCanvasView(this);
        canvasFrame.addView(canvasView);
        workspace.addView(canvasFrame);

        rightLayersDock = createRightLayersDock();
        workspace.addView(rightLayersDock);

        root.addView(workspace);
        return root;
    }

    private View createTopMenuBar() {
        LinearLayout mb = new LinearLayout(this);
        mb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        mb.setBackgroundColor(Color.parseColor("#181818"));
        mb.setOrientation(LinearLayout.HORIZONTAL);
        mb.setGravity(Gravity.CENTER_VERTICAL);
        mb.setPadding(dp(6), 0, dp(6), 0);

        Bitmap customAppIcon = null;
        try (InputStream is = getAssets().open("ejitor.png")) {
            customAppIcon = BitmapFactory.decodeStream(is);
        } catch (Exception ignored) {}

        View.OnClickListener goHomeListener = v -> exitWithoutLoading();

        if (customAppIcon != null) {
            ImageView appIconIv = new ImageView(this);
            appIconIv.setImageBitmap(customAppIcon);
            appIconIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            GradientDrawable cr = new GradientDrawable();
            cr.setCornerRadius(dp(3));
            appIconIv.setBackground(cr);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                appIconIv.setClipToOutline(true);
            }
            appIconIv.setOnClickListener(withFeedback(goHomeListener));
            mb.addView(appIconIv, new LinearLayout.LayoutParams(dp(22), dp(22)));
        } else {
            TextView badge = new TextView(this);
            badge.setText("e");
            badge.setTextColor(Color.WHITE);
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            badge.setTypeface(null, Typeface.BOLD);
            badge.setGravity(Gravity.CENTER);
            GradientDrawable badgeBg = new GradientDrawable();
            badgeBg.setColor(Color.parseColor("#FF1238"));
            badgeBg.setCornerRadius(dp(3));
            badge.setBackground(badgeBg); // <-- এখানে badge.setBackground(badgeBg) হবে
            badge.setOnClickListener(withFeedback(goHomeListener));
            mb.addView(badge, new LinearLayout.LayoutParams(dp(22), dp(22)));
        }
        TextView appTitle = new TextView(this);
        appTitle.setText(" EJITOR ");
        appTitle.setTextColor(Color.WHITE);
        appTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        appTitle.setTypeface(null, Typeface.BOLD);
        appTitle.setPadding(dp(4), 0, dp(6), 0);
        appTitle.setOnClickListener(withFeedback(goHomeListener));
        mb.addView(appTitle);

        HorizontalScrollView menuScroll = new HorizontalScrollView(this);
        menuScroll.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        menuScroll.setHorizontalScrollBarEnabled(false);

        menuContainer = new LinearLayout(this);
        menuContainer.setOrientation(LinearLayout.HORIZONTAL);
        menuContainer.setGravity(Gravity.CENTER_VERTICAL);

        menuContainer.addView(createMenuItem("File", this::showFileDropdownMenu));
        menuContainer.addView(createMenuItem("Edit", this::showEditDropdownMenu));
        menuContainer.addView(createMenuItem("Select", this::showSelectDropdownMenu));
        menuContainer.addView(createMenuItem("Align", this::showAlignMenu));
        menuContainer.addView(createMenuItem("Image", v -> showInAppMultiImagePicker()));
        menuContainer.addView(createMenuItem("Layer", v -> addNewBlankLayer()));
        menuContainer.addView(createMenuItem("Filter", v -> Toast.makeText(this, "Filter Engine Ready", Toast.LENGTH_SHORT).show()));
        menuContainer.addView(createMenuItem("Workspace", this::showWorkspaceDropdownMenu));

        menuScroll.addView(menuContainer);
        mb.addView(menuScroll);

        LinearLayout rightGroup = new LinearLayout(this);
        rightGroup.setOrientation(LinearLayout.HORIZONTAL);
        rightGroup.setGravity(Gravity.CENTER_VERTICAL);

        pNameHeaderTv = new TextView(this);
        pNameHeaderTv.setText(projectName + " ");
        pNameHeaderTv.setTextColor(Color.parseColor("#888888"));
        pNameHeaderTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        rightGroup.addView(pNameHeaderTv);

        final ImageView undoBtn = new ImageView(this);
        LinearLayout.LayoutParams pUndo = new LinearLayout.LayoutParams(dp(26), dp(26));
        pUndo.setMargins(dp(3), 0, 0, 0);
        undoBtn.setLayoutParams(pUndo);
        undoBtn.setImageDrawable(createVectorUndoIcon());
        undoBtn.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable bgUndo = new GradientDrawable();
        bgUndo.setColor(Color.parseColor("#222222"));
        bgUndo.setStroke(dp(1), Color.parseColor("#323232"));
        bgUndo.setCornerRadius(dp(3));
        undoBtn.setBackground(bgUndo);
        undoBtn.setClickable(true);
        undoBtn.setFocusable(false);
        undoBtn.setOnClickListener(v -> performUndo());
        rightGroup.addView(undoBtn);

        final ImageView redoBtn = new ImageView(this);
        LinearLayout.LayoutParams pRedo = new LinearLayout.LayoutParams(dp(26), dp(26));
        pRedo.setMargins(dp(3), 0, 0, 0);
        redoBtn.setLayoutParams(pRedo);
        redoBtn.setImageDrawable(createVectorRedoIcon());
        redoBtn.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable bgRedo = new GradientDrawable();
        bgRedo.setColor(Color.parseColor("#222222"));
        bgRedo.setStroke(dp(1), Color.parseColor("#323232"));
        bgRedo.setCornerRadius(dp(3));
        redoBtn.setBackground(bgRedo);
        redoBtn.setClickable(true);
        redoBtn.setFocusable(false);
        redoBtn.setOnClickListener(v -> performRedo());
        rightGroup.addView(redoBtn);

        final ImageView layersToggleBtn = new ImageView(this);
        LinearLayout.LayoutParams pLayers = new LinearLayout.LayoutParams(dp(26), dp(26));
        pLayers.setMargins(dp(3), 0, 0, 0);
        layersToggleBtn.setLayoutParams(pLayers);
        layersToggleBtn.setImageDrawable(createVectorLayersDockIcon());
        layersToggleBtn.setScaleType(ImageView.ScaleType.CENTER);
        GradientDrawable bgLayers = new GradientDrawable();
        bgLayers.setColor(Color.parseColor("#222222"));
        bgLayers.setStroke(dp(1), Color.parseColor("#323232"));
        bgLayers.setCornerRadius(dp(3));
        layersToggleBtn.setBackground(bgLayers);
        layersToggleBtn.setClickable(true);
        layersToggleBtn.setFocusable(false);
        layersToggleBtn.setOnClickListener(v -> {
            if (rightLayersDock != null) {
                int currentVis = rightLayersDock.getVisibility();
                rightLayersDock.setVisibility(currentVis == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        rightGroup.addView(layersToggleBtn);

        mb.addView(rightGroup);
        return mb;
    }

    private TextView createMenuItem(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#D4D4D4"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setPadding(dp(9), dp(6), dp(9), dp(6));
        tv.setOnClickListener(withFeedback(l));
        return tv;
    }

    private void showWorkspaceDropdownMenu(View anchor) {
        String[] items = {"Artboard Settings...", "Reset Viewport"};
        showAnchoredMenu(anchor, items, idx -> {
            if (idx == 0) {
                showArtboardSettingsDialog();
            } else if (idx == 1) {
                canvasView.resetViewport();
            }
        });
    }

    public void showCustomNumericKeypad(final View anchorView, String title, final float min, final float max, float initialVal, final OnNumericInputListener listener) {
        try {
            Class<?> pClass = Class.forName("com.example.ejitor.popup");
            Method m = pClass.getMethod("showNumericKeypad", Activity.class, View.class, String.class, float.class, float.class, float.class, OnNumericInputListener.class);
            m.invoke(null, this, anchorView, title, min, max, initialVal, listener);
            return;
        } catch (Exception ignored) {}

        Toast.makeText(this, title + ": " + (int)initialVal, Toast.LENGTH_SHORT).show();
    }

    private void showArtboardSettingsDialog() {
        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#1E1E1E"));
        layout.setPadding(dp(18), dp(16), dp(18), dp(16));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E1E1E"));
        bg.setCornerRadius(dp(10));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        layout.setBackground(bg);

        TextView title = new TextView(this);
        title.setText("Artboard Settings");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(12));
        layout.addView(title);

        final ProjectTabSession s = getCurrentSession();
        final int[] curW = {s.canvasWidth};
        final int[] curH = {s.canvasHeight};

        final TextView wBox = createClickableValueBox(String.valueOf(curW[0]));
        final TextView hBox = createClickableValueBox(String.valueOf(curH[0]));

        wBox.setOnClickListener(v -> showCustomNumericKeypad(wBox, "Artboard Width", 100, 10000, curW[0], val -> {
            curW[0] = (int) val;
            wBox.setText(String.valueOf(curW[0]));
        }));

        hBox.setOnClickListener(v -> showCustomNumericKeypad(hBox, "Artboard Height", 100, 10000, curH[0], val -> {
            curH[0] = (int) val;
            hBox.setText(String.valueOf(curH[0]));
        }));

        layout.addView(createFieldLabel("Width (px):"));
        layout.addView(wBox);
        layout.addView(createFieldLabel("Height (px):"));
        layout.addView(hBox);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(14), 0, 0);

        Button applyBtn = new Button(this);
        applyBtn.setText("Apply");
        applyBtn.setTextColor(Color.WHITE);
        applyBtn.setBackgroundColor(Color.parseColor("#FF1238"));
        applyBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(34), 1f));
        applyBtn.setOnClickListener(withFeedback(v -> {
            try {
                if (curW[0] > 50 && curH[0] > 50) {
                    s.canvasWidth = curW[0];
                    s.canvasHeight = curH[0];
                    recordHistory();
                    canvasView.autoCenterArtboard(canvasView.getWidth(), canvasView.getHeight());
                    autoSaveCurrentProject();
                    Toast.makeText(this, "Artboard Size Updated", Toast.LENGTH_SHORT).show();
                    d.dismiss();
                }
            } catch (Exception ignored) {}
        }));

        Button closeBtn = new Button(this);
        closeBtn.setText("Cancel");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setBackgroundColor(Color.parseColor("#333333"));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(34), 1f);
        clp.setMargins(dp(8), 0, 0, 0);
        closeBtn.setLayoutParams(clp);
        closeBtn.setOnClickListener(withFeedback(v -> d.dismiss()));

        btnRow.addView(applyBtn);
        btnRow.addView(closeBtn);
        layout.addView(btnRow);

        d.setContentView(layout);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        d.show();
    }

    private TextView createClickableValueBox(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(dp(10), 0, dp(10), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#121212"));
        bg.setStroke(dp(1), Color.parseColor("#303030"));
        bg.setCornerRadius(dp(3));
        tv.setBackground(bg);
        tv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        return tv;
    }

    private TextView createFieldLabel(String text) {
        TextView l = new TextView(this);
        l.setText(text);
        l.setTextColor(Color.parseColor("#888888"));
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        l.setPadding(0, dp(6), 0, dp(2));
        return l;
    }

    public void openColorPicker(View anchor, final boolean isForeground, final boolean isStrokeMode) {
        try {
            Class<?> pClass = Class.forName("com.example.ejitor.popup");
            Method m = pClass.getMethod("showColorPicker", Activity.class, View.class, boolean.class, boolean.class);
            m.invoke(null, this, anchor, isForeground, isStrokeMode);
            return;
        } catch (Exception ignored) {}

        try {
            Class<?> ed5Clazz = Class.forName("com.example.ejitor.editor_5");
            Field instField = ed5Clazz.getField("instance");
            Object ed5Inst = instField.get(null);
            if (ed5Inst != null) {
                Method m = ed5Clazz.getMethod("showRectangularColorPickerWithFeatures", View.class);
                m.invoke(ed5Inst, anchor);
                return;
            }
        } catch (Exception ignored) {}

        Toast.makeText(this, "Color Picker Opening...", Toast.LENGTH_SHORT).show();
    }

    public void showDraggableColorPickerDialog(final boolean isForeground, final boolean isStrokeMode) {
        openColorPicker(fgSwatchView, isForeground, isStrokeMode);
    }

    private void updateOptionControlsBar() {
        if (optionControlsBar == null) return;
        optionControlsBar.removeAllViews();

        ProjectTabSession s = getCurrentSession();

        if ("shape".equals(activeTool)) {
            TextView shapeBtn = createOptionPillBtn("Shape: " + capitalize(activeShapeType) + " ⌵", v -> showShapePickerPopup());
            optionControlsBar.addView(shapeBtn);

            final LinearLayout cbShapeLock = createCustomCheckbox(" Shape Lock", shapeLock, checked -> shapeLock = checked);
            optionControlsBar.addView(cbShapeLock);

            TextView strLbl = new TextView(this);
            strLbl.setText(" Stroke: ");
            strLbl.setTextColor(Color.parseColor("#CCCCCC"));
            strLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            optionControlsBar.addView(strLbl);

            final TextView strokeBox = createClickablePillBox(String.valueOf((int) shapeStrokeWidth));
            strokeBox.setOnClickListener(v -> showCustomNumericKeypad(strokeBox, "Stroke", 0, 100, shapeStrokeWidth, val -> {
                shapeStrokeWidth = val;
                strokeBox.setText(String.valueOf((int) shapeStrokeWidth));
                reRenderActiveShapeLayer();
            }));
            optionControlsBar.addView(strokeBox);

            TextView fillBtn = createOptionPillBtn("Fill", v -> openColorPicker(v, true, false));
            optionControlsBar.addView(fillBtn);

            TextView strokeBtn = createOptionPillBtn("Stroke", v -> openColorPicker(v, false, true));
            strokeBtn.setBackgroundColor(Color.parseColor("#FF1238"));
            optionControlsBar.addView(strokeBtn);

            final ImageView linkBtn = new ImageView(this);
            LinearLayout.LayoutParams lpLink = new LinearLayout.LayoutParams(dp(22), dp(22));
            lpLink.setMargins(dp(3), 0, dp(3), 0);
            linkBtn.setLayoutParams(lpLink);
            linkBtn.setImageDrawable(createVectorChainLinkIcon(linkCorners));
            linkBtn.setBackgroundColor(Color.parseColor(linkCorners ? "#FF1238" : "#282828"));
            linkBtn.setPadding(dp(3), dp(3), dp(3), dp(3));
            linkBtn.setOnClickListener(withFeedback(v -> {
                linkCorners = !linkCorners;
                linkBtn.setImageDrawable(createVectorChainLinkIcon(linkCorners));
                linkBtn.setBackgroundColor(Color.parseColor(linkCorners ? "#FF1238" : "#282828"));
            }));
            optionControlsBar.addView(linkBtn);

            optionControlsBar.addView(createCornerInput("TL: ", (int) shapeRadiusTL, val -> {
                shapeRadiusTL = val;
                if (linkCorners) shapeRadiusTR = shapeRadiusBR = shapeRadiusBL = val;
                reRenderActiveShapeLayer();
                if (linkCorners) updateOptionControlsBar();
            }));

            optionControlsBar.addView(createCornerInput("TR: ", (int) shapeRadiusTR, val -> {
                shapeRadiusTR = val;
                if (linkCorners) shapeRadiusTL = shapeRadiusBR = shapeRadiusBL = val;
                reRenderActiveShapeLayer();
                if (linkCorners) updateOptionControlsBar();
            }));

            optionControlsBar.addView(createCornerInput("BR: ", (int) shapeRadiusBR, val -> {
                shapeRadiusBR = val;
                if (linkCorners) shapeRadiusTL = shapeRadiusTR = shapeRadiusBL = val;
                reRenderActiveShapeLayer();
                if (linkCorners) updateOptionControlsBar();
            }));

            optionControlsBar.addView(createCornerInput("BL: ", (int) shapeRadiusBL, val -> {
                shapeRadiusBL = val;
                if (linkCorners) shapeRadiusTL = shapeRadiusTR = shapeRadiusBR = val;
                reRenderActiveShapeLayer();
                if (linkCorners) updateOptionControlsBar();
            }));

        } else if ("move".equals(activeTool)) {
            final LinearLayout cbShift = createCustomCheckbox(" Shift (Lock Ratio)", maintainAspectRatio, checked -> maintainAspectRatio = checked);
            optionControlsBar.addView(cbShift);

            final LinearLayout cbTransform = createCustomCheckbox(" Show Transform", showTransformControls, checked -> {
                showTransformControls = checked;
                canvasView.invalidate();
            });
            optionControlsBar.addView(cbTransform);

            final LinearLayout btnSnap = createSnappingToggleBtn();
            optionControlsBar.addView(btnSnap);

        } else if ("select_rect".equals(activeTool)) {
            TextView modeBtn = createOptionPillBtn("Mode: " + getSelectionModeName(), v -> showMarqueeOptionsDialog());
            optionControlsBar.addView(modeBtn);
            TextView deselectBtn = createOptionPillBtn("Deselect", v -> canvasView.clearLassoSelection());
            optionControlsBar.addView(deselectBtn);

        } else if ("lasso".equals(activeTool)) {
            TextView modeBtn = createOptionPillBtn(getLassoSubToolName() + " ▾", v -> showLassoOptionsDialog());
            optionControlsBar.addView(modeBtn);

            if (lassoSubTool == 3 || lassoSubTool == 4) {
                TextView sizeLbl = new TextView(this);
                sizeLbl.setText(" Size: ");
                sizeLbl.setTextColor(Color.parseColor("#CCCCCC"));
                sizeLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
                optionControlsBar.addView(sizeLbl);

                final TextView sizeBox = createClickablePillBox(String.valueOf((int) polyLineWidth));
                sizeBox.setOnClickListener(v -> showCustomNumericKeypad(sizeBox, "Line Size", 1, 100, polyLineWidth, val -> {
                    polyLineWidth = Math.max(1f, val);
                    sizeBox.setText(String.valueOf((int) polyLineWidth));
                    updateActivePolygonShapeProperties();
                    canvasView.invalidate();
                }));
                optionControlsBar.addView(sizeBox);

                final TextView strokeBtn = createOptionPillBtn(polyStrokeEnabled ? "Stroke: ON" : "Stroke", null);
                strokeBtn.setBackgroundColor(Color.parseColor(polyStrokeEnabled ? "#FF1238" : "#282828"));
                strokeBtn.setOnClickListener(v -> {
                    polyStrokeEnabled = !polyStrokeEnabled;
                    if (polyStrokeEnabled) {
                        openColorPicker(v, false, true);
                    }
                    strokeBtn.setText(polyStrokeEnabled ? "Stroke: ON" : "Stroke");
                    strokeBtn.setBackgroundColor(Color.parseColor(polyStrokeEnabled ? "#FF1238" : "#282828"));
                    updateActivePolygonShapeProperties();
                    canvasView.invalidate();
                });
                optionControlsBar.addView(strokeBtn);

                final TextView fillBtn = createOptionPillBtn(polyFillEnabled ? "Fill: ON" : "Fill", null);
                fillBtn.setBackgroundColor(Color.parseColor(polyFillEnabled ? "#FF1238" : "#282828"));
                fillBtn.setOnClickListener(v -> {
                    polyFillEnabled = !polyFillEnabled;
                    if (polyFillEnabled) {
                        openColorPicker(v, true, false);
                    }
                    fillBtn.setText(polyFillEnabled ? "Fill: ON" : "Fill");
                    fillBtn.setBackgroundColor(Color.parseColor(polyFillEnabled ? "#FF1238" : "#282828"));
                    updateActivePolygonShapeProperties();
                    canvasView.invalidate();
                });
                optionControlsBar.addView(fillBtn);

                final TextView mergeBtn = createOptionPillBtn(polyMergePath ? "Merge: ON" : "Merge", null);
                mergeBtn.setBackgroundColor(Color.parseColor(polyMergePath ? "#FF1238" : "#282828"));
                mergeBtn.setOnClickListener(v -> {
                    polyMergePath = !polyMergePath;
                    mergeBtn.setText(polyMergePath ? "Merge: ON" : "Merge");
                    mergeBtn.setBackgroundColor(Color.parseColor(polyMergePath ? "#FF1238" : "#282828"));
                    updateActivePolygonShapeProperties();
                    canvasView.invalidate();
                });
                optionControlsBar.addView(mergeBtn);

                TextView anchorMenuBtn = createOptionPillBtn("Anchor: " + anchorMode + " ▾", this::showAnchorModesDropdown);
                anchorMenuBtn.setBackgroundColor(Color.parseColor("#FF1238"));
                optionControlsBar.addView(anchorMenuBtn);

                TextView finishBtn = createOptionPillBtn("✓ Done Selection", v -> finishPolygonSelection());
                finishBtn.setBackgroundColor(Color.parseColor("#FF1238"));
                optionControlsBar.addView(finishBtn);

                TextView deselectBtn = createOptionPillBtn("Deselect", v -> canvasView.clearLassoSelection());
                optionControlsBar.addView(deselectBtn);

                TextView convertShapeBtn = createOptionPillBtn("Shape", v -> convertPolygonToShapeLayer());
                convertShapeBtn.setBackgroundColor(Color.parseColor("#FF1238"));
                optionControlsBar.addView(convertShapeBtn);

                TextView delPointBtn = createOptionPillBtn("Del Point", v -> deleteSelectedAnchorPoint());
                delPointBtn.setBackgroundColor(Color.parseColor("#282828"));
                optionControlsBar.addView(delPointBtn);
            } else {
                TextView deselectBtn = createOptionPillBtn("Deselect", v -> canvasView.clearLassoSelection());
                optionControlsBar.addView(deselectBtn);
            }

        } else if ("gradient".equals(activeTool)) {
            final LinearLayout cbShift = createCustomCheckbox(" Shift", maintainAspectRatio, checked -> maintainAspectRatio = checked);
            optionControlsBar.addView(cbShift);

            String gType = (s != null && s.gradientType != null) ? s.gradientType : "Linear";
            TextView typeBtn = createOptionPillBtn("Type: " + gType + " ▾", this::showGradientTypeDropdown);
            optionControlsBar.addView(typeBtn);

            TextView addStopBtn = createOptionPillBtn("+ Add Stop", v -> {
                if (s == null) return;
                float newPos = 0.5f;
                GradStop newStop = new GradStop(newPos, fgColor);
                s.gradStops.add(newStop);
                s.activeGradStop = newStop;
                updateSwatchPreviews();
                applyOnCanvasGradientToActiveLayer(true);
                canvasView.invalidate();
                Toast.makeText(this, "New Color Stop Added", Toast.LENGTH_SHORT).show();
            });
            optionControlsBar.addView(addStopBtn);

            TextView presetBtn = createOptionPillBtn("Presets ▾", v -> showGradientPresetsDialog());
            optionControlsBar.addView(presetBtn);

            TextView saveGradBtn = createOptionPillBtn("Save ▾", this::showSaveGradientDropdown);
            optionControlsBar.addView(saveGradBtn);
        }

        activeToolLabelTv = new TextView(this);
        activeToolLabelTv.setText("  [" + activeTool.toUpperCase() + "]");
        activeToolLabelTv.setTextColor(Color.parseColor("#777777"));
        activeToolLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        optionControlsBar.addView(activeToolLabelTv);
    }

    private void showGradientTypeDropdown(View anchor) {
        String[] types = {"Linear", "Radial", "Angle (Sweep)", "Reflected", "Diamond"};
        showAnchoredMenu(anchor, types, idx -> {
            ProjectTabSession s = getCurrentSession();
            if (s != null) {
                if (idx == 0) s.gradientType = "Linear";
                else if (idx == 1) s.gradientType = "Radial";
                else if (idx == 2) s.gradientType = "Angle";
                else if (idx == 3) s.gradientType = "Reflected";
                else if (idx == 4) s.gradientType = "Diamond";

                updateOptionControlsBar();
                applyOnCanvasGradientToActiveLayer(true);
                if (canvasView != null) canvasView.invalidate();
                autoSaveCurrentProject();
            }
        });
    }

    private TextView createClickablePillBox(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(Color.parseColor("#222222"));
        tv.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(22)));
        return tv;
    }

    private LinearLayout createCornerInput(String label, int initVal, final ValueChangeListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(2), 0, dp(2), 0);

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#AAAAAA"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        row.addView(tv);

        final TextView valBox = createClickablePillBox(String.valueOf(initVal));
        valBox.setOnClickListener(v -> showCustomNumericKeypad(valBox, label.trim(), 0, 500, initVal, val -> {
            valBox.setText(String.valueOf((int) val));
            if (l != null) l.onChanged(val);
        }));
        row.addView(valBox);
        return row;
    }

    interface ValueChangeListener { void onChanged(float val); }

    private void syncPolygonFromActiveLayer() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.isPolygonShape) {
                polyAnchors.clear();
                for (PolyAnchorPoint ap : al.polygonAnchors) {
                    polyAnchors.add(ap.copy());
                }
                polyFillEnabled = al.polygonHasFill;
                polyFillColor = al.shapeFill;
                polyStrokeEnabled = al.polygonHasStroke;
                polyStrokeColor = al.shapeStroke;
                polyLineWidth = al.shapeStrokeW;
                polyMergePath = al.polygonIsMerged;
            }
        }
    }

    private void updateActivePolygonShapeProperties() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.isPolygonShape) {
                al.polygonHasFill = polyFillEnabled;
                al.shapeFill = polyFillColor;
                al.polygonHasStroke = polyStrokeEnabled;
                al.shapeStroke = polyStrokeColor;
                al.shapeStrokeW = polyLineWidth;
                al.polygonIsMerged = polyMergePath;
                reRenderActivePolygonShapeLayer();
            }
        }
    }

    private void deleteSelectedAnchorPoint() {
        if (polyAnchors.isEmpty()) {
            Toast.makeText(this, "No Anchor Points to delete", Toast.LENGTH_SHORT).show();
            return;
        }
        if (canvasView.selectedAnchorIndex >= 0 && canvasView.selectedAnchorIndex < polyAnchors.size()) {
            polyAnchors.remove(canvasView.selectedAnchorIndex);
            canvasView.selectedAnchorIndex = -1;
            canvasView.selectedHandleSide = 0;
        } else {
            polyAnchors.remove(polyAnchors.size() - 1);
        }

        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.isPolygonShape) {
                al.polygonAnchors.clear();
                for (PolyAnchorPoint ap : polyAnchors) al.polygonAnchors.add(ap.copy());
                reRenderActivePolygonShapeLayer();
            }
        }

        canvasView.invalidate();
        Toast.makeText(this, "Anchor Point Deleted", Toast.LENGTH_SHORT).show();
    }

    private Path buildPathFromAnchors(List<PolyAnchorPoint> points, boolean closePath) {
        Path path = new Path();
        if (points == null || points.isEmpty()) return path;

        PolyAnchorPoint first = points.get(0);
        path.moveTo(first.x, first.y);

        for (int i = 1; i < points.size(); i++) {
            PolyAnchorPoint prev = points.get(i - 1);
            PolyAnchorPoint curr = points.get(i);
            if (prev.hasHandles || curr.hasHandles) {
                path.cubicTo(prev.hOutX, prev.hOutY, curr.hInX, curr.hInY, curr.x, curr.y);
            } else {
                path.lineTo(curr.x, curr.y);
            }
        }

        if (closePath && points.size() >= 3) {
            PolyAnchorPoint last = points.get(points.size() - 1);
            if (last.hasHandles || first.hasHandles) {
                path.cubicTo(last.hOutX, last.hOutY, first.hInX, first.hInY, first.x, first.y);
            } else {
                path.close();
            }
        }
        return path;
    }

    private void convertPolygonToShapeLayer() {
        if (polyAnchors.size() < 3) {
            Toast.makeText(this, "Add at least 3 points to create a Shape", Toast.LENGTH_SHORT).show();
            return;
        }
        ProjectTabSession s = getCurrentSession();
        if (s == null) return;

        LayerItem targetLayer = null;
        if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem cur = s.layers.get(s.activeLayerIndex);
            if (cur.isPolygonShape) {
                targetLayer = cur;
            }
        }

        if (targetLayer == null) {
            Bitmap shapeBmp = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
            float abOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
            targetLayer = new LayerItem("Polygon Shape " + (s.layers.size() + 1), shapeBmp, abOffset, 0, false);
            targetLayer.isShape = true;
            targetLayer.isBlank = false;
            targetLayer.isPolygonShape = true;
            synchronized (s.layers) {
                s.layers.add(targetLayer);
                s.activeLayerIndex = s.layers.size() - 1;
            }
        }

        targetLayer.polygonAnchors.clear();
        for (PolyAnchorPoint ap : polyAnchors) {
            targetLayer.polygonAnchors.add(ap.copy());
        }
        targetLayer.polygonHasFill = polyFillEnabled;
        targetLayer.shapeFill = polyFillColor;
        targetLayer.polygonHasStroke = polyStrokeEnabled;
        targetLayer.shapeStroke = polyStrokeColor;
        targetLayer.shapeStrokeW = polyLineWidth;
        targetLayer.polygonIsMerged = polyMergePath;

        reRenderActivePolygonShapeLayer();
        recordHistory();
        updateLayersDockUI();
        canvasView.invalidate();
        Toast.makeText(this, "Polygon Shape Updated", Toast.LENGTH_SHORT).show();
    }

    private void reRenderActivePolygonShapeLayer() {
        ProjectTabSession s = getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        LayerItem al = s.layers.get(s.activeLayerIndex);
        if (!al.isPolygonShape || al.polygonAnchors.size() < 2) return;

        if (al.bitmap == null || al.bitmap.isRecycled()) {
            al.bitmap = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
        } else {
            al.bitmap.eraseColor(Color.TRANSPARENT);
        }

        Canvas c = new Canvas(al.bitmap);
        Path p = buildPathFromAnchors(al.polygonAnchors, al.polygonIsMerged);

        if (al.polygonHasFill) {
            Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG | Paint.FILTER_BITMAP_FLAG);
            fillP.setStyle(Paint.Style.FILL);
            fillP.setColor(al.shapeFill);
            c.drawPath(p, fillP);
        }

        if (al.polygonHasStroke && al.shapeStrokeW > 0) {
            Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG | Paint.FILTER_BITMAP_FLAG);
            strokeP.setStyle(Paint.Style.STROKE);
            strokeP.setColor(al.shapeStroke);
            strokeP.setStrokeWidth(dp(al.shapeStrokeW));
            strokeP.setStrokeJoin(Paint.Join.ROUND);
            strokeP.setStrokeCap(Paint.Cap.ROUND);
            c.drawPath(p, strokeP);
        }

        al.isBlank = false;
        al.isShape = true;
        al.isPolygonShape = true;
        al.isDirty = true;
        al.updateThumb();
        autoSaveCurrentProject();
    }

    private void showAnchorModesDropdown(View anchor) {
        String[] modes = {"Free", "Asymmetric", "Symmetric", "Smooth"};
        showAnchoredMenu(anchor, modes, idx -> {
            anchorMode = modes[idx];
            if ("Smooth".equalsIgnoreCase(anchorMode)) {
                applySmoothToAllPolygonAnchors();
            }
            updateOptionControlsBar();
            canvasView.invalidate();
        });
    }

    private void applySmoothToAllPolygonAnchors() {
        if (polyAnchors.size() < 2) return;
        for (int i = 0; i < polyAnchors.size(); i++) {
            PolyAnchorPoint curr = polyAnchors.get(i);
            PolyAnchorPoint prev = polyAnchors.get((i - 1 + polyAnchors.size()) % polyAnchors.size());
            PolyAnchorPoint next = polyAnchors.get((i + 1) % polyAnchors.size());

            float dx = (next.x - prev.x) * 0.25f;
            float dy = (next.y - prev.y) * 0.25f;

            curr.hasHandles = true;
            curr.hInX = curr.x - dx;
            curr.hInY = curr.y - dy;
            curr.hOutX = curr.x + dx;
            curr.hOutY = curr.y + dy;
        }

        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.isPolygonShape) {
                al.polygonAnchors.clear();
                for (PolyAnchorPoint ap : polyAnchors) al.polygonAnchors.add(ap.copy());
                reRenderActivePolygonShapeLayer();
            }
        }
        Toast.makeText(this, "Corners Smoothed", Toast.LENGTH_SHORT).show();
    }

    private void showSaveGradientDropdown(View anchor) {
        String[] opts = {"Save Gradient", "Open Gradient"};
        showAnchoredMenu(anchor, opts, idx -> {
            if (idx == 0) {
                saveCurrentCustomGradient();
            } else if (idx == 1) {
                openSavedGradientsList(anchor);
            }
        });
    }

    private void saveCurrentCustomGradient() {
        ProjectTabSession s = getCurrentSession();
        if (s == null || s.gradStops == null || s.gradStops.isEmpty()) return;
        try {
            SharedPreferences sp = getSharedPreferences("ejitor_gradients", MODE_PRIVATE);
            String existing = sp.getString("saved_list", "[]");
            JSONArray arr = new JSONArray(existing);

            JSONObject gradObj = new JSONObject();
            gradObj.put("name", "Gradient " + (arr.length() + 1));
            gradObj.put("type", s.gradientType != null ? s.gradientType : "Linear");
            JSONArray stops = new JSONArray();
            for (GradStop gs : s.gradStops) {
                JSONObject o = new JSONObject();
                o.put("pos", gs.pos);
                o.put("color", gs.color);
                stops.put(o);
            }
            gradObj.put("stops", stops);
            arr.put(gradObj);

            sp.edit().putString("saved_list", arr.toString()).apply();
            Toast.makeText(this, "Gradient Saved Successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to save gradient", Toast.LENGTH_SHORT).show();
        }
    }

    private void openSavedGradientsList(View anchor) {
        try {
            SharedPreferences sp = getSharedPreferences("ejitor_gradients", MODE_PRIVATE);
            String existing = sp.getString("saved_list", "[]");
            JSONArray arr = new JSONArray(existing);
            if (arr.length() == 0) {
                Toast.makeText(this, "No saved gradients found", Toast.LENGTH_SHORT).show();
                return;
            }

            String[] names = new String[arr.length()];
            for (int i = 0; i < arr.length(); i++) {
                names[i] = arr.getJSONObject(i).optString("name", "Gradient " + (i + 1));
            }

            showAnchoredMenu(anchor, names, selIdx -> {
                try {
                    JSONObject gObj = arr.getJSONObject(selIdx);
                    JSONArray stops = gObj.getJSONArray("stops");
                    ProjectTabSession s = getCurrentSession();
                    if (s == null) return;
                    s.gradStops.clear();
                    s.gradientType = gObj.optString("type", "Linear");
                    for (int k = 0; k < stops.length(); k++) {
                        JSONObject o = stops.getJSONObject(k);
                        s.gradStops.add(new GradStop((float) o.getDouble("pos"), o.getInt("color")));
                    }
                    if (!s.gradStops.isEmpty()) {
                        s.activeGradStop = s.gradStops.get(0);
                        fgColor = s.activeGradStop.color;
                        updateSwatchPreviews();
                    }
                    updateOptionControlsBar();
                    applyOnCanvasGradientToActiveLayer(true);
                    canvasView.invalidate();
                    Toast.makeText(this, "Loaded: " + names[selIdx], Toast.LENGTH_SHORT).show();
                } catch (Exception ignored) {}
            });
        } catch (Exception ignored) {}
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return "";
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    private void reRenderActiveShapeLayer() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.isPolygonShape) {
                reRenderActivePolygonShapeLayer();
                return;
            }
            if (al.isShape && al.bitmap != null) {
                int w = Math.max(10, al.bitmap.getWidth());
                int h = Math.max(10, al.bitmap.getHeight());
                Bitmap newBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(newBmp);

                Path p = generateShapePath(activeShapeType, w, h);

                if ("line".equals(activeShapeType)) {
                    Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
                    strokeP.setColor(shapeStrokeColor);
                    strokeP.setStyle(Paint.Style.STROKE);
                    strokeP.setStrokeWidth(Math.max(2f, shapeStrokeWidth));
                    strokeP.setStrokeCap(Paint.Cap.ROUND);
                    c.drawPath(p, strokeP);
                } else {
                    Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
                    fillP.setColor(shapeFillColor);
                    fillP.setStyle(Paint.Style.FILL);
                    c.drawPath(p, fillP);

                    if (shapeStrokeWidth > 0) {
                        Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
                        strokeP.setColor(shapeStrokeColor);
                        strokeP.setStyle(Paint.Style.STROKE);
                        strokeP.setStrokeWidth(shapeStrokeWidth);
                        c.drawPath(p, strokeP);
                    }
                }

                al.bitmap = newBmp;
                al.shapeStrokeW = shapeStrokeWidth;
                al.radiusTL = shapeRadiusTL;
                al.radiusTR = shapeRadiusTR;
                al.radiusBR = shapeRadiusBR;
                al.radiusBL = shapeRadiusBL;
                al.shapeFill = shapeFillColor;
                al.shapeStroke = shapeStrokeColor;
                al.isDirty = true;
                al.updateThumb();
                canvasView.invalidate();
                autoSaveCurrentProject();
            }
        }
    }

    private TextView createOptionPillBtn(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setPadding(dp(6), dp(2), dp(6), dp(2));
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#252525"));
        gd.setStroke(dp(1), Color.parseColor("#383838"));
        gd.setCornerRadius(dp(3));
        tv.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
        lp.setMargins(dp(2), 0, dp(2), 0);
        tv.setLayoutParams(lp);
        if (l != null) tv.setOnClickListener(withFeedback(l));
        return tv;
    }

    private String getSelectionModeName() {
        return selectionMode == 1 ? "Add (+)" : (selectionMode == 2 ? "Sub (-)" : "New");
    }

    private String getLassoSubToolName() {
        switch (lassoSubTool) {
            case 1: return "Lasso Add";
            case 2: return "Lasso Sub";
            case 3: return "Polygon";
            case 4: return "Polygon Sub";
            case 5: return "Pen Brush";
            case 6: return "Pen Eraser";
            default: return "Freehand Lasso";
        }
    }

    private LinearLayout createCustomCheckbox(String label, boolean initial, final OnCheckedListener l) {
        final LinearLayout cb = new LinearLayout(this);
        cb.setOrientation(LinearLayout.HORIZONTAL);
        cb.setGravity(Gravity.CENTER_VERTICAL);
        cb.setPadding(dp(4), dp(2), dp(6), dp(2));

        final boolean[] state = {initial};
        final ImageView iv = new ImageView(this);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(13), dp(13)));
        iv.setImageDrawable(createVectorCheckmarkIcon(state[0]));
        cb.addView(iv);

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#E0E0E0"));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        cb.addView(tv);

        cb.setOnClickListener(v -> {
            state[0] = !state[0];
            iv.setImageDrawable(createVectorCheckmarkIcon(state[0]));
            if (l != null) l.onChecked(state[0]);
        });
        return cb;
    }

    interface OnCheckedListener { void onChecked(boolean checked); }

    private LinearLayout createSnappingToggleBtn() {
        final LinearLayout btnSnap = new LinearLayout(this);
        btnSnap.setOrientation(LinearLayout.HORIZONTAL);
        btnSnap.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams bsp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(21));
        bsp.setMargins(dp(8), 0, 0, 0);
        btnSnap.setLayoutParams(bsp);
        btnSnap.setPadding(dp(6), 0, dp(7), 0);

        final GradientDrawable snapBg = new GradientDrawable();
        snapBg.setColor(snappingEnabled ? Color.parseColor("#FF1238") : Color.parseColor("#2E2E2E"));
        snapBg.setCornerRadius(dp(3));
        btnSnap.setBackground(snapBg);

        final ImageView snapIcon = new ImageView(this);
        snapIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(11), dp(11)));
        snapIcon.setImageDrawable(createVectorSnappingIcon());
        btnSnap.addView(snapIcon);

        final TextView snapTv = new TextView(this);
        snapTv.setText(snappingEnabled ? " Snapping: ON" : " Snapping: OFF");
        snapTv.setTextColor(Color.WHITE);
        snapTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.8f);
        snapTv.setTypeface(null, Typeface.BOLD);
        btnSnap.addView(snapTv);

        btnSnap.setOnClickListener(v -> {
            snappingEnabled = !snappingEnabled;
            snapTv.setText(snappingEnabled ? " Snapping: ON" : " Snapping: OFF");
            snapBg.setColor(snappingEnabled ? Color.parseColor("#FF1238") : Color.parseColor("#2E2E2E"));
            btnSnap.setBackground(snapBg);
        });
        return btnSnap;
    }

    private View createMultiTabStrip() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)));
        hsv.setBackgroundColor(Color.parseColor("#121212"));
        hsv.setHorizontalScrollBarEnabled(false);

        tabStripLayout = new LinearLayout(this);
        tabStripLayout.setOrientation(LinearLayout.HORIZONTAL);
        tabStripLayout.setGravity(Gravity.CENTER_VERTICAL);
        hsv.addView(tabStripLayout);

        refreshTabStripUI();
        return hsv;
    }

    private void refreshTabStripUI() {
        if (tabStripLayout == null) return;
        tabStripLayout.removeAllViews();

        for (int i = 0; i < openTabs.size(); i++) {
            final int index = i;
            final ProjectTabSession tab = openTabs.get(i);

            LinearLayout tabChip = new LinearLayout(this);
            tabChip.setOrientation(LinearLayout.HORIZONTAL);
            tabChip.setGravity(Gravity.CENTER_VERTICAL);
            tabChip.setBackgroundColor(Color.parseColor(index == currentTabIdx ? "#1E1E1E" : "#141414"));
            tabChip.setPadding(dp(8), 0, dp(8), 0);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(22));
            cp.setMargins(0, 0, dp(2), 0);
            tabChip.setLayoutParams(cp);

            TextView titleTv = new TextView(this);
            String layerName = (tab.activeLayerIndex >= 0 && tab.activeLayerIndex < tab.layers.size()) ? tab.layers.get(tab.activeLayerIndex).name : "Background";
            titleTv.setText(tab.projectName + " @ " + (int)(tab.scale * 100) + "% (" + layerName + ", RGB/8#) * ");
            titleTv.setTextColor(Color.parseColor(index == currentTabIdx ? "#FFFFFF" : "#888888"));
            titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
            titleTv.setTypeface(null, index == currentTabIdx ? Typeface.BOLD : Typeface.NORMAL);
            tabChip.addView(titleTv);

            TextView closeX = new TextView(this);
            closeX.setText("✕");
            closeX.setTextColor(Color.parseColor("#888888"));
            closeX.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
            closeX.setPadding(dp(5), 0, dp(2), 0);
            closeX.setOnClickListener(withFeedback(v -> closeTab(index)));
            tabChip.addView(closeX);

            tabChip.setOnClickListener(withFeedback(v -> switchTab(index)));
            tabStripLayout.addView(tabChip);
        }
    }

    public void openNewTabWithSession(ProjectTabSession session) {
        if (session == null) return;
        openTabs.add(session);
        switchTab(openTabs.size() - 1);
        recordHistory();
    }

    private void switchTab(int index) {
        if (index < 0 || index >= openTabs.size()) return;
        saveProjectToDiskImmediate(getCurrentSession());
        currentTabIdx = index;
        projectName = getCurrentSession().projectName;
        if (pNameHeaderTv != null) pNameHeaderTv.setText(projectName + "   ");
        refreshTabStripUI();
        syncPolygonFromActiveLayer();
        updateLayersDockUI();
        if (canvasView != null) {
            canvasView.clearLassoSelection();
            canvasView.post(() -> canvasView.autoCenterArtboard(canvasView.getWidth(), canvasView.getHeight()));
        }
    }

    private void closeTab(int index) {
        if (openTabs.size() <= 1) {
            exitWithoutLoading();
            return;
        }
        saveProjectToDiskImmediate(openTabs.get(index));
        openTabs.remove(index);
        currentTabIdx = Math.max(0, currentTabIdx - 1);
        projectName = getCurrentSession().projectName;
        if (pNameHeaderTv != null) pNameHeaderTv.setText(projectName + "   ");
        refreshTabStripUI();
        syncPolygonFromActiveLayer();
        updateLayersDockUI();
        if (canvasView != null) canvasView.invalidate();
    }

    private final ArrayList<ImageView> toolButtons = new ArrayList<>();

    private View createLeftToolbar() {
        LinearLayout tb = new LinearLayout(this);
        tb.setLayoutParams(new LinearLayout.LayoutParams(dp(38), ViewGroup.LayoutParams.MATCH_PARENT));
        tb.setBackgroundColor(Color.parseColor("#181818"));
        tb.setOrientation(LinearLayout.VERTICAL);
        tb.setGravity(Gravity.CENTER_HORIZONTAL);
        tb.setPadding(0, dp(4), 0, dp(4));

        toolButtons.clear();

        toolButtons.add(createToolIconBtn(createVectorMoveIcon(), activeTool.equals("move"), v -> {
            activeTool = "move";
            updateToolSelection(0);
            updateOptionControlsBar();
        }));

        ImageView marqueeBtn = createToolIconBtn(createVectorMarqueeIcon(), activeTool.equals("select_rect"), v -> {
            activeTool = "select_rect";
            updateToolSelection(1);
            updateOptionControlsBar();
        });
        marqueeBtn.setOnLongClickListener(v -> {
            showMarqueeOptionsDialog();
            return true;
        });
        toolButtons.add(marqueeBtn);

        ImageView lassoBtn = createToolIconBtn(createVectorRoundLassoIcon(), activeTool.equals("lasso"), v -> {
            activeTool = "lasso";
            updateToolSelection(2);
            syncPolygonFromActiveLayer();
            updateOptionControlsBar();
        });
        lassoBtn.setOnLongClickListener(v -> {
            showLassoOptionsDialog();
            return true;
        });
        toolButtons.add(lassoBtn);

        toolButtons.add(createToolIconBtn(createVectorGradientIcon(), activeTool.equals("gradient"), v -> {
            activeTool = "gradient";
            updateToolSelection(3);
            startOnCanvasGradient();
            updateOptionControlsBar();
        }));

        toolButtons.add(createToolIconBtn(createVectorShapeIcon(), activeTool.equals("shape"), v -> {
            activeTool = "shape";
            updateToolSelection(4);
            updateOptionControlsBar();
        }));

        for (ImageView iv : toolButtons) tb.addView(iv);

        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(dp(1), 0, 1f));
        tb.addView(spacer);

        LinearLayout swatchWrap = new LinearLayout(this);
        swatchWrap.setOrientation(LinearLayout.VERTICAL);
        swatchWrap.setGravity(Gravity.CENTER_HORIZONTAL);
        swatchWrap.setPadding(0, dp(2), 0, dp(14));

        FrameLayout swatchContainer = new FrameLayout(this);
        swatchContainer.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));

        bgSwatchView = new View(this);
        FrameLayout.LayoutParams bgP = new FrameLayout.LayoutParams(dp(20), dp(20));
        bgP.gravity = Gravity.BOTTOM | Gravity.END;
        bgSwatchView.setLayoutParams(bgP);
        GradientDrawable bgDr = new GradientDrawable();
        bgDr.setColor(bgColor);
        bgDr.setStroke(dp(1.2f), Color.parseColor("#444444"));
        bgSwatchView.setBackground(bgDr);
        swatchContainer.addView(bgSwatchView);

        fgSwatchView = new View(this);
        FrameLayout.LayoutParams fgP = new FrameLayout.LayoutParams(dp(20), dp(20));
        fgP.gravity = Gravity.TOP | Gravity.START;
        fgSwatchView.setLayoutParams(fgP);
        GradientDrawable fgDr = new GradientDrawable();
        fgDr.setColor(fgColor);
        fgDr.setStroke(dp(1.2f), Color.WHITE);
        fgSwatchView.setBackground(fgDr);
        swatchContainer.addView(fgSwatchView);

        fgSwatchView.setOnClickListener(withFeedback(v -> openColorPicker(fgSwatchView, true, false)));
        bgSwatchView.setOnClickListener(withFeedback(v -> openColorPicker(bgSwatchView, false, false)));

        swatchWrap.addView(swatchContainer);

        ImageView swapBtn = new ImageView(this);
        LinearLayout.LayoutParams spP = new LinearLayout.LayoutParams(dp(16), dp(14));
        spP.setMargins(0, dp(4), 0, 0);
        swapBtn.setLayoutParams(spP);
        swapBtn.setImageDrawable(createVectorSwapIcon());
        swapBtn.setScaleType(ImageView.ScaleType.CENTER);
        swapBtn.setOnClickListener(withFeedback(v -> {
            int temp = fgColor;
            fgColor = bgColor;
            bgColor = temp;
            updateSwatchPreviews();
        }));
        swatchWrap.addView(swapBtn);

        tb.addView(swatchWrap);
        return tb;
    }

    private ImageView createToolIconBtn(BitmapDrawable icon, boolean selected, View.OnClickListener l) {
        ImageView iv = new ImageView(this);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(28), dp(28));
        p.setMargins(0, dp(2), 0, dp(2));
        iv.setLayoutParams(p);
        iv.setImageDrawable(icon);
        iv.setScaleType(ImageView.ScaleType.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? Color.parseColor("#38191E") : Color.TRANSPARENT);
        bg.setStroke(dp(1.5f), selected ? Color.parseColor("#FF1238") : Color.TRANSPARENT);
        bg.setCornerRadius(dp(3));
        iv.setBackground(bg);
        iv.setOnClickListener(l);
        return iv;
    }

    private void updateToolSelection(int selIdx) {
        for (int i = 0; i < toolButtons.size(); i++) {
            ImageView iv = toolButtons.get(i);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(i == selIdx ? Color.parseColor("#38191E") : Color.TRANSPARENT);
            bg.setStroke(dp(1.5f), i == selIdx ? Color.parseColor("#FF1238") : Color.TRANSPARENT);
            bg.setCornerRadius(dp(3));
            iv.setBackground(bg);
        }
        canvasView.invalidate();
    }

    private void showMarqueeOptionsDialog() {
        showAnchoredMenu(optionControlsBar, new String[]{"1. New Selection", "2. Add to Selection (+)", "3. Subtract Selection (-)"}, idx -> {
            selectionMode = idx;
            updateOptionControlsBar();
        });
    }

    private void showLassoOptionsDialog() {
        String[] opts = {
                "1. Freehand Lasso", "2. Add to Lasso", "3. Subtract from Lasso",
                "4. Polygonal Lasso", "5. Polygonal Subtract", "6. Pen Brush",
                "7. Pen Eraser"
        };
        showAnchoredMenu(optionControlsBar, opts, idx -> {
            lassoSubTool = idx;
            if (idx == 3 || idx == 4) {
                syncPolygonFromActiveLayer();
            } else {
                polyAnchors.clear();
            }
            updateOptionControlsBar();
            canvasView.invalidate();
        });
    }

    private void finishPolygonSelection() {
        if (polyAnchors.size() < 3) return;
        Path polyPath = buildPathFromAnchors(polyAnchors, true);

        if (activeSelectionPath == null || selectionMode == 0) {
            activeSelectionPath = polyPath;
        } else if (selectionMode == 1 || lassoSubTool == 1) {
            activeSelectionPath.op(polyPath, Path.Op.UNION);
        } else if (selectionMode == 2 || lassoSubTool == 2 || lassoSubTool == 4) {
            activeSelectionPath.op(polyPath, Path.Op.DIFFERENCE);
        }

        selectionBounds = new RectF();
        activeSelectionPath.computeBounds(selectionBounds, true);
        if (selectionBounds.isEmpty()) {
            activeSelectionPath = null;
            selectionBounds = null;
        }
        recordHistory();
        canvasView.invalidate();
        Toast.makeText(this, "Selection Finished", Toast.LENGTH_SHORT).show();
    }

    public void fillActiveSelectionWithColor(int color) {
        ProjectTabSession s = getCurrentSession();
        if (activeSelectionPath == null) {
            Toast.makeText(this, "No selection active to fill", Toast.LENGTH_SHORT).show();
            return;
        }
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        LayerItem al = s.layers.get(s.activeLayerIndex);
        if (al.bitmap == null || al.bitmap.isRecycled()) return;

        if (!al.bitmap.isMutable()) {
            al.bitmap = al.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        }

        Canvas c = new Canvas(al.bitmap);
        Matrix layerMatrix = new Matrix();
        layerMatrix.postScale(al.scaleX, al.scaleY);
        layerMatrix.postRotate(al.rotation, (al.bitmap.getWidth() * al.scaleX) / 2f, (al.bitmap.getHeight() * al.scaleY) / 2f);
        layerMatrix.postTranslate(al.x, al.y);

        Matrix inv = new Matrix();
        layerMatrix.invert(inv);

        Path localPath = new Path();
        activeSelectionPath.transform(inv, localPath);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        p.setColor(color);
        p.setStyle(Paint.Style.FILL);

        c.save();
        c.clipPath(localPath);
        c.drawPaint(p);
        c.restore();

        al.isBlank = false;
        al.isShape = false;
        al.isDirty = true;
        al.updateThumb();
        recordHistory();
        updateLayersDockUI();
        canvasView.invalidate();
        autoSaveCurrentProject();
        Toast.makeText(this, "Color Filled in Selection", Toast.LENGTH_SHORT).show();
    }

    public void cutActiveSelection() {
        ProjectTabSession s = getCurrentSession();
        if (activeSelectionPath == null) {
            Toast.makeText(this, "No selection active to cut", Toast.LENGTH_SHORT).show();
            return;
        }
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        LayerItem al = s.layers.get(s.activeLayerIndex);
        if (al.bitmap == null || al.bitmap.isRecycled()) return;

        if (!al.bitmap.isMutable()) {
            al.bitmap = al.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        }

        Matrix layerMatrix = new Matrix();
        layerMatrix.postScale(al.scaleX, al.scaleY);
        layerMatrix.postRotate(al.rotation, (al.bitmap.getWidth() * al.scaleX) / 2f, (al.bitmap.getHeight() * al.scaleY) / 2f);
        layerMatrix.postTranslate(al.x, al.y);

        Matrix inv = new Matrix();
        layerMatrix.invert(inv);
        Path localPath = new Path();
        activeSelectionPath.transform(inv, localPath);

        Bitmap cutBmp = Bitmap.createBitmap(al.bitmap.getWidth(), al.bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas cutCanvas = new Canvas(cutBmp);
        cutCanvas.clipPath(localPath);
        cutCanvas.drawBitmap(al.bitmap, 0, 0, null);
        clipboardLayer = new LayerItem("Cut Layer", cutBmp, al.x, al.y, false);
        clipboardLayer.isBlank = false;

        Canvas c = new Canvas(al.bitmap);
        Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        c.drawPath(localPath, clearPaint);

        al.isShape = false;
        al.isDirty = true;
        al.updateThumb();
        recordHistory();
        updateLayersDockUI();
        canvasView.invalidate();
        autoSaveCurrentProject();
        Toast.makeText(this, "Cut to Clipboard", Toast.LENGTH_SHORT).show();
    }

    private void showShapePickerPopup() {
        final String[] shapes = {
                "rectangle", "circle", "line", "triangle", "right-triangle",
                "star-5", "star-4", "heart", "diamond", "pentagon",
                "hexagon", "octagon", "arrow-right", "arrow-left", "cross",
                "cloud", "crescent-moon", "ring-donut", "lightning", "speech-bubble"
        };

        showAnchoredMenu(optionControlsBar, shapes, idx -> {
            activeShapeType = shapes[idx];
            updateOptionControlsBar();
            reRenderActiveShapeLayer();
        });
    }

    private void createShapeLayerFromBounds(float x, float y, float w, float h) {
        int rw = Math.max(10, Math.min(4096, (int) w));
        int rh = Math.max(10, Math.min(4096, (int) h));
        Bitmap shapeBmp = Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(shapeBmp);

        Path p = generateShapePath(activeShapeType, rw, rh);

        if ("line".equals(activeShapeType)) {
            Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
            strokeP.setColor(shapeStrokeColor);
            strokeP.setStyle(Paint.Style.STROKE);
            strokeP.setStrokeWidth(Math.max(2f, shapeStrokeWidth));
            strokeP.setStrokeCap(Paint.Cap.ROUND);
            c.drawPath(p, strokeP);
        } else {
            Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
            fillP.setColor(shapeFillColor);
            fillP.setStyle(Paint.Style.FILL);
            c.drawPath(p, fillP);

            if (shapeStrokeWidth > 0) {
                Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
                strokeP.setColor(shapeStrokeColor);
                strokeP.setStyle(Paint.Style.STROKE);
                strokeP.setStrokeWidth(shapeStrokeWidth);
                c.drawPath(p, strokeP);
            }
        }

        ProjectTabSession s = getCurrentSession();
        if (s == null) return;
        LayerItem shapeLayer = new LayerItem("Shape " + (s.layers.size() + 1), shapeBmp, x, y, false);
        shapeLayer.isShape = true;
        shapeLayer.isBlank = false;
        shapeLayer.shapeType = activeShapeType;
        shapeLayer.shapeFill = shapeFillColor;
        shapeLayer.shapeStroke = shapeStrokeColor;
        shapeLayer.shapeStrokeW = shapeStrokeWidth;
        shapeLayer.radiusTL = shapeRadiusTL;
        shapeLayer.radiusTR = shapeRadiusTR;
        shapeLayer.radiusBR = shapeRadiusBR;
        shapeLayer.radiusBL = shapeRadiusBL;

        synchronized (s.layers) {
            s.layers.add(shapeLayer);
            s.activeLayerIndex = s.layers.size() - 1;
        }
        recordHistory();
        updateLayersDockUI();
        canvasView.invalidate();
    }

    private Path generateShapePath(String type, int w, int h) {
        Path p = new Path();
        RectF r = new RectF(dp(2), dp(2), w - dp(2), h - dp(2));

        if ("circle".equals(type)) {
            p.addOval(r, Path.Direction.CW);
        } else if ("line".equals(type)) {
            p.moveTo(dp(2), h / 2f); p.lineTo(w - dp(2), h / 2f);
        } else if ("triangle".equals(type)) {
            p.moveTo(w / 2f, dp(2)); p.lineTo(w - dp(2), h - dp(2)); p.lineTo(dp(2), h - dp(2)); p.close();
        } else if ("right-triangle".equals(type)) {
            p.moveTo(dp(2), dp(2)); p.lineTo(w - dp(2), h - dp(2)); p.lineTo(dp(2), h - dp(2)); p.close();
        } else if ("star-5".equals(type)) {
            float midX = w / 2f, midY = h / 2f, outR = Math.min(w, h) / 2f - dp(2), inR = outR * 0.45f;
            for (int i = 0; i < 10; i++) {
                double a = Math.PI / 5 * i - Math.PI / 2;
                float cr = (i % 2 == 0) ? outR : inR;
                float px = (float) (midX + Math.cos(a) * cr);
                float py = (float) (midY + Math.sin(a) * cr);
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close();
        } else if ("star-4".equals(type)) {
            float midX = w / 2f, midY = h / 2f, outR = Math.min(w, h) / 2f - dp(2), inR = outR * 0.35f;
            for (int i = 0; i < 8; i++) {
                double a = Math.PI / 4 * i - Math.PI / 2;
                float cr = (i % 2 == 0) ? outR : inR;
                float px = (float) (midX + Math.cos(a) * cr);
                float py = (float) (midY + Math.sin(a) * cr);
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close();
        } else if ("heart".equals(type)) {
            p.moveTo(w / 2f, h * 0.85f);
            p.cubicTo(dp(2), h * 0.5f, dp(2), dp(4), w / 2f, h * 0.35f);
            p.cubicTo(w - dp(2), dp(4), w - dp(2), h * 0.5f, w / 2f, h * 0.85f);
        } else if ("diamond".equals(type)) {
            p.moveTo(w / 2f, dp(2)); p.lineTo(w - dp(2), h / 2f); p.lineTo(w / 2f, h - dp(2)); p.lineTo(dp(2), h / 2f); p.close();
        } else if ("pentagon".equals(type)) {
            float midX = w / 2f, midY = h / 2f, rad = Math.min(w, h) / 2f - dp(2);
            for (int i = 0; i < 5; i++) {
                double a = 2 * Math.PI / 5 * i - Math.PI / 2;
                float px = (float) (midX + Math.cos(a) * rad);
                float py = (float) (midY + Math.sin(a) * rad);
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close();
        } else if ("hexagon".equals(type)) {
            float midX = w / 2f, midY = h / 2f, rad = Math.min(w, h) / 2f - dp(2);
            for (int i = 0; i < 6; i++) {
                double a = 2 * Math.PI / 6 * i;
                float px = (float) (midX + Math.cos(a) * rad);
                float py = (float) (midY + Math.sin(a) * rad);
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close();
        } else if ("octagon".equals(type)) {
            float midX = w / 2f, midY = h / 2f, rad = Math.min(w, h) / 2f - dp(2);
            for (int i = 0; i < 8; i++) {
                double a = 2 * Math.PI / 8 * i + Math.PI / 8;
                float px = (float) (midX + Math.cos(a) * rad);
                float py = (float) (midY + Math.sin(a) * rad);
                if (i == 0) p.moveTo(px, py); else p.lineTo(px, py);
            }
            p.close();
        } else if ("arrow-right".equals(type)) {
            p.moveTo(dp(2), h * 0.35f); p.lineTo(w * 0.6f, h * 0.35f); p.lineTo(w * 0.6f, dp(2));
            p.lineTo(w - dp(2), h / 2f); p.lineTo(w * 0.6f, h - dp(2)); p.lineTo(w * 0.6f, h * 0.65f); p.lineTo(dp(2), h * 0.65f); p.close();
        } else if ("arrow-left".equals(type)) {
            p.moveTo(w - dp(2), h * 0.35f); p.lineTo(w * 0.4f, h * 0.35f); p.lineTo(w * 0.4f, dp(2));
            p.lineTo(dp(2), h / 2f); p.lineTo(w * 0.4f, h - dp(2)); p.lineTo(w * 0.4f, h * 0.65f); p.lineTo(w - dp(2), h * 0.65f); p.close();
        } else if ("cross".equals(type)) {
            p.moveTo(w * 0.35f, dp(2)); p.lineTo(w * 0.65f, dp(2)); p.lineTo(w * 0.65f, h * 0.35f);
            p.lineTo(w - dp(2), h * 0.35f); p.lineTo(w - dp(2), h * 0.65f); p.lineTo(w * 0.65f, h * 0.65f);
            p.lineTo(w * 0.65f, h - dp(2)); p.lineTo(w * 0.35f, h - dp(2)); p.lineTo(w * 0.35f, h * 0.65f);
            p.lineTo(dp(2), h * 0.65f); p.lineTo(dp(2), h * 0.35f); p.lineTo(w * 0.35f, h * 0.35f); p.close();
        } else if ("cloud".equals(type)) {
            p.moveTo(w * 0.2f, h * 0.7f);
            p.quadTo(dp(2), h * 0.5f, w * 0.3f, h * 0.35f);
            p.quadTo(w * 0.5f, dp(2), w * 0.7f, h * 0.35f);
            p.quadTo(w - dp(2), h * 0.4f, w * 0.85f, h * 0.7f);
            p.close();
        } else if ("crescent-moon".equals(type)) {
            p.addOval(r, Path.Direction.CW);
            Path cut = new Path();
            cut.addOval(new RectF(w * 0.25f, dp(2), w * 1.15f, h - dp(2)), Path.Direction.CW);
            p.op(cut, Path.Op.DIFFERENCE);
        } else if ("ring-donut".equals(type)) {
            p.addOval(r, Path.Direction.CW);
            Path inner = new Path();
            inner.addOval(new RectF(w * 0.25f, h * 0.25f, w * 0.75f, h * 0.75f), Path.Direction.CW);
            p.op(inner, Path.Op.DIFFERENCE);
        } else if ("lightning".equals(type)) {
            p.moveTo(w * 0.55f, dp(2)); p.lineTo(dp(2), h * 0.55f); p.lineTo(w * 0.45f, h * 0.55f);
            p.lineTo(w * 0.35f, h - dp(2)); p.lineTo(w - dp(2), h * 0.45f); p.lineTo(w * 0.55f, h * 0.45f); p.close();
        } else if ("speech-bubble".equals(type)) {
            p.addRoundRect(new RectF(dp(2), dp(2), w - dp(2), h * 0.75f), dp(12), dp(12), Path.Direction.CW);
            Path tail = new Path();
            tail.moveTo(w * 0.2f, h * 0.75f); tail.lineTo(w * 0.1f, h - dp(2)); tail.lineTo(w * 0.4f, h * 0.75f); tail.close();
            p.op(tail, Path.Op.UNION);
        } else {
            float[] radii = new float[]{
                    shapeRadiusTL, shapeRadiusTL,
                    shapeRadiusTR, shapeRadiusTR,
                    shapeRadiusBR, shapeRadiusBR,
                    shapeRadiusBL, shapeRadiusBL
            };
            p.addRoundRect(r, radii, Path.Direction.CW);
        }
        return p;
    }

    private void startOnCanvasGradient() {
        ProjectTabSession s = getCurrentSession();
        if (s == null) return;
        
        float abOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
        s.hasGradientLine = true;
        s.gradStartX = abOffset + s.canvasWidth * 0.2f;
        s.gradStartY = s.canvasHeight * 0.8f;
        s.gradEndX = abOffset + s.canvasWidth * 0.8f;
        s.gradEndY = s.canvasHeight * 0.2f;

        s.gradStops = new ArrayList<>();
        s.gradStops.add(new GradStop(0.0f, Color.parseColor("#FF1238")));
        s.gradStops.add(new GradStop(1.0f, Color.BLACK));
        s.activeGradStop = s.gradStops.get(0);

        fgColor = s.activeGradStop.color;
        updateSwatchPreviews();

        applyOnCanvasGradientToActiveLayer(true);
        canvasView.invalidate();
    }

    private void showGradientPresetsDialog() {
        String[] presets = {
                "Red & Black (Default)",
                "Foreground to Background",
                "Black & White",
                "Sunset (Orange / Pink)",
                "Neon Cyan & Pink"
        };
        showAnchoredMenu(optionControlsBar, presets, idx -> {
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            s.gradStops.clear();
            if (idx == 0) {
                s.gradStops.add(new GradStop(0.0f, Color.parseColor("#FF1238")));
                s.gradStops.add(new GradStop(1.0f, Color.BLACK));
            } else if (idx == 1) {
                s.gradStops.add(new GradStop(0.0f, fgColor));
                s.gradStops.add(new GradStop(1.0f, bgColor));
            } else if (idx == 2) {
                s.gradStops.add(new GradStop(0.0f, Color.BLACK));
                s.gradStops.add(new GradStop(1.0f, Color.WHITE));
            } else if (idx == 3) {
                s.gradStops.add(new GradStop(0.0f, Color.parseColor("#FF512F")));
                s.gradStops.add(new GradStop(1.0f, Color.parseColor("#DD2476")));
            } else if (idx == 4) {
                s.gradStops.add(new GradStop(0.0f, Color.parseColor("#FF007F")));
                s.gradStops.add(new GradStop(1.0f, Color.parseColor("#00E5FF")));
            }
            if (!s.gradStops.isEmpty()) {
                s.activeGradStop = s.gradStops.get(0);
                fgColor = s.activeGradStop.color;
                updateSwatchPreviews();
            }
            applyOnCanvasGradientToActiveLayer(true);
            canvasView.invalidate();
        });
    }

    private void applyOnCanvasGradientToActiveLayer() {
        applyOnCanvasGradientToActiveLayer(true);
    }

    // updateThumbnail = false দিলে কোনো ল্যাগ ছাড়াই ড্র্যাগ করার সময় লাইভ রেন্ডার হবে
    private void applyOnCanvasGradientToActiveLayer(boolean updateThumbnail) {
        ProjectTabSession s = getCurrentSession();
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;
        LayerItem al = s.layers.get(s.activeLayerIndex);

        if (al.bitmap == null || al.bitmap.isRecycled()) {
            al.bitmap = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
            al.x = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
            al.y = 0; al.scaleX = 1f; al.scaleY = 1f;
        } else if (!al.bitmap.isMutable()) {
            al.bitmap = al.bitmap.copy(Bitmap.Config.ARGB_8888, true);
        }

        Collections.sort(s.gradStops, (a, b) -> Float.compare(a.pos, b.pos));

        int stopCount = Math.max(2, s.gradStops.size());
        int[] colors = new int[stopCount];
        float[] positions = new float[stopCount];
        for (int i = 0; i < stopCount; i++) {
            colors[i] = s.gradStops.get(i).color;
            positions[i] = Math.max(0.0f, Math.min(1.0f, s.gradStops.get(i).pos));
        }

        float gx1 = (s.gradStartX - al.x) / al.scaleX;
        float gy1 = (s.gradStartY - al.y) / al.scaleY;
        float gx2 = (s.gradEndX - al.x) / al.scaleX;
        float gy2 = (s.gradEndY - al.y) / al.scaleY;

        Shader gradientShader;
        String mode = s.gradientType != null ? s.gradientType : "Linear";

        if ("Radial".equalsIgnoreCase(mode)) {
            float radius = (float) Math.hypot(gx2 - gx1, gy2 - gy1);
            if (radius <= 0) radius = 10f;
            gradientShader = new RadialGradient(gx1, gy1, radius, colors, positions, Shader.TileMode.CLAMP);
        } else if ("Angle".equalsIgnoreCase(mode)) {
            gradientShader = new SweepGradient(gx1, gy1, colors, positions);
            Matrix sm = new Matrix();
            float angle = (float) Math.toDegrees(Math.atan2(gy2 - gy1, gx2 - gx1));
            sm.postRotate(angle, gx1, gy1);
            gradientShader.setLocalMatrix(sm);
        } else if ("Reflected".equalsIgnoreCase(mode)) {
            int reflCount = (stopCount - 1) * 2 + 1;
            int[] reflColors = new int[reflCount];
            float[] reflPos = new float[reflCount];

            for (int i = 0; i < stopCount; i++) {
                reflColors[stopCount - 1 + i] = colors[i];
                reflColors[stopCount - 1 - i] = colors[i];
                reflPos[stopCount - 1 + i] = 0.5f + positions[i] * 0.5f;
                reflPos[stopCount - 1 - i] = 0.5f - positions[i] * 0.5f;
            }
            float dx = gx2 - gx1;
            float dy = gy2 - gy1;
            gradientShader = new LinearGradient(gx1 - dx, gy1 - dy, gx2, gy2, reflColors, reflPos, Shader.TileMode.CLAMP);
        } else if ("Diamond".equalsIgnoreCase(mode)) {
            float dist = (float) Math.hypot(gx2 - gx1, gy2 - gy1);
            if (dist <= 0) dist = 10f;
            int dim = (int) Math.max(16, dist * 2);
            Bitmap diamBmp = Bitmap.createBitmap(dim, dim, Bitmap.Config.ARGB_8888);
            Canvas dc = new Canvas(diamBmp);
            float cx = dim / 2f, cy = dim / 2f;

            for (int step = stopCount - 1; step >= 0; step--) {
                Paint dp = new Paint(Paint.ANTI_ALIAS_FLAG);
                dp.setColor(colors[step]);
                dp.setStyle(Paint.Style.FILL);
                float curR = positions[step] * (dim / 2f);
                Path dPath = new Path();
                dPath.moveTo(cx, cy - curR);
                dPath.lineTo(cx + curR, cy);
                dPath.lineTo(cx, cy + curR);
                dPath.lineTo(cx - curR, cy);
                dPath.close();
                dc.drawPath(dPath, dp);
            }
            gradientShader = new BitmapShader(diamBmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            Matrix dm = new Matrix();
            float rotAngle = (float) Math.toDegrees(Math.atan2(gy2 - gy1, gx2 - gx1));
            dm.postTranslate(-cx, -cy);
            dm.postRotate(rotAngle);
            dm.postTranslate(gx1, gy1);
            gradientShader.setLocalMatrix(dm);
        } else {
            gradientShader = new LinearGradient(gx1, gy1, gx2, gy2, colors, positions, Shader.TileMode.CLAMP);
        }

        Bitmap gBmp = al.bitmap;
        Canvas c = new Canvas(gBmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        p.setShader(gradientShader);

        if (activeSelectionPath != null) {
            c.save();
            Matrix layerMatrix = new Matrix();
            layerMatrix.postScale(al.scaleX, al.scaleY);
            layerMatrix.postRotate(al.rotation, (al.bitmap.getWidth() * al.scaleX) / 2f, (al.bitmap.getHeight() * al.scaleY) / 2f);
            layerMatrix.postTranslate(al.x, al.y);
            Matrix inv = new Matrix();
            layerMatrix.invert(inv);
            Path localPath = new Path();
            activeSelectionPath.transform(inv, localPath);
            c.clipPath(localPath);
            c.drawRect(0, 0, gBmp.getWidth(), gBmp.getHeight(), p);
            c.restore();
            al.isShape = false;
        } else if (al.isShape) {
            Path sp = generateShapePath(al.shapeType, gBmp.getWidth(), gBmp.getHeight());
            c.drawPath(sp, p);
        } else {
            c.drawRect(0, 0, gBmp.getWidth(), gBmp.getHeight(), p);
        }

        al.isBlank = false;
        al.isDirty = true;
        if (updateThumbnail) {
            al.updateThumb();
        }
    }

    private void updateSwatchPreviews() {
        if (fgSwatchView != null) {
            GradientDrawable fgDr = new GradientDrawable();
            fgDr.setColor(fgColor);
            fgDr.setStroke(dp(1.2f), Color.WHITE);
            fgSwatchView.setBackground(fgDr);
        }
        if (bgSwatchView != null) {
            GradientDrawable bgDr = new GradientDrawable();
            bgDr.setColor(bgColor);
            bgDr.setStroke(dp(1.2f), Color.parseColor("#333333"));
            bgSwatchView.setBackground(bgDr);
        }
    }

    interface OnMenuSelectedListener { void onSelected(int index); }

    private void showAnchoredMenu(View anchor, String[] items, final OnMenuSelectedListener listener) {
        final PopupWindow popup = new PopupWindow(this);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(6), dp(8), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        l.setBackground(bg);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(true);
        sv.setScrollbarFadingEnabled(false);

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            TextView itemTv = new TextView(this);
            itemTv.setText(items[i]);
            itemTv.setTextColor(Color.WHITE);
            itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            itemTv.setPadding(dp(12), dp(8), dp(12), dp(8));
            itemTv.setOnClickListener(withFeedback(v -> {
                popup.dismiss();
                if (listener != null) listener.onSelected(idx);
            }));
            inner.addView(itemTv);
        }
        sv.addView(inner);
        l.addView(sv);

        popup.setContentView(l);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);

        int screenH = getResources().getDisplayMetrics().heightPixels;
        int maxH = (int) (screenH * 0.65f);

        if (items.length > 8) {
            sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, maxH));
            popup.setHeight(maxH);
        } else {
            sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    private void showInAppMultiImagePicker() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(intent, "Select Images"), REQ_IMPORT_MULTI_IMAGE);
    }

    private void showFileDropdownMenu(View anchor) {
        String[] items = {
                "Project Add", 
                "Open File",
                "Open Image",
                "Save PNG", 
                "Save JPG", 
                "Save PDF", 
                "Save PSD", 
                "Save Project jr",
                "Back (Exit to Home)"
        };
        showAnchoredMenu(anchor, items, idx -> {
            if (idx == 0) {
                addNewBlankLayer();
            } else if (idx == 1) {
                openHomeToPickProject(); 
            } else if (idx == 2) {
                openProjectFileChooser();
            } else if (idx == 3) {
                exportMedia("png");
            } else if (idx == 4) {
                exportMedia("jpg");
            } else if (idx == 5) {
                exportPdf();
            } else if (idx == 6) {
                exportPsd();
            } else if (idx == 7) {
                exportJrProject();
            } else if (idx == 8) {
                exitWithoutLoading();
            }
        });
    }

    public void openHomeToPickProject() {
        Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (intent == null) {
            try {
                intent = new Intent(this, Class.forName(getPackageName() + ".MainActivity"));
            } catch (Exception ignored) {}
        }
        if (intent != null) {
            intent.putExtra("is_pick_mode", true);
            startActivityForResult(intent, REQ_PICK_PROJECT_TO_TAB);
        } else {
            Toast.makeText(this, "Home Studio opening...", Toast.LENGTH_SHORT).show();
        }
    }

    private void openProjectFileChooser() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(intent, "Open PSD, JR, PDF or Image"), REQ_OPEN_PROJECT_FILE);
    }

    private void showEditDropdownMenu(View anchor) {
        String[] items = {
                "Undo", "Redo", "Cut", "Copy Layer", "Paste Layer",
                "Copy Artboard", "Paste Artboard", "Flip Horizontal", "Flip Vertical",
                "Deselect"
        };
        showAnchoredMenu(anchor, items, idx -> {
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            if (idx == 0) performUndo();
            else if (idx == 1) performRedo();
            else if (idx == 2) cutActiveSelection();
            else if (idx == 3) {
                if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                    clipboardLayer = s.layers.get(s.activeLayerIndex).copy(true);
                    Toast.makeText(this, "Copied Layer to Clipboard", Toast.LENGTH_SHORT).show();
                }
            } else if (idx == 4) {
                if (clipboardLayer != null) {
                    LayerItem cl = clipboardLayer.copy(true);
                    cl.x += dp(20); cl.y += dp(20); cl.isBlank = false;
                    synchronized (s.layers) {
                        s.layers.add(cl);
                        s.activeLayerIndex = s.layers.size() - 1;
                    }
                    syncPolygonFromActiveLayer();
                    recordHistory();
                    updateLayersDockUI();
                    canvasView.invalidate();
                    Toast.makeText(this, "Layer Pasted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show();
                }
            } else if (idx == 5) {
                clipboardArtboardLayers.clear();
                synchronized (s.layers) {
                    for (LayerItem l : s.layers) clipboardArtboardLayers.add(l.copy(true));
                }
                clipboardArtboardWidth = s.canvasWidth;
                clipboardArtboardHeight = s.canvasHeight;
                clipboardArtboardBgColor = s.artboardBgColor;
                Toast.makeText(this, "Artboard Copied", Toast.LENGTH_SHORT).show();
            } else if (idx == 6) {
                if (clipboardArtboardLayers.isEmpty()) {
                    Toast.makeText(this, "No Artboard in Clipboard", Toast.LENGTH_SHORT).show();
                    return;
                }
                s.artboardCount++;
                float offset = (s.artboardCount - 1) * (s.canvasWidth + dp(ARTBOARD_GAP_DP));

                synchronized (s.layers) {
                    for (LayerItem l : clipboardArtboardLayers) {
                        LayerItem copyL = l.copy(true);
                        copyL.x += offset;
                        s.layers.add(copyL);
                    }
                    s.activeLayerIndex = s.layers.size() - 1;
                }
                recordHistory();
                updateLayersDockUI();
                canvasView.autoCenterArtboard(canvasView.getWidth(), canvasView.getHeight());
                Toast.makeText(this, "Pasted as Artboard " + s.artboardCount, Toast.LENGTH_SHORT).show();
            } else if (idx == 7) {
                flipActiveLayer(true);
            } else if (idx == 8) {
                flipActiveLayer(false);
            } else if (idx == 9) {
                canvasView.clearLassoSelection();
            }
        });
    }

    private void flipActiveLayer(boolean horizontal) {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem al = s.layers.get(s.activeLayerIndex);
            if (al.bitmap != null && !al.bitmap.isRecycled()) {
                Matrix m = new Matrix();
                if (horizontal) m.preScale(-1, 1);
                else m.preScale(1, -1);

                Bitmap flipped = Bitmap.createBitmap(al.bitmap, 0, 0, al.bitmap.getWidth(), al.bitmap.getHeight(), m, true);
                al.bitmap = flipped;
                al.isDirty = true;
                al.updateThumb();
                recordHistory();
                canvasView.invalidate();
                autoSaveCurrentProject();
                Toast.makeText(this, horizontal ? "Flipped Horizontally" : "Flipped Vertically", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void showSelectDropdownMenu(View anchor) {
        String[] items = {"Select All", "Deselect", "Inverse", "Fill Selection (Color)", "Cut Selection"};
        showAnchoredMenu(anchor, items, idx -> {
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            if (idx == 0) {
                activeSelectionPath = new Path();
                float totalW = s.artboardCount * s.canvasWidth + (s.artboardCount - 1) * dp(ARTBOARD_GAP_DP);
                activeSelectionPath.addRect(0, 0, totalW, s.canvasHeight, Path.Direction.CW);
                selectionBounds = new RectF(0, 0, totalW, s.canvasHeight);
                recordHistory();
                canvasView.invalidate();
                Toast.makeText(this, "Selected All", Toast.LENGTH_SHORT).show();
            } else if (idx == 1) {
                canvasView.clearLassoSelection();
                Toast.makeText(this, "Deselected", Toast.LENGTH_SHORT).show();
            } else if (idx == 2) {
                float totalW = s.artboardCount * s.canvasWidth + (s.artboardCount - 1) * dp(ARTBOARD_GAP_DP);
                if (activeSelectionPath == null) {
                    activeSelectionPath = new Path();
                    activeSelectionPath.addRect(0, 0, totalW, s.canvasHeight, Path.Direction.CW);
                } else {
                    Path fullCanvasPath = new Path();
                    fullCanvasPath.addRect(0, 0, totalW, s.canvasHeight, Path.Direction.CW);
                    Path inverted = new Path();
                    inverted.op(fullCanvasPath, activeSelectionPath, Path.Op.DIFFERENCE);
                    activeSelectionPath = inverted;
                }
                selectionBounds = new RectF();
                activeSelectionPath.computeBounds(selectionBounds, true);
                recordHistory();
                canvasView.invalidate();
                Toast.makeText(this, "Selection Inverted", Toast.LENGTH_SHORT).show();
            } else if (idx == 3) {
                fillActiveSelectionWithColor(fgColor);
            } else if (idx == 4) {
                cutActiveSelection();
            }
        });
    }

    private void showAlignMenu(View anchor) {
        String[] items = {"Align Center", "Align Center Horizontal", "Align Center Vertical", "Align Left", "Align Top"};
        showAnchoredMenu(anchor, items, idx -> {
            ProjectTabSession s = getCurrentSession();
            if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                LayerItem li = s.layers.get(s.activeLayerIndex);
                float abOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
                if (idx == 0) alignActiveLayerCenter();
                else if (idx == 1) li.x = abOffset + (s.canvasWidth - (li.bitmap.getWidth() * li.scaleX)) / 2f;
                else if (idx == 2) li.y = (s.canvasHeight - (li.bitmap.getHeight() * li.scaleY)) / 2f;
                else if (idx == 3) li.x = abOffset;
                else if (idx == 4) li.y = 0;
                recordHistory();
                canvasView.invalidate();
            }
        });
    }

    private void showCleanBlendModePopup(final TextView anchor) {
        String[] modes = {
                "Normal", "Dissolve", "Darken", "Multiply", "Color Burn", "Linear Burn",
                "Lighten", "Screen", "Color Dodge", "Linear Dodge", "Add",
                "Overlay", "Soft Light", "Hard Light", "Vivid Light", "Linear Light",
                "Pin Light", "Difference", "Exclusion", "Hue", "Saturation"
        };

        showAnchoredMenu(anchor, modes, idx -> {
            String m = modes[idx];
            anchor.setText(m + " ▾");
            ProjectTabSession s = getCurrentSession();
            if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                s.layers.get(s.activeLayerIndex).blendMode = m;
                recordHistory();
                canvasView.invalidate();
            }
        });
    }

    private LinearLayout createRightLayersDock() {
        LinearLayout dock = new LinearLayout(this);
        dock.setLayoutParams(new LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.MATCH_PARENT));
        dock.setBackgroundColor(Color.parseColor("#181818"));
        dock.setOrientation(LinearLayout.VERTICAL);
        dock.setPadding(dp(6), dp(4), dp(6), dp(4));

        LinearLayout topHeader = new LinearLayout(this);
        topHeader.setOrientation(LinearLayout.HORIZONTAL);
        topHeader.setGravity(Gravity.CENTER_VERTICAL);
        topHeader.setPadding(dp(4), dp(4), dp(4), dp(4));

        TextView layersTitle = new TextView(this);
        layersTitle.setText("LAYERS");
        layersTitle.setTextColor(Color.parseColor("#CCCCCC"));
        layersTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        layersTitle.setTypeface(null, Typeface.BOLD);
        layersTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topHeader.addView(layersTitle);

        ImageView folderBtn = new ImageView(this);
        folderBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
        folderBtn.setImageDrawable(createVectorFolderIcon());
        folderBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        topHeader.addView(folderBtn);
        dock.addView(topHeader);

        LinearLayout blendRow = new LinearLayout(this);
        blendRow.setOrientation(LinearLayout.HORIZONTAL);
        blendRow.setGravity(Gravity.CENTER_VERTICAL);
        blendRow.setPadding(dp(4), dp(2), dp(4), dp(4));

        final TextView blendLabelBtn = new TextView(this);
        blendLabelBtn.setText("Normal ▾");
        blendLabelBtn.setTextColor(Color.WHITE);
        blendLabelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        blendLabelBtn.setPadding(dp(6), dp(3), dp(6), dp(3));
        GradientDrawable blBg = new GradientDrawable();
        blBg.setColor(Color.parseColor("#121212"));
        blBg.setStroke(dp(1), Color.parseColor("#333333"));
        blBg.setCornerRadius(dp(2));
        blendLabelBtn.setBackground(blBg);
        blendLabelBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(26), 1.2f));
        blendLabelBtn.setOnClickListener(withFeedback(v -> showCleanBlendModePopup(blendLabelBtn)));
        blendRow.addView(blendLabelBtn);

        final TextView opTv = new TextView(this);
        opTv.setText(" Op: 100%");
        opTv.setTextColor(Color.WHITE);
        opTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        blendRow.addView(opTv);
        dock.addView(blendRow);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        scroll.setVerticalScrollBarEnabled(true);

        layersListContainer = new LinearLayout(this);
        layersListContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layersListContainer);
        dock.addView(scroll);

        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bottomBar.setPadding(0, dp(4), dp(4), dp(4));

        ImageView addLayerBtn = new ImageView(this);
        addLayerBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(20), dp(20)));
        addLayerBtn.setImageDrawable(createVectorPlusIcon());
        addLayerBtn.setOnClickListener(withFeedback(v -> addNewBlankLayer()));
        bottomBar.addView(addLayerBtn);

        ImageView dupLayerBtn = new ImageView(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(20), dp(20));
        dlp.setMargins(dp(10), 0, dp(10), 0);
        dupLayerBtn.setLayoutParams(dlp);
        dupLayerBtn.setImageDrawable(createVectorDuplicateIcon());
        dupLayerBtn.setOnClickListener(withFeedback(v -> duplicateActiveLayer()));
        bottomBar.addView(dupLayerBtn);

        ImageView trashBtn = new ImageView(this);
        trashBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(20), dp(20)));
        trashBtn.setImageDrawable(createVectorTrashIcon());
        trashBtn.setOnClickListener(withFeedback(v -> deleteActiveLayer()));
        bottomBar.addView(trashBtn);

        dock.addView(bottomBar);
        updateLayersDockUI();
        return dock;
    }

    private void updateLayersDockUI() {
        if (layersListContainer == null) return;
        layersListContainer.removeAllViews();
        final ProjectTabSession s = getCurrentSession();
        if (s == null) return;

        for (int i = s.layers.size() - 1; i >= 0; i--) {
            final int index = i;
            final LayerItem layer = s.layers.get(i);
            final boolean isSelected = (index == s.activeLayerIndex);

            final LinearLayout row = new LinearLayout(this);
            row.setTag(index);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6), dp(4), dp(6), dp(4));

            GradientDrawable rowBg = new GradientDrawable();
            if (isSelected) {
                rowBg.setColor(Color.parseColor("#261719"));
                rowBg.setStroke(dp(1), Color.parseColor("#7D1B28"));
            } else {
                rowBg.setColor(Color.parseColor("#1C1C1C"));
                rowBg.setStroke(dp(1), Color.parseColor("#222222"));
            }
            rowBg.setCornerRadius(dp(3));
            row.setBackground(rowBg);

            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34));
            rp.setMargins(0, 0, 0, dp(2));
            row.setLayoutParams(rp);

            ImageView eyeBtn = new ImageView(this);
            eyeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(18), dp(18)));
            eyeBtn.setImageDrawable(layer.isVisible ? cachedEyeOpenIcon : cachedEyeClosedIcon);
            eyeBtn.setScaleType(ImageView.ScaleType.CENTER);
            eyeBtn.setOnClickListener(withFeedback(v -> {
                layer.isVisible = !layer.isVisible;
                eyeBtn.setImageDrawable(layer.isVisible ? cachedEyeOpenIcon : cachedEyeClosedIcon);
                recordHistory();
                canvasView.invalidate();
            }));
            row.addView(eyeBtn);

            FrameLayout thumbFrame = new FrameLayout(this);
            LinearLayout.LayoutParams tfp = new LinearLayout.LayoutParams(dp(22), dp(22));
            tfp.setMargins(dp(4), 0, dp(6), 0);
            thumbFrame.setLayoutParams(tfp);

            GradientDrawable thumbFrameBg = new GradientDrawable();
            thumbFrameBg.setColor(Color.parseColor("#0C0C0C"));
            thumbFrameBg.setStroke(dp(1), Color.parseColor("#2C2C2C"));
            thumbFrameBg.setCornerRadius(dp(2));
            thumbFrame.setBackground(thumbFrameBg);

            ImageView thumb = new ImageView(this);
            thumb.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (layer.thumbBitmap != null && !layer.thumbBitmap.isRecycled()) {
                thumb.setImageBitmap(layer.thumbBitmap);
            } else {
                layer.updateThumb();
                thumb.setImageBitmap(layer.thumbBitmap);
            }
            thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
            thumbFrame.addView(thumb);
            row.addView(thumbFrame);

            TextView nameTv = new TextView(this);
            String prefix = layer.isClippingMask ? "↳ " : "";
            nameTv.setText(prefix + layer.name);
            nameTv.setTextColor(Color.parseColor(isSelected ? "#FFFFFF" : "#CCCCCC"));
            nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            nameTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(nameTv);

            ImageView dragHandle = new ImageView(this);
            LinearLayout.LayoutParams dhp = new LinearLayout.LayoutParams(dp(22), dp(26));
            dhp.setMargins(dp(2), 0, dp(4), 0);
            dragHandle.setLayoutParams(dhp);
            dragHandle.setImageDrawable(cachedDragDotsIcon);
            dragHandle.setScaleType(ImageView.ScaleType.CENTER);

            dragHandle.setOnTouchListener(new View.OnTouchListener() {
                float startY = 0f;
                boolean isDragging = false;
                int targetIndex = index;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startY = event.getRawY();
                            isDragging = true;
                            targetIndex = index;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                row.setElevation(dp(8f));
                            }
                            android.view.ViewParent parent = v.getParent();
                            while (parent != null) {
                                parent.requestDisallowInterceptTouchEvent(true);
                                parent = parent.getParent();
                            }
                            row.setAlpha(0.65f);
                            triggerClickFeedback(row);
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            if (isDragging) {
                                android.view.ViewParent p = v.getParent();
                                while (p != null) {
                                    p.requestDisallowInterceptTouchEvent(true);
                                    p = p.getParent();
                                }
                                float dY = event.getRawY() - startY;
                                float rowH = dp(36f);
                                int steps = Math.round(-dY / rowH);
                                targetIndex = Math.max(0, Math.min(s.layers.size() - 1, index + steps));

                                for (int c = 0; c < layersListContainer.getChildCount(); c++) {
                                    View child = layersListContainer.getChildAt(c);
                                    Object tag = child.getTag();
                                    if (tag instanceof Integer) {
                                        int layerIdx = (Integer) tag;
                                        if (layerIdx == index) {
                                            child.setTranslationY(dY);
                                        } else if (index < targetIndex) {
                                            if (layerIdx > index && layerIdx <= targetIndex) {
                                                child.setTranslationY(rowH);
                                            } else {
                                                child.setTranslationY(0f);
                                            }
                                        } else if (index > targetIndex) {
                                            if (layerIdx < index && layerIdx >= targetIndex) {
                                                child.setTranslationY(-rowH);
                                            } else {
                                                child.setTranslationY(0f);
                                            }
                                        } else {
                                            child.setTranslationY(0f);
                                        }
                                    }
                                }
                            }
                            return true;

                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            if (isDragging) {
                                isDragging = false;
                                row.setAlpha(1.0f);
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                    row.setElevation(0f);
                                }
                                android.view.ViewParent p = v.getParent();
                                while (p != null) {
                                    p.requestDisallowInterceptTouchEvent(false);
                                    p = p.getParent();
                                }
                                for (int c = 0; c < layersListContainer.getChildCount(); c++) {
                                    layersListContainer.getChildAt(c).setTranslationY(0f);
                                }
                                if (targetIndex != index) {
                                    EditorActivity.this.moveLayerToPosition(index, targetIndex);
                                } else {
                                    EditorActivity.this.autoSaveCurrentProject();
                                }
                            }
                            return true;
                    }
                    return false;
                }
            });
            row.addView(dragHandle);

            ImageView lockBtn = new ImageView(this);
            lockBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
            lockBtn.setImageDrawable(layer.isLocked ? cachedLockClosedIcon : cachedLockOpenIcon);
            lockBtn.setScaleType(ImageView.ScaleType.CENTER);
            lockBtn.setOnClickListener(withFeedback(v -> {
                layer.isLocked = !layer.isLocked;
                lockBtn.setImageDrawable(layer.isLocked ? cachedLockClosedIcon : cachedLockOpenIcon);
                recordHistory();
                canvasView.invalidate();
            }));
            row.addView(lockBtn);

            row.setOnClickListener(withFeedback(v -> {
                s.activeLayerIndex = index;
                syncPolygonFromActiveLayer();
                updateLayersDockUI();
                updateOptionControlsBar();
                canvasView.invalidate();
            }));

            layersListContainer.addView(row);
        }
    }

    private void alignActiveLayerCenter() {
        ProjectTabSession s = getCurrentSession();
        if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
            LayerItem l = s.layers.get(s.activeLayerIndex);
            float abOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
            l.x = abOffset + (s.canvasWidth - (l.bitmap.getWidth() * l.scaleX)) / 2f;
            l.y = (s.canvasHeight - (l.bitmap.getHeight() * l.scaleY)) / 2f;
            canvasView.invalidate();
            autoSaveCurrentProject();
            Toast.makeText(this, "Centered", Toast.LENGTH_SHORT).show();
        }
    }

    private void exportMedia(String format) {
        new Thread(() -> {
            try {
                ProjectTabSession s = getCurrentSession();
                if (s == null) return;
                boolean isPng = format.equalsIgnoreCase("png");
                Bitmap master = renderCompositeCanvasForArtboard(s.currentActiveArtboard, isPng);
                int serial = getNextSerialIndex();
                String fileName = "ejitor_jr(" + serial + ")." + format.toLowerCase();
                String mime = isPng ? "image/png" : "image/jpeg";

                OutputStream os = getDownloadsFileOutputStream(fileName, mime);
                if (os != null) {
                    if (isPng) master.compress(Bitmap.CompressFormat.PNG, 100, os);
                    else master.compress(Bitmap.CompressFormat.JPEG, 95, os);
                    os.flush();
                    os.close();
                    runOnUiThread(() -> Toast.makeText(this, "Saved to Downloads/EJITOR: " + fileName, Toast.LENGTH_LONG).show());
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Failed to export image", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Export Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void exportPdf() {
        new Thread(() -> {
            try {
                ProjectTabSession s = getCurrentSession();
                if (s == null) return;
                PdfDocument doc = new PdfDocument();
                for (int i = 0; i < s.artboardCount; i++) {
                    PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(s.canvasWidth, s.canvasHeight, i + 1).create();
                    PdfDocument.Page page = doc.startPage(pageInfo);
                    Canvas c = page.getCanvas();
                    Bitmap abBitmap = renderCompositeCanvasForArtboard(i, false);
                    c.drawBitmap(abBitmap, 0, 0, null);
                    doc.finishPage(page);
                }
                int serial = getNextSerialIndex();
                String fileName = "ejitor_jr(" + serial + ").pdf";

                OutputStream os = getDownloadsFileOutputStream(fileName, "application/pdf");
                if (os != null) {
                    doc.writeTo(os);
                    os.flush();
                    os.close();
                    runOnUiThread(() -> Toast.makeText(this, "Saved to Downloads/EJITOR: " + fileName, Toast.LENGTH_LONG).show());
                }
                doc.close();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "PDF Export Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void exportPsd() {
        new Thread(() -> {
            try {
                ProjectTabSession s = getCurrentSession();
                if (s == null) return;
                Bitmap master = renderCompositeCanvasForArtboard(s.currentActiveArtboard, false);
                int serial = getNextSerialIndex();
                String fileName = "ejitor_jr(" + serial + ").psd";

                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                DataOutputStream out = new DataOutputStream(baos);

                out.writeBytes("8BPS"); out.writeShort(1); out.write(new byte[6]); out.writeShort(3);
                out.writeInt(master.getHeight()); out.writeInt(master.getWidth());
                out.writeShort(8); out.writeShort(3);
                out.writeInt(0); out.writeInt(0); out.writeInt(0); out.writeShort(0);

                int len = master.getWidth() * master.getHeight();
                int[] pixels = new int[len];
                master.getPixels(pixels, 0, master.getWidth(), 0, 0, master.getWidth(), master.getHeight());

                byte[] r = new byte[len]; byte[] g = new byte[len]; byte[] b = new byte[len];
                for (int i = 0; i < len; i++) {
                    r[i] = (byte) Color.red(pixels[i]);
                    g[i] = (byte) Color.green(pixels[i]);
                    b[i] = (byte) Color.blue(pixels[i]);
                }
                out.write(r); out.write(g); out.write(b); out.flush();

                OutputStream os = getDownloadsFileOutputStream(fileName, "image/vnd.adobe.photoshop");
                if (os != null) {
                    os.write(baos.toByteArray());
                    os.flush();
                    os.close();
                    runOnUiThread(() -> Toast.makeText(this, "Saved to Downloads/EJITOR: " + fileName, Toast.LENGTH_LONG).show());
                }
                out.close();
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "PSD Export Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void exportJrProject() {
        new Thread(() -> {
            try {
                ProjectTabSession s = getCurrentSession();
                if (s == null) return;
                int serial = getNextSerialIndex();
                String fileName = "ejitor_jr(" + serial + ").jr";
                OutputStream os = getDownloadsFileOutputStream(fileName, "application/octet-stream");

                if (os != null) {
                    ZipOutputStream zos = new ZipOutputStream(os);

                    JSONObject json = new JSONObject();
                    json.put("name", s.projectName);
                    json.put("width", s.canvasWidth);
                    json.put("height", s.canvasHeight);
                    json.put("artboards", s.artboardCount);
                    json.put("bg", s.artboardBgColor);
                    json.put("gradientType", s.gradientType != null ? s.gradientType : "Linear");

                    JSONArray layerArray = new JSONArray();
                    synchronized (s.layers) {
                        for (int i = 0; i < s.layers.size(); i++) {
                            LayerItem l = s.layers.get(i);
                            JSONObject lj = new JSONObject();
                            lj.put("id", l.id);
                            lj.put("name", l.name);
                            lj.put("x", l.x);
                            lj.put("y", l.y);
                            lj.put("scaleX", l.scaleX);
                            lj.put("scaleY", l.scaleY);
                            lj.put("rotation", l.rotation);
                            lj.put("opacity", l.opacity);
                            lj.put("visible", l.isVisible);
                            lj.put("locked", l.isLocked);
                            lj.put("blend", l.blendMode);
                            lj.put("isShape", l.isShape);
                            lj.put("shapeType", l.shapeType);

                            String bmpName = "layer_" + l.id + ".png";
                            lj.put("file", bmpName);
                            layerArray.put(lj);

                            if (l.bitmap != null && !l.bitmap.isRecycled()) {
                                zos.putNextEntry(new ZipEntry(bmpName));
                                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                                l.bitmap.compress(Bitmap.CompressFormat.PNG, 90, bos);
                                zos.write(bos.toByteArray());
                                zos.closeEntry();
                            }
                        }
                    }
                    json.put("layers", layerArray);

                    zos.putNextEntry(new ZipEntry("project_data.json"));
                    zos.write(json.toString().getBytes("UTF-8"));
                    zos.closeEntry();

                    zos.flush();
                    zos.close();
                    runOnUiThread(() -> Toast.makeText(this, "Saved to Downloads/EJITOR: " + fileName, Toast.LENGTH_LONG).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Save JR Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private int getNextSerialIndex() {
        SharedPreferences sp = getSharedPreferences("ejitor_prefs", MODE_PRIVATE);
        int cur = sp.getInt("ejitor_serial_counter", 1);
        sp.edit().putInt("ejitor_serial_counter", cur + 1).apply();
        return cur;
    }

    private OutputStream getDownloadsFileOutputStream(String fileName, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            return uri != null ? resolver.openOutputStream(uri) : null;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, fileName);
            return new FileOutputStream(f);
        }
    }

    private Bitmap renderCompositeCanvasForArtboard(int abIdx, boolean isPng) {
        ProjectTabSession s = getCurrentSession();
        if (s == null) return Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);
        Bitmap res = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(res);

        boolean isBgLayerVisible = (!s.layers.isEmpty() && s.layers.get(0).name.equalsIgnoreCase("Background") && s.layers.get(0).isVisible);

        if (!isPng && isBgLayerVisible && s.artboardBgColor != Color.TRANSPARENT) {
            c.drawColor(s.artboardBgColor);
        }

        float abOffset = abIdx * (s.canvasWidth + dp(ARTBOARD_GAP_DP));

        synchronized (s.layers) {
            drawLayersWithClippingMask(c, s.layers, abOffset);
        }
        return res;
    }

    private void drawLayersWithClippingMask(Canvas canvas, List<LayerItem> layers, float xOffset) {
        Paint layerPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        Matrix m = new Matrix();

        for (int j = 0; j < layers.size(); j++) {
            LayerItem l = layers.get(j);
            if (!l.isVisible || l.bitmap == null || l.isBlank) continue;

            boolean hasMasksAbove = (j + 1 < layers.size() && layers.get(j + 1).isClippingMask);

            if (hasMasksAbove && !l.isClippingMask) {
                int saveCount = canvas.saveLayer(null, null);

                layerPaint.setAlpha((int) (l.opacity * 255));
                applyBlendModeToPaint(layerPaint, l.blendMode);
                m.reset();
                m.postScale(l.scaleX, l.scaleY);
                m.postRotate(l.rotation, (l.bitmap.getWidth() * l.scaleX) / 2f, (l.bitmap.getHeight() * l.scaleY) / 2f);
                m.postTranslate(l.x - xOffset, l.y);
                canvas.drawBitmap(l.bitmap, m, layerPaint);

                while (j + 1 < layers.size() && layers.get(j + 1).isClippingMask) {
                    j++;
                    LayerItem clipL = layers.get(j);
                    if (clipL.isVisible && clipL.bitmap != null && !clipL.isBlank) {
                        Matrix cm = new Matrix();
                        cm.postScale(clipL.scaleX, clipL.scaleY);
                        cm.postRotate(clipL.rotation, (clipL.bitmap.getWidth() * clipL.scaleX) / 2f, (clipL.bitmap.getHeight() * clipL.scaleY) / 2f);
                        cm.postTranslate(clipL.x - xOffset, clipL.y);

                        Paint blendCompositePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                        blendCompositePaint.setAlpha((int) (clipL.opacity * 255));
                        applyBlendModeToPaint(blendCompositePaint, clipL.blendMode);

                        int clipSave = canvas.saveLayer(null, blendCompositePaint);

                        Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                        canvas.drawBitmap(l.bitmap, m, maskPaint);

                        Paint contentPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                        contentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                        canvas.drawBitmap(clipL.bitmap, cm, contentPaint);

                        canvas.restoreToCount(clipSave);
                    }
                }
                canvas.restoreToCount(saveCount);
            } else if (!l.isClippingMask) {
                layerPaint.setAlpha((int) (l.opacity * 255));
                applyBlendModeToPaint(layerPaint, l.blendMode);
                m.reset();
                m.postScale(l.scaleX, l.scaleY);
                m.postRotate(l.rotation, (l.bitmap.getWidth() * l.scaleX) / 2f, (l.bitmap.getHeight() * l.scaleY) / 2f);
                m.postTranslate(l.x - xOffset, l.y);
                canvas.drawBitmap(l.bitmap, m, layerPaint);
            }
        }
    }

    private void applyBlendModeToPaint(Paint p, String mode) {
        if (mode == null || "Normal".equalsIgnoreCase(mode)) {
            p.setXfermode(null);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            BlendMode bm = BlendMode.SRC_OVER;
            if ("Multiply".equalsIgnoreCase(mode)) bm = BlendMode.MULTIPLY;
            else if ("Screen".equalsIgnoreCase(mode)) bm = BlendMode.SCREEN;
            else if ("Overlay".equalsIgnoreCase(mode)) bm = BlendMode.OVERLAY;
            else if ("Darken".equalsIgnoreCase(mode)) bm = BlendMode.DARKEN;
            else if ("Lighten".equalsIgnoreCase(mode)) bm = BlendMode.LIGHTEN;
            else if ("Color Dodge".equalsIgnoreCase(mode)) bm = BlendMode.COLOR_DODGE;
            else if ("Color Burn".equalsIgnoreCase(mode)) bm = BlendMode.COLOR_BURN;
            else if ("Hard Light".equalsIgnoreCase(mode)) bm = BlendMode.HARD_LIGHT;
            else if ("Soft Light".equalsIgnoreCase(mode)) bm = BlendMode.SOFT_LIGHT;
            else if ("Difference".equalsIgnoreCase(mode)) bm = BlendMode.DIFFERENCE;
            else if ("Exclusion".equalsIgnoreCase(mode)) bm = BlendMode.EXCLUSION;
            else if ("Hue".equalsIgnoreCase(mode)) bm = BlendMode.HUE;
            else if ("Saturation".equalsIgnoreCase(mode)) bm = BlendMode.SATURATION;
            else if ("Add".equalsIgnoreCase(mode) || "Linear Dodge".equalsIgnoreCase(mode)) bm = BlendMode.PLUS;
            else if ("Linear Burn".equalsIgnoreCase(mode)) bm = BlendMode.DARKEN;
            else if ("Vivid Light".equalsIgnoreCase(mode)) bm = BlendMode.OVERLAY;
            else if ("Dissolve".equalsIgnoreCase(mode)) bm = BlendMode.SRC_OVER;
            else if ("Clear".equalsIgnoreCase(mode)) bm = BlendMode.CLEAR;
            p.setBlendMode(bm);
        } else {
            PorterDuff.Mode pd = PorterDuff.Mode.SRC_OVER;
            if ("Multiply".equalsIgnoreCase(mode) || "Linear Burn".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.MULTIPLY;
            else if ("Screen".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.SCREEN;
            else if ("Overlay".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.OVERLAY;
            else if ("Darken".equalsIgnoreCase(mode) || "Color Burn".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.DARKEN;
            else if ("Lighten".equalsIgnoreCase(mode) || "Color Dodge".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.LIGHTEN;
            else if ("Add".equalsIgnoreCase(mode) || "Linear Dodge".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.ADD;
            else if ("Difference".equalsIgnoreCase(mode) || "Exclusion".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.XOR;
            else if ("Clear".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.CLEAR;
            p.setXfermode(new PorterDuffXfermode(pd));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQ_PICK_PROJECT_TO_TAB || requestCode == 5001) {
                ArrayList<String> projectNames = data.getStringArrayListExtra("selected_projects");
                
                if (projectNames != null && !projectNames.isEmpty()) {
                    for (String pName : projectNames) {
                        ProjectTabSession newTab = new ProjectTabSession(pName, 1080, 1080, 1, Color.WHITE);
                        if (!loadProjectFromDisk(newTab)) {
                            initDefaultTabLayers(newTab);
                        }
                        openNewTabWithSession(newTab);
                    }
                    Toast.makeText(this, projectNames.size() + " Project(s) Added to Tabs!", Toast.LENGTH_SHORT).show();
                } 
                else if (data.getStringExtra("project_name") != null) {
                    String pName = data.getStringExtra("project_name");
                    int w = data.getIntExtra("width", 1080);
                    int h = data.getIntExtra("height", 1080);
                    int ab = data.getIntExtra("artboards", 1);
                    int bg = data.getIntExtra("bg", Color.WHITE);

                    ProjectTabSession newTab = new ProjectTabSession(pName, w, h, ab, bg);
                    if (!loadProjectFromDisk(newTab)) {
                        initDefaultTabLayers(newTab);
                    }
                    openNewTabWithSession(newTab);
                    Toast.makeText(this, pName + " Opened in New Tab!", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQ_IMPORT_MULTI_IMAGE) {
                ProjectTabSession s = getCurrentSession();
                if (s == null) return;
                ArrayList<Uri> imageUris = new ArrayList<>();
                if (data.getClipData() != null) {
                    ClipData cd = data.getClipData();
                    for (int i = 0; i < cd.getItemCount(); i++) imageUris.add(cd.getItemAt(i).getUri());
                } else if (data.getData() != null) {
                    imageUris.add(data.getData());
                }

                float curOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
                for (int i = 0; i < imageUris.size(); i++) {
                    Bitmap imported = decodeSafeBitmap(imageUris.get(i), 2048);
                    if (imported != null) {
                        float offsetX = (i * dp(20));
                        LayerItem item = new LayerItem("Image Layer " + (s.layers.size() + 1), imported, curOffset + s.canvasWidth / 6f + offsetX, s.canvasHeight / 6f + offsetX, false);
                        item.isBlank = false;
                        synchronized (s.layers) {
                            s.layers.add(item);
                        }
                    }
                }
                s.activeLayerIndex = s.layers.size() - 1;
                recordHistory();
                updateLayersDockUI();
                canvasView.invalidate();
                Toast.makeText(this, "Imported " + imageUris.size() + " Images", Toast.LENGTH_SHORT).show();

            } else if (requestCode == REQ_OPEN_PROJECT_FILE && data.getData() != null) {
                handleOpenFileInNewTab(data.getData());
            }
        }
    }

    private void handleOpenFileInNewTab(Uri uri) {
        new Thread(() -> {
            try {
                String pathStr = uri.getPath() != null ? uri.getPath() : "";
                String lower = pathStr.toLowerCase();

                if (lower.endsWith(".jr") || isZipUri(uri)) {
                    ProjectTabSession jrSession = parseJrProjectFile(uri);
                    if (jrSession != null) {
                        runOnUiThread(() -> {
                            openNewTabWithSession(jrSession);
                            Toast.makeText(this, "Project (.jr) Loaded in New Tab", Toast.LENGTH_SHORT).show();
                        });
                        return;
                    }
                }

                if (lower.endsWith(".pdf") || isPdfUri(uri)) {
                    ProjectTabSession pdfSession = parsePdfFile(uri);
                    if (pdfSession != null) {
                        runOnUiThread(() -> {
                            openNewTabWithSession(pdfSession);
                            Toast.makeText(this, "PDF Loaded in New Tab", Toast.LENGTH_SHORT).show();
                        });
                        return;
                    }
                }

                if (lower.endsWith(".psd") || isPsdUri(uri)) {
                    ProjectTabSession psdSession = parsePsdFile(uri);
                    if (psdSession != null) {
                        runOnUiThread(() -> {
                            openNewTabWithSession(psdSession);
                            Toast.makeText(this, "PSD Loaded in New Tab", Toast.LENGTH_SHORT).show();
                        });
                        return;
                    }
                }

                Bitmap img = decodeSafeBitmap(uri, 2048);
                if (img != null) {
                    ProjectTabSession imgSession = new ProjectTabSession("Image-" + (openTabs.size() + 1), img.getWidth(), img.getHeight(), 1, Color.WHITE);
                    LayerItem base = new LayerItem("Background", img, 0, 0, false);
                    base.isBlank = false;
                    imgSession.layers.add(base);
                    imgSession.activeLayerIndex = 0;
                    runOnUiThread(() -> {
                        openNewTabWithSession(imgSession);
                        Toast.makeText(this, "Image Opened in New Tab", Toast.LENGTH_SHORT).show();
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Unsupported or Corrupted File", Toast.LENGTH_SHORT).show());
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Error Opening File: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private boolean isZipUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[4];
            return is != null && is.read(h) == 4 && h[0] == 0x50 && h[1] == 0x4B;
        } catch (Exception e) { return false; }
    }

    private boolean isPdfUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[5];
            return is != null && is.read(h) == 5 && new String(h).startsWith("%PDF");
        } catch (Exception e) { return false; }
    }

    private boolean isPsdUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[4];
            return is != null && is.read(h) == 4 && new String(h).equals("8BPS");
        } catch (Exception e) { return false; }
    }

    private ProjectTabSession parseJrProjectFile(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri);
             ZipInputStream zis = new ZipInputStream(is)) {

            ZipEntry entry;
            String jsonStr = null;
            java.util.Map<String, Bitmap> bitMapMap = new java.util.HashMap<>();

            while ((entry = zis.getNextEntry()) != null) {
                if (entry.getName().equals("project_data.json") || entry.getName().equals("project.json")) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[4096];
                    int len;
                    while ((len = zis.read(buffer)) > 0) bos.write(buffer, 0, len);
                    jsonStr = bos.toString("UTF-8");
                } else if (entry.getName().endsWith(".png") && !entry.getName().equals("thumbnail.png")) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[4096];
                    int len;
                    while ((len = zis.read(buffer)) > 0) bos.write(buffer, 0, len);
                    byte[] bytes = bos.toByteArray();
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bmp != null) bitMapMap.put(entry.getName(), bmp.copy(Bitmap.Config.ARGB_8888, true));
                }
                zis.closeEntry();
            }

            if (jsonStr != null) {
                JSONObject json = new JSONObject(jsonStr);
                String pName = json.optString("name", "JR-Project");
                int w = json.optInt("width", 1080);
                int h = json.optInt("height", 1080);
                int ab = json.optInt("artboards", 1);
                int bg = json.optInt("bg", Color.WHITE);

                ProjectTabSession session = new ProjectTabSession(pName, w, h, ab, bg);
                session.gradientType = json.optString("gradientType", "Linear");
                session.layers.clear();
                JSONArray arr = json.getJSONArray("layers");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);
                    String file = obj.getString("file");
                    Bitmap b = bitMapMap.get(file);
                    if (b == null) b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);

                    LayerItem li = new LayerItem(obj.getString("name"), b, (float) obj.getDouble("x"), (float) obj.getDouble("y"), obj.getBoolean("locked"));
                    li.id = obj.optString("id", li.id);
                    li.scaleX = (float) obj.optDouble("scaleX", 1f);
                    li.scaleY = (float) obj.optDouble("scaleY", 1f);
                    li.rotation = (float) obj.optDouble("rotation", 0f);
                    li.opacity = (float) obj.optDouble("opacity", 1f);
                    li.isVisible = obj.getBoolean("visible");
                    li.blendMode = obj.optString("blend", "Normal");
                    li.isShape = obj.optBoolean("isShape", false);
                    li.shapeType = obj.optString("shapeType", "rectangle");
                    li.isSmartObject = obj.optBoolean("isSmartObject", false);
                    li.isClippingMask = obj.optBoolean("isClippingMask", false);

                    li.isPolygonShape = obj.optBoolean("isPolygonShape", false);
                    li.polygonHasFill = obj.optBoolean("polygonHasFill", false);
                    li.polygonHasStroke = obj.optBoolean("polygonHasStroke", true);
                    li.polygonIsMerged = obj.optBoolean("polygonIsMerged", false);
                    li.shapeFill = obj.optInt("shapeFill", li.shapeFill);
                    li.shapeStroke = obj.optInt("shapeStroke", li.shapeStroke);
                    li.shapeStrokeW = (float) obj.optDouble("shapeStrokeW", li.shapeStrokeW);

                    li.radiusTL = (float) obj.optDouble("radiusTL", 0);
                    li.radiusTR = (float) obj.optDouble("radiusTR", 0);
                    li.radiusBR = (float) obj.optDouble("radiusBR", 0);
                    li.radiusBL = (float) obj.optDouble("radiusBL", 0);

                    if (obj.has("polygonAnchors")) {
                        JSONArray paArr = obj.getJSONArray("polygonAnchors");
                        li.polygonAnchors.clear();
                        for (int k = 0; k < paArr.length(); k++) {
                            JSONObject po = paArr.getJSONObject(k);
                            PolyAnchorPoint ap = new PolyAnchorPoint((float) po.getDouble("x"), (float) po.getDouble("y"));
                            ap.hInX = (float) po.optDouble("hInX", ap.x);
                            ap.hInY = (float) po.optDouble("hInY", ap.y);
                            ap.hOutX = (float) po.optDouble("hOutX", ap.x);
                            ap.hOutY = (float) po.optDouble("hOutY", ap.y);
                            ap.hasHandles = po.optBoolean("hasHandles", false);
                            li.polygonAnchors.add(ap);
                        }
                    }

                    session.layers.add(li);
                }
                session.activeLayerIndex = Math.max(0, session.layers.size() - 1);
                return session;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private ProjectTabSession parsePdfFile(Uri uri) {
        try {
            File tempPdf = new File(getCacheDir(), "temp_pdf_render.pdf");
            try (InputStream is = getContentResolver().openInputStream(uri); FileOutputStream fos = new FileOutputStream(tempPdf)) {
                byte[] buf = new byte[8192];
                int l;
                while (is != null && (l = is.read(buf)) > 0) fos.write(buf, 0, l);
            }

            ParcelFileDescriptor pfd = ParcelFileDescriptor.open(tempPdf, ParcelFileDescriptor.MODE_READ_ONLY);
            PdfRenderer renderer = new PdfRenderer(pfd);
            int pageCount = Math.min(renderer.getPageCount(), 10);
            if (pageCount <= 0) return null;

            PdfRenderer.Page firstPage = renderer.openPage(0);
            int pW = firstPage.getWidth() * 2;
            int pH = firstPage.getHeight() * 2;
            firstPage.close();

            ProjectTabSession session = new ProjectTabSession("PDF-Document", pW, pH, pageCount, Color.WHITE);
            session.layers.clear();

            for (int i = 0; i < pageCount; i++) {
                PdfRenderer.Page page = renderer.openPage(i);
                Bitmap pageBmp = Bitmap.createBitmap(pW, pH, Bitmap.Config.ARGB_8888);
                Canvas pc = new Canvas(pageBmp);
                pc.drawColor(Color.WHITE);
                page.render(pageBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();

                float offset = i * (pW + dp(ARTBOARD_GAP_DP));
                LayerItem pageLayer = new LayerItem("Page " + (i + 1), pageBmp, offset, 0, false);
                pageLayer.isBlank = false;
                session.layers.add(pageLayer);
            }
            renderer.close();
            pfd.close();
            session.activeLayerIndex = 0;
            return session;
        } catch (Exception ignored) {}
        return null;
    }

    private ProjectTabSession parsePsdFile(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri);
             DataInputStream dis = new DataInputStream(is)) {

            byte[] sig = new byte[4];
            dis.readFully(sig);
            if (!new String(sig).equals("8BPS")) return null;

            int version = dis.readShort();
            dis.skipBytes(6);
            int channels = dis.readShort();
            int height = dis.readInt();
            int width = dis.readInt();
            int depth = dis.readShort();
            int mode = dis.readShort();

            Bitmap psdBmp = decodeSafeBitmap(uri, 2048);
            if (psdBmp == null) {
                psdBmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(psdBmp);
                c.drawColor(Color.WHITE);
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.DKGRAY);
                p.setTextSize(dp(22));
                c.drawText("Photoshop Document (" + width + "x" + height + ")", dp(20), dp(50), p);
            }

            ProjectTabSession session = new ProjectTabSession("PSD-" + (openTabs.size() + 1), width, height, 1, Color.TRANSPARENT);
            session.layers.clear();
            LayerItem base = new LayerItem("PSD Composite Layer", psdBmp, 0, 0, false);
            base.isBlank = false;
            session.layers.add(base);
            session.activeLayerIndex = 0;
            return session;
        } catch (Exception ignored) {}
        return null;
    }

    private Bitmap decodeSafeBitmap(Uri uri, int maxDim) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(is, null, opts);
            if (is != null) is.close();

            int sample = 1;
            while ((opts.outWidth / sample) > maxDim || (opts.outHeight / sample) > maxDim) sample *= 2;

            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sample;
            opts.inMutable = true;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;

            is = getContentResolver().openInputStream(uri);
            Bitmap finalBmp = BitmapFactory.decodeStream(is, null, opts);
            if (is != null) is.close();
            return finalBmp;
        } catch (Exception e) {
            return null;
        }
    }

    private BitmapDrawable createVectorDragDotsIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(14), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#888888"));
        p.setStyle(Paint.Style.FILL);
        for (int row = 0; row < 4; row++) {
            c.drawCircle(dp(4), dp(3.5f + row * 4.5f), dp(1.5f), p);
            c.drawCircle(dp(10), dp(3.5f + row * 4.5f), dp(1.5f), p);
        }
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorChainLinkIcon(boolean linked) { 
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888); 
        Canvas c = new Canvas(bmp); 
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); 
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.3f)); 
        
        c.drawRoundRect(new RectF(dp(2), dp(4), dp(8), dp(12)), dp(2), dp(2), p); 
        c.drawRoundRect(new RectF(dp(8), dp(4), dp(14), dp(12)), dp(2), dp(2), p); 
        
        if (linked) {
            c.drawLine(dp(6), dp(8), dp(10), dp(8), p); 
        }
            
        return new BitmapDrawable(getResources(), bmp); 
    }

    private BitmapDrawable createVectorEyeIcon(boolean visible) {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        p.setColor(visible ? Color.parseColor("#CCCCCC") : Color.parseColor("#444444"));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.4f));

        Path path = new Path();
        path.moveTo(dp(2.5f), dp(10));
        path.cubicTo(dp(5.5f), dp(4.5f), dp(14.5f), dp(4.5f), dp(17.5f), dp(10));
        path.cubicTo(dp(14.5f), dp(15.5f), dp(5.5f), dp(15.5f), dp(2.5f), dp(10));
        c.drawPath(path, p);

        if (visible) {
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
            c.drawCircle(dp(10), dp(10), dp(3.8f), p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.parseColor("#EEEEEE"));
            c.drawCircle(dp(10), dp(10), dp(2.2f), p);
            p.setColor(Color.WHITE); c.drawCircle(dp(11.2f), dp(8.8f), dp(0.8f), p);
        } else {
            p.setColor(Color.parseColor("#666666")); p.setStrokeWidth(dp(1.4f));
            c.drawLine(dp(3.5f), dp(16.5f), dp(16.5f), dp(3.5f), p);
        }
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorLockIcon(boolean locked) {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(locked ? Color.parseColor("#FF1238") : Color.parseColor("#444444"));
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f));
        Path shackle = new Path(); shackle.moveTo(dp(5), dp(7));
        shackle.lineTo(dp(5), dp(4.5f));
        shackle.quadTo(dp(8), dp(2), dp(11), dp(4.5f));
        shackle.lineTo(dp(11), dp(7));
        c.drawPath(shackle, p);
        p.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(dp(3.5f), dp(7), dp(12.5f), dp(14)), dp(1.5f), dp(1.5f), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorCheckmarkIcon(boolean checked) {
        Bitmap bmp = Bitmap.createBitmap(dp(13), dp(13), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (checked) {
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(Color.parseColor("#FF1238")); gd.setCornerRadius(dp(2)); gd.setBounds(0, 0, dp(13), dp(13)); gd.draw(c);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.6f)); p.setStrokeCap(Paint.Cap.ROUND);
            Path path = new Path(); path.moveTo(dp(2.8f), dp(6.5f)); path.lineTo(dp(5.3f), dp(9.5f)); path.lineTo(dp(10.2f), dp(3.5f)); c.drawPath(path, p);
        } else {
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(Color.parseColor("#161616")); gd.setStroke(dp(1.1f), Color.parseColor("#444444")); gd.setCornerRadius(dp(2)); gd.setBounds(0, 0, dp(13), dp(13)); gd.draw(c);
        }
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorSnappingIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(11), dp(11), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
        c.drawLine(dp(1), dp(3.5f), dp(1), dp(1), p); c.drawLine(dp(1), dp(1), dp(3.5f), dp(1), p);
        c.drawLine(dp(10), dp(3.5f), dp(10), dp(1), p); c.drawLine(dp(10), dp(1), dp(7.5f), dp(1), p);
        c.drawLine(dp(1), dp(7.5f), dp(1), dp(10), p); c.drawLine(dp(1), dp(10), dp(3.5f), dp(10), p);
        c.drawLine(dp(10), dp(7.5f), dp(10), dp(10), p); c.drawLine(dp(10), dp(10), dp(7.5f), dp(10), p);
        p.setStyle(Paint.Style.FILL); c.drawCircle(dp(5.5f), dp(5.5f), dp(1f), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorSwapIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(12), dp(10), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#888888")); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.1f));
        c.drawLine(dp(2), dp(3), dp(9.5f), dp(3), p);
        Path a1 = new Path(); a1.moveTo(dp(7.5f), dp(1)); a1.lineTo(dp(10), dp(3)); a1.lineTo(dp(7.5f), dp(5)); c.drawPath(a1, p);
        c.drawLine(dp(10), dp(7), dp(2.5f), dp(7), p);
        Path a2 = new Path(); a2.moveTo(dp(4.5f), dp(5)); a2.lineTo(dp(2), dp(7)); a2.lineTo(dp(4.5f), dp(9)); c.drawPath(a2, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorFolderIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#888888")); p.setStyle(Paint.Style.FILL);
        Path path = new Path(); path.moveTo(dp(1), dp(3)); path.lineTo(dp(6), dp(3)); path.lineTo(dp(8), dp(5)); path.lineTo(dp(15), dp(5)); path.lineTo(dp(15), dp(13)); path.lineTo(dp(1), dp(13)); path.close();
        c.drawPath(path, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorPlusIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#777777")); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f));
        c.drawLine(dp(9), dp(3.5f), dp(9), dp(14.5f), p); c.drawLine(dp(3.5f), dp(9), dp(14.5f), dp(9), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorDuplicateIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#777777")); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
        c.drawRoundRect(new RectF(dp(5.5f), dp(2.5f), dp(14.5f), dp(11.5f)), dp(1), dp(1), p);
        c.drawRoundRect(new RectF(dp(2.5f), dp(5.5f), dp(11.5f), dp(14.5f)), dp(1), dp(1), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorTrashIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#777777")); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
        c.drawLine(dp(3), dp(4.5f), dp(15), dp(4.5f), p); c.drawLine(dp(6.5f), dp(3), dp(11.5f), dp(3), p);
        Path bin = new Path(); bin.moveTo(dp(4.5f), dp(4.5f)); bin.lineTo(dp(5.5f), dp(15)); bin.lineTo(dp(12.5f), dp(15)); bin.lineTo(dp(13.5f), dp(4.5f)); c.drawPath(bin, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorUndoIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.8f));
        Path path = new Path(); path.moveTo(dp(14), dp(13)); path.quadTo(dp(14), dp(5), dp(7), dp(5)); c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL); Path a = new Path(); a.moveTo(dp(8), dp(2)); a.lineTo(dp(3), dp(5)); a.lineTo(dp(8), dp(8)); a.close(); c.drawPath(a, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorRedoIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.8f));
        Path path = new Path(); path.moveTo(dp(4), dp(13)); path.quadTo(dp(4), dp(5), dp(11), dp(5)); c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL); Path a = new Path(); a.moveTo(dp(10), dp(2)); a.lineTo(dp(15), dp(5)); a.lineTo(dp(10), dp(8)); a.close(); c.drawPath(a, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorLayersDockIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.3f));
        Path d1 = new Path(); d1.moveTo(dp(9), dp(2)); d1.lineTo(dp(16), dp(5.5f)); d1.lineTo(dp(9), dp(9)); d1.lineTo(dp(2), dp(5.5f)); d1.close(); c.drawPath(d1, p);
        Path d2 = new Path(); d2.moveTo(dp(2), dp(9)); d2.lineTo(dp(9), dp(12.5f)); d2.lineTo(dp(16), dp(9)); c.drawPath(d2, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorMoveIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(10), dp(3), dp(10), dp(17), p); c.drawLine(dp(3), dp(10), dp(17), dp(10), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorMarqueeIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.4f));
        p.setPathEffect(new DashPathEffect(new float[]{dp(3), dp(3)}, 0));
        c.drawRect(dp(3), dp(3), dp(17), dp(17), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorRoundLassoIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f));
        c.drawCircle(dp(10), dp(10), dp(6.5f), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorGradientIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.3f));
        c.drawRect(dp(3), dp(3), dp(17), dp(17), p); p.setStyle(Paint.Style.FILL);
        Path half = new Path(); half.moveTo(dp(3), dp(17)); half.lineTo(dp(17), dp(3)); half.lineTo(dp(17), dp(17)); half.close(); c.drawPath(half, p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private BitmapDrawable createVectorShapeIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(20), dp(20), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.5f));
        c.drawRoundRect(new RectF(dp(3), dp(5), dp(17), dp(15)), dp(2), dp(2), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    private Drawable createDialogBg() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private Drawable createCloseVectorDrawable() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new BitmapDrawable(getResources(), bmp);
    }

    public class StudioCanvasView extends View {
        private final Paint artboardPaint = new Paint();
        private final Paint artboardShadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint guidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handleBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gradLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint gradCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint polyLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint polyFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkerPaint = new Paint();

        private final Paint antUnderlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint antPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Paint handleLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handleSquarePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handleSquareBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint anchorCirclePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint anchorCircleBorderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        private final Paint nodeFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint nodeStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint liveStroke = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private final Paint liveFill = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
        private final Paint liveSelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint liveLassoP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint selRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Matrix sharedTransformMatrix = new Matrix();

        private float lastTouchX, lastTouchY;
        private float lastMidX, lastMidY;
        private boolean isTwoFingerNavigating = false;

        private int activePointerId = -1;
        private int selectedHandle = -1;
        private int selectedCornerNode = -1;

        private boolean isRotatingLayer = false;
        private float initialTouchAngle = 0f;
        private float initialLayerRotation = 0f;
        private float handleInitialAspect = 1.0f;

        public int selectedAnchorIndex = -1;
        public int selectedHandleSide = 0;
        private long lastAnchorTapTime = 0;
        private int lastAnchorTapIdx = -1;

        private float initialDownX = 0f, initialDownY = 0f;
        private boolean isPotentialNewAnchor = false;

        private GradStop selectedStopRef = null;
        private boolean isDraggingGradStart = false;
        private boolean isDraggingGradEnd = false;
        private boolean isDraggingNewGradLine = false;
        private boolean isDraggingLayer = false;
        private boolean isDraggingHandle = false;

        private boolean isDrawingShape = false;
        private float shapeStartX, shapeStartY, shapeCurX, shapeCurY;
        private final Path tempDrawPath = new Path();

        private final ScaleGestureDetector scaleDetector;

        public StudioCanvasView(Context context) {
            super(context);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                setLayerType(View.LAYER_TYPE_HARDWARE, null);
            }

            artboardPaint.setColor(Color.WHITE);
            artboardShadowPaint.setColor(Color.parseColor("#080808"));
            artboardShadowPaint.setStyle(Paint.Style.FILL);

            guidePaint.setColor(Color.parseColor("#FF1238"));
            guidePaint.setStyle(Paint.Style.STROKE);
            guidePaint.setStrokeWidth(dp(1.0f));

            handlePaint.setColor(Color.WHITE);
            handlePaint.setStyle(Paint.Style.FILL);

            handleBorderPaint.setColor(Color.parseColor("#FF1238"));
            handleBorderPaint.setStyle(Paint.Style.STROKE);
            handleBorderPaint.setStrokeWidth(dp(1.0f));

            gradLinePaint.setColor(Color.parseColor("#FF1238"));
            gradLinePaint.setStyle(Paint.Style.STROKE);
            gradLinePaint.setStrokeWidth(dp(2f));
            gradCirclePaint.setStyle(Paint.Style.FILL);

            polyLinePaint.setColor(Color.parseColor("#FF1238"));
            polyLinePaint.setStyle(Paint.Style.STROKE);
            polyLinePaint.setStrokeWidth(dp(polyLineWidth));

            polyFillPaint.setStyle(Paint.Style.FILL);
            polyFillPaint.setColor(polyFillColor);

            handleLinePaint.setColor(Color.parseColor("#FF1238"));
            handleLinePaint.setStyle(Paint.Style.STROKE);
            handleLinePaint.setStrokeWidth(dp(1.4f));

            handleSquarePaint.setColor(Color.parseColor("#FF1238"));
            handleSquarePaint.setStyle(Paint.Style.FILL);

            handleSquareBorderPaint.setColor(Color.WHITE);
            handleSquareBorderPaint.setStyle(Paint.Style.STROKE);
            handleSquareBorderPaint.setStrokeWidth(dp(1.2f));

            anchorCirclePaint.setColor(Color.WHITE);
            anchorCirclePaint.setStyle(Paint.Style.FILL);

            anchorCircleBorderPaint.setColor(Color.parseColor("#FF1238"));
            anchorCircleBorderPaint.setStyle(Paint.Style.STROKE);
            anchorCircleBorderPaint.setStrokeWidth(dp(1.8f));

            nodeFill.setColor(Color.WHITE);
            nodeFill.setStyle(Paint.Style.FILL);
            nodeStroke.setColor(Color.parseColor("#FF1238"));
            nodeStroke.setStyle(Paint.Style.STROKE);

            liveSelPaint.setStyle(Paint.Style.STROKE);
            liveSelPaint.setColor(Color.parseColor("#00E5FF"));

            liveLassoP.setStyle(Paint.Style.STROKE);
            liveLassoP.setColor(Color.CYAN);

            selRing.setStyle(Paint.Style.STROKE);

            Bitmap tileBmp = Bitmap.createBitmap(dp(24), dp(24), Bitmap.Config.ARGB_8888);
            Canvas tc = new Canvas(tileBmp);
            Paint tp1 = new Paint(); tp1.setColor(Color.parseColor("#1E1E1E"));
            Paint tp2 = new Paint(); tp2.setColor(Color.parseColor("#282828"));
            tc.drawRect(0, 0, dp(12), dp(12), tp1);
            tc.drawRect(dp(12), 0, dp(24), dp(12), tp2);
            tc.drawRect(0, dp(12), dp(12), dp(24), tp2);
            tc.drawRect(dp(12), dp(12), dp(24), dp(24), tp1);
            BitmapShader checkerShader = new BitmapShader(tileBmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
            checkerPaint.setShader(checkerShader);

            antUnderlayPaint.setStyle(Paint.Style.STROKE);
            antUnderlayPaint.setColor(Color.BLACK);

            antPaint.setStyle(Paint.Style.STROKE);
            antPaint.setColor(Color.WHITE);

            scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    ProjectTabSession s = getCurrentSession();
                    if (s == null) return false;
                    float prevScale = s.scale;
                    s.scale *= detector.getScaleFactor();
                    s.scale = Math.max(0.05f, Math.min(s.scale, 8.0f));

                    float focusX = detector.getFocusX();
                    float focusY = detector.getFocusY();
                    s.panX = focusX - (focusX - s.panX) * (s.scale / prevScale);
                    s.panY = focusY - (focusY - s.panY) * (s.scale / prevScale);

                    invalidate();
                    return true;
                }

                @Override public void onScaleEnd(ScaleGestureDetector detector) {
                    refreshTabStripUI();
                }
            });
        }

        private float snapPositionX(float targetX, float layerW, ProjectTabSession s) {
            if (!snappingEnabled || s == null) return targetX;
            float threshold = dp(6) / s.scale;
            float currentOffset = s.currentActiveArtboard * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
            float centerX = currentOffset + (s.canvasWidth - layerW) / 2f;
            if (Math.abs(targetX - centerX) < threshold) return centerX;
            if (Math.abs(targetX - currentOffset) < threshold) return currentOffset;
            float rightX = currentOffset + s.canvasWidth - layerW;
            if (Math.abs(targetX - rightX) < threshold) return rightX;
            return targetX;
        }

        private float snapPositionY(float targetY, float layerH, ProjectTabSession s) {
            if (!snappingEnabled || s == null) return targetY;
            float threshold = dp(6) / s.scale;
            float centerY = (s.canvasHeight - layerH) / 2f;
            if (Math.abs(targetY - centerY) < threshold) return centerY;
            if (Math.abs(targetY) < threshold) return 0f;
            float bottomY = s.canvasHeight - layerH;
            if (Math.abs(targetY - bottomY) < threshold) return bottomY;
            return targetY;
        }

        private boolean isLayerEligibleForTransform(LayerItem al) {
            if (al == null || al.bitmap == null) return false;
            if (al.isBlank || al.isLocked) return false;
            if ("Background".equalsIgnoreCase(al.name)) return false;
            return al.bitmap.getWidth() > 0 && al.bitmap.getHeight() > 0;
        }

        public void autoCenterArtboard(int viewW, int viewH) {
            ProjectTabSession s = getCurrentSession();
            if (s == null || viewW <= 0 || viewH <= 0) return;

            float singleW = s.canvasWidth;
            float singleH = s.canvasHeight;
            float totalW = s.artboardCount * singleW + (s.artboardCount - 1) * dp(ARTBOARD_GAP_DP);

            float fitScaleX = (viewW * 0.90f) / (s.artboardCount == 1 ? singleW : totalW);
            float fitScaleY = (viewH * 0.88f) / singleH;
            s.scale = Math.min(fitScaleX, fitScaleY);
            s.scale = Math.max(0.08f, Math.min(s.scale, 5.0f));

            if (s.artboardCount == 1) {
                s.panX = (viewW - (singleW * s.scale)) / 2f;
            } else {
                float targetOffset = s.currentActiveArtboard * (singleW + dp(ARTBOARD_GAP_DP));
                s.panX = (viewW / 2f) - ((targetOffset + singleW / 2f) * s.scale);
            }
            s.panY = (viewH - (singleH * s.scale)) / 2f;

            refreshTabStripUI();
            invalidate();
        }

        public void resetViewport() { 
            autoCenterArtboard(getWidth(), getHeight()); 
        }

        public void clearLassoSelection() {
            activeSelectionPath = null;
            selectionBounds = null;
            polyAnchors.clear();
            selectedAnchorIndex = -1;
            selectedHandleSide = 0;
            recordHistory();
            invalidate();
        }

        @Override 
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (oldw == 0 && oldh == 0) {
                if (w > 0 && h > 0) autoCenterArtboard(w, h);
            } else if (w > 0 && oldw > 0) {
                ProjectTabSession s = getCurrentSession();
                if (s != null) {
                    s.panX += (w - oldw) / 2f;
                    invalidate();
                }
            }
        }

        @Override 
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            ProjectTabSession s = getCurrentSession();
            if (s == null) return;
            canvas.save();
            canvas.translate(s.panX, s.panY);
            canvas.scale(s.scale, s.scale);

            for (int i = 0; i < s.artboardCount; i++) {
                float offset = i * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
                canvas.drawRect(offset + dp(5), dp(5), offset + s.canvasWidth + dp(5), s.canvasHeight + dp(5), artboardShadowPaint);
            }

            boolean isBgVisible = (!s.layers.isEmpty() && s.layers.get(0).name.equalsIgnoreCase("Background") && s.layers.get(0).isVisible);

            for (int i = 0; i < s.artboardCount; i++) {
                float offset = i * (s.canvasWidth + dp(ARTBOARD_GAP_DP));
                canvas.save();
                canvas.translate(offset, 0);
                canvas.clipRect(0, 0, s.canvasWidth, s.canvasHeight);

                if (!isBgVisible || s.artboardBgColor == Color.TRANSPARENT) {
                    canvas.drawRect(0, 0, s.canvasWidth, s.canvasHeight, checkerPaint);
                } else {
                    artboardPaint.setColor(s.artboardBgColor);
                    canvas.drawRect(0, 0, s.canvasWidth, s.canvasHeight, artboardPaint);
                }

                synchronized (s.layers) {
                    drawLayersWithClippingMask(canvas, s.layers, offset);
                }
                canvas.restore();
            }

            if (s.hasGradientLine && "gradient".equals(activeTool)) {
                canvas.drawLine(s.gradStartX, s.gradStartY, s.gradEndX, s.gradEndY, gradLinePaint);

                float cRad = dp(9) / s.scale;
                for (int st = 0; st < s.gradStops.size(); st++) {
                    GradStop stop = s.gradStops.get(st);
                    float sx = s.gradStartX + (s.gradEndX - s.gradStartX) * stop.pos;
                    float sy = s.gradStartY + (s.gradEndY - s.gradStartY) * stop.pos;

                    gradCirclePaint.setColor(stop.color);
                    canvas.drawCircle(sx, sy, cRad, gradCirclePaint);

                    if (stop == s.activeGradStop) {
                        selRing.setStrokeWidth(dp(2.5f) / s.scale);
                        selRing.setColor(Color.WHITE);
                        canvas.drawCircle(sx, sy, cRad + dp(3.5f) / s.scale, selRing);

                        selRing.setColor(Color.parseColor("#FF1238"));
                        selRing.setStrokeWidth(dp(1.2f) / s.scale);
                        canvas.drawCircle(sx, sy, cRad, selRing);
                    } else {
                        canvas.drawCircle(sx, sy, cRad, handleBorderPaint);
                    }
                }
            }

            if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                LayerItem al = s.layers.get(s.activeLayerIndex);
                if (al.isShape && !al.isPolygonShape && al.isVisible && "shape".equals(activeTool)) {
                    float left = al.x, top = al.y;
                    float right = al.x + (al.bitmap.getWidth() * al.scaleX);
                    float bottom = al.y + (al.bitmap.getHeight() * al.scaleY);

                    canvas.drawRect(left, top, right, bottom, guidePaint);

                    float nodeRad = dp(5.5f) / s.scale;
                    float nodeOffset = dp(10) / s.scale;

                    nodeStroke.setStrokeWidth(dp(1.8f) / s.scale);

                    canvas.drawCircle(left + nodeOffset, top + nodeOffset, nodeRad, nodeFill);
                    canvas.drawCircle(left + nodeOffset, top + nodeOffset, nodeRad, nodeStroke);

                    canvas.drawCircle(right - nodeOffset, top + nodeOffset, nodeRad, nodeFill);
                    canvas.drawCircle(right - nodeOffset, top + nodeOffset, nodeRad, nodeStroke);

                    canvas.drawCircle(right - nodeOffset, bottom - nodeOffset, nodeRad, nodeFill);
                    canvas.drawCircle(right - nodeOffset, bottom - nodeOffset, nodeRad, nodeStroke);

                    canvas.drawCircle(left + nodeOffset, bottom - nodeOffset, nodeRad, nodeFill);
                    canvas.drawCircle(left + nodeOffset, bottom - nodeOffset, nodeRad, nodeStroke);
                }
            }

            if (isDrawingShape && "shape".equals(activeTool)) {
                float sw = Math.abs(shapeCurX - shapeStartX);
                float sh = Math.abs(shapeCurY - shapeStartY);

                if (shapeLock) {
                    float side = Math.max(sw, sh);
                    sw = side;
                    sh = side;
                }

                float sx = (shapeCurX >= shapeStartX) ? shapeStartX : (shapeStartX - sw);
                float sy = (shapeCurY >= shapeStartY) ? shapeStartY : (shapeStartY - sh);

                Path liveShape = generateShapePath(activeShapeType, (int) Math.max(10, sw), (int) Math.max(10, sh));
                sharedTransformMatrix.reset();
                sharedTransformMatrix.postTranslate(sx, sy);
                liveShape.transform(sharedTransformMatrix);

                if ("line".equals(activeShapeType)) {
                    liveStroke.setColor(shapeStrokeColor);
                    liveStroke.setStyle(Paint.Style.STROKE);
                    liveStroke.setStrokeWidth(Math.max(2f, shapeStrokeWidth) / s.scale);
                    liveStroke.setStrokeCap(Paint.Cap.ROUND);
                    canvas.drawPath(liveShape, liveStroke);
                } else {
                    liveFill.setColor(shapeFillColor);
                    liveFill.setStyle(Paint.Style.FILL);
                    canvas.drawPath(liveShape, liveFill);

                    if (shapeStrokeWidth > 0) {
                        liveStroke.setColor(shapeStrokeColor);
                        liveStroke.setStyle(Paint.Style.STROKE);
                        liveStroke.setStrokeWidth(shapeStrokeWidth / s.scale);
                        canvas.drawPath(liveShape, liveStroke);
                    }
                }
            }

            if (activeSelectionPath != null) {
                try {
                    float strokeW = Math.max(1f, Math.min(dp(1.5f) / s.scale, 4f));
                    float dashSize = Math.max(4f, Math.min(dp(4f) / s.scale, 16f));

                    antUnderlayPaint.setStrokeWidth(strokeW);
                    canvas.drawPath(activeSelectionPath, antUnderlayPaint);

                    antPaint.setStrokeWidth(strokeW);
                    antPaint.setPathEffect(new DashPathEffect(new float[]{dashSize, dashSize}, 0));
                    canvas.drawPath(activeSelectionPath, antPaint);
                } catch (Exception ignored) {}
            }

            if ("select_rect".equals(activeTool) && isDrawingShape) {
                liveSelPaint.setStrokeWidth(dp(1.5f) / s.scale);
                liveSelPaint.setPathEffect(new DashPathEffect(new float[]{dp(3) / s.scale, dp(3) / s.scale}, 0));
                canvas.drawRect(Math.min(shapeStartX, shapeCurX), Math.min(shapeStartY, shapeCurY),
                        Math.max(shapeStartX, shapeCurX), Math.max(shapeStartY, shapeCurY), liveSelPaint);
            }

            if ("lasso".equals(activeTool) && !tempDrawPath.isEmpty()) {
                liveLassoP.setStrokeWidth(dp(1.5f) / s.scale);
                canvas.drawPath(tempDrawPath, liveLassoP);
            }

            if (!polyAnchors.isEmpty() && "lasso".equals(activeTool)) {
                Path pLine = buildPathFromAnchors(polyAnchors, polyMergePath);

                if (polyFillEnabled) {
                    polyFillPaint.setColor(polyFillColor);
                    canvas.drawPath(pLine, polyFillPaint);
                }

                if (polyStrokeEnabled) {
                    polyLinePaint.setColor(polyStrokeColor);
                    polyLinePaint.setStrokeWidth(dp(polyLineWidth) / s.scale);
                    canvas.drawPath(pLine, polyLinePaint);
                }

                float sqSize = dp(5f) / s.scale;
                float dotRad = dp(4.5f) / s.scale;

                for (int i = 0; i < polyAnchors.size(); i++) {
                    PolyAnchorPoint pt = polyAnchors.get(i);

                    if (pt.hasHandles) {
                        canvas.drawLine(pt.x, pt.y, pt.hInX, pt.hInY, handleLinePaint);
                        canvas.drawLine(pt.x, pt.y, pt.hOutX, pt.hOutY, handleLinePaint);

                        canvas.drawRect(pt.hInX - sqSize, pt.hInY - sqSize, pt.hInX + sqSize, pt.hInY + sqSize, handleSquarePaint);
                        canvas.drawRect(pt.hInX - sqSize, pt.hInY - sqSize, pt.hInX + sqSize, pt.hInY + sqSize, handleSquareBorderPaint);

                        canvas.drawRect(pt.hOutX - sqSize, pt.hOutY - sqSize, pt.hOutX + sqSize, pt.hOutY + sqSize, handleSquarePaint);
                        canvas.drawRect(pt.hOutX - sqSize, pt.hOutY - sqSize, pt.hOutX + sqSize, pt.hOutY + sqSize, handleSquareBorderPaint);
                    }

                    canvas.drawCircle(pt.x, pt.y, dotRad, anchorCirclePaint);
                    canvas.drawCircle(pt.x, pt.y, dotRad, anchorCircleBorderPaint);
                }
            }

            if (showTransformControls && "move".equals(activeTool) && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                LayerItem al = s.layers.get(s.activeLayerIndex);
                if (isLayerEligibleForTransform(al)) {
                    float left = al.x, top = al.y;
                    float layerW = Math.max(dp(8), al.bitmap.getWidth() * al.scaleX);
                    float layerH = Math.max(dp(8), al.bitmap.getHeight() * al.scaleY);
                    float right = left + layerW;
                    float bottom = top + layerH;
                    float centerX = left + layerW / 2f;
                    float centerY = top + layerH / 2f;

                    canvas.save();
                    canvas.rotate(al.rotation, centerX, centerY);

                    canvas.drawRect(left, top, right, bottom, guidePaint);

                    float[][] handles = {
                            {left, top},
                            {(left + right) / 2, top},
                            {right, top},
                            {left, (top + bottom) / 2},
                            {(left + right) / 2, (top + bottom) / 2},
                            {right, (top + bottom) / 2},
                            {left, bottom},
                            {(left + right) / 2, bottom},
                            {right, bottom}
                    };

                    float handleSize = dp(7.5f) / s.scale;
                    for (int h = 0; h < 9; h++) {
                        float hx = handles[h][0], hy = handles[h][1];
                        canvas.drawRect(hx - handleSize / 2, hy - handleSize / 2, hx + handleSize / 2, hy + handleSize / 2, handlePaint);
                        canvas.drawRect(hx - handleSize / 2, hy - handleSize / 2, hx + handleSize / 2, hy + handleSize / 2, handleBorderPaint);
                    }

                    canvas.restore();
                }
            }

            canvas.restore();
        }

        @Override 
        public boolean onTouchEvent(MotionEvent event) {
            scaleDetector.onTouchEvent(event);

            ProjectTabSession s = getCurrentSession();
            if (s == null) return false;
            int action = event.getActionMasked();
            int pointerCount = event.getPointerCount();

            if (pointerCount >= 2) {
                isTwoFingerNavigating = true;
                isPotentialNewAnchor = false;
                float midX = (event.getX(0) + event.getX(1)) / 2f;
                float midY = (event.getY(0) + event.getY(1)) / 2f;

                if (action == MotionEvent.ACTION_MOVE && !scaleDetector.isInProgress()) {
                    float pDx = midX - lastMidX;
                    float pDy = midY - lastMidY;
                    s.panX += pDx;
                    s.panY += pDy;
                    invalidate();
                }
                lastMidX = midX;
                lastMidY = midY;
                return true;
            }

            if (isTwoFingerNavigating) {
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    isTwoFingerNavigating = false;
                }
                return true;
            }

            float curX = event.getX();
            float curY = event.getY();
            float cX = (curX - s.panX) / s.scale;
            float cY = (curY - s.panY) / s.scale;

            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    activePointerId = event.getPointerId(0);
                    lastTouchX = curX;
                    lastTouchY = curY;
                    initialDownX = curX;
                    initialDownY = curY;
                    selectedHandle = -1;
                    selectedCornerNode = -1;
                    selectedAnchorIndex = -1;
                    selectedHandleSide = 0;
                    isRotatingLayer = false;
                    isPotentialNewAnchor = false;
                    selectedStopRef = null;
                    isDraggingGradStart = false;
                    isDraggingGradEnd = false;
                    isDraggingNewGradLine = false;
                    isDraggingHandle = false;
                    isDraggingLayer = false;

                    // Fix: ১০-১২টি আর্টবোর্ডের যেকোনোটিতে টাচ করলে নিখুঁত ডিটেকশন (বর্ডার বা এক্সট্রা হাইলাইট ছাড়া)
                    float singleAbW = s.canvasWidth;
                    float gapAbW = dp(ARTBOARD_GAP_DP);
                    for (int ab = 0; ab < s.artboardCount; ab++) {
                        float abLeft = ab * (singleAbW + gapAbW);
                        float abRight = abLeft + singleAbW;
                        if (cX >= abLeft && cX <= abRight && cY >= 0 && cY <= s.canvasHeight) {
                            s.currentActiveArtboard = ab;
                            break;
                        }
                    }

                    if ("shape".equals(activeTool) && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        LayerItem al = s.layers.get(s.activeLayerIndex);
                        if (al.isShape && !al.isPolygonShape && al.isVisible) {
                            float left = al.x, top = al.y;
                            float right = al.x + (al.bitmap.getWidth() * al.scaleX);
                            float bottom = al.y + (al.bitmap.getHeight() * al.scaleY);
                            float nodeOffset = dp(10) / s.scale;
                            float hitDist = dp(24) / s.scale;

                            if (Math.hypot(cX - (left + nodeOffset), cY - (top + nodeOffset)) < hitDist) {
                                selectedCornerNode = 0; return true;
                            } else if (Math.hypot(cX - (right - nodeOffset), cY - (top + nodeOffset)) < hitDist) {
                                selectedCornerNode = 1; return true;
                            } else if (Math.hypot(cX - (right - nodeOffset), cY - (bottom - nodeOffset)) < hitDist) {
                                selectedCornerNode = 2; return true;
                            } else if (Math.hypot(cX - (left + nodeOffset), cY - (bottom - nodeOffset)) < hitDist) {
                                selectedCornerNode = 3; return true;
                            }
                        }
                    }

                    if ("shape".equals(activeTool) || "select_rect".equals(activeTool)) {
                        isDrawingShape = true;
                        shapeStartX = cX;
                        shapeStartY = cY;
                        shapeCurX = cX;
                        shapeCurY = cY;
                        invalidate();
                        return true;
                    }

                    if ("lasso".equals(activeTool) && (lassoSubTool == 3 || lassoSubTool == 4)) {
                        float hitDist = dp(20) / s.scale;
                        long now = System.currentTimeMillis();
                        boolean touchedExisting = false;

                        for (int pi = 0; pi < polyAnchors.size(); pi++) {
                            PolyAnchorPoint pt = polyAnchors.get(pi);
                            if (pt.hasHandles) {
                                if (Math.hypot(cX - pt.hInX, cY - pt.hInY) < hitDist) {
                                    selectedAnchorIndex = pi;
                                    selectedHandleSide = 1;
                                    touchedExisting = true;
                                    return true;
                                } else if (Math.hypot(cX - pt.hOutX, cY - pt.hOutY) < hitDist) {
                                    selectedAnchorIndex = pi;
                                    selectedHandleSide = 2;
                                    touchedExisting = true;
                                    return true;
                                }
                            }
                            if (Math.hypot(cX - pt.x, cY - pt.y) < hitDist) {
                                if (now - lastAnchorTapTime < 350 && lastAnchorTapIdx == pi) {
                                    pt.hasHandles = !pt.hasHandles;
                                    if (pt.hasHandles && pt.hInX == pt.x && pt.hInY == pt.y) {
                                        pt.hInX = pt.x - dp(26) / s.scale;
                                        pt.hInY = pt.y;
                                        pt.hOutX = pt.x + dp(26) / s.scale;
                                        pt.hOutY = pt.y;
                                    }
                                    lastAnchorTapTime = 0;
                                    lastAnchorTapIdx = -1;

                                    if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                                        LayerItem al = s.layers.get(s.activeLayerIndex);
                                        if (al.isPolygonShape) {
                                            al.polygonAnchors.clear();
                                            for (PolyAnchorPoint ap : polyAnchors) al.polygonAnchors.add(ap.copy());
                                            reRenderActivePolygonShapeLayer();
                                        }
                                    }

                                    invalidate();
                                    return true;
                                } else {
                                    lastAnchorTapTime = now;
                                    lastAnchorTapIdx = pi;
                                    selectedAnchorIndex = pi;
                                    selectedHandleSide = 0;
                                    touchedExisting = true;
                                    return true;
                                }
                            }
                        }

                        if (!touchedExisting) {
                            isPotentialNewAnchor = true;
                            return true;
                        }
                    }

                    if ("lasso".equals(activeTool) && lassoSubTool != 3 && lassoSubTool != 4) {
                        tempDrawPath.reset();
                        tempDrawPath.moveTo(cX, cY);
                        invalidate();
                        return true;
                    }

                    if ("gradient".equals(activeTool)) {
                        float hitDist = dp(20) / s.scale;
                        if (s.hasGradientLine && Math.hypot(cX - s.gradStartX, cY - s.gradStartY) < hitDist) {
                            isDraggingGradStart = true;
                            if (!s.gradStops.isEmpty()) {
                                s.activeGradStop = s.gradStops.get(0);
                                fgColor = s.activeGradStop.color;
                                updateSwatchPreviews();
                            }
                            invalidate();
                            return true;
                        }
                        if (s.hasGradientLine && Math.hypot(cX - s.gradEndX, cY - s.gradEndY) < hitDist) {
                            isDraggingGradEnd = true;
                            if (!s.gradStops.isEmpty()) {
                                s.activeGradStop = s.gradStops.get(s.gradStops.size() - 1);
                                fgColor = s.activeGradStop.color;
                                updateSwatchPreviews();
                            }
                            invalidate();
                            return true;
                        }
                        boolean hitStop = false;
                        if (s.hasGradientLine) {
                            for (int st = 0; st < s.gradStops.size(); st++) {
                                GradStop stop = s.gradStops.get(st);
                                float sx = s.gradStartX + (s.gradEndX - s.gradStartX) * stop.pos;
                                float sy = s.gradStartY + (s.gradEndY - s.gradStartY) * stop.pos;
                                if (Math.hypot(cX - sx, cY - sy) < hitDist) {
                                    selectedStopRef = stop;
                                    s.activeGradStop = stop;
                                    fgColor = stop.color;
                                    updateSwatchPreviews();
                                    invalidate();
                                    hitStop = true;
                                    return true;
                                }
                            }
                        }

                        if (!hitStop) {
                            s.hasGradientLine = true;
                            s.gradStartX = cX;
                            s.gradStartY = cY;
                            s.gradEndX = cX;
                            s.gradEndY = cY;
                            isDraggingNewGradLine = true;
                            invalidate();
                            return true;
                        }
                    }

                    if ("move".equals(activeTool) && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        LayerItem al = s.layers.get(s.activeLayerIndex);
                        if (isLayerEligibleForTransform(al)) {
                            float left = al.x, top = al.y;
                            float layerW = Math.max(dp(8), al.bitmap.getWidth() * al.scaleX);
                            float layerH = Math.max(dp(8), al.bitmap.getHeight() * al.scaleY);
                            float right = left + layerW;
                            float bottom = top + layerH;
                            float centerX = left + layerW / 2f;
                            float centerY = top + layerH / 2f;

                            double rad = Math.toRadians(-al.rotation);
                            float relX = cX - centerX;
                            float relY = cY - centerY;
                            float rotX = (float) (relX * Math.cos(rad) - relY * Math.sin(rad)) + centerX;
                            float rotY = (float) (relX * Math.sin(rad) + relY * Math.cos(rad)) + centerY;

                            float distToTL = (float) Math.hypot(rotX - left, rotY - top);
                            float rotateTriggerZone = dp(28) / s.scale;
                            if (distToTL < rotateTriggerZone && (rotX < left || rotY < top)) {
                                isRotatingLayer = true;
                                initialTouchAngle = (float) Math.toDegrees(Math.atan2(cY - centerY, cX - centerX));
                                initialLayerRotation = al.rotation;
                                return true;
                            }

                            float[][] handles = {
                                    {left, top},
                                    {(left + right) / 2, top},
                                    {right, top},
                                    {left, (top + bottom) / 2},
                                    {(left + right) / 2, (top + bottom) / 2},
                                    {right, (top + bottom) / 2},
                                    {left, bottom},
                                    {(left + right) / 2, bottom},
                                    {right, bottom}
                            };
                            float hitDist = dp(20) / s.scale;
                            for (int h = 0; h < 9; h++) {
                                if (h == 4) continue;
                                if (Math.hypot(rotX - handles[h][0], rotY - handles[h][1]) < hitDist) {
                                    selectedHandle = h;
                                    isDraggingHandle = true;
                                    handleInitialAspect = (al.scaleY != 0) ? (al.scaleX / al.scaleY) : 1.0f;
                                    return true;
                                }
                            }

                            if (!al.isLocked && rotX >= left && rotX <= right && rotY >= top && rotY <= bottom) {
                                isDraggingLayer = true;
                                return true;
                            }
                        }
                    }
                    break;

                case MotionEvent.ACTION_MOVE:
                    float dx = curX - lastTouchX;
                    float dy = curY - lastTouchY;
                    lastTouchX = curX;
                    lastTouchY = curY;

                    if (isPotentialNewAnchor && Math.hypot(curX - initialDownX, curY - initialDownY) > dp(6)) {
                        isPotentialNewAnchor = false;
                    }

                    if (isRotatingLayer && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        LayerItem al = s.layers.get(s.activeLayerIndex);
                        float centerX = al.x + (al.bitmap.getWidth() * al.scaleX) / 2f;
                        float centerY = al.y + (al.bitmap.getHeight() * al.scaleY) / 2f;
                        float curAngle = (float) Math.toDegrees(Math.atan2(cY - centerY, cX - centerX));
                        al.rotation = initialLayerRotation + (curAngle - initialTouchAngle);
                        invalidate();
                        return true;
                    }

                    if (selectedAnchorIndex != -1 && selectedAnchorIndex < polyAnchors.size()) {
                        PolyAnchorPoint ap = polyAnchors.get(selectedAnchorIndex);

                        if (selectedHandleSide == 2) {
                            ap.hOutX = cX;
                            ap.hOutY = cY;
                            float diffX = cX - ap.x;
                            float diffY = cY - ap.y;

                            if ("Symmetric".equalsIgnoreCase(anchorMode) || "Smooth".equalsIgnoreCase(anchorMode)) {
                                ap.hInX = ap.x - diffX;
                                ap.hInY = ap.y - diffY;
                            } else if ("Asymmetric".equalsIgnoreCase(anchorMode)) {
                                float lenOut = (float) Math.hypot(diffX, diffY);
                                if (lenOut > 0) {
                                    float curInLen = (float) Math.hypot(ap.hInX - ap.x, ap.hInY - ap.y);
                                    if (curInLen == 0) curInLen = lenOut;
                                    ap.hInX = ap.x - (diffX / lenOut) * curInLen;
                                    ap.hInY = ap.y - (diffY / lenOut) * curInLen;
                                }
                            }
                        } else if (selectedHandleSide == 1) {
                            ap.hInX = cX;
                            ap.hInY = cY;
                            float diffX = cX - ap.x;
                            float diffY = cY - ap.y;

                            if ("Symmetric".equalsIgnoreCase(anchorMode) || "Smooth".equalsIgnoreCase(anchorMode)) {
                                ap.hOutX = ap.x - diffX;
                                ap.hOutY = ap.y - diffY;
                            } else if ("Asymmetric".equalsIgnoreCase(anchorMode)) {
                                float lenIn = (float) Math.hypot(diffX, diffY);
                                if (lenIn > 0) {
                                    float curOutLen = (float) Math.hypot(ap.hOutX - ap.x, ap.hOutY - ap.y);
                                    if (curOutLen == 0) curOutLen = lenIn;
                                    ap.hOutX = ap.x - (diffX / lenIn) * curOutLen;
                                    ap.hOutY = ap.y - (diffY / lenIn) * curOutLen;
                                }
                            }
                        } else if (selectedHandleSide == 0) {
                            float shiftX = dx / s.scale;
                            float shiftY = dy / s.scale;
                            ap.x += shiftX;
                            ap.y += shiftY;
                            ap.hInX += shiftX;
                            ap.hInY += shiftY;
                            ap.hOutX += shiftX;
                            ap.hOutY += shiftY;
                        }

                        if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                            LayerItem al = s.layers.get(s.activeLayerIndex);
                            if (al.isPolygonShape) {
                                al.polygonAnchors.clear();
                                for (PolyAnchorPoint pAnchor : polyAnchors) al.polygonAnchors.add(pAnchor.copy());
                                reRenderActivePolygonShapeLayer();
                            }
                        }

                        invalidate();
                        return true;
                    }

                    if (selectedCornerNode != -1 && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        float delta = Math.abs(dx) + Math.abs(dy);
                        float step = (dx > 0 || dy > 0) ? delta / s.scale : -delta / s.scale;

                        if (selectedCornerNode == 0) shapeRadiusTL = Math.max(0, shapeRadiusTL + step);
                        else if (selectedCornerNode == 1) shapeRadiusTR = Math.max(0, shapeRadiusTR + step);
                        else if (selectedCornerNode == 2) shapeRadiusBR = Math.max(0, shapeRadiusBR + step);
                        else if (selectedCornerNode == 3) shapeRadiusBL = Math.max(0, shapeRadiusBL + step);

                        if (linkCorners) {
                            float master = (selectedCornerNode == 0) ? shapeRadiusTL : (selectedCornerNode == 1 ? shapeRadiusTR : (selectedCornerNode == 2 ? shapeRadiusBR : shapeRadiusBL));
                            shapeRadiusTL = shapeRadiusTR = shapeRadiusBR = shapeRadiusBL = master;
                        }
                        reRenderActiveShapeLayer();
                        updateOptionControlsBar();
                        return true;
                    }

                    if ("shape".equals(activeTool) || "select_rect".equals(activeTool)) {
                        shapeCurX = cX; shapeCurY = cY;
                        invalidate();
                        return true;
                    }

                    if ("lasso".equals(activeTool) && lassoSubTool != 3 && lassoSubTool != 4) {
                        tempDrawPath.lineTo(cX, cY);
                        invalidate();
                        return true;
                    }

                    // Fix: হাত ঘোরানোর সাথে সাথে আর্টবোর্ডের কালার 100% লাইভ চেঞ্জ হবে (ল্যাগ ছাড়া)
                    if ("gradient".equals(activeTool)) {
                        if (isDraggingNewGradLine) {
                            s.gradEndX = cX;
                            s.gradEndY = cY;
                            applyOnCanvasGradientToActiveLayer(false); // লাইভ প্রিভিউ (নো ল্যাগ)
                            invalidate();
                            return true;
                        } else if (isDraggingGradStart) {
                            s.gradStartX = cX; s.gradStartY = cY;
                            applyOnCanvasGradientToActiveLayer(false); // লাইভ প্রিভিউ (নো ল্যাগ)
                            invalidate();
                            return true;
                        } else if (isDraggingGradEnd) {
                            s.gradEndX = cX; s.gradEndY = cY;
                            applyOnCanvasGradientToActiveLayer(false); // লাইভ প্রিভিউ (নো ল্যাগ)
                            invalidate();
                            return true;
                        } else if (selectedStopRef != null) {
                            float lineLen = (float) Math.hypot(s.gradEndX - s.gradStartX, s.gradEndY - s.gradStartY);
                            if (lineLen > 0) {
                                float proj = ((cX - s.gradStartX) * (s.gradEndX - s.gradStartX) + (cY - s.gradStartY) * (s.gradEndY - s.gradStartY)) / (lineLen * lineLen);
                                selectedStopRef.pos = Math.max(0.0f, Math.min(1.0f, proj));
                                applyOnCanvasGradientToActiveLayer(false); // লাইভ প্রিভিউ (নো ল্যাগ)
                                invalidate();
                            }
                            return true;
                        }
                    }

                    if ("move".equals(activeTool)) {
                        if (isDraggingHandle && selectedHandle != -1 && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                            LayerItem al = s.layers.get(s.activeLayerIndex);
                            if (!al.isLocked && isLayerEligibleForTransform(al)) {
                                float bmpW = Math.max(10f, al.bitmap.getWidth());
                                float bmpH = Math.max(10f, al.bitmap.getHeight());

                                boolean isLine = (al.isShape && "line".equals(al.shapeType));
                                boolean lockRatio = (maintainAspectRatio || (al.isShape && shapeLock)) && !isLine;

                                switch (selectedHandle) {
                                    case 8:
                                        al.scaleX = Math.max(0.08f, al.scaleX + (dx / s.scale / bmpW));
                                        if (lockRatio) al.scaleY = al.scaleX / handleInitialAspect;
                                        else if (!isLine) al.scaleY = Math.max(0.08f, al.scaleY + (dy / s.scale / bmpH));
                                        break;
                                    case 0:
                                        float dScaleX0 = -(dx / s.scale / bmpW);
                                        float dScaleY0 = isLine ? 0 : -(dy / s.scale / bmpH);
                                        al.scaleX = Math.max(0.08f, al.scaleX + dScaleX0);
                                        if (!isLine) al.scaleY = Math.max(0.08f, lockRatio ? (al.scaleX / handleInitialAspect) : (al.scaleY + dScaleY0));
                                        al.x += dx / s.scale;
                                        if (!isLine) al.y += dy / s.scale;
                                        break;
                                    case 2:
                                        al.scaleX = Math.max(0.08f, al.scaleX + (dx / s.scale / bmpW));
                                        if (lockRatio) al.scaleY = al.scaleX / handleInitialAspect;
                                        else if (!isLine) al.scaleY = Math.max(0.08f, al.scaleY - (dy / s.scale / bmpH));
                                        if (!isLine) al.y += dy / s.scale;
                                        break;
                                    case 6:
                                        al.scaleX = Math.max(0.08f, al.scaleX - (dx / s.scale / bmpW));
                                        if (lockRatio) al.scaleY = al.scaleX / handleInitialAspect;
                                        else if (!isLine) al.scaleY = Math.max(0.08f, al.scaleY + (dy / s.scale / bmpH));
                                        al.x += dx / s.scale;
                                        break;
                                    case 1:
                                        if (!isLine) {
                                            al.scaleY = Math.max(0.08f, al.scaleY - (dy / s.scale / bmpH));
                                            if (lockRatio) al.scaleX = al.scaleY * handleInitialAspect;
                                            al.y += dy / s.scale;
                                        }
                                        break;
                                    case 7:
                                        if (!isLine) {
                                            al.scaleY = Math.max(0.08f, al.scaleY + (dy / s.scale / bmpH));
                                            if (lockRatio) al.scaleX = al.scaleY * handleInitialAspect;
                                        }
                                        break;
                                    case 3:
                                        al.scaleX = Math.max(0.08f, al.scaleX - (dx / s.scale / bmpW));
                                        if (lockRatio) al.scaleY = al.scaleX / handleInitialAspect;
                                        al.x += dx / s.scale;
                                        break;
                                    case 5:
                                        al.scaleX = Math.max(0.08f, al.scaleX + (dx / s.scale / bmpW));
                                        if (lockRatio) al.scaleY = al.scaleX / handleInitialAspect;
                                        break;
                                }
                                al.isDirty = true;
                                invalidate();
                            }
                        } else if (isDraggingLayer && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                            LayerItem al = s.layers.get(s.activeLayerIndex);
                            if (!al.isLocked && isLayerEligibleForTransform(al)) {
                                float targetX = al.x + dx / s.scale;
                                float targetY = al.y + dy / s.scale;
                                al.x = snapPositionX(targetX, al.bitmap.getWidth() * al.scaleX, s);
                                al.y = snapPositionY(targetY, al.bitmap.getHeight() * al.scaleY, s);
                                al.isDirty = true;
                                invalidate();
                            }
                        } else if (!scaleDetector.isInProgress()) {
                            s.panX += dx; s.panY += dy;
                            invalidate();
                        }
                    }
                    break;

                case MotionEvent.ACTION_POINTER_UP:
                    int pIndex = event.getActionIndex();
                    int pId = event.getPointerId(pIndex);
                    if (pId == activePointerId) {
                        int newPIndex = (pIndex == 0) ? 1 : 0;
                        lastTouchX = event.getX(newPIndex);
                        lastTouchY = event.getY(newPIndex);
                        activePointerId = event.getPointerId(newPIndex);
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activePointerId = -1;
                    selectedStopRef = null;
                    selectedCornerNode = -1;
                    selectedAnchorIndex = -1;
                    selectedHandleSide = 0;
                    isRotatingLayer = false;

                    if (isPotentialNewAnchor && !isTwoFingerNavigating && "lasso".equals(activeTool) && (lassoSubTool == 3 || lassoSubTool == 4)) {
                        if (Math.hypot(curX - initialDownX, curY - initialDownY) < dp(6)) {
                            PolyAnchorPoint newPt = new PolyAnchorPoint(cX, cY);
                            polyAnchors.add(newPt);

                            if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                                LayerItem al = s.layers.get(s.activeLayerIndex);
                                if (al.isPolygonShape) {
                                    al.polygonAnchors.add(newPt.copy());
                                    reRenderActivePolygonShapeLayer();
                                }
                            }
                            invalidate();
                        }
                    }
                    isPotentialNewAnchor = false;

                    // Fix: হাত তুলে নিলে মাত্র ১ বার ফাইনাল থাম্বনেইল রেন্ডার ও হিস্ট্রি সেভ হবে
                    if ("gradient".equals(activeTool) && (isDraggingGradStart || isDraggingGradEnd || isDraggingNewGradLine)) {
                        applyOnCanvasGradientToActiveLayer(true);
                        updateLayersDockUI();
                        recordHistory();
                    }

                    if ("move".equals(activeTool) && (isDraggingLayer || isDraggingHandle || isRotatingLayer)) {
                        recordHistory();
                    }

                    isDraggingGradStart = false;
                    isDraggingGradEnd = false;
                    isDraggingNewGradLine = false;
                    isDraggingHandle = false;
                    isDraggingLayer = false;

                    if (isDrawingShape && "shape".equals(activeTool)) {
                        isDrawingShape = false;
                        float sw = Math.abs(shapeCurX - shapeStartX);
                        float sh = Math.abs(shapeCurY - shapeStartY);

                        if (shapeLock) {
                            float side = Math.max(sw, sh);
                            sw = side;
                            sh = side;
                        }

                        float sx = (shapeCurX >= shapeStartX) ? shapeStartX : (shapeStartX - sw);
                        float sy = (shapeCurY >= shapeStartY) ? shapeStartY : (shapeStartY - sh);

                        if (sw > 10 || sh > 10) {
                            createShapeLayerFromBounds(sx, sy, Math.max(10, sw), Math.max(10, sh));
                        }
                        invalidate();
                    } else if (isDrawingShape && "select_rect".equals(activeTool)) {
                        isDrawingShape = false;
                        float left = Math.min(shapeStartX, shapeCurX);
                        float top = Math.min(shapeStartY, shapeCurY);
                        float right = Math.max(shapeStartX, shapeCurX);
                        float bottom = Math.max(shapeStartY, shapeCurY);

                        if (right > left && bottom > top) {
                            Path newP = new Path();
                            newP.addRect(left, top, right, bottom, Path.Direction.CW);
                            if (activeSelectionPath == null || selectionMode == 0) activeSelectionPath = newP;
                            else if (selectionMode == 1) activeSelectionPath.op(newP, Path.Op.UNION);
                            else if (selectionMode == 2) activeSelectionPath.op(newP, Path.Op.DIFFERENCE);

                            selectionBounds = new RectF();
                            activeSelectionPath.computeBounds(selectionBounds, true);
                            if (selectionBounds.isEmpty()) {
                                activeSelectionPath = null;
                                selectionBounds = null;
                            }
                            recordHistory();
                        }
                        invalidate();
                    } else if ("lasso".equals(activeTool) && (lassoSubTool == 0 || lassoSubTool == 1 || lassoSubTool == 2)) {
                        tempDrawPath.close();
                        if (activeSelectionPath == null || selectionMode == 0) activeSelectionPath = new Path(tempDrawPath);
                        else if (selectionMode == 1 || lassoSubTool == 1) activeSelectionPath.op(tempDrawPath, Path.Op.UNION);
                        else if (selectionMode == 2 || lassoSubTool == 2) activeSelectionPath.op(tempDrawPath, Path.Op.DIFFERENCE);

                        selectionBounds = new RectF();
                        activeSelectionPath.computeBounds(selectionBounds, true);
                        if (selectionBounds.isEmpty()) {
                            activeSelectionPath = null;
                            selectionBounds = null;
                        }
                        tempDrawPath.reset();
                        recordHistory();
                        invalidate();
                    }
                    selectedHandle = -1;
                    break;
            }
            return true;
        }
    }
}