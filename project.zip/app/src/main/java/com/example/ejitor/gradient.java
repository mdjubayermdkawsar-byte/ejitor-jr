package com.example.ejitor;

import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class gradient {

    // popup.java-এর রিফ্লেকশন সাপোর্টের জন্য পাবলিক ফিল্ড
    public static class NamedGradient {
        public String name;
        public int[] colors;

        public NamedGradient(String name, int[] colors) {
            this.name = name;
            this.colors = colors;
        }

        public String getName() {
            return name;
        }

        public int[] getColors() {
            return colors;
        }
    }

    public static final List<NamedGradient> namedTemplates = new ArrayList<>();
    public static final List<int[]> templates = new ArrayList<>();

    static {
        initAllTemplates();
    }

    public static synchronized List<NamedGradient> getNamedTemplates() {
        if (namedTemplates.isEmpty()) {
            initAllTemplates();
        }
        return namedTemplates;
    }

    public static synchronized List<int[]> getTemplates() {
        if (templates.isEmpty()) {
            initAllTemplates();
        }
        return templates;
    }

    /**
     * নাম দিয়ে সরাসরি গ্রেডিয়েন্ট সার্চ করার মেথড
     */
    public static List<NamedGradient> search(String query) {
        if (query == null || query.trim().isEmpty()) {
            return getNamedTemplates();
        }
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<NamedGradient> results = new ArrayList<>();
        for (NamedGradient ng : getNamedTemplates()) {
            if (ng.name.toLowerCase(Locale.ROOT).contains(q)) {
                results.add(ng);
            }
        }
        return results;
    }

    private static int c(String hex) {
        return Color.parseColor(hex);
    }

    private static void addNamed(String name, String... hexes) {
        int[] colors = new int[hexes.length];
        for (int i = 0; i < hexes.length; i++) {
            colors[i] = c(hexes[i]);
        }
        namedTemplates.add(new NamedGradient(name, colors));
        templates.add(colors);
    }

    private static void addGenerated(String name, int[] colors) {
        namedTemplates.add(new NamedGradient(name, colors));
        templates.add(colors);
    }

    private static void initAllTemplates() {
        namedTemplates.clear();
        templates.clear();

        // =====================================================================
        // ১. আইকনিক হ্যান্ডক্র্যাফটেড মাস্টারপিস গ্রেডিয়েন্ট (২৪টি বিশেষ প্রিসেট)
        // =====================================================================
        addNamed("24K Luxury Gold", "#BF953F", "#FCF6BA", "#B38728", "#FBF5B7", "#AA771C"); // ৫ স্টপ
        addNamed("Rainbow Prism", "#FF0000", "#FF7F00", "#FFFF00", "#00FF00", "#0000FF", "#4B0082", "#9400D3"); // ৭ স্টপ
        addNamed("Ultra Hologram", "#FF9A9E", "#FECFEF", "#A1C4FD", "#C2E9FB", "#E2D1C3", "#FDFCFB", "#D4FC79", "#96E6A1", "#84FAB0", "#8FD3F4", "#F6D365", "#FDA085", "#FEE140", "#FA709A", "#FF0844"); // ১৫ স্টপ
        addNamed("Holographic Silk", "#FEE140", "#FA709A", "#FF007F", "#7928CA", "#00DFD8", "#00F2FE", "#4FACFE", "#43E97B", "#38F9D7"); // ৯ স্টপ
        addNamed("Cyberpunk Neon", "#00F2FE", "#4FACFE", "#F355DA"); // ৩ স্টপ
        addNamed("Sunset Glow", "#FA709A", "#FEE140", "#FF5E62", "#FFD166"); // ৪ স্টপ
        addNamed("Warm Flame", "#FF1238", "#FF5E62", "#FF8C00"); // ৩ স্টপ
        addNamed("Miami Nights", "#00DBDE", "#FC00FF", "#711C91"); // ৩ স্টপ
        addNamed("Deep Ocean Lagoon", "#000428", "#004E92", "#00C6FF", "#0072FF"); // ৪ স্টপ
        addNamed("Emerald Forest", "#053823", "#0BA360", "#3CBA92", "#A8E063"); // ৪ স্টপ
        addNamed("Blood Orange Dusk", "#870000", "#FF416C", "#FF4B2B"); // ৩ স্টপ
        addNamed("Neon Violet", "#1565C0", "#B92B27", "#F107A3"); // ৩ স্টপ
        addNamed("Cosmic Dust", "#0F0C29", "#302B63", "#24243E", "#8E2DE2", "#F000FF"); // ৫ স্টপ
        addNamed("Cotton Candy Dreams", "#FFAFBD", "#FFC3A0", "#FBC2EB", "#A6C1EE"); // ৪ স্টপ
        addNamed("Bubblegum Pop", "#F78CA0", "#F9748F", "#FD868C", "#FE9A8B"); // ৪ স্টপ
        addNamed("Arctic Iceberg", "#E0EAFC", "#CFDEF3", "#89F7FE", "#66A6FF"); // ৪ স্টপ
        addNamed("Polished Titanium", "#292E49", "#536976", "#BBD2C5", "#536976", "#292E49"); // ৫ স্টপ
        addNamed("Imperial Amethyst", "#360033", "#0B8793", "#61045F", "#AA076B"); // ৪ স্টপ
        addNamed("Solar Flare", "#F857A6", "#FF5858", "#FFCC00"); // ৩ স্টপ
        addNamed("Citrus Burst", "#FDC830", "#F37335", "#FF5E62"); // ৩ স্টপ
        addNamed("Midnight Ocean", "#0F2027", "#203A43", "#2C5364"); // ৩ স্টপ
        addNamed("Fresh Grass", "#11998E", "#38EF7D", "#A8E063"); // ৩ স্টপ
        addNamed("Dark Aurora", "#1F4037", "#99F2C8", "#00C9FF"); // ৩ স্টপ
        addNamed("Pure Platinum", "#D3CCE3", "#E9E4F0", "#FFFFFF", "#E9E4F0", "#D3CCE3"); // ৫ স্টপ

        // =====================================================================
        // ২. মাস্টার স্টুডিও লাইব্রেরি (১,০৮৮টি ইউনিক কালার ও নামের গ্রেডিয়েন্ট)
        // মোট হবে: ২৪ + ১,০৮৮ = ১,১১২টি টেমপ্লেট (১০০০+ এর বেশি)
        // =====================================================================
        buildStudioLibrary();
    }

    private static void buildStudioLibrary() {
        final String[] prefixes = {
                "Vibrant", "Deep", "Celestial", "Luminous", "Royal", "Velvet", "Electric", "Mystic",
                "Golden", "Cosmic", "Ethereal", "Radiant", "Shadow", "Glacial", "Imperial", "Neon",
                "Prismatic", "Pure", "Twilight", "Aurora", "Infinite", "Silken", "Blazing", "Crystal",
                "Subtle", "Hyper", "Midnight", "Amber", "Emerald", "Solar", "Oceanic", "Starlight"
        }; // ৩২টি প্রিফিক্স

        final String[] bases = {
                "Sunset", "Ocean", "Nebula", "Horizon", "Lagoon", "Firefly", "Amethyst", "Galaxy",
                "Flame", "Sapphire", "Breeze", "Mirage", "Forest", "Citrus", "Chrome", "Canopy",
                "Eclipse", "Ruby", "Pastel", "Dusk", "Dawn", "Hologram", "Blossom", "Meadow",
                "Obsidian", "Topaz", "Tide", "Opal", "Spectrum", "Zenith", "Cascade", "Pulse",
                "Vortex", "Prism"
        }; // ৩৪টি বেস নাম

        // ৩২ x ৩৪ = ১,০৮৮টি সম্পূর্ণ স্বতন্ত্র নাম

        // ২, ৩, ৪, ৫, ৬, ৭, ৮, ৯, ১০, ১২, ১৫ স্টপের সুষম প্যাটার্ন
        final int[] stopPattern = {
                3, 4, 5, 2, 8, 4, 3, 6, 5, 9,
                4, 3, 7, 5, 12, 4, 3, 8, 5, 15,
                2, 4, 6, 5, 3, 8, 4, 9, 5, 3,
                7, 4, 10, 5
        };

        for (int pIdx = 0; pIdx < prefixes.length; pIdx++) {
            String prefix = prefixes[pIdx];

            for (int bIdx = 0; bIdx < bases.length; bIdx++) {
                String base = bases[bIdx];
                String fullName = prefix + " " + base;

                int stops = stopPattern[bIdx % stopPattern.length];

                // বিশেষ কিছু ক্যাটাগরিতে হাই-স্টপ (৮, ৯, ১২, ১৫ কালার) দেওয়া
                if ("Spectrum".equals(base) || "Hologram".equals(base) || "Prism".equals(base)) {
                    stops = (pIdx % 2 == 0) ? 9 : 15;
                } else if ("Prismatic".equals(prefix) || "Infinite".equals(prefix) || "Aurora".equals(prefix)) {
                    stops = (bIdx % 2 == 0) ? 8 : 12;
                } else if ("Subtle".equals(prefix) || "Pure".equals(prefix)) {
                    stops = (bIdx % 2 == 0) ? 2 : 3;
                }

                int[] colors = generateHarmoniousColors(pIdx, bIdx, prefix, base, stops);
                addGenerated(fullName, colors);
            }
        }
    }

    /**
     * কালার থিওরি মেনে ২ থেকে ১৫ স্টপের আকর্ষণীয় কালার প্যালেট জেনারেটর
     */
    private static int[] generateHarmoniousColors(int pIdx, int bIdx, String prefix, String base, int stops) {
        int[] palette = new int[stops];
        float baseHue;

        // বেস নাম অনুযায়ী মূল হিউ (Hue) নির্বাচন
        if ("Sunset".equals(base) || "Flame".equals(base) || "Dusk".equals(base) || "Dawn".equals(base) || "Citrus".equals(base)) {
            baseHue = 12f + (pIdx * 5f); // লাল, কমলা, গোল্ডেন, পিচ
        } else if ("Ocean".equals(base) || "Lagoon".equals(base) || "Breeze".equals(base) || "Tide".equals(base) || "Glacial".equals(prefix)) {
            baseHue = 185f + (pIdx * 4f); // সিয়ান, অ্যাকোয়া, ডিপ ব্লু
        } else if ("Forest".equals(base) || "Meadow".equals(base) || "Canopy".equals(base) || "Firefly".equals(base) || "Emerald".equals(prefix)) {
            baseHue = 95f + (pIdx * 5f); // লাইম, এমারেল্ড, মিন্ট
        } else if ("Nebula".equals(base) || "Galaxy".equals(base) || "Eclipse".equals(base) || "Obsidian".equals(base) || "Vortex".equals(base)) {
            baseHue = 265f + (pIdx * 5f); // ইন্ডিগো, ডিপ স্পেস পার্পল, মেজেন্টা
        } else if ("Amethyst".equals(base) || "Ruby".equals(base) || "Sapphire".equals(base) || "Topaz".equals(base)) {
            baseHue = 295f + (pIdx * 6f); // রয়্যাল জুয়েল টোন
        } else if ("Pastel".equals(base) || "Blossom".equals(base) || "Mirage".equals(base)) {
            baseHue = 330f + (pIdx * 4f); // সফট গোলাপি, ল্যাভেন্ডার
        } else {
            baseHue = (pIdx * 11.25f + bIdx * 8f) % 360f; // ফুল স্পেকট্রাম
        }

        boolean isRainbow = "Spectrum".equals(base) || "Hologram".equals(base) || "Prism".equals(base) || "Prismatic".equals(prefix);
        boolean isMetallic = "Chrome".equals(base) || "Gold".equals(prefix) || "Golden".equals(prefix) || "Imperial".equals(prefix);
        boolean isDark = "Deep".equals(prefix) || "Shadow".equals(prefix) || "Midnight".equals(prefix) || "Obsidian".equals(base);

        for (int k = 0; k < stops; k++) {
            float t = (float) k / (float) Math.max(1, stops - 1);
            float h, s, v;

            if (isRainbow) {
                // ৮, ৯, ১২ ও ১৫ স্টপের ফুল রেইনবো / হলোগ্রাফিক সাইকেল
                h = (baseHue + (360f / stops) * k) % 360f;
                s = 0.70f + 0.25f * (float) Math.sin(t * Math.PI);
                v = 0.95f;
            } else if (isMetallic) {
                // মেটালিক স্পেকুলার হাইলাইট (মাঝে উজ্জ্বল গ্লেসি রিফ্লেকশন)
                h = baseHue;
                float shine = (float) Math.sin(t * Math.PI);
                s = Math.max(0.15f, 0.85f - (shine * 0.70f)); // শাইনের জায়গায় স্যাচুরেশন কমে হোয়াইটিশ হবে
                v = Math.min(1.0f, 0.45f + (shine * 0.55f));  // শাইনের জায়গায় ভ্যালু বেড়ে আলো ছড়াবে
            } else if (isDark) {
                // ডার্ক ও অমোলেড ডিপ স্পেস কালার
                h = (baseHue + (t * 40f)) % 360f;
                s = 0.85f;
                v = Math.max(0.12f, 0.15f + (t * 0.55f));
            } else {
                // স্মুথ এনালগাস ব্লেন্ড
                h = (baseHue + (t * 55f)) % 360f;
                s = 0.75f + (0.20f * (float) Math.sin(t * Math.PI));
                v = 0.85f + (0.15f * (float) Math.cos(t * Math.PI * 0.5f));
            }

            palette[k] = Color.HSVToColor(new float[]{h, Math.max(0.05f, Math.min(1f, s)), Math.max(0.1f, Math.min(1f, v))});
        }

        return palette;
    }
}