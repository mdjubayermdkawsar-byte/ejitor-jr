package com.example.ejitor;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class editor_4 {

    private EditorActivity activity;
    private final ExecutorService blurExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger taskCounter = new AtomicInteger(0);

    // ২০টি নির্দিষ্ট ব্লার মোড
    private final String[] blurModes = {
            "1. Gaussian Blur",
            "2. Moving Blur",
            "3. Zooming Blur",
            "4. Spin Blur",
            "5. Lens Blur (Bokeh)",
            "6. Unsharp Mask",
            "7. Frosted Glass (Normal)",
            "8. Frosted Glass (Zooming)",
            "9. Frosted Glass (Moving)",
            "10. Mosaic / Pixelate",
            "11. Box Blur",
            "12. Surface Blur",
            "13. Smart Blur",
            "14. Tilt-Shift Blur",
            "15. Radial Blur",
            "16. Cross Blur",
            "17. Soft Focus Blur",
            "18. Glow Blur",
            "19. Average Blur",
            "20. Median Blur"
    };

    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        hookFilterMenu();
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    // --- রিফ্লেকশন মেথডসমূহ ---
    private void invokePrivateMethod(EditorActivity act, String name) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    private void invokePrivateSessionMethod(EditorActivity act, String name, EditorActivity.ProjectTabSession s) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name, EditorActivity.ProjectTabSession.class);
            m.setAccessible(true);
            m.invoke(act, s);
        } catch (Exception ignored) {}
    }

    // ১. Filter মেনু হুক
    private void hookFilterMenu() {
        if (activity == null || activity.menuContainer == null) return;

        for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
            View child = activity.menuContainer.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if ("Filter".equalsIgnoreCase(tv.getText().toString().trim())) {
                    tv.setOnClickListener(this::showFilterMenuDropdown);
                    break;
                }
            }
        }
    }

    private void showFilterMenuDropdown(View anchor) {
        final PopupWindow popup = new PopupWindow(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(8), dp(6), dp(8), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        layout.setBackground(bg);

        TextView blurItem = new TextView(activity);
        blurItem.setText("Blur");
        blurItem.setTextColor(Color.WHITE);
        blurItem.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        blurItem.setPadding(dp(14), dp(8), dp(14), dp(8));

        blurItem.setOnClickListener(v -> {
            popup.dismiss();
            openImage2StyleBlurDialog();
        });

        layout.addView(blurItem);
        popup.setContentView(layout);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    // ২. ক্লোজ আইকন
    private BitmapDrawable createVectorCloseIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    // ৩. ব্লার ডায়ালগ (প্রতেকটা ব্লারে Transform 0-1000px স্লাইডার সহ)
    private void openImage2StyleBlurDialog() {
        final EditorActivity.ProjectTabSession session = activity.getCurrentSession();
        if (session == null || session.layers.isEmpty() || session.activeLayerIndex < 0 || session.activeLayerIndex >= session.layers.size()) {
            Toast.makeText(activity, "Please select an active layer first", Toast.LENGTH_SHORT).show();
            return;
        }

        final EditorActivity.LayerItem[] targetLayer = new EditorActivity.LayerItem[]{session.layers.get(session.activeLayerIndex)};
        final Bitmap[] originalBitmap = new Bitmap[]{targetLayer[0].bitmap != null ? targetLayer[0].bitmap.copy(Bitmap.Config.ARGB_8888, true) : null};
        final float[] origX = new float[]{targetLayer[0].x};
        final float[] origY = new float[]{targetLayer[0].y};

        if (originalBitmap[0] == null) {
            Toast.makeText(activity, "Active layer has no image content to blur", Toast.LENGTH_SHORT).show();
            return;
        }

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL); // জুম ও প্যান অক্ষত
            dialog.getWindow().setGravity(Gravity.CENTER);
        }

        final WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(320), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(18));

        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setColor(Color.parseColor("#1C1C1C"));
        rootBg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        rootBg.setCornerRadius(dp(12));
        root.setBackground(rootBg);

        // হেডার
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(14));

        TextView titleTv = new TextView(activity);
        titleTv.setText("Blur Filter");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createVectorCloseIcon());
        header.addView(closeX);
        root.addView(header);

        header.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX() - lp.x;
                        startY = event.getRawY() - lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = (int) (event.getRawX() - startX);
                        lp.y = (int) (event.getRawY() - startY);
                        dialog.getWindow().setAttributes(lp);
                        return true;
                }
                return false;
            }
        });

        final int[] currentModeIndex = {0};
        final float[] p = new float[]{25f, 0f, 0f, 0f};
        final float[] transformPad = new float[]{0f}; // প্রতিটি ব্লারে ট্রান্সফর্ম প্যাডিং (০-১০০০ px)

        LinearLayout typeRow = new LinearLayout(activity);
        typeRow.setOrientation(LinearLayout.HORIZONTAL);
        typeRow.setGravity(Gravity.CENTER_VERTICAL);
        typeRow.setPadding(0, 0, 0, dp(14));

        TextView typeLabel = new TextView(activity);
        typeLabel.setText("Type:");
        typeLabel.setTextColor(Color.parseColor("#AAAAAA"));
        typeLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        typeLabel.setLayoutParams(new LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT));
        typeRow.addView(typeLabel);

        final LinearLayout typeDropdownBtn = new LinearLayout(activity);
        typeDropdownBtn.setOrientation(LinearLayout.HORIZONTAL);
        typeDropdownBtn.setGravity(Gravity.CENTER_VERTICAL);
        typeDropdownBtn.setPadding(dp(10), dp(7), dp(10), dp(7));

        GradientDrawable dropBg = new GradientDrawable();
        dropBg.setColor(Color.parseColor("#121212"));
        dropBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        dropBg.setCornerRadius(dp(4));
        typeDropdownBtn.setBackground(dropBg);
        typeDropdownBtn.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView typeText = new TextView(activity);
        typeText.setText(blurModes[currentModeIndex[0]]);
        typeText.setTextColor(Color.WHITE);
        typeText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        typeText.setSingleLine(true);
        typeText.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        typeDropdownBtn.addView(typeText);

        TextView typeArrow = new TextView(activity);
        typeArrow.setText("v");
        typeArrow.setTextColor(Color.parseColor("#888888"));
        typeDropdownBtn.addView(typeArrow);

        typeRow.addView(typeDropdownBtn);
        root.addView(typeRow);

        ScrollView sliderScroll = new ScrollView(activity);
        sliderScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)));
        sliderScroll.setVerticalScrollBarEnabled(false);

        final LinearLayout paramsContainer = new LinearLayout(activity);
        paramsContainer.setOrientation(LinearLayout.VERTICAL);
        sliderScroll.addView(paramsContainer);
        root.addView(sliderScroll);

        // লাইভ প্রিভিউ লুপ (Transform স্লাইডার দিয়ে বাউন্ডারি বাড়িয়ে ব্লার প্রকাশ করা)
        final Runnable triggerPreview = () -> {
            EditorActivity.ProjectTabSession s = activity.getCurrentSession();
            if (s != null && s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                EditorActivity.LayerItem active = s.layers.get(s.activeLayerIndex);
                if (active != targetLayer[0]) {
                    targetLayer[0] = active;
                    originalBitmap[0] = active.bitmap != null ? active.bitmap.copy(Bitmap.Config.ARGB_8888, true) : null;
                    origX[0] = active.x;
                    origY[0] = active.y;
                }
            }

            if (originalBitmap[0] == null || originalBitmap[0].isRecycled()) return;

            final int mode = currentModeIndex[0];
            final float p0 = p[0], p1 = p[1], p2 = p[2], p3 = p[3];
            final int pad = Math.max(0, Math.min(1000, (int) transformPad[0]));
            final Bitmap baseSnapshot = originalBitmap[0];

            final int currentId = taskCounter.incrementAndGet();
            blurExecutor.execute(() -> {
                if (currentId != taskCounter.get()) return;

                Bitmap inputBmp = null;
                try {
                    // ট্রান্সফর্ম স্লাইডার অনুযায়ী প্যাডিং দিয়ে ক্যানভাস বড় করা (যাতে ব্লার না কাটে)
                    if (pad > 0) {
                        inputBmp = Bitmap.createBitmap(baseSnapshot.getWidth() + pad * 2, baseSnapshot.getHeight() + pad * 2, Bitmap.Config.ARGB_8888);
                        Canvas pc = new Canvas(inputBmp);
                        pc.drawBitmap(baseSnapshot, pad, pad, null);
                    } else {
                        inputBmp = baseSnapshot.copy(Bitmap.Config.ARGB_8888, true);
                    }
                } catch (OutOfMemoryError oom) {
                    System.gc();
                    return;
                }

                Bitmap result = AllBlurProcessors.applyBlurAdvanced(inputBmp, mode, p0, p1, p2, p3);
                if (inputBmp != result && !inputBmp.isRecycled()) {
                    inputBmp.recycle();
                }

                if (currentId == taskCounter.get() && result != null) {
                    activity.runOnUiThread(() -> {
                        if (currentId == taskCounter.get() && targetLayer[0] != null) {
                            targetLayer[0].bitmap = result;
                            targetLayer[0].x = origX[0] - (pad * targetLayer[0].scaleX);
                            targetLayer[0].y = origY[0] - (pad * targetLayer[0].scaleY);
                            if (activity.canvasView != null) activity.canvasView.invalidate();
                        }
                    });
                }
            });
        };

        // প্রতিটি ব্লারে সংশ্লিষ্ট সেটিংস এবং সর্বশেষে "Transform (0-1000px)" স্লাইডার রিবিল্ড
        final Runnable rebuildParamsUI = () -> {
            paramsContainer.removeAllViews();
            int mode = currentModeIndex[0];

            switch (mode) {
                case 1: // Moving Blur (Strength, Direction)
                    p[0] = 30f; p[1] = 0f;
                    paramsContainer.addView(createSliderRow("Strength:", 0, 300, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Direction:", 0, 360, (int) p[1], "°", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 2: // Zooming Blur (Strength, Center Radius)
                    p[0] = 60f; p[1] = 50f;
                    paramsContainer.addView(createSliderRow("Strength:", 0, 100, (int) p[0], "", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Center Radius:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 3: // Spin Blur (Strength, Inner Radius)
                    p[0] = 70f; p[1] = 20f;
                    paramsContainer.addView(createSliderRow("Strength:", 0, 100, (int) p[0], "", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Inner Radius:", 0, 80, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 4: // Lens Blur (Bokeh) (Radius, Brightness, Direction)
                    p[0] = 30f; p[1] = 50f; p[2] = 0f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 200, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Brightness:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Direction:", 0, 360, (int) p[2], "°", val -> { p[2] = val; triggerPreview.run(); }));
                    break;
                case 5: // Unsharp Mask (Radius, Strength)
                    p[0] = 4f; p[1] = 180f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 100, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Strength:", 0, 300, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 6: // Frosted Glass (Normal)
                    p[0] = 10f; p[1] = 80f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 100, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Variance:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 7: // Frosted Glass (Zooming)
                    p[0] = 50f; p[1] = 30f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 200, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Center Radius:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 8: // Frosted Glass (Moving)
                    p[0] = 60f; p[1] = 0f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 200, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Direction:", 0, 360, (int) p[1], "°", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 9: // Mosaic
                    p[0] = 15f;
                    paramsContainer.addView(createSliderRow("Width:", 1, 200, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    break;
                case 11: 
                case 12: // Surface / Smart Blur
                    p[0] = 25f; p[1] = 40f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 200, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Threshold:", 1, 100, (int) p[1], "", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 13: // Tilt-Shift Blur
                    p[0] = 35f; p[1] = 50f; p[2] = 30f;
                    paramsContainer.addView(createSliderRow("Blur Radius:", 0, 300, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Focus Position:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Focus Width:", 10, 100, (int) p[2], "%", val -> { p[2] = val; triggerPreview.run(); }));
                    break;
                case 15: // Cross Blur
                    p[0] = 30f; p[1] = 30f;
                    paramsContainer.addView(createSliderRow("Horizontal:", 0, 300, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Vertical:", 0, 300, (int) p[1], "px", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                case 17: // Glow Blur
                    p[0] = 50f; p[1] = 75f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 500, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    paramsContainer.addView(createSliderRow("Intensity:", 0, 100, (int) p[1], "%", val -> { p[1] = val; triggerPreview.run(); }));
                    break;
                default: 
                    p[0] = 25f;
                    paramsContainer.addView(createSliderRow("Radius:", 0, 500, (int) p[0], "px", val -> { p[0] = val; triggerPreview.run(); }));
                    break;
            }

            // প্রতিটি ব্লারে Transform স্লাইডার (০ থেকে ১০০০ px) যুক্ত করা হলো
            paramsContainer.addView(createSliderRow("Transform:", 0, 1000, (int) transformPad[0], "px", val -> {
                transformPad[0] = val;
                triggerPreview.run();
            }));

            triggerPreview.run();
        };

        rebuildParamsUI.run();

        typeDropdownBtn.setOnClickListener(v -> {
            showBlurModesListPopup(typeDropdownBtn, currentModeIndex[0], selectedIdx -> {
                currentModeIndex[0] = selectedIdx;
                typeText.setText(blurModes[selectedIdx]);
                rebuildParamsUI.run();
            });
        });

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnRow.setPadding(0, dp(10), 0, 0);

        Button btnCancel = new Button(activity);
        btnCancel.setText("Cancel");
        btnCancel.setTextColor(Color.parseColor("#E0E0E0"));
        btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        GradientDrawable canBg = new GradientDrawable();
        canBg.setColor(Color.parseColor("#262626"));
        canBg.setStroke(dp(1), Color.parseColor("#383838"));
        canBg.setCornerRadius(dp(4));
        btnCancel.setBackground(canBg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(70), dp(30));
        cp.setMargins(0, 0, dp(8), 0);
        btnCancel.setLayoutParams(cp);

        // Cancel বাটনে ক্লিক করলে পূর্বের আসল অবস্থায় ফিরবে
        Runnable cancelAction = () -> {
            if (targetLayer[0] != null && originalBitmap[0] != null) {
                targetLayer[0].bitmap = originalBitmap[0];
                targetLayer[0].x = origX[0];
                targetLayer[0].y = origY[0];
                if (activity.canvasView != null) activity.canvasView.invalidate();
            }
            dialog.dismiss();
        };

        btnCancel.setOnClickListener(v -> cancelAction.run());
        closeX.setOnClickListener(v -> cancelAction.run());
        btnRow.addView(btnCancel);

        Button btnApply = new Button(activity);
        btnApply.setText("APPLY");
        btnApply.setTextColor(Color.WHITE);
        btnApply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnApply.setTypeface(null, Typeface.BOLD);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setColor(Color.parseColor("#FF1238"));
        okBg.setCornerRadius(dp(4));
        btnApply.setBackground(okBg);
        btnApply.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(30)));

        // APPLY চাপলে ব্লার পার্মানেন্ট হবে কিন্তু ডায়ালগ বন্ধ হবে না
        btnApply.setOnClickListener(v -> {
            if (targetLayer[0] != null && targetLayer[0].bitmap != null) {
                targetLayer[0].isBlank = false;
                originalBitmap[0] = targetLayer[0].bitmap.copy(Bitmap.Config.ARGB_8888, true);
                origX[0] = targetLayer[0].x;
                origY[0] = targetLayer[0].y;
                transformPad[0] = 0f; // প্যাডিং স্থায়ীভাবে অন্তর্ভুক্ত হওয়ায় রিসেট
                invokePrivateMethod(activity, "recordHistory");
                invokePrivateMethod(activity, "updateLayersDockUI");
                invokePrivateSessionMethod(activity, "saveProjectToDisk", activity.getCurrentSession());
                Toast.makeText(activity, "Blur Filter Applied", Toast.LENGTH_SHORT).show();
            }
        });
        btnRow.addView(btnApply);

        root.addView(btnRow);
        dialog.setContentView(root);
        dialog.show();
    }

    private interface OnParamChangeListener { void onChange(float val); }

    private LinearLayout createSliderRow(String label, int min, int max, int defaultVal, String unit, OnParamChangeListener listener) {
        LinearLayout wrap = new LinearLayout(activity);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, 0, 0, dp(10));

        LinearLayout topRow = new LinearLayout(activity);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView labelTv = new TextView(activity);
        labelTv.setText(label);
        labelTv.setTextColor(Color.parseColor("#AAAAAA"));
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        labelTv.setLayoutParams(new LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT));
        topRow.addView(labelTv);

        final EditText valBox = new EditText(activity);
        valBox.setText(String.valueOf(defaultVal));
        valBox.setTextColor(Color.WHITE);
        valBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        valBox.setGravity(Gravity.CENTER);
        valBox.setSingleLine(true);
        valBox.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        valBox.setLayoutParams(new LinearLayout.LayoutParams(dp(75), dp(28)));

        GradientDrawable valBg = new GradientDrawable();
        valBg.setColor(Color.parseColor("#121212"));
        valBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        valBg.setCornerRadius(dp(3));
        valBox.setBackground(valBg);
        topRow.addView(valBox);

        TextView unitTv = new TextView(activity);
        unitTv.setText("  " + unit);
        unitTv.setTextColor(Color.parseColor("#888888"));
        unitTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        topRow.addView(unitTv);
        wrap.addView(topRow);

        final SeekBar seekBar = new SeekBar(activity);
        seekBar.setMax(max - min);
        seekBar.setProgress(defaultVal - min);
        applyCustomSeekBarStyle(seekBar);
        wrap.addView(seekBar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    int val = min + progress;
                    valBox.setText(String.valueOf(val));
                    if (listener != null) listener.onChange(val);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        valBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    String str = cs.toString().trim();
                    if (!str.isEmpty() && !str.equals("-")) {
                        int val = Integer.parseInt(str);
                        val = Math.max(min, Math.min(max, val));
                        if (seekBar.getProgress() != (val - min)) {
                            seekBar.setProgress(val - min);
                            if (listener != null) listener.onChange(val);
                        }
                    }
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        return wrap;
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(8), dp(6), dp(14));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }

    private void showBlurModesListPopup(View anchor, int selectedIndex, final OnModeSelectedListener listener) {
        final PopupWindow popup = new PopupWindow(activity);
        LinearLayout container = new LinearLayout(activity);
        container.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#181818"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        container.setBackground(bg);
        container.setPadding(dp(4), dp(4), dp(4), dp(4));

        ScrollView sv = new ScrollView(activity);
        sv.setVerticalScrollBarEnabled(true);
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < blurModes.length; i++) {
            final int idx = i;
            TextView row = new TextView(activity);
            row.setText(blurModes[i]);
            row.setTextColor(idx == selectedIndex ? Color.parseColor("#FF1238") : Color.WHITE);
            row.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
            row.setPadding(dp(12), dp(8), dp(12), dp(8));

            if (idx == selectedIndex) {
                GradientDrawable sel = new GradientDrawable();
                sel.setColor(Color.parseColor("#281619"));
                sel.setCornerRadius(dp(3));
                row.setBackground(sel);
            }

            row.setOnClickListener(v -> {
                popup.dismiss();
                if (listener != null) listener.onSelected(idx);
            });
            list.addView(row);
        }

        sv.addView(list);
        container.addView(sv);

        popup.setContentView(container);
        popup.setWidth(Math.max(anchor.getWidth(), dp(170)));
        popup.setHeight(dp(220));
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(2));
    }

    interface OnModeSelectedListener { void onSelected(int index); }

    // ৪. সম্পূর্ণ ও নির্ভুল ২০টি ব্লার অ্যালগরিদম ইঞ্জিন
    public static class AllBlurProcessors {

        public static Bitmap applyBlurAdvanced(Bitmap src, int modeIndex, float p0, float p1, float p2, float p3) {
            if (src == null || src.isRecycled()) return src;

            try {
                switch (modeIndex) {
                    case 0: return trueGaussianBlur(src, (int) p0);
                    case 1: return movingBlur(src, p0, p1); 
                    case 2: return zoomingBlur(src, p0, p1); 
                    case 3: return spinBlur(src, p0, p1); 
                    case 4: return lensBokehBlur(src, p0, p1, p2); 
                    case 5: return unsharpMask(src, p0, p1); 
                    case 6: return frostedGlassNormal(src, p0, p1); 
                    case 7: return frostedGlassZooming(src, p0, p1); 
                    case 8: return frostedGlassMoving(src, p0, p1); 
                    case 9: return mosaicPixelate(src, (int) p0); 
                    case 10: return trueBoxBlur(src, (int) p0);
                    case 11: return surfaceBlur(src, (int) p0, (int) p1);
                    case 12: return surfaceBlur(src, (int) p0, (int) p1); 
                    case 13: return tiltShiftBlur(src, (int) p0, p1, p2);
                    case 14: return radialBlur(src, p0);
                    case 15: return crossBlur(src, p0, p1);
                    case 16: return softFocusBlur(src, (int) p0, p1);
                    case 17: return glowBlur(src, (int) p0, p1);
                    case 18: return averageBlur(src, (int) p0);
                    case 19: return medianBlur(src, (int) p0);
                    default: return trueGaussianBlur(src, (int) p0);
                }
            } catch (Throwable t) {
                System.gc();
                return src.copy(Bitmap.Config.ARGB_8888, true);
            }
        }

        private static Bitmap trueGaussianBlur(Bitmap src, int radius) {
            int w = src.getWidth(), h = src.getHeight();
            if (w <= 0 || h <= 0) return src;

            int scale = 1;
            if (radius > 45) scale = 2;
            if (radius > 150) scale = 4;

            int sw = Math.max(2, w / scale);
            int sh = Math.max(2, h / scale);
            Bitmap workBmp = (scale > 1) ? Bitmap.createScaledBitmap(src, sw, sh, true) : src.copy(Bitmap.Config.ARGB_8888, true);

            int effR = Math.max(1, radius / scale);
            int[] pix = new int[sw * sh];
            workBmp.getPixels(pix, 0, sw, 0, 0, sw, sh);

            int passR = Math.max(1, effR / 3);
            int[] temp = new int[sw * sh];

            boxBlurH(pix, temp, sw, sh, passR); boxBlurV(temp, pix, sw, sh, passR);
            boxBlurH(pix, temp, sw, sh, passR); boxBlurV(temp, pix, sw, sh, passR);
            boxBlurH(pix, temp, sw, sh, passR); boxBlurV(temp, pix, sw, sh, passR);

            workBmp.setPixels(pix, 0, sw, 0, 0, sw, sh);

            if (scale > 1) {
                Bitmap res = Bitmap.createScaledBitmap(workBmp, w, h, true);
                workBmp.recycle();
                return res;
            }
            return workBmp;
        }

        private static Bitmap movingBlur(Bitmap src, float strength, float direction) {
            int w = src.getWidth(), h = src.getHeight();
            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(res);
            int steps = 28;
            float rad = (float) Math.toRadians(direction);
            float cos = (float) Math.cos(rad), sin = (float) Math.sin(rad);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

            for (int i = 0; i < steps; i++) {
                float off = -strength / 2f + (strength * i / (steps - 1f));
                p.setAlpha((int) (255f / (i + 1)));
                c.drawBitmap(src, off * cos, off * sin, p);
            }
            return res;
        }

        private static Bitmap zoomingBlur(Bitmap src, float strength, float centerRadiusPercent) {
            int w = src.getWidth(), h = src.getHeight();
            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(res);
            int steps = 26;
            float maxScale = 1.0f + (strength * 0.008f);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

            for (int i = 0; i < steps; i++) {
                float s = 1.0f + ((maxScale - 1.0f) * i / (steps - 1f));
                c.save();
                c.scale(s, s, w / 2f, h / 2f);
                p.setAlpha((int) (255f / (i + 1)));
                c.drawBitmap(src, 0, 0, p);
                c.restore();
            }

            float safeRadius = (Math.min(w, h) / 2f) * (centerRadiusPercent / 100f);
            if (safeRadius > 5) {
                Paint sharpP = new Paint(Paint.ANTI_ALIAS_FLAG);
                Bitmap centerMask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas mc = new Canvas(centerMask);
                mc.drawCircle(w / 2f, h / 2f, safeRadius, sharpP);
                sharpP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                mc.drawBitmap(src, 0, 0, sharpP);
                c.drawBitmap(centerMask, 0, 0, null);
                centerMask.recycle();
            }
            return res;
        }

        private static Bitmap spinBlur(Bitmap src, float strength, float innerRadiusPercent) {
            int w = src.getWidth(), h = src.getHeight();
            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(res);
            int steps = 26;
            float maxAngle = Math.max(2f, (strength / 100f) * 45f);
            Paint p = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);

            for (int i = 0; i < steps; i++) {
                float rot = -maxAngle / 2f + (maxAngle * i / (steps - 1f));
                c.save();
                c.rotate(rot, w / 2f, h / 2f);
                p.setAlpha((int) (255f / (i + 1)));
                c.drawBitmap(src, 0, 0, p);
                c.restore();
            }

            float safeInner = (Math.min(w, h) / 2f) * (innerRadiusPercent / 100f);
            if (safeInner > 5) {
                Paint sharpP = new Paint(Paint.ANTI_ALIAS_FLAG);
                Bitmap maskBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                Canvas mc = new Canvas(maskBmp);
                mc.drawCircle(w / 2f, h / 2f, safeInner, sharpP);
                sharpP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                mc.drawBitmap(src, 0, 0, sharpP);
                c.drawBitmap(maskBmp, 0, 0, null);
                maskBmp.recycle();
            }
            return res;
        }

        private static Bitmap lensBokehBlur(Bitmap src, float radius, float brightness, float direction) {
            Bitmap base = trueGaussianBlur(src, Math.max(2, (int) radius));
            int w = src.getWidth(), h = src.getHeight();
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            Canvas c = new Canvas(res);
            c.drawBitmap(base, 0, 0, null);

            if (brightness > 2) {
                Bitmap bokeh = trueGaussianBlur(src, Math.max(3, (int) (radius * 0.4f)));
                Paint screenP = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                screenP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
                screenP.setAlpha((int) (Math.min(100f, brightness) * 2.2f));
                c.drawBitmap(bokeh, 0, 0, screenP);
                bokeh.recycle();
            }
            base.recycle();
            return res;
        }

        private static Bitmap unsharpMask(Bitmap src, float radius, float strength) {
            Bitmap blurred = trueGaussianBlur(src, Math.max(1, (int) radius));
            int w = src.getWidth(), h = src.getHeight();
            int[] origPix = new int[w * h];
            int[] blurPix = new int[w * h];
            src.getPixels(origPix, 0, w, 0, 0, w, h);
            blurred.getPixels(blurPix, 0, w, 0, 0, w, h);
            blurred.recycle();

            float weight = Math.max(0.1f, strength / 100f);
            for (int i = 0; i < origPix.length; i++) {
                int oc = origPix[i];
                int bc = blurPix[i];

                int a = (oc >>> 24);
                int r = (oc >> 16) & 0xff;
                int g = (oc >> 8) & 0xff;
                int b = oc & 0xff;

                int brR = (bc >> 16) & 0xff;
                int brG = (bc >> 8) & 0xff;
                int brB = bc & 0xff;

                int nr = Math.max(0, Math.min(255, (int) (r + (r - brR) * weight)));
                int ng = Math.max(0, Math.min(255, (int) (g + (g - brG) * weight)));
                int nb = Math.max(0, Math.min(255, (int) (b + (b - brB) * weight)));

                origPix[i] = (a << 24) | (nr << 16) | (ng << 8) | nb;
            }

            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            res.setPixels(origPix, 0, w, 0, 0, w, h);
            return res;
        }

        private static Bitmap frostedGlassNormal(Bitmap src, float radius, float variance) {
            Bitmap base = (radius > 0) ? trueGaussianBlur(src, (int) radius) : src.copy(Bitmap.Config.ARGB_8888, true);
            int w = base.getWidth(), h = base.getHeight();
            int[] pix = new int[w * h];
            base.getPixels(pix, 0, w, 0, 0, w, h);

            int[] out = new int[w * h];
            Random rnd = new Random();
            int maxD = Math.max(1, (int) ((variance / 100f) * 20));

            for (int y = 0; y < h; y++) {
                int yw = y * w;
                for (int x = 0; x < w; x++) {
                    int dx = rnd.nextInt(maxD * 2 + 1) - maxD;
                    int dy = rnd.nextInt(maxD * 2 + 1) - maxD;

                    int nx = Math.max(0, Math.min(w - 1, x + dx));
                    int ny = Math.max(0, Math.min(h - 1, y + dy));

                    out[yw + x] = pix[ny * w + nx];
                }
            }

            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            res.setPixels(out, 0, w, 0, 0, w, h);
            base.recycle();
            return res;
        }

        private static Bitmap frostedGlassZooming(Bitmap src, float radius, float centerRadiusPercent) {
            Bitmap zBmp = zoomingBlur(src, Math.min(100f, radius), centerRadiusPercent);
            Bitmap res = frostedGlassNormal(zBmp, 2f, 85f);
            zBmp.recycle();
            return res;
        }

        private static Bitmap frostedGlassMoving(Bitmap src, float radius, float direction) {
            Bitmap base = trueGaussianBlur(src, Math.max(1, (int) (radius * 0.15f)));
            int w = base.getWidth(), h = base.getHeight();
            int[] pix = new int[w * h];
            base.getPixels(pix, 0, w, 0, 0, w, h);

            int[] out = new int[w * h];
            Random rnd = new Random();
            float rad = (float) Math.toRadians(direction);
            float cos = (float) Math.cos(rad);
            float sin = (float) Math.sin(rad);

            int maxD = Math.max(2, (int) (radius * 0.25f));

            for (int y = 0; y < h; y++) {
                int yw = y * w;
                for (int x = 0; x < w; x++) {
                    float dist = rnd.nextFloat() * maxD * 2 - maxD;
                    int nx = Math.max(0, Math.min(w - 1, (int) (x + dist * cos)));
                    int ny = Math.max(0, Math.min(h - 1, (int) (y + dist * sin)));

                    out[yw + x] = pix[ny * w + nx];
                }
            }

            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            res.setPixels(out, 0, w, 0, 0, w, h);
            base.recycle();
            return res;
        }

        private static Bitmap mosaicPixelate(Bitmap src, int width) {
            int w = src.getWidth(), h = src.getHeight();
            int blockSize = Math.max(1, width);
            int bw = Math.max(1, w / blockSize);
            int bh = Math.max(1, h / blockSize);
            Bitmap small = Bitmap.createScaledBitmap(src, bw, bh, false);
            Bitmap res = Bitmap.createScaledBitmap(small, w, h, false);
            small.recycle();
            return res;
        }

        private static Bitmap trueBoxBlur(Bitmap src, int radius) {
            int w = src.getWidth(), h = src.getHeight();
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            int[] pix = new int[w * h];
            res.getPixels(pix, 0, w, 0, 0, w, h);
            int[] temp = new int[w * h];
            boxBlurH(pix, temp, w, h, Math.max(1, radius));
            boxBlurV(temp, pix, w, h, Math.max(1, radius));
            res.setPixels(pix, 0, w, 0, 0, w, h);
            return res;
        }

        private static Bitmap surfaceBlur(Bitmap src, int radius, int threshold) {
            Bitmap blurred = trueGaussianBlur(src, Math.max(2, radius / 2));
            int w = src.getWidth(), h = src.getHeight();
            int[] origPix = new int[w * h];
            int[] blurPix = new int[w * h];
            src.getPixels(origPix, 0, w, 0, 0, w, h);
            blurred.getPixels(blurPix, 0, w, 0, 0, w, h);

            int th = Math.max(5, threshold);
            for (int i = 0; i < origPix.length; i++) {
                int oc = origPix[i];
                int bc = blurPix[i];
                int dr = Math.abs(((oc >> 16) & 0xff) - ((bc >> 16) & 0xff));
                int dg = Math.abs(((oc >> 8) & 0xff) - ((bc >> 8) & 0xff));
                int db = Math.abs((oc & 0xff) - (bc & 0xff));
                if (dr + dg + db > th * 3) {
                    blurPix[i] = oc;
                }
            }
            Bitmap res = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            res.setPixels(blurPix, 0, w, 0, 0, w, h);
            blurred.recycle();
            return res;
        }

        private static Bitmap tiltShiftBlur(Bitmap src, int radius, float focusPos, float focusWidth) {
            int w = src.getWidth(), h = src.getHeight();
            Bitmap blurred = trueGaussianBlur(src, radius);
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            Canvas c = new Canvas(res);

            Bitmap maskBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas mc = new Canvas(maskBmp);
            Paint gradP = new Paint(Paint.ANTI_ALIAS_FLAG);

            float center = (focusPos / 100f) * h;
            float halfW = (focusWidth / 200f) * h;
            float topEdge = Math.max(0, center - halfW);
            float bottomEdge = Math.min(h, center + halfW);

            LinearGradient lg = new LinearGradient(
                    0, 0, 0, h,
                    new int[]{0xFFFFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0xFFFFFFFF},
                    new float[]{Math.max(0f, topEdge / h * 0.7f), topEdge / h, bottomEdge / h, Math.min(1f, bottomEdge / h + (1f - bottomEdge / h) * 0.3f)},
                    Shader.TileMode.CLAMP
            );
            gradP.setShader(lg);
            mc.drawRect(0, 0, w, h, gradP);

            Paint blendP = new Paint(Paint.ANTI_ALIAS_FLAG);
            blendP.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            Canvas bc = new Canvas(blurred);
            bc.drawBitmap(maskBmp, 0, 0, blendP);
            maskBmp.recycle();

            c.drawBitmap(blurred, 0, 0, null);
            blurred.recycle();
            return res;
        }

        private static Bitmap radialBlur(Bitmap src, float angle) {
            return movingBlur(src, angle, 90f);
        }

        private static Bitmap crossBlur(Bitmap src, float hRadius, float vRadius) {
            Bitmap b1 = movingBlur(src, hRadius, 0f);
            Bitmap b2 = movingBlur(b1, vRadius, 90f);
            b1.recycle();
            return b2;
        }

        private static Bitmap softFocusBlur(Bitmap src, int radius, float opacity) {
            Bitmap g = trueGaussianBlur(src, radius);
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            Canvas c = new Canvas(res);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setAlpha((int) (Math.max(1, opacity) * 2.55f));
            c.drawBitmap(g, 0, 0, p);
            g.recycle();
            return res;
        }

        private static Bitmap glowBlur(Bitmap src, int radius, float intensity) {
            Bitmap g = trueGaussianBlur(src, Math.max(5, radius));
            Bitmap res = src.copy(Bitmap.Config.ARGB_8888, true);
            Canvas c = new Canvas(res);

            c.drawBitmap(g, 0, 0, null);

            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
            float effAlpha = Math.max(20f, intensity) * 2.55f;
            p.setAlpha((int) Math.min(255f, effAlpha));
            c.drawBitmap(g, 0, 0, p);

            g.recycle();
            return res;
        }

        private static Bitmap averageBlur(Bitmap src, int blockSize) {
            return mosaicPixelate(src, Math.max(4, blockSize));
        }

        private static Bitmap medianBlur(Bitmap src, int radius) {
            int scale = Math.max(2, Math.min(10, radius / 5));
            int w = src.getWidth(), h = src.getHeight();
            Bitmap small = Bitmap.createScaledBitmap(src, Math.max(2, w / scale), Math.max(2, h / scale), true);
            int sw = small.getWidth(), sh = small.getHeight();

            int[] pix = new int[sw * sh];
            small.getPixels(pix, 0, sw, 0, 0, sw, sh);
            int[] out = new int[sw * sh];

            int[] windowR = new int[9];
            int[] windowG = new int[9];
            int[] windowB = new int[9];

            for (int y = 1; y < sh - 1; y++) {
                int yw = y * sw;
                for (int x = 1; x < sw - 1; x++) {
                    int k = 0;
                    for (int dy = -1; dy <= 1; dy++) {
                        int row = (y + dy) * sw;
                        for (int dx = -1; dx <= 1; dx++) {
                            int px = pix[row + (x + dx)];
                            windowR[k] = (px >> 16) & 0xff;
                            windowG[k] = (px >> 8) & 0xff;
                            windowB[k] = px & 0xff;
                            k++;
                        }
                    }
                    Arrays.sort(windowR);
                    Arrays.sort(windowG);
                    Arrays.sort(windowB);
                    out[yw + x] = (pix[yw + x] & 0xFF000000) | (windowR[4] << 16) | (windowG[4] << 8) | windowB[4];
                }
            }
            small.setPixels(out, 0, sw, 0, 0, sw, sh);
            Bitmap res = Bitmap.createScaledBitmap(small, w, h, true);
            small.recycle();
            return res;
        }

        private static void boxBlurH(int[] in, int[] out, int w, int h, int r) {
            int div = r + r + 1;
            for (int y = 0; y < h; y++) {
                int yw = y * w;
                long aSum = 0, rSum = 0, gSum = 0, bSum = 0;

                int first = in[yw];
                aSum += (long) (first >>> 24) * (r + 1);
                rSum += (long) ((first >> 16) & 0xff) * (r + 1);
                gSum += (long) ((first >> 8) & 0xff) * (r + 1);
                bSum += (long) (first & 0xff) * (r + 1);

                for (int i = 1; i <= r; i++) {
                    int p = in[yw + Math.min(w - 1, i)];
                    aSum += (p >>> 24);
                    rSum += (p >> 16) & 0xff;
                    gSum += (p >> 8) & 0xff;
                    bSum += p & 0xff;
                }

                for (int x = 0; x < w; x++) {
                    out[yw + x] = (((int) (aSum / div)) << 24) |
                                  (((int) (rSum / div)) << 16) |
                                  (((int) (gSum / div)) << 8) |
                                  ((int) (bSum / div));

                    int pOut = in[yw + Math.max(0, x - r)];
                    int pIn = in[yw + Math.min(w - 1, x + r + 1)];

                    aSum += (pIn >>> 24) - (pOut >>> 24);
                    rSum += ((pIn >> 16) & 0xff) - ((pOut >> 16) & 0xff);
                    gSum += ((pIn >> 8) & 0xff) - ((pOut >> 8) & 0xff);
                    bSum += (pIn & 0xff) - (pOut & 0xff);
                }
            }
        }

        private static void boxBlurV(int[] in, int[] out, int w, int h, int r) {
            int div = r + r + 1;
            for (int x = 0; x < w; x++) {
                long aSum = 0, rSum = 0, gSum = 0, bSum = 0;

                int first = in[x];
                aSum += (long) (first >>> 24) * (r + 1);
                rSum += (long) ((first >> 16) & 0xff) * (r + 1);
                gSum += (long) ((first >> 8) & 0xff) * (r + 1);
                bSum += (long) (first & 0xff) * (r + 1);

                for (int i = 1; i <= r; i++) {
                    int p = in[Math.min(h - 1, i) * w + x];
                    aSum += (p >>> 24);
                    rSum += (p >> 16) & 0xff;
                    gSum += (p >> 8) & 0xff;
                    bSum += p & 0xff;
                }

                for (int y = 0; y < h; y++) {
                    out[y * w + x] = (((int) (aSum / div)) << 24) |
                                    (((int) (rSum / div)) << 16) |
                                    (((int) (gSum / div)) << 8) |
                                    ((int) (bSum / div));

                    int pOut = in[Math.max(0, y - r) * w + x];
                    int pIn = in[Math.min(h - 1, y + r + 1) * w + x];

                    aSum += (pIn >>> 24) - (pOut >>> 24);
                    rSum += ((pIn >> 16) & 0xff) - ((pOut >> 16) & 0xff);
                    gSum += ((pIn >> 8) & 0xff) - ((pOut >> 8) & 0xff);
                    bSum += (pIn & 0xff) - (pOut & 0xff);
                }
            }
        }
    }
}