package com.example.ejitor;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class editor_9 implements EditorActivity.EditorModule {

    private EditorActivity activity;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicInteger taskCounter = new AtomicInteger(0);

    private int selectedTargetColor = Color.WHITE;
    private float currentTolerance = 15f;
    private float currentSmoothness = 2f;

    private ImageView toolButtonView = null;
    private ImageView cropToolButtonView = null;
    private boolean isEyeDropperActive = false;

    @Override
    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        hookLeftToolbar();
    }

    @Override
    public void onCommand(String command, Object... args) {
        if ("openColorRemover".equalsIgnoreCase(command)) {
            openColorRemoverDialog();
        } else if ("openCropTool".equalsIgnoreCase(command)) {
            openLayerCropDialog();
        }
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private void invokePrivateMethod(EditorActivity act, String name) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    private void invokePrivateSessionMethod(EditorActivity act, String name, EditorActivity.ProjectTabSession s) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name, EditorActivity.ProjectTabSession.class);
            m.setAccessible(true);
            m.invoke(act, s);
        } catch (Exception ignored) {}
    }

    private int getEditorActivityFgColor() {
        if (activity == null) return selectedTargetColor;
        try {
            Field f = EditorActivity.class.getDeclaredField("fgColor");
            f.setAccessible(true);
            return f.getInt(activity);
        } catch (Exception e) {
            return selectedTargetColor;
        }
    }

    // সম্পূর্ণ ডায়নামিকালি লেফট টুলবারকে স্ক্রলেবল করা (EditorActivity টাচ না করেই)
    private void hookLeftToolbar() {
        if (activity == null || activity.canvasView == null) return;

        activity.canvasView.post(() -> {
            try {
                ViewParent canvasFrame = activity.canvasView.getParent();
                if (canvasFrame instanceof ViewGroup) {
                    ViewParent workspace = canvasFrame.getParent();
                    if (workspace instanceof ViewGroup) {
                        ViewGroup wsGroup = (ViewGroup) workspace;
                        if (wsGroup.getChildCount() > 0 && wsGroup.getChildAt(0) instanceof LinearLayout) {
                            LinearLayout leftTb = (LinearLayout) wsGroup.getChildAt(0);
                            setupScrollableToolbar(leftTb);
                        }
                    }
                }
            } catch (Exception ignored) {}
        });
    }

    private void setupScrollableToolbar(LinearLayout leftTb) {
        if (leftTb == null) return;

        // ইতোমধ্যে স্ক্রলভিউ থাকলে সরাসরি কন্টেইনারে বাটন যুক্ত করা
        View existingScroll = leftTb.findViewWithTag("ejitor_left_tools_scroll");
        if (existingScroll instanceof ScrollView) {
            LinearLayout container = (LinearLayout) ((ScrollView) existingScroll).getChildAt(0);
            attachToolbarButtons(container);
            return;
        }

        // কালার সোয়াচ আলাদা রাখা (সাধারণত শেষের চাইল্ড)
        View swatchWrap = null;
        int childCount = leftTb.getChildCount();
        if (childCount > 0) {
            View last = leftTb.getChildAt(childCount - 1);
            if (last instanceof LinearLayout) {
                swatchWrap = last;
            }
        }

        // বাকি সব টুল বাটন সংগ্রহ করা
        ArrayList<View> normalToolViews = new ArrayList<>();
        for (int i = 0; i < leftTb.getChildCount(); i++) {
            View child = leftTb.getChildAt(i);
            if (child != swatchWrap) {
                normalToolViews.add(child);
            }
        }

        // টুলবার খালি করে স্ক্রলভিউ সেটআপ করা
        leftTb.removeAllViews();

        ScrollView toolsScrollView = new ScrollView(activity);
        toolsScrollView.setTag("ejitor_left_tools_scroll");
        LinearLayout.LayoutParams svParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        toolsScrollView.setLayoutParams(svParams);
        toolsScrollView.setFillViewport(true);
        toolsScrollView.setVerticalScrollBarEnabled(false);
        toolsScrollView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        LinearLayout toolsContainer = new LinearLayout(activity);
        toolsContainer.setOrientation(LinearLayout.VERTICAL);
        toolsContainer.setGravity(Gravity.CENTER_HORIZONTAL);
        toolsContainer.setPadding(0, dp(2), 0, dp(4));

        for (View tool : normalToolViews) {
            // পুরাতন বাটনগুলোর স্পেসার থাকলে বাদ দিয়ে অ্যাড করা
            if (tool.getLayoutParams() != null && tool.getLayoutParams().height != 0) {
                toolsContainer.addView(tool);
            } else if (tool instanceof ImageView) {
                toolsContainer.addView(tool);
            }
        }

        // নতুন আইড্রপার ও ক্রপ টুল বাটন যোগ করা
        attachToolbarButtons(toolsContainer);

        toolsScrollView.addView(toolsContainer);
        leftTb.addView(toolsScrollView);

        // কালার সোয়াচকে নিচে ফিক্সড হিসেবে যুক্ত করা
        if (swatchWrap != null) {
            leftTb.addView(swatchWrap);
        }
    }

    private void attachToolbarButtons(ViewGroup container) {
        if (container == null) return;

        // ১. আইড্রপার কালার রিমুভার বাটন
        if (container.findViewWithTag("ejitor_eyedropper_tool_btn") == null) {
            toolButtonView = new ImageView(activity);
            toolButtonView.setTag("ejitor_eyedropper_tool_btn");
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(28), dp(28));
            p.setMargins(0, dp(2), 0, dp(2));
            toolButtonView.setLayoutParams(p);
            toolButtonView.setImageDrawable(createExactPhotoshopEyedropperWithDropletIcon());
            toolButtonView.setScaleType(ImageView.ScaleType.CENTER);

            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.TRANSPARENT);
            bg.setCornerRadius(dp(3));
            toolButtonView.setBackground(bg);

            toolButtonView.setOnClickListener(v -> {
                activity.triggerClickFeedback(v);
                openColorRemoverDialog();
            });

            container.addView(toolButtonView);
        }

        // ২. ক্রপ টুল বাটন
        if (container.findViewWithTag("ejitor_crop_tool_btn") == null) {
            cropToolButtonView = new ImageView(activity);
            cropToolButtonView.setTag("ejitor_crop_tool_btn");
            LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(dp(28), dp(28));
            p2.setMargins(0, dp(2), 0, dp(2));
            cropToolButtonView.setLayoutParams(p2);
            cropToolButtonView.setImageDrawable(createPhotoshopCropIcon());
            cropToolButtonView.setScaleType(ImageView.ScaleType.CENTER);

            GradientDrawable bg2 = new GradientDrawable();
            bg2.setColor(Color.TRANSPARENT);
            bg2.setCornerRadius(dp(3));
            cropToolButtonView.setBackground(bg2);

            cropToolButtonView.setOnClickListener(v -> {
                activity.triggerClickFeedback(v);
                openLayerCropDialog();
            });

            container.addView(cropToolButtonView);
        }
    }

    private BitmapDrawable createExactPhotoshopEyedropperWithDropletIcon() {
        int w = dp(22);
        Bitmap bmp = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        float cx = w / 2f;
        float cy = w / 2f;

        c.save();
        c.rotate(-45f, cx, cy);

        Paint bulbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bulbPaint.setColor(Color.WHITE);
        bulbPaint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy - dp(5.5f), dp(3.2f), bulbPaint);

        c.drawRoundRect(new RectF(cx - dp(2.8f), cy - dp(2.4f), cx + dp(2.8f), cy - dp(1.2f)), dp(0.6f), dp(0.6f), bulbPaint);

        Paint tubePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        tubePaint.setColor(Color.WHITE);
        tubePaint.setStyle(Paint.Style.STROKE);
        tubePaint.setStrokeWidth(dp(1.3f));

        c.drawRect(cx - dp(2.1f), cy - dp(1.0f), cx + dp(2.1f), cy + dp(4.2f), tubePaint);

        Path nozzle = new Path();
        nozzle.moveTo(cx - dp(2.1f), cy + dp(4.2f));
        nozzle.lineTo(cx - dp(0.9f), cy + dp(7.2f));
        nozzle.lineTo(cx + dp(0.9f), cy + dp(7.2f));
        nozzle.lineTo(cx + dp(2.1f), cy + dp(4.2f));
        c.drawPath(nozzle, tubePaint);

        Paint dropPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        dropPaint.setColor(Color.WHITE);
        dropPaint.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy + dp(9.8f), dp(1.2f), dropPaint);

        c.restore();

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createPhotoshopCropIcon() {
        int w = dp(20);
        Bitmap bmp = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.6f));
        paint.setStrokeCap(Paint.Cap.SQUARE);

        c.drawLine(dp(3), dp(7), dp(13), dp(7), paint);
        c.drawLine(dp(7), dp(3), dp(7), dp(13), paint);

        c.drawLine(dp(7), dp(13), dp(17), dp(13), paint);
        c.drawLine(dp(13), dp(7), dp(13), dp(17), paint);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createCloseVectorIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(8), dp(6), dp(14));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }

    // =========================================================================
    // ১. কালার রিমুভার ডায়ালগ
    // =========================================================================
    private void openColorRemoverDialog() {
        final EditorActivity.ProjectTabSession session = activity.getCurrentSession();
        if (session == null || session.layers.isEmpty() || session.activeLayerIndex < 0 || session.activeLayerIndex >= session.layers.size()) {
            Toast.makeText(activity, "Please select an active layer first", Toast.LENGTH_SHORT).show();
            return;
        }

        final EditorActivity.LayerItem activeLayer = session.layers.get(session.activeLayerIndex);
        if (activeLayer.bitmap == null || activeLayer.isBlank) {
            Toast.makeText(activity, "Active layer has no image content", Toast.LENGTH_SHORT).show();
            return;
        }

        final Bitmap originalBitmap = activeLayer.bitmap.copy(Bitmap.Config.ARGB_8888, true);

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            dialog.getWindow().setGravity(Gravity.CENTER);
        }

        final WindowManager.LayoutParams lp = dialog.getWindow().getAttributes();

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setColor(Color.parseColor("#1C1C1C"));
        rootBg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        rootBg.setCornerRadius(dp(12));
        root.setBackground(rootBg);

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(12));

        TextView titleTv = new TextView(activity);
        titleTv.setText("Color to Transparent");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorIcon());
        header.addView(closeX);
        root.addView(header);

        header.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX() - lp.x;
                        startY = event.getRawY() - lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = (int) (event.getRawX() - startX);
                        lp.y = (int) (event.getRawY() - startY);
                        dialog.getWindow().setAttributes(lp);
                        return true;
                }
                return false;
            }
        });

        LinearLayout colorRow = new LinearLayout(activity);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);
        colorRow.setGravity(Gravity.CENTER_VERTICAL);
        colorRow.setPadding(0, 0, 0, dp(12));

        TextView colLbl = new TextView(activity);
        colLbl.setText("Color: ");
        colLbl.setTextColor(Color.parseColor("#AAAAAA"));
        colLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        colorRow.addView(colLbl);

        final View colorSwatch = new View(activity);
        colorSwatch.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(26)));
        updateSwatchBg(colorSwatch, selectedTargetColor);
        colorRow.addView(colorSwatch);

        View sp1 = new View(activity);
        sp1.setLayoutParams(new LinearLayout.LayoutParams(0, dp(1), 1f));
        colorRow.addView(sp1);

        Button eyedropperBtn = new Button(activity);
        eyedropperBtn.setText("Pick on Image");
        eyedropperBtn.setTextColor(Color.WHITE);
        eyedropperBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        GradientDrawable eyeBg = new GradientDrawable();
        eyeBg.setColor(Color.parseColor("#262626"));
        eyeBg.setStroke(dp(1), Color.parseColor("#383838"));
        eyeBg.setCornerRadius(dp(4));
        eyedropperBtn.setBackground(eyeBg);
        eyedropperBtn.setPadding(dp(8), 0, dp(8), 0);
        eyedropperBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        colorRow.addView(eyedropperBtn);

        View sp2 = new View(activity);
        sp2.setLayoutParams(new LinearLayout.LayoutParams(dp(5), dp(1)));
        colorRow.addView(sp2);

        Button paletteBtn = new Button(activity);
        paletteBtn.setText("Color Picker");
        paletteBtn.setTextColor(Color.WHITE);
        paletteBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        paletteBtn.setBackground(eyeBg);
        paletteBtn.setPadding(dp(8), 0, dp(8), 0);
        paletteBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)));
        colorRow.addView(paletteBtn);

        root.addView(colorRow);

        final Runnable triggerProcess = () -> {
            final int targetCol = selectedTargetColor;
            final float tol = currentTolerance;
            final float smooth = currentSmoothness;

            final int currentId = taskCounter.incrementAndGet();
            executor.execute(() -> {
                if (currentId != taskCounter.get()) return;

                Bitmap result = applyColorToAlpha(originalBitmap, targetCol, tol, smooth);

                if (currentId == taskCounter.get() && result != null) {
                    activity.runOnUiThread(() -> {
                        if (currentId == taskCounter.get() && activeLayer != null) {
                            activeLayer.bitmap = result;
                            activeLayer.isDirty = true;
                            if (activity.canvasView != null) activity.canvasView.invalidate();
                        }
                    });
                }
            });
        };

        final View.OnClickListener openPopupColorPickerAction = v -> {
            boolean openedViaProxy = false;
            try {
                Class<?> pClass = Class.forName("com.example.ejitor.popup");
                for (Method m : pClass.getDeclaredMethods()) {
                    if (m.getName().equals("showStandaloneColorPicker") && m.getParameterTypes().length == 3) {
                        Class<?> callbackType = m.getParameterTypes()[2];
                        Object proxy = Proxy.newProxyInstance(
                                callbackType.getClassLoader(),
                                new Class<?>[]{callbackType},
                                (p, method, args) -> {
                                    if (args != null && args.length > 0 && args[0] instanceof Integer) {
                                        final int newCol = (Integer) args[0];
                                        activity.runOnUiThread(() -> {
                                            selectedTargetColor = newCol;
                                            updateSwatchBg(colorSwatch, selectedTargetColor);
                                            triggerProcess.run();
                                        });
                                    }
                                    return null;
                                }
                        );
                        m.invoke(null, activity, selectedTargetColor, proxy);
                        openedViaProxy = true;
                        break;
                    }
                }
            } catch (Throwable ignored) {}

            if (!openedViaProxy) {
                activity.openColorPicker(v, true, false);

                final Handler watcherHandler = new Handler(Looper.getMainLooper());
                final int[] lastObservedColor = { getEditorActivityFgColor() };
                watcherHandler.post(new Runnable() {
                    int checks = 0;
                    @Override
                    public void run() {
                        int fg = getEditorActivityFgColor();
                        if (fg != lastObservedColor[0]) {
                            lastObservedColor[0] = fg;
                            selectedTargetColor = fg;
                            updateSwatchBg(colorSwatch, selectedTargetColor);
                            triggerProcess.run();
                        }
                        if (checks++ < 350 && dialog.isShowing()) {
                            watcherHandler.postDelayed(this, 80);
                        }
                    }
                });
            }
        };

        colorSwatch.setOnClickListener(openPopupColorPickerAction);
        paletteBtn.setOnClickListener(openPopupColorPickerAction);

        eyedropperBtn.setOnClickListener(v -> {
            isEyeDropperActive = true;
            Toast.makeText(activity, "Tap on image to pick color", Toast.LENGTH_SHORT).show();
            dialog.hide();

            activity.canvasView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (event.getAction() == MotionEvent.ACTION_UP && isEyeDropperActive) {
                        float cX = (event.getX() - session.panX) / session.scale;
                        float cY = (event.getY() - session.panY) / session.scale;

                        float localX = (cX - activeLayer.x) / activeLayer.scaleX;
                        float localY = (cY - activeLayer.y) / activeLayer.scaleY;

                        if (localX >= 0 && localX < originalBitmap.getWidth() && localY >= 0 && localY < originalBitmap.getHeight()) {
                            int pixel = originalBitmap.getPixel((int) localX, (int) localY);
                            selectedTargetColor = pixel;
                            updateSwatchBg(colorSwatch, selectedTargetColor);
                            triggerProcess.run();
                            Toast.makeText(activity, "Color Selected!", Toast.LENGTH_SHORT).show();
                        }

                        isEyeDropperActive = false;
                        activity.canvasView.setOnTouchListener(null);
                        dialog.show();
                        return true;
                    }
                    return true;
                }
            });
        });

        root.addView(createSliderRow("Tolerance:", 0, 100, (int) currentTolerance, "%", val -> {
            currentTolerance = val;
            triggerProcess.run();
        }));

        root.addView(createSliderRow("Smoothness:", 0, 20, (int) currentSmoothness, "px", val -> {
            currentSmoothness = val;
            triggerProcess.run();
        }));

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnRow.setPadding(0, dp(10), 0, 0);

        Button btnCancel = new Button(activity);
        btnCancel.setText("Cancel");
        btnCancel.setTextColor(Color.parseColor("#E0E0E0"));
        btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        GradientDrawable canBg = new GradientDrawable();
        canBg.setColor(Color.parseColor("#262626"));
        canBg.setStroke(dp(1), Color.parseColor("#383838"));
        canBg.setCornerRadius(dp(4));
        btnCancel.setBackground(canBg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(70), dp(30));
        cp.setMargins(0, 0, dp(8), 0);
        btnCancel.setLayoutParams(cp);

        Runnable cancelAction = () -> {
            activeLayer.bitmap = originalBitmap;
            if (activity.canvasView != null) activity.canvasView.invalidate();
            dialog.dismiss();
        };

        btnCancel.setOnClickListener(v -> cancelAction.run());
        closeX.setOnClickListener(v -> cancelAction.run());
        btnRow.addView(btnCancel);

        Button btnApply = new Button(activity);
        btnApply.setText("REMOVE");
        btnApply.setTextColor(Color.WHITE);
        btnApply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnApply.setTypeface(null, Typeface.BOLD);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setColor(Color.parseColor("#FF1238"));
        okBg.setCornerRadius(dp(4));
        btnApply.setBackground(okBg);
        btnApply.setLayoutParams(new LinearLayout.LayoutParams(dp(75), dp(30)));

        btnApply.setOnClickListener(v -> {
            if (activeLayer.bitmap != null) {
                activeLayer.isBlank = false;
                activeLayer.isDirty = true;
                invokePrivateMethod(activity, "recordHistory");
                invokePrivateMethod(activity, "updateLayersDockUI");
                invokePrivateSessionMethod(activity, "saveProjectToDisk", activity.getCurrentSession());
                Toast.makeText(activity, "Color Removed Successfully", Toast.LENGTH_SHORT).show();
            }
            dialog.dismiss();
        });
        btnRow.addView(btnApply);

        root.addView(btnRow);
        dialog.setContentView(root);
        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(dp(310), ViewGroup.LayoutParams.WRAP_CONTENT);
        }

        triggerProcess.run();
    }

    // =========================================================================
    // ২. ক্রপ টুল ডায়ালগ (Crop Tool Dialog)
    // =========================================================================
    private void openLayerCropDialog() {
        final EditorActivity.ProjectTabSession session = activity.getCurrentSession();
        if (session == null || session.layers.isEmpty() || session.activeLayerIndex < 0 || session.activeLayerIndex >= session.layers.size()) {
            Toast.makeText(activity, "Please select an active layer to crop", Toast.LENGTH_SHORT).show();
            return;
        }

        final EditorActivity.LayerItem activeLayer = session.layers.get(session.activeLayerIndex);
        if (activeLayer.bitmap == null || activeLayer.isBlank) {
            Toast.makeText(activity, "Selected layer has no image to crop", Toast.LENGTH_SHORT).show();
            return;
        }

        final Bitmap src = activeLayer.bitmap;
        final Dialog cropDialog = new Dialog(activity);
        cropDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(10));

        TextView tv = new TextView(activity);
        tv.setText("Crop Layer Image");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(tv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorIcon());
        closeX.setOnClickListener(v -> cropDialog.dismiss());
        header.addView(closeX);
        box.addView(header);

        final FrameLayout previewFrame = new FrameLayout(activity);
        final int previewMaxW = dp(270);
        final int previewMaxH = dp(200);

        float scale = Math.min((float) previewMaxW / src.getWidth(), (float) previewMaxH / src.getHeight());
        final int imgW = Math.max(10, (int) (src.getWidth() * scale));
        final int imgH = Math.max(10, (int) (src.getHeight() * scale));

        LinearLayout.LayoutParams fLp = new LinearLayout.LayoutParams(imgW, imgH);
        fLp.gravity = Gravity.CENTER_HORIZONTAL;
        fLp.setMargins(0, 0, 0, dp(10));
        previewFrame.setLayoutParams(fLp);

        ImageView iv = new ImageView(activity);
        iv.setImageBitmap(src);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);
        previewFrame.addView(iv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final RectF cropRect = new RectF(0, 0, imgW, imgH);
        final View cropOverlay = new View(activity) {
            private final Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Paint darkPaint = new Paint();
            private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

            {
                borderPaint.setColor(Color.WHITE);
                borderPaint.setStyle(Paint.Style.STROKE);
                borderPaint.setStrokeWidth(dp(1.8f));

                darkPaint.setColor(Color.parseColor("#99000000"));
                darkPaint.setStyle(Paint.Style.FILL);

                gridPaint.setColor(Color.parseColor("#80FFFFFF"));
                gridPaint.setStyle(Paint.Style.STROKE);
                gridPaint.setStrokeWidth(dp(0.8f));

                handlePaint.setColor(Color.parseColor("#FF1238"));
                handlePaint.setStyle(Paint.Style.FILL);
            }

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                canvas.drawRect(0, 0, getWidth(), cropRect.top, darkPaint);
                canvas.drawRect(0, cropRect.bottom, getWidth(), getHeight(), darkPaint);
                canvas.drawRect(0, cropRect.top, cropRect.left, cropRect.bottom, darkPaint);
                canvas.drawRect(cropRect.right, cropRect.top, getWidth(), cropRect.bottom, darkPaint);

                canvas.drawRect(cropRect, borderPaint);

                float wThird = cropRect.width() / 3f;
                float hThird = cropRect.height() / 3f;
                canvas.drawLine(cropRect.left + wThird, cropRect.top, cropRect.left + wThird, cropRect.bottom, gridPaint);
                canvas.drawLine(cropRect.left + wThird * 2, cropRect.top, cropRect.left + wThird * 2, cropRect.bottom, gridPaint);
                canvas.drawLine(cropRect.left, cropRect.top + hThird, cropRect.right, cropRect.top + hThird, gridPaint);
                canvas.drawLine(cropRect.left, cropRect.top + hThird * 2, cropRect.right, cropRect.top + hThird * 2, gridPaint);

                float hs = dp(4f);
                canvas.drawRect(cropRect.left - hs, cropRect.top - hs, cropRect.left + hs, cropRect.top + hs, handlePaint);
                canvas.drawRect(cropRect.right - hs, cropRect.top - hs, cropRect.right + hs, cropRect.top + hs, handlePaint);
                canvas.drawRect(cropRect.right - hs, cropRect.bottom - hs, cropRect.right + hs, cropRect.bottom + hs, handlePaint);
                canvas.drawRect(cropRect.left - hs, cropRect.bottom - hs, cropRect.left + hs, cropRect.bottom + hs, handlePaint);
            }

            int activeEdge = -1;
            float lastX, lastY;

            @Override
            public boolean onTouchEvent(MotionEvent event) {
                float x = event.getX();
                float y = event.getY();
                float hit = dp(18);

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        lastX = x;
                        lastY = y;
                        if (Math.hypot(x - cropRect.left, y - cropRect.top) < hit) activeEdge = 0;
                        else if (Math.hypot(x - cropRect.right, y - cropRect.top) < hit) activeEdge = 1;
                        else if (Math.hypot(x - cropRect.right, y - cropRect.bottom) < hit) activeEdge = 2;
                        else if (Math.hypot(x - cropRect.left, y - cropRect.bottom) < hit) activeEdge = 3;
                        else if (cropRect.contains(x, y)) activeEdge = 4;
                        else activeEdge = -1;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = x - lastX;
                        float dy = y - lastY;
                        lastX = x;
                        lastY = y;
                        if (activeEdge == 0) {
                            cropRect.left = Math.min(cropRect.right - dp(20), Math.max(0, cropRect.left + dx));
                            cropRect.top = Math.min(cropRect.bottom - dp(20), Math.max(0, cropRect.top + dy));
                        } else if (activeEdge == 1) {
                            cropRect.right = Math.max(cropRect.left + dp(20), Math.min(imgW, cropRect.right + dx));
                            cropRect.top = Math.min(cropRect.bottom - dp(20), Math.max(0, cropRect.top + dy));
                        } else if (activeEdge == 2) {
                            cropRect.right = Math.max(cropRect.left + dp(20), Math.min(imgW, cropRect.right + dx));
                            cropRect.bottom = Math.max(cropRect.top + dp(20), Math.min(imgH, cropRect.bottom + dy));
                        } else if (activeEdge == 3) {
                            cropRect.left = Math.min(cropRect.right - dp(20), Math.max(0, cropRect.left + dx));
                            cropRect.bottom = Math.max(cropRect.top + dp(20), Math.min(imgH, cropRect.bottom + dy));
                        } else if (activeEdge == 4) {
                            if (cropRect.left + dx >= 0 && cropRect.right + dx <= imgW) {
                                cropRect.left += dx;
                                cropRect.right += dx;
                            }
                            if (cropRect.top + dy >= 0 && cropRect.bottom + dy <= imgH) {
                                cropRect.top += dy;
                                cropRect.bottom += dy;
                            }
                        }
                        invalidate();
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        activeEdge = -1;
                        return true;
                }
                return false;
            }
        };
        previewFrame.addView(cropOverlay, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        box.addView(previewFrame);

        LinearLayout bRow = new LinearLayout(activity);
        bRow.setOrientation(LinearLayout.HORIZONTAL);
        bRow.setGravity(Gravity.CENTER_VERTICAL);
        bRow.setPadding(0, dp(4), 0, 0);

        Button autoTrimBtn = new Button(activity);
        autoTrimBtn.setText("Auto Trim");
        autoTrimBtn.setTextColor(Color.WHITE);
        autoTrimBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        GradientDrawable atBg = new GradientDrawable();
        atBg.setColor(Color.parseColor("#262626"));
        atBg.setStroke(dp(1), Color.parseColor("#383838"));
        atBg.setCornerRadius(dp(4));
        autoTrimBtn.setBackground(atBg);
        autoTrimBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(85), dp(30)));

        autoTrimBtn.setOnClickListener(v -> {
            Rect bounds = findNonTransparentBounds(src);
            if (bounds != null && bounds.width() > 10 && bounds.height() > 10) {
                cropRect.left = (bounds.left / (float) src.getWidth()) * imgW;
                cropRect.top = (bounds.top / (float) src.getHeight()) * imgH;
                cropRect.right = (bounds.right / (float) src.getWidth()) * imgW;
                cropRect.bottom = (bounds.bottom / (float) src.getHeight()) * imgH;
                cropOverlay.invalidate();
                Toast.makeText(activity, "Transparent Edges Trimmed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(activity, "No transparent edges found", Toast.LENGTH_SHORT).show();
            }
        });
        bRow.addView(autoTrimBtn);

        View sp = new View(activity);
        sp.setLayoutParams(new LinearLayout.LayoutParams(0, dp(1), 1f));
        bRow.addView(sp);

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("Cancel");
        cancelBtn.setTextColor(Color.parseColor("#CCCCCC"));
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        cancelBtn.setBackground(atBg);
        cancelBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(30)));
        cancelBtn.setOnClickListener(v -> cropDialog.dismiss());
        bRow.addView(cancelBtn);

        View sp3 = new View(activity);
        sp3.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(1)));
        bRow.addView(sp3);

        Button applyCropBtn = new Button(activity);
        applyCropBtn.setText("APPLY CROP");
        applyCropBtn.setTextColor(Color.WHITE);
        applyCropBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        applyCropBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable acBg = new GradientDrawable();
        acBg.setColor(Color.parseColor("#FF1238"));
        acBg.setCornerRadius(dp(4));
        applyCropBtn.setBackground(acBg);
        applyCropBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(95), dp(30)));

        applyCropBtn.setOnClickListener(v -> {
            try {
                int realX = (int) ((cropRect.left / imgW) * src.getWidth());
                int realY = (int) ((cropRect.top / imgH) * src.getHeight());
                int realW = (int) ((cropRect.width() / imgW) * src.getWidth());
                int realH = (int) ((cropRect.height() / imgH) * src.getHeight());

                realX = Math.max(0, Math.min(src.getWidth() - 1, realX));
                realY = Math.max(0, Math.min(src.getHeight() - 1, realY));
                realW = Math.max(1, Math.min(src.getWidth() - realX, realW));
                realH = Math.max(1, Math.min(src.getHeight() - realY, realH));

                Bitmap croppedBmp = Bitmap.createBitmap(src, realX, realY, realW, realH);
                if (croppedBmp != null) {
                    activeLayer.bitmap = croppedBmp;
                    activeLayer.x += realX * activeLayer.scaleX;
                    activeLayer.y += realY * activeLayer.scaleY;
                    activeLayer.isDirty = true;
                    invokePrivateMethod(activity, "recordHistory");
                    invokePrivateMethod(activity, "updateLayersDockUI");
                    invokePrivateSessionMethod(activity, "saveProjectToDisk", session);
                    if (activity.canvasView != null) activity.canvasView.invalidate();
                    Toast.makeText(activity, "Layer Cropped Successfully", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception ignored) {}
            cropDialog.dismiss();
        });
        bRow.addView(applyCropBtn);

        box.addView(bRow);
        cropDialog.setContentView(box);
        if (cropDialog.getWindow() != null) {
            cropDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            cropDialog.getWindow().setLayout(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        cropDialog.show();
    }

    private Rect findNonTransparentBounds(Bitmap bmp) {
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int[] pixels = new int[w];

        int minX = w, maxX = 0, minY = h, maxY = 0;
        boolean foundAny = false;

        for (int y = 0; y < h; y++) {
            bmp.getPixels(pixels, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if (((pixels[x] >>> 24) & 0xFF) > 10) {
                    foundAny = true;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (!foundAny) return null;
        return new Rect(minX, minY, Math.min(w, maxX + 1), Math.min(h, maxY + 1));
    }

    private void updateSwatchBg(View swatch, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setStroke(dp(1.5f), Color.WHITE);
        bg.setCornerRadius(dp(4));
        swatch.setBackground(bg);
    }

    private Bitmap applyColorToAlpha(Bitmap src, int targetColor, float tolerancePercent, float smoothness) {
        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);

        int tr = (targetColor >> 16) & 0xFF;
        int tg = (targetColor >> 8) & 0xFF;
        int tb = targetColor & 0xFF;

        float maxAllowedDist = (tolerancePercent / 100f) * 150.0f;

        for (int i = 0; i < pixels.length; i++) {
            int c = pixels[i];
            int a = (c >>> 24);
            if (a == 0) continue;

            int r = (c >> 16) & 0xFF;
            int g = (c >> 8) & 0xFF;
            int b = c & 0xFF;

            int dr = r - tr;
            int dg = g - tg;
            int db = b - tb;
            double dist = Math.sqrt(dr * dr + dg * dg + db * db);

            if (dist <= maxAllowedDist) {
                pixels[i] = 0x00FFFFFF;
            }
        }

        Bitmap output = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        output.setPixels(pixels, 0, w, 0, 0, w, h);
        return output;
    }

    private interface OnParamChangeListener { void onChange(float val); }

    private LinearLayout createSliderRow(String label, int min, int max, int defaultVal, String unit, OnParamChangeListener listener) {
        LinearLayout wrap = new LinearLayout(activity);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, 0, 0, dp(10));

        LinearLayout topRow = new LinearLayout(activity);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView labelTv = new TextView(activity);
        labelTv.setText(label);
        labelTv.setTextColor(Color.parseColor("#AAAAAA"));
        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        labelTv.setLayoutParams(new LinearLayout.LayoutParams(dp(95), ViewGroup.LayoutParams.WRAP_CONTENT));
        topRow.addView(labelTv);

        final EditText valBox = new EditText(activity);
        valBox.setText(String.valueOf(defaultVal));
        valBox.setTextColor(Color.WHITE);
        valBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        valBox.setGravity(Gravity.CENTER);
        valBox.setSingleLine(true);
        valBox.setInputType(InputType.TYPE_CLASS_NUMBER);
        valBox.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(28)));

        GradientDrawable valBg = new GradientDrawable();
        valBg.setColor(Color.parseColor("#121212"));
        valBg.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        valBg.setCornerRadius(dp(3));
        valBox.setBackground(valBg);
        topRow.addView(valBox);

        TextView unitTv = new TextView(activity);
        unitTv.setText("  " + unit);
        unitTv.setTextColor(Color.parseColor("#888888"));
        unitTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        topRow.addView(unitTv);
        wrap.addView(topRow);

        final SeekBar seekBar = new SeekBar(activity);
        seekBar.setMax(max - min);
        seekBar.setProgress(defaultVal - min);
        applyCustomSeekBarStyle(seekBar);
        wrap.addView(seekBar);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    int val = min + progress;
                    valBox.setText(String.valueOf(val));
                    if (listener != null) listener.onChange(val);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        valBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    String str = cs.toString().trim();
                    if (!str.isEmpty()) {
                        int val = Integer.parseInt(str);
                        val = Math.max(min, Math.min(max, val));
                        if (seekBar.getProgress() != (val - min)) {
                            seekBar.setProgress(val - min);
                            if (listener != null) listener.onChange(val);
                        }
                    }
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        return wrap;
    }
}