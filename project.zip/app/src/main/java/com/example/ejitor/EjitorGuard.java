package com.example.ejitor;

import android.util.Base64;

public class EjitorGuard {

    // এটি আপনার সিক্রেট চাবি (হ্যাকাররা জানবে না কারণ প্রোগার্ড এটিকে a,b,c বানিয়ে দেবে)
    private static final String SECRET_KEY = "EJITOR_2026_PRO";

    /**
     * ডিক্রিপ্ট ইঞ্জিন (অ্যাপ চলার সময় ইনক্রিপ্ট করা লেখাকে আসল লেখায় রূপান্তর করবে)
     * আপনি আপনার details.java ফাইলে এটি ব্যবহার করবেন।
     */
    public static String d(String encryptedBase64) {
        try {
            byte[] decoded = Base64.decode(encryptedBase64, Base64.DEFAULT);
            byte[] keyBytes = SECRET_KEY.getBytes("UTF-8");
            byte[] result = new byte[decoded.length];
            for (int i = 0; i < decoded.length; i++) {
                result[i] = (byte) (decoded[i] ^ keyBytes[i % keyBytes.length]);
            }
            return new String(result, "UTF-8");
        } catch (Exception e) {
            return "Error";
        }
    }

    /**
     * ইনক্রিপ্ট ইঞ্জিন (আপনার সাধারণ লেখাকে হ্যাকারদের থেকে লুকানোর কোড বানাবে)
     * এটি ব্যবহার করে আপনি আপনার লেখাগুলোকে একবার এনকোড করে নেবেন।
     */
    public static String e(String plainText) {
        try {
            byte[] textBytes = plainText.getBytes("UTF-8");
            byte[] keyBytes = SECRET_KEY.getBytes("UTF-8");
            byte[] result = new byte[textBytes.length];
            for (int i = 0; i < textBytes.length; i++) {
                result[i] = (byte) (textBytes[i] ^ keyBytes[i % keyBytes.length]);
            }
            return Base64.encodeToString(result, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }
}