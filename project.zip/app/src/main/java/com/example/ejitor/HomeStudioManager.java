package com.example.ejitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class HomeStudioManager {

    private final Activity activity;
    private LinearLayout rootLayout;
    private LinearLayout dynamicContentArea;
    private TextView panelTitle;
    private String currentTab = "home";
    private String currentModalCat = "Recent";

    // সাইডবার নেভিগেশন টেক্সট রেফারেন্স
    private TextView navHome;
    private TextView navLearn;
    private TextView navFiles;

    // আপনার নতুন ভার্সেল গেটওয়ে লিংক
    private static final String APP_GATEWAY_URL = "https://api-ke-linker.vercel.app/gateway/goggle";

    // Your Files ব্যাচ সিলেকশন স্টেট
    private boolean isBatchMode = false;
    private final Set<Integer> selectedProjectIndices = new HashSet<>();

    // কাস্টম ব্যাকগ্রাউন্ড কালার সিলেক্টর
    private int selectedBgColor = Color.WHITE;
    private View liveSwatchPreview;

    public static final int REQ_OPEN_HOME_FILE = 1001;

    // ইউনিট, কালার মোড ও ডিপিআই কনফিগারেশন স্টেট
    private String currentUnit = "Pixels";
    private String currentColorMode = "RGB Color";
    private String currentBitDepth = "8 bit";
    private int currentDpi = 72;

    // মোট ১২০টি ফটোশপ স্ট্যান্ডার্ড প্রিসেট টেমপ্লেট
    private final String[][] templates = {
            // Social Media & Recent (1-20)
            {"YouTube Thumbnail", "1280", "720", "Recent"},
            {"Instagram Square Post", "1080", "1080", "Recent"},
            {"Instagram Story / Reel", "1080", "1920", "Recent"},
            {"Facebook Post", "1200", "630", "Recent"},
            {"Twitter / X Post", "1200", "675", "Recent"},
            {"Pinterest Pin", "1000", "1500", "Recent"},
            {"LinkedIn Banner", "1584", "396", "Recent"},
            {"YouTube Channel Banner", "2560", "1440", "Recent"},
            {"Twitch Stream Overlay", "1920", "1080", "Recent"},
            {"Facebook Cover Photo", "851", "315", "Recent"},
            {"Twitter Header Graphic", "1500", "500", "Recent"},
            {"TikTok Video Canvas", "1080", "1920", "Recent"},
            {"Instagram Portrait Post", "1080", "1350", "Recent"},
            {"Discord Server Banner", "960", "540", "Recent"},
            {"Snapchat Geofilter", "1080", "2340", "Recent"},
            {"Etsy Shop Banner", "1200", "300", "Recent"},
            {"SoundCloud Header", "2480", "520", "Recent"},
            {"Twitch Profile Banner", "1200", "480", "Recent"},
            {"Spotify Playlist Cover", "1000", "1000", "Recent"},
            {"Weibo Standard Post", "1200", "675", "Recent"},

            // Film & Video (21-40)
            {"Full HD 1080p", "1920", "1080", "Film & Video"},
            {"4K Ultra HD Display", "3840", "2160", "Film & Video"},
            {"720p HD Video Screen", "1280", "720", "Film & Video"},
            {"DCI 4K Cinema Scope", "4096", "2160", "Film & Video"},
            {"8K Super Ultra HD", "7680", "4320", "Film & Video"},
            {"Cinemascope 21:9", "2560", "1080", "Film & Video"},
            {"Anamorphic 2.39:1", "3840", "1606", "Film & Video"},
            {"IMAX Digital Aspect", "1920", "1440", "Film & Video"},
            {"Vertical Shorts 2K", "1440", "2560", "Film & Video"},
            {"Broadcast NTSC D1", "720", "486", "Film & Video"},
            {"Broadcast PAL D1", "720", "576", "Film & Video"},
            {"HDV 1080 Anamorphic", "1440", "1080", "Film & Video"},
            {"UHDTV 4K Video", "3840", "2160", "Film & Video"},
            {"YouTube Shorts 4K", "2160", "3840", "Film & Video"},
            {"GoPro Hero 4:3", "4000", "3000", "Film & Video"},
            {"Drone 4K Aerial", "4000", "2250", "Film & Video"},
            {"Retro CRT Monitor 4:3", "1024", "768", "Film & Video"},
            {"VGA Standard Display", "640", "480", "Film & Video"},
            {"SVGA Retro Frame", "800", "600", "Film & Video"},
            {"Ultrawide QHD", "3440", "1440", "Film & Video"},

            // Print & Paper (41-60)
            {"A4 Paper (300 DPI)", "2480", "3508", "Print"},
            {"A3 Poster (300 DPI)", "3508", "4960", "Print"},
            {"A5 Booklet (300 DPI)", "1748", "2480", "Print"},
            {"US Letter Standard", "2550", "3300", "Print"},
            {"US Legal Document", "2550", "4200", "Print"},
            {"Tabloid Newspaper", "3300", "5100", "Print"},
            {"Business Card (Standard)", "1050", "600", "Print"},
            {"Square Business Card", "750", "750", "Print"},
            {"Poster Architectural D", "2400", "3600", "Print"},
            {"Poster Architectural C", "1800", "2400", "Print"},
            {"Flyer US Half Letter", "1650", "2550", "Print"},
            {"Postcard International", "1800", "1200", "Print"},
            {"Trifold Brochure Page", "2550", "3300", "Print"},
            {"Magazine Cover Full", "2550", "3300", "Print"},
            {"Book Cover Standard", "1800", "2700", "Print"},
            {"B5 Journal Sheet", "2079", "2953", "Print"},
            {"A6 Postcard Print", "1240", "1748", "Print"},
            {"Letterhead Corporate", "2550", "3300", "Print"},
            {"Gift Certificate", "2400", "1200", "Print"},
            {"Event Ticket Stub", "1650", "600", "Print"},

            // Mobile & Devices (61-80)
            {"iPhone 15 Pro", "1179", "2556", "Mobile"},
            {"iPhone 15 Pro Max", "1290", "2796", "Mobile"},
            {"iPhone 14 / 13", "1170", "2532", "Mobile"},
            {"iPhone SE 3rd Gen", "750", "1334", "Mobile"},
            {"Android Flagship 2K", "1440", "3200", "Mobile"},
            {"Android FHD+ Screen", "1080", "2400", "Mobile"},
            {"iPad Pro 12.9 Retina", "2048", "2732", "Mobile"},
            {"iPad Air 10.9", "1640", "2360", "Mobile"},
            {"iPad Mini 8.3", "1488", "2266", "Mobile"},
            {"Samsung Galaxy S24 Ultra", "1440", "3120", "Mobile"},
            {"Google Pixel 8 Pro", "1344", "2992", "Mobile"},
            {"Apple Watch Ultra", "410", "502", "Mobile"},
            {"Apple Watch 45mm", "396", "484", "Mobile"},
            {"Android Wear Square", "450", "450", "Mobile"},
            {"Tablet 10 Inch Display", "1920", "1200", "Mobile"},
            {"Foldable Inner Screen", "1812", "2176", "Mobile"},
            {"Foldable Outer Cover", "904", "2316", "Mobile"},
            {"Surface Pro 13 Inch", "2880", "1920", "Mobile"},
            {"Kindle Paperwhite Display", "1236", "1648", "Mobile"},
            {"Steam Deck Portable", "1280", "800", "Mobile"},

            // Web & UI/UX (81-100)
            {"Web Large Desktop", "1920", "1080", "Web"},
            {"Web Medium Desktop", "1440", "900", "Web"},
            {"Web Small Laptop", "1366", "768", "Web"},
            {"MacBook Pro 16 Inch", "3456", "2234", "Web"},
            {"MacBook Air 13 Inch", "2560", "1664", "Web"},
            {"iMac 24 Inch 4.5K", "4480", "2520", "Web"},
            {"Web Header Standard", "1200", "400", "Web"},
            {"Blog Post Header", "1200", "800", "Web"},
            {"Dribbble Portfolio Shot", "1600", "1200", "Web"},
            {"Dribbble HD Video", "1920", "1440", "Web"},
            {"Behance Project Cover", "1600", "1200", "Web"},
            {"Behance Full Width Strip", "1400", "3000", "Web"},
            {"Leaderboard Banner Ad", "728", "90", "Web"},
            {"Medium Rectangle Ad", "300", "250", "Web"},
            {"Skyscraper Banner Ad", "160", "600", "Web"},
            {"Billboard Web Ad", "970", "250", "Web"},
            {"Email Newsletter Header", "600", "300", "Web"},
            {"Hero Image Web Strip", "1920", "700", "Web"},
            {"Landing Page Section", "1920", "1200", "Web"},
            {"Favicon / App Icon HD", "1024", "1024", "Web"},

            // Photo Studio & Art (101-120)
            {"Photo 4x6 Small Print", "1800", "1200", "Photo"},
            {"Photo 5x7 Classic Print", "2100", "1500", "Photo"},
            {"Photo 8x10 Gallery Print", "2400", "3000", "Photo"},
            {"Photo 11x14 Master Print", "3300", "4200", "Photo"},
            {"Photo 16x20 Exhibition", "4800", "6000", "Photo"},
            {"Square Photo Print 8x8", "2400", "2400", "Photo"},
            {"Square Photo Print 12x12", "3600", "3600", "Photo"},
            {"Wallet Prints (Pair)", "1500", "1050", "Photo"},
            {"Panoramic Photo Landscape", "5400", "1800", "Photo"},
            {"Canvas Wrap 20x30", "6000", "9000", "Photo"},
            {"Square Album Cover", "3000", "3000", "Saved"},
            {"Icon Master 512x512", "512", "512", "Saved"},
            {"Master Canvas 4K Square", "4096", "4096", "Saved"},
            {"Pixel Art Workspace", "256", "256", "Saved"},
            {"Vector Icon 128x128", "128", "128", "Saved"},
            {"High Quality Logo Canvas", "2000", "2000", "Saved"},
            {"NFT Collectible Frame", "3000", "3000", "Saved"},
            {"Merchandise T-Shirt Art", "4500", "5400", "Saved"},
            {"Coffee Mug Wrap Canvas", "2625", "1050", "Saved"},
            {"Ultra Hi-Res Master 8K", "8192", "8192", "Saved"}
    };

    public HomeStudioManager(Activity activity) {
        this.activity = activity;
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private static int dpStatic(Context ctx, float value) {
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private String normalizeTitle(String title) {
        if (title == null) return "";
        return title.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(Locale.ROOT);
    }

    private float toPixels(float value, String unit, int dpi) {
        if ("Inches".equalsIgnoreCase(unit)) return value * dpi;
        else if ("Centimeters".equalsIgnoreCase(unit)) return (value / 2.54f) * dpi;
        else if ("Millimeters".equalsIgnoreCase(unit)) return (value / 25.4f) * dpi;
        return value;
    }

    private float fromPixels(float pixels, String unit, int dpi) {
        if ("Inches".equalsIgnoreCase(unit)) return pixels / (float) dpi;
        else if ("Centimeters".equalsIgnoreCase(unit)) return (pixels * 2.54f) / (float) dpi;
        else if ("Millimeters".equalsIgnoreCase(unit)) return (pixels * 25.4f) / (float) dpi;
        return pixels;
    }

    private String formatUnitValue(float val, String unit) {
        if ("Pixels".equalsIgnoreCase(unit)) return String.valueOf(Math.round(val));
        else if ("Millimeters".equalsIgnoreCase(unit)) return String.format(Locale.US, "%.1f", val);
        else return String.format(Locale.US, "%.2f", val);
    }

    public View buildHomeScreen() {
        checkAppUpdate();

        rootLayout = new LinearLayout(activity);
        rootLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootLayout.setOrientation(LinearLayout.HORIZONTAL);
        rootLayout.setBackgroundColor(Color.parseColor("#181818"));

        int screenW = activity.getResources().getDisplayMetrics().widthPixels;
        int sidebarW = (screenW < dp(500)) ? dp(145) : dp(210);

        ScrollView sidebarScroll = new ScrollView(activity);
        sidebarScroll.setLayoutParams(new LinearLayout.LayoutParams(sidebarW, ViewGroup.LayoutParams.MATCH_PARENT));
        sidebarScroll.setFillViewport(true);
        sidebarScroll.setVerticalScrollBarEnabled(false);
        sidebarScroll.setBackgroundColor(Color.parseColor("#141414"));

        LinearLayout sidebar = createSidebar();
        sidebarScroll.addView(sidebar);
        rootLayout.addView(sidebarScroll);

        LinearLayout mainPanel = new LinearLayout(activity);
        LinearLayout.LayoutParams mainParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        mainPanel.setLayoutParams(mainParams);
        mainPanel.setOrientation(LinearLayout.VERTICAL);
        mainPanel.setPadding(dp(14), dp(16), dp(14), dp(16));
        mainPanel.setBackgroundColor(Color.parseColor("#181818"));

        panelTitle = new TextView(activity);
        panelTitle.setText("Recent");
        panelTitle.setTextColor(Color.WHITE);
        panelTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        panelTitle.setTypeface(null, Typeface.BOLD);
        panelTitle.setPadding(0, 0, 0, dp(12));
        mainPanel.addView(panelTitle);

        ScrollView scroll = new ScrollView(activity);
        scroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        scroll.setFillViewport(true);

        dynamicContentArea = new LinearLayout(activity);
        dynamicContentArea.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dynamicContentArea.setOrientation(LinearLayout.VERTICAL);

        scroll.addView(dynamicContentArea);
        mainPanel.addView(scroll);

        rootLayout.addView(mainPanel);

        switchTab("home");
        return rootLayout;
    }

    private void checkAppUpdate() {
        new Thread(() -> {
            try {
                URL url = new URL(APP_GATEWAY_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(6000);
                conn.setReadTimeout(6000);

                int respCode = conn.getResponseCode();
                InputStream is = (respCode >= 200 && respCode < 400) ? conn.getInputStream() : conn.getErrorStream();

                if (is != null) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();

                    String res = sb.toString();
                    if (res != null && !res.equals("null") && !res.trim().isEmpty()) {
                        JSONObject obj = new JSONObject(res);

                        boolean shouldLock = false;
                        String title = "APP NOTICE";
                        String message = "This app is temporarily disabled.";
                        String updateUrl = "https://t.me/ejitor_jr";
                        String btnText = "Exit";

                        String appStatus = obj.optString("app_status", "");
                        String status = obj.optString("status", "");

                        if ("offline".equalsIgnoreCase(appStatus) || "blocked".equalsIgnoreCase(appStatus) || "banned".equalsIgnoreCase(status) || respCode == 403) {
                            shouldLock = true;
                            if (obj.has("popup")) {
                                JSONObject popup = obj.optJSONObject("popup");
                                if (popup != null) {
                                    title = popup.optString("title", "APP NOTICE");
                                    message = popup.optString("message", "App is temporarily closed.");
                                    btnText = popup.optString("btnText", "OK");
                                    updateUrl = popup.optString("btnUrl", "https://t.me/ejitor_jr");
                                }
                            } else {
                                message = obj.optString("message", "App is disabled by admin.");
                                title = "APP NOTICE";
                            }
                        } else if (obj.optBoolean("force_update", false) || "true".equalsIgnoreCase(obj.optString("force_update"))) {
                            shouldLock = true;
                            title = "APP UPDATE REQUIRED";
                            message = obj.optString("update_message", "A new version of EJITOR is available! Please update.");
                            updateUrl = obj.optString("update_url", "https://t.me/ejitor_jr");
                            btnText = obj.optString("btn_text", "Update Now");
                        }

                        if (shouldLock) {
                            final String fTitle = title;
                            final String fMessage = message;
                            final String fUrl = updateUrl;
                            final String fBtn = btnText;
                            new Handler(Looper.getMainLooper()).post(() -> showUpdateLockDialog(fTitle, fMessage, fUrl, fBtn));
                        }
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void showUpdateLockDialog(String title, String message, final String updateUrl, String btnText) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        LinearLayout container = new LinearLayout(activity);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setGravity(Gravity.CENTER_HORIZONTAL);
        container.setPadding(dp(26), dp(28), dp(26), dp(28));

        GradientDrawable bgShape = new GradientDrawable();
        bgShape.setColor(Color.parseColor("#141414"));
        bgShape.setStroke(dp(1.8f), Color.parseColor("#FF1238"));
        bgShape.setCornerRadius(dp(18));
        container.setBackground(bgShape);

        TextView titleTv = new TextView(activity);
        titleTv.setText(title != null && !title.isEmpty() ? title : "APP UPDATE REQUIRED");
        titleTv.setTextColor(Color.parseColor("#FF1238"));
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setGravity(Gravity.CENTER);
        container.addView(titleTv);

        TextView msgTv = new TextView(activity);
        msgTv.setText(message);
        msgTv.setTextColor(Color.parseColor("#E0E0E0"));
        msgTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        msgTv.setGravity(Gravity.CENTER);
        msgTv.setPadding(0, dp(14), 0, dp(24));
        container.addView(msgTv);

        LinearLayout btnContainer = new LinearLayout(activity);
        btnContainer.setOrientation(LinearLayout.HORIZONTAL);
        btnContainer.setGravity(Gravity.CENTER);
        btnContainer.setWeightSum(2f);

        Button exitBtn = new Button(activity);
        exitBtn.setText("Exit");
        exitBtn.setTextColor(Color.parseColor("#121212"));
        exitBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        exitBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable exitBg = new GradientDrawable();
        exitBg.setColor(Color.WHITE);
        exitBg.setCornerRadius(dp(8));
        exitBtn.setBackground(exitBg);
        LinearLayout.LayoutParams exitParams = new LinearLayout.LayoutParams(0, dp(46), 1f);
        exitParams.setMargins(0, 0, dp(8), 0);
        exitBtn.setLayoutParams(exitParams);
        exitBtn.setOnClickListener(v -> {
            activity.finishAffinity();
            System.exit(0);
        });

        Button updateBtn = new Button(activity);
        updateBtn.setText(btnText != null && !btnText.isEmpty() ? btnText : "Update");
        updateBtn.setTextColor(Color.parseColor("#121212"));
        updateBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        updateBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable updateBg = new GradientDrawable();
        updateBg.setColor(Color.WHITE);
        updateBg.setCornerRadius(dp(8));
        updateBtn.setBackground(updateBg);
        LinearLayout.LayoutParams updateParams = new LinearLayout.LayoutParams(0, dp(46), 1f);
        updateParams.setMargins(dp(8), 0, 0, 0);
        updateBtn.setLayoutParams(updateParams);
        updateBtn.setOnClickListener(v -> {
            try {
                if (updateUrl != null && !updateUrl.isEmpty()) {
                    activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl)));
                }
            } catch (Exception ignored) {}
            activity.finishAffinity();
            System.exit(0);
        });

        btnContainer.addView(exitBtn);
        btnContainer.addView(updateBtn);
        container.addView(btnContainer);

        dialog.setContentView(container);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            int dialogWidth = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.88);
            dialog.getWindow().setLayout(Math.min(dp(380), dialogWidth), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private LinearLayout createSidebar() {
        LinearLayout sidebar = new LinearLayout(activity);
        sidebar.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sidebar.setBackgroundColor(Color.parseColor("#141414"));
        sidebar.setOrientation(LinearLayout.VERTICAL);
        sidebar.setPadding(dp(10), dp(16), dp(10), dp(30));

        LinearLayout topBrand = new LinearLayout(activity);
        topBrand.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        topBrand.setOrientation(LinearLayout.HORIZONTAL);
        topBrand.setGravity(Gravity.CENTER_VERTICAL);
        topBrand.setPadding(0, 0, 0, dp(16));

        // রিয়েল অ্যাপ আইকন: assets/ejitor.png থেকে লোড
        Bitmap customAppIcon = null;
        try (InputStream is = activity.getAssets().open("ejitor.png")) {
            customAppIcon = BitmapFactory.decodeStream(is);
        } catch (Exception ignored) {}

        if (customAppIcon != null) {
            ImageView appIconIv = new ImageView(activity);
            appIconIv.setImageBitmap(customAppIcon);
            appIconIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            GradientDrawable cr = new GradientDrawable();
            cr.setCornerRadius(dp(4));
            appIconIv.setBackground(cr);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                appIconIv.setClipToOutline(true);
            }
            topBrand.addView(appIconIv, new LinearLayout.LayoutParams(dp(24), dp(24)));
        } else {
            TextView badge = new TextView(activity);
            badge.setText("e");
            badge.setTextColor(Color.WHITE);
            badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            badge.setTypeface(null, Typeface.BOLD);
            badge.setGravity(Gravity.CENTER);
            GradientDrawable badgeBg = new GradientDrawable();
            badgeBg.setColor(Color.parseColor("#FF1238"));
            badgeBg.setCornerRadius(dp(4));
            badge.setBackground(badgeBg);
            topBrand.addView(badge, new LinearLayout.LayoutParams(dp(24), dp(24)));
        }

        // 2026 বাদ দিয়ে বড় হাতের অক্ষরে "EJITOR"
        TextView title = new TextView(activity);
        title.setText("  EJITOR");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
        title.setTypeface(null, Typeface.BOLD);
        topBrand.addView(title);
        sidebar.addView(topBrand);

        Button btnNew = new Button(activity);
        btnNew.setText("+ NEW PROJECT");
        btnNew.setTextColor(Color.WHITE);
        btnNew.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnNew.setTypeface(null, Typeface.BOLD);
        btnNew.setGravity(Gravity.CENTER);
        GradientDrawable redPill = new GradientDrawable();
        redPill.setColor(Color.parseColor("#FF1238"));
        redPill.setCornerRadius(dp(24));
        btnNew.setBackground(redPill);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        np.setMargins(0, 0, 0, dp(8));
        btnNew.setLayoutParams(np);
        btnNew.setOnClickListener(v -> openNewProjectDialog());
        sidebar.addView(btnNew);

        Button btnOpen = new Button(activity);
        btnOpen.setText("OPEN");
        btnOpen.setTextColor(Color.parseColor("#E0E0E0"));
        btnOpen.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        btnOpen.setGravity(Gravity.CENTER);
        GradientDrawable darkPill = new GradientDrawable();
        darkPill.setColor(Color.parseColor("#202020"));
        darkPill.setStroke(dp(1), Color.parseColor("#3C3C3C"));
        darkPill.setCornerRadius(dp(24));
        btnOpen.setBackground(darkPill);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40));
        op.setMargins(0, 0, 0, dp(18));
        btnOpen.setLayoutParams(op);
        btnOpen.setOnClickListener(v -> openUnifiedFilePicker());
        sidebar.addView(btnOpen);

        navHome = createNavItem("Home", true, v -> switchTab("home"));
        navLearn = createNavItem("Learn", false, v -> switchTab("learn"));
        sidebar.addView(navHome);
        sidebar.addView(navLearn);

        TextView fileHeading = new TextView(activity);
        fileHeading.setText("FILES");
        fileHeading.setTextColor(Color.parseColor("#666666"));
        fileHeading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        fileHeading.setTypeface(null, Typeface.BOLD);
        fileHeading.setPadding(dp(8), dp(14), 0, dp(4));
        sidebar.addView(fileHeading);

        navFiles = createNavItem("Your files", false, v -> switchTab("files"));
        sidebar.addView(navFiles);

        TextView commHeading = new TextView(activity);
        commHeading.setText("COMMUNITY");
        commHeading.setTextColor(Color.parseColor("#666666"));
        commHeading.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        commHeading.setTypeface(null, Typeface.BOLD);
        commHeading.setPadding(dp(8), dp(18), 0, dp(4));
        sidebar.addView(commHeading);

        sidebar.addView(createNavItem("jr.d.s.page", false, v -> openLink("https://www.facebook.com/share/1Ep6UsYPM5/")));
        sidebar.addView(createNavItem("jr.d.s.telegram", false, v -> openLink("https://t.me/jrdesignstore50")));
        sidebar.addView(createNavItem("Official Channel", false, v -> openLink("https://t.me/ejitor_jr")));
        sidebar.addView(createNavItem("Discussion & Help", false, v -> openLink("https://t.me/ejitorcommunicatio_jr")));

        return sidebar;
    }

    private TextView createNavItem(String text, boolean active, View.OnClickListener listener) {
        TextView item = new TextView(activity);
        item.setText(text);
        item.setTextColor(active ? Color.WHITE : Color.parseColor("#999999"));
        item.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        item.setTypeface(null, active ? Typeface.BOLD : Typeface.NORMAL);
        item.setPadding(dp(10), dp(8), dp(10), dp(8));
        item.setOnClickListener(listener);
        return item;
    }

    private void switchTab(String tab) {
        currentTab = tab;
        isBatchMode = false;
        selectedProjectIndices.clear();

        if (navHome != null && navLearn != null && navFiles != null) {
            navHome.setTextColor(tab.equals("home") ? Color.WHITE : Color.parseColor("#888888"));
            navHome.setTypeface(null, tab.equals("home") ? Typeface.BOLD : Typeface.NORMAL);

            navLearn.setTextColor(tab.equals("learn") ? Color.WHITE : Color.parseColor("#888888"));
            navLearn.setTypeface(null, tab.equals("learn") ? Typeface.BOLD : Typeface.NORMAL);

            navFiles.setTextColor(tab.equals("files") ? Color.WHITE : Color.parseColor("#888888"));
            navFiles.setTypeface(null, tab.equals("files") ? Typeface.BOLD : Typeface.NORMAL);
        }

        if (tab.equals("home")) {
            panelTitle.setText("Recent");
            renderHomeContent();
        } else if (tab.equals("files")) {
            panelTitle.setText("Your files");
            renderFilesContent();
        } else if (tab.equals("learn")) {
            launchDetailsActivity();
        }
    }

    private void renderHomeContent() {
        dynamicContentArea.removeAllViews();

        ArrayList<View> allCards = new ArrayList<>();

        LinearLayout createNewCard = new LinearLayout(activity);
        createNewCard.setOrientation(LinearLayout.VERTICAL);
        createNewCard.setPadding(dp(6), dp(6), dp(6), dp(6));

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#1E1E1E"));
        cardBg.setCornerRadius(dp(6));
        cardBg.setStroke(dp(1), Color.parseColor("#282828"));
        createNewCard.setBackground(cardBg);
        createNewCard.setOnClickListener(v -> openNewProjectDialog());

        FrameLayout newThumbFrame = new FrameLayout(activity);
        newThumbFrame.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(105)));
        GradientDrawable ntBg = new GradientDrawable();
        ntBg.setColor(Color.parseColor("#141414"));
        ntBg.setCornerRadius(dp(4));
        newThumbFrame.setBackground(ntBg);

        ImageView thumb = new ImageView(activity);
        thumb.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        thumb.setImageDrawable(createPhotoshopDocIcon(dp(28), dp(28), "#FF1238"));
        thumb.setScaleType(ImageView.ScaleType.CENTER);
        newThumbFrame.addView(thumb);
        createNewCard.addView(newThumbFrame);

        TextView cardTitle = new TextView(activity);
        cardTitle.setText("Create New");
        cardTitle.setTextColor(Color.WHITE);
        cardTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        cardTitle.setTypeface(null, Typeface.BOLD);
        cardTitle.setSingleLine(true);
        cardTitle.setPadding(dp(2), dp(6), 0, dp(1));
        createNewCard.addView(cardTitle);

        TextView cardSub = new TextView(activity);
        cardSub.setText("Click to design");
        cardSub.setTextColor(Color.parseColor("#888888"));
        cardSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        cardSub.setSingleLine(true);
        cardSub.setPadding(dp(2), 0, 0, dp(2));
        createNewCard.addView(cardSub);

        allCards.add(createNewCard);

        JSONArray arr = getSavedProjects();
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject obj = arr.getJSONObject(i);
                final String pName = obj.optString("title", "Untitled-1");
                final String pDate = obj.optString("date", "Saved Project");
                final int w = obj.optInt("width", 1080);
                final int h = obj.optInt("height", 1080);
                final int artboards = obj.optInt("artboards", 1);
                final int bg = obj.optInt("bg", Color.WHITE);

                LinearLayout recentProjCard = new LinearLayout(activity);
                recentProjCard.setOrientation(LinearLayout.VERTICAL);
                recentProjCard.setPadding(dp(6), dp(6), dp(6), dp(6));

                GradientDrawable rCardBg = new GradientDrawable();
                rCardBg.setColor(Color.parseColor("#1E1E1E"));
                rCardBg.setCornerRadius(dp(6));
                rCardBg.setStroke(dp(1), Color.parseColor("#282828"));
                recentProjCard.setBackground(rCardBg);

                FrameLayout thumbFrame = new FrameLayout(activity);
                thumbFrame.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(105)));

                GradientDrawable tfBg = new GradientDrawable();
                tfBg.setColor(Color.parseColor("#141414"));
                tfBg.setCornerRadius(dp(4));
                thumbFrame.setBackground(tfBg);

                ImageView projThumb = new ImageView(activity);
                projThumb.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                projThumb.setScaleType(ImageView.ScaleType.FIT_CENTER);

                Bitmap actualPreview = getProjectThumbnail(pName, bg);
                projThumb.setImageBitmap(actualPreview);
                thumbFrame.addView(projThumb);
                recentProjCard.addView(thumbFrame);

                TextView pTitle = new TextView(activity);
                pTitle.setText(pName);
                pTitle.setTextColor(Color.WHITE);
                pTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                pTitle.setTypeface(null, Typeface.BOLD);
                pTitle.setSingleLine(true);
                pTitle.setPadding(dp(2), dp(6), 0, dp(1));
                recentProjCard.addView(pTitle);

                TextView pSub = new TextView(activity);
                pSub.setText((artboards > 1 ? artboards + " Artboards • " : "") + pDate);
                pSub.setTextColor(Color.parseColor("#888888"));
                pSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
                pSub.setSingleLine(true);
                pSub.setPadding(dp(2), 0, 0, dp(2));
                recentProjCard.addView(pSub);

                recentProjCard.setOnClickListener(v -> launchEditor(pName, w, h, artboards, bg));
                allCards.add(recentProjCard);
            } catch (Exception ignored) {}
        }

        final int cols = 3;
        for (int i = 0; i < allCards.size(); i += cols) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setWeightSum(3f);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rowParams.setMargins(0, 0, 0, dp(10));
            row.setLayoutParams(rowParams);

            for (int j = 0; j < cols; j++) {
                if (i + j < allCards.size()) {
                    View card = allCards.get(i + j);
                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    if (j > 0) cp.setMargins(dp(8), 0, 0, 0);
                    card.setLayoutParams(cp);
                    row.addView(card);
                } else {
                    View emptySpace = new View(activity);
                    LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    if (j > 0) ep.setMargins(dp(8), 0, 0, 0);
                    emptySpace.setLayoutParams(ep);
                    row.addView(emptySpace);
                }
            }
            dynamicContentArea.addView(row);
        }
    }

    public static void showProjectPickerDialog(final Activity act) {
        if (act == null) return;

        final Dialog pickDialog = new Dialog(act);
        pickDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(act);
        root.setLayoutParams(new LinearLayout.LayoutParams(dpStatic(act, 480), dpStatic(act, 380)));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#181818"));
        root.setPadding(dpStatic(act, 14), dpStatic(act, 12), dpStatic(act, 14), dpStatic(act, 12));

        GradientDrawable rBg = new GradientDrawable();
        rBg.setColor(Color.parseColor("#181818"));
        rBg.setStroke(dpStatic(act, 1), Color.parseColor("#333333"));
        rBg.setCornerRadius(dpStatic(act, 10));
        root.setBackground(rBg);

        LinearLayout topBar = new LinearLayout(act);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(0, 0, 0, dpStatic(act, 10));

        TextView titleTv = new TextView(act);
        titleTv.setText("Project Add (Select to Add as Tabs)");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topBar.addView(titleTv);

        TextView closeX = new TextView(act);
        closeX.setText("✕");
        closeX.setTextColor(Color.parseColor("#888888"));
        closeX.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        closeX.setPadding(dpStatic(act, 6), dpStatic(act, 2), dpStatic(act, 6), dpStatic(act, 2));
        closeX.setOnClickListener(v -> pickDialog.dismiss());
        topBar.addView(closeX);
        root.addView(topBar);

        final ArrayList<String> selectedProjects = new ArrayList<>();
        final Button addBtn = new Button(act);

        ScrollView sv = new ScrollView(act);
        sv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        sv.setFillViewport(true);

        LinearLayout cardsContainer = new LinearLayout(act);
        cardsContainer.setOrientation(LinearLayout.VERTICAL);

        HomeStudioManager hsm = new HomeStudioManager(act);
        JSONArray arr = hsm.getSavedProjects();

        if (arr.length() == 0) {
            TextView noProj = new TextView(act);
            noProj.setText("No saved projects found in Home Studio.");
            noProj.setTextColor(Color.parseColor("#777777"));
            noProj.setPadding(0, dpStatic(act, 20), 0, 0);
            cardsContainer.addView(noProj);
        } else {
            ArrayList<View> cardViews = new ArrayList<>();
            for (int i = 0; i < arr.length(); i++) {
                try {
                    JSONObject obj = arr.getJSONObject(i);
                    final String pName = obj.optString("title", "Project");
                    final int bg = obj.optInt("bg", Color.WHITE);

                    final LinearLayout c = new LinearLayout(act);
                    c.setOrientation(LinearLayout.VERTICAL);
                    c.setPadding(dpStatic(act, 6), dpStatic(act, 6), dpStatic(act, 6), dpStatic(act, 6));

                    final GradientDrawable cBg = new GradientDrawable();
                    cBg.setColor(Color.parseColor("#222222"));
                    cBg.setStroke(dpStatic(act, 1), Color.parseColor("#333333"));
                    cBg.setCornerRadius(dpStatic(act, 6));
                    c.setBackground(cBg);

                    ImageView thumb = new ImageView(act);
                    thumb.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpStatic(act, 80)));
                    thumb.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    thumb.setImageBitmap(hsm.getProjectThumbnail(pName, bg));
                    c.addView(thumb);

                    TextView pTv = new TextView(act);
                    pTv.setText(pName);
                    pTv.setTextColor(Color.WHITE);
                    pTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                    pTv.setTypeface(null, Typeface.BOLD);
                    pTv.setSingleLine(true);
                    pTv.setPadding(dpStatic(act, 2), dpStatic(act, 4), 0, 0);
                    c.addView(pTv);

                    c.setOnClickListener(v -> {
                        if (selectedProjects.contains(pName)) {
                            selectedProjects.remove(pName);
                            cBg.setColor(Color.parseColor("#222222"));
                            cBg.setStroke(dpStatic(act, 1), Color.parseColor("#333333"));
                            pTv.setText(pName);
                        } else {
                            selectedProjects.add(pName);
                            cBg.setColor(Color.parseColor("#341B20"));
                            cBg.setStroke(dpStatic(act, 1.8f), Color.parseColor("#FF1238"));
                            pTv.setText("✓ " + pName);
                        }
                        c.setBackground(cBg);
                        addBtn.setText("ADD TO STUDIO (" + selectedProjects.size() + ")");
                        addBtn.setEnabled(!selectedProjects.isEmpty());
                    });

                    cardViews.add(c);
                } catch (Exception ignored) {}
            }

            final int cols = 3;
            for (int i = 0; i < cardViews.size(); i += cols) {
                LinearLayout row = new LinearLayout(act);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setWeightSum(3f);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.setMargins(0, 0, 0, dpStatic(act, 8));
                row.setLayoutParams(rp);

                for (int j = 0; j < cols; j++) {
                    if (i + j < cardViews.size()) {
                        View card = cardViews.get(i + j);
                        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                        if (j > 0) cp.setMargins(dpStatic(act, 6), 0, 0, 0);
                        card.setLayoutParams(cp);
                        row.addView(card);
                    } else {
                        View blank = new View(act);
                        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                        if (j > 0) bp.setMargins(dpStatic(act, 6), 0, 0, 0);
                        blank.setLayoutParams(bp);
                        row.addView(blank);
                    }
                }
                cardsContainer.addView(row);
            }
        }

        sv.addView(cardsContainer);
        root.addView(sv);

        addBtn.setText("ADD TO STUDIO (0)");
        addBtn.setTextColor(Color.WHITE);
        addBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        addBtn.setTypeface(null, Typeface.BOLD);
        addBtn.setEnabled(false);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(Color.parseColor("#FF1238"));
        btnBg.setCornerRadius(dpStatic(act, 6));
        addBtn.setBackground(btnBg);
        LinearLayout.LayoutParams abp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpStatic(act, 38));
        abp.setMargins(0, dpStatic(act, 10), 0, 0);
        addBtn.setLayoutParams(abp);

        addBtn.setOnClickListener(v -> {
            if (EditorActivity.instance != null && !selectedProjects.isEmpty()) {
                for (String pName : selectedProjects) {
                    EditorActivity.ProjectTabSession newTab = new EditorActivity.ProjectTabSession(pName, 1080, 1080, 1, Color.WHITE);
                    if (!EditorActivity.instance.loadProjectFromDisk(newTab)) {
                        try {
                            java.lang.reflect.Method m = EditorActivity.class.getDeclaredMethod("initDefaultTabLayers", EditorActivity.ProjectTabSession.class);
                            m.setAccessible(true);
                            m.invoke(EditorActivity.instance, newTab);
                        } catch (Exception ignored) {}
                    }
                    EditorActivity.instance.openNewTabWithSession(newTab);
                }
                Toast.makeText(act, selectedProjects.size() + " Project(s) Added to Tabs!", Toast.LENGTH_SHORT).show();
            }
            pickDialog.dismiss();
        });

        root.addView(addBtn);

        pickDialog.setContentView(root);
        if (pickDialog.getWindow() != null) {
            pickDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int w = (int) (act.getResources().getDisplayMetrics().widthPixels * 0.90);
            int h = (int) (act.getResources().getDisplayMetrics().heightPixels * 0.85);
            pickDialog.getWindow().setLayout(w, h);
        }
        pickDialog.show();
    }

    private void renderFilesContent() {
        dynamicContentArea.removeAllViews();
        final JSONArray arr = getSavedProjects();

        if (arr.length() == 0) {
            TextView placeholder = new TextView(activity);
            placeholder.setText("No saved files found. Click '+ NEW PROJECT' to create one.");
            placeholder.setTextColor(Color.parseColor("#777777"));
            placeholder.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            dynamicContentArea.addView(placeholder);
            return;
        }

        if (isBatchMode) {
            LinearLayout batchBar = new LinearLayout(activity);
            batchBar.setOrientation(LinearLayout.HORIZONTAL);
            batchBar.setGravity(Gravity.CENTER_VERTICAL);
            batchBar.setBackgroundColor(Color.parseColor("#222222"));
            batchBar.setPadding(dp(10), dp(8), dp(10), dp(8));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bp.setMargins(0, 0, 0, dp(12));
            batchBar.setLayoutParams(bp);

            Button backBtn = createBatchBtn("← Back", v -> {
                isBatchMode = false;
                selectedProjectIndices.clear();
                renderFilesContent();
            });
            batchBar.addView(backBtn);

            TextView countTv = new TextView(activity);
            countTv.setText(" Selected: " + selectedProjectIndices.size() + "/" + arr.length() + " ");
            countTv.setTextColor(Color.WHITE);
            countTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            countTv.setTypeface(null, Typeface.BOLD);
            batchBar.addView(countTv);

            batchBar.addView(createBatchBtn("Select All", v -> {
                for (int i = 0; i < arr.length(); i++) selectedProjectIndices.add(i);
                renderFilesContent();
            }));

            batchBar.addView(createBatchBtn("Clear", v -> {
                selectedProjectIndices.clear();
                renderFilesContent();
            }));

            batchBar.addView(createBatchBtn("SAVE PNG", v -> batchExport("PNG")));
            batchBar.addView(createBatchBtn("SAVE JPG", v -> batchExport("JPG")));
            batchBar.addView(createBatchBtn("SAVE PDF", v -> batchExport("PDF")));
            batchBar.addView(createBatchBtn("SAVE PSD", v -> batchExport("PSD")));
            batchBar.addView(createBatchBtn("SAVE JR", v -> batchExport("JR")));

            Button delBatchBtn = createBatchBtn("DELETE", v -> batchDelete());
            delBatchBtn.setTextColor(Color.parseColor("#FF5F56"));
            batchBar.addView(delBatchBtn);

            HorizontalScrollView hsv = new HorizontalScrollView(activity);
            hsv.setHorizontalScrollBarEnabled(false);
            hsv.addView(batchBar);
            dynamicContentArea.addView(hsv);
        }

        LinearLayout filesGrid = new LinearLayout(activity);
        filesGrid.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < arr.length(); i++) {
            try {
                final int index = i;
                final JSONObject obj = arr.getJSONObject(i);
                final String pName = obj.optString("title", "Untitled-1");
                final String pDate = obj.optString("date", "Saved Project");
                final int w = obj.optInt("width", 1080);
                final int h = obj.optInt("height", 1080);
                final int artboards = obj.optInt("artboards", 1);
                final int bg = obj.optInt("bg", Color.WHITE);

                final LinearLayout itemRow = new LinearLayout(activity);
                itemRow.setOrientation(LinearLayout.HORIZONTAL);
                itemRow.setGravity(Gravity.CENTER_VERTICAL);
                itemRow.setPadding(dp(14), dp(10), dp(14), dp(10));

                GradientDrawable rowBorder = new GradientDrawable();
                rowBorder.setColor(Color.parseColor(selectedProjectIndices.contains(index) ? "#2C1B1D" : "#1E1E1E"));
                rowBorder.setStroke(dp(1), Color.parseColor(selectedProjectIndices.contains(index) ? "#FF1238" : "#2A2A2A"));
                rowBorder.setCornerRadius(dp(4));
                itemRow.setBackground(rowBorder);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 0, 0, dp(8));
                itemRow.setLayoutParams(lp);

                if (isBatchMode) {
                    CheckBox cb = new CheckBox(activity);
                    cb.setChecked(selectedProjectIndices.contains(index));
                    cb.setOnClickListener(v -> {
                        if (selectedProjectIndices.contains(index)) selectedProjectIndices.remove(index);
                        else selectedProjectIndices.add(index);
                        renderFilesContent();
                    });
                    itemRow.addView(cb);
                }

                ImageView thumbView = new ImageView(activity);
                thumbView.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                thumbView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                thumbView.setImageBitmap(getProjectThumbnail(pName, bg));
                LinearLayout.LayoutParams tp = (LinearLayout.LayoutParams) thumbView.getLayoutParams();
                tp.setMargins(0, 0, dp(12), 0);
                itemRow.addView(thumbView);

                TextView titleTv = new TextView(activity);
                titleTv.setText(pName + "\n" + (artboards > 1 ? artboards + " Artboards • " : "") + pDate);
                titleTv.setTextColor(Color.WHITE);
                titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                itemRow.addView(titleTv);

                if (!isBatchMode) {
                    Button renBtn = new Button(activity);
                    renBtn.setText("Rename");
                    renBtn.setTextColor(Color.WHITE);
                    renBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                    GradientDrawable btnBg = new GradientDrawable();
                    btnBg.setColor(Color.parseColor("#282828"));
                    btnBg.setCornerRadius(dp(3));
                    renBtn.setBackground(btnBg);
                    renBtn.setPadding(dp(10), 0, dp(10), 0);
                    renBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)));
                    renBtn.setOnClickListener(v -> showRenameDialog(index, pName));
                    itemRow.addView(renBtn);

                    Button delBtn = new Button(activity);
                    delBtn.setText("Delete");
                    delBtn.setTextColor(Color.parseColor("#FF5F56"));
                    delBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                    GradientDrawable delBg = new GradientDrawable();
                    delBg.setColor(Color.parseColor("#282828"));
                    delBg.setCornerRadius(dp(3));
                    delBtn.setBackground(delBg);
                    delBtn.setPadding(dp(10), 0, dp(10), 0);
                    LinearLayout.LayoutParams dpL = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32));
                    dpL.setMargins(dp(6), 0, 0, 0);
                    delBtn.setLayoutParams(dpL);
                    delBtn.setOnClickListener(v -> deleteProject(index));
                    itemRow.addView(delBtn);
                }

                itemRow.setOnLongClickListener(v -> {
                    isBatchMode = true;
                    if (!selectedProjectIndices.contains(index)) {
                        selectedProjectIndices.add(index);
                    }
                    renderFilesContent();
                    return true;
                });

                itemRow.setOnClickListener(v -> {
                    if (isBatchMode) {
                        if (selectedProjectIndices.contains(index)) selectedProjectIndices.remove(index);
                        else selectedProjectIndices.add(index);
                        renderFilesContent();
                    } else {
                        launchEditor(pName, w, h, artboards, bg);
                    }
                });

                filesGrid.addView(itemRow);
            } catch (Exception ignored) {}
        }
        dynamicContentArea.addView(filesGrid);
    }

    private Button createBatchBtn(String title, final View.OnClickListener l) {
        final Button b = new Button(activity);
        b.setText(title);
        b.setTextColor(Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        b.setSingleLine(true);
        b.setPadding(dp(12), dp(4), dp(12), dp(4));

        final GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor("#2E2E2E"));
        gd.setCornerRadius(dp(4));
        b.setBackground(gd);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        lp.setMargins(dp(4), 0, dp(4), 0);
        b.setLayoutParams(lp);

        b.setOnClickListener(l);
        return b;
    }

    private File getProjectFolder(String pTitle) {
        String safeName = pTitle.replaceAll("[^a-zA-Z0-9._-]", "_");
        File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File dir = new File(downloads, "EJITOR/ejitor_project/" + safeName);
        if (!dir.exists()) {
            File altDir = new File(downloads, "EJITOR/editor_project/" + safeName);
            if (altDir.exists()) return altDir;
            File altDir2 = new File(downloads, "ejitor/editor_project/" + safeName);
            if (altDir2.exists()) return altDir2;
        }
        return dir;
    }

    public Bitmap getProjectThumbnail(String pTitle, int defaultBg) {
        try {
            File baseDir = getProjectFolder(pTitle);
            File thumbFile = new File(baseDir, "thumbnail.jpg");
            if (thumbFile.exists() && thumbFile.length() > 0) {
                Bitmap bmp = BitmapFactory.decodeFile(thumbFile.getAbsolutePath());
                if (bmp != null) return bmp;
            }
        } catch (Exception ignored) {}
        return getProjectCompositeBitmap(pTitle, 240, 240, defaultBg);
    }

    private File findLayerImageFile(File baseDir, String fileName) {
        if (fileName == null || fileName.isEmpty()) return null;
        File fLayers = new File(new File(baseDir, "layers"), fileName);
        if (fLayers.exists() && fLayers.length() > 0) return fLayers;
        File f = new File(baseDir, fileName);
        if (f.exists() && f.length() > 0) return f;
        File fImages = new File(new File(baseDir, "images"), fileName);
        if (fImages.exists() && fImages.length() > 0) return fImages;
        return null;
    }

    private Bitmap getProjectCompositeBitmap(String pTitle, int w, int h, int defaultBg) {
        int finalBg = defaultBg;
        File baseDir = getProjectFolder(pTitle);
        File metaFile = new File(baseDir, "project.json");
        if (!metaFile.exists()) {
            metaFile = new File(baseDir, "project_data.json");
        }

        JSONObject json = null;
        if (metaFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(metaFile), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                json = new JSONObject(sb.toString());
                finalBg = json.optInt("bg", defaultBg);
            } catch (Exception ignored) {}
        }

        Bitmap resBmp = Bitmap.createBitmap(Math.max(10, w), Math.max(10, h), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(resBmp);

        if (finalBg != Color.TRANSPARENT) {
            canvas.drawColor(finalBg);
        }

        if (json != null) {
            try {
                int origW = json.optInt("width", w);
                int origH = json.optInt("height", h);
                float scaleXRatio = (float) w / (float) origW;
                float scaleYRatio = (float) h / (float) origH;

                JSONArray layerArray = json.getJSONArray("layers");
                for (int i = 0; i < layerArray.length(); i++) {
                    JSONObject lObj = layerArray.getJSONObject(i);
                    if (!lObj.optBoolean("visible", true)) continue;

                    String fileName = lObj.optString("file", "");
                    File imgFile = findLayerImageFile(baseDir, fileName);

                    if (imgFile != null && imgFile.exists()) {
                        BitmapFactory.Options opts = new BitmapFactory.Options();
                        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                        Bitmap layerBmp = BitmapFactory.decodeFile(imgFile.getAbsolutePath(), opts);

                        if (layerBmp != null) {
                            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                            p.setAlpha((int) (lObj.optDouble("opacity", 1.0) * 255));

                            String blend = lObj.optString("blend", "Normal");
                            if ("Multiply".equalsIgnoreCase(blend)) p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));
                            else if ("Screen".equalsIgnoreCase(blend)) p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));
                            else if ("Overlay".equalsIgnoreCase(blend)) p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.OVERLAY));

                            Matrix m = new Matrix();
                            m.postScale((float) lObj.optDouble("scaleX", 1f) * scaleXRatio, (float) lObj.optDouble("scaleY", 1f) * scaleYRatio);
                            m.postRotate((float) lObj.optDouble("rotation", 0f), (layerBmp.getWidth() * (float) lObj.optDouble("scaleX", 1f) * scaleXRatio) / 2f, (layerBmp.getHeight() * (float) lObj.optDouble("scaleY", 1f) * scaleYRatio) / 2f);
                            m.postTranslate((float) lObj.optDouble("x", 0) * scaleXRatio, (float) lObj.optDouble("y", 0) * scaleYRatio);
                            canvas.drawBitmap(layerBmp, m, p);
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        return resBmp;
    }

    private void batchExport(String format) {
        if (selectedProjectIndices.isEmpty()) {
            Toast.makeText(activity, "Please select at least one project", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONArray arr = getSavedProjects();
        int exported = 0;

        for (Integer idx : selectedProjectIndices) {
            try {
                JSONObject obj = arr.getJSONObject(idx);
                String title = obj.optString("title", "Project");
                int w = obj.optInt("width", 1080);
                int h = obj.optInt("height", 1080);
                int artboards = obj.optInt("artboards", 1);
                int bg = obj.optInt("bg", Color.WHITE);

                if (format.equalsIgnoreCase("PDF")) {
                    saveMultiPagePdfToDownloads(title, w, h, artboards, bg);
                } else if (format.equalsIgnoreCase("PSD")) {
                    saveRealPhotoshopPsdToDownloads(title, w, h, bg);
                } else if (format.equalsIgnoreCase("JR")) {
                    saveJrProjectToDownloads(title);
                } else {
                    saveBitmapToDownloads(title, w, h, bg, format);
                }
                exported++;
            } catch (Exception ignored) {}
        }

        Toast.makeText(activity, "Saved " + exported + " artwork(s) as " + format + " in Downloads/EJITOR!", Toast.LENGTH_LONG).show();
    }

    private void saveJrProjectToDownloads(String title) {
        try {
            File baseDir = getProjectFolder(title);
            File metaFile = new File(baseDir, "project.json");
            if (!metaFile.exists()) metaFile = new File(baseDir, "project_data.json");
            if (!metaFile.exists()) return;

            String fileName = title + "_" + System.currentTimeMillis() + ".jr";
            OutputStream os = null;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = activity.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) os = resolver.openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
                if (!dir.exists()) dir.mkdirs();
                os = new FileOutputStream(new File(dir, fileName));
            }

            if (os != null) {
                ZipOutputStream zos = new ZipOutputStream(os);

                zos.putNextEntry(new ZipEntry("project_data.json"));
                FileInputStream fisMeta = new FileInputStream(metaFile);
                byte[] buffer = new byte[4096];
                int len;
                while ((len = fisMeta.read(buffer)) > 0) zos.write(buffer, 0, len);
                fisMeta.close();
                zos.closeEntry();

                File thumb = new File(baseDir, "thumbnail.jpg");
                if (thumb.exists()) {
                    zos.putNextEntry(new ZipEntry("thumbnail.png"));
                    FileInputStream fisThumb = new FileInputStream(thumb);
                    while ((len = fisThumb.read(buffer)) > 0) zos.write(buffer, 0, len);
                    fisThumb.close();
                    zos.closeEntry();
                }

                File layersDir = new File(baseDir, "layers");
                if (layersDir.exists()) {
                    File[] lFiles = layersDir.listFiles();
                    if (lFiles != null) {
                        for (File lf : lFiles) {
                            if (lf.isFile()) {
                                zos.putNextEntry(new ZipEntry(lf.getName()));
                                FileInputStream fisLayer = new FileInputStream(lf);
                                while ((len = fisLayer.read(buffer)) > 0) zos.write(buffer, 0, len);
                                fisLayer.close();
                                zos.closeEntry();
                            }
                        }
                    }
                }
                zos.flush();
                zos.close();
            }
        } catch (Exception ignored) {}
    }

    private void saveMultiPagePdfToDownloads(String title, int width, int height, int pageCount, int bgColor) {
        try {
            PdfDocument document = new PdfDocument();
            Bitmap composite = getProjectCompositeBitmap(title, width, height, bgColor);

            for (int i = 0; i < pageCount; i++) {
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(width, height, i + 1).create();
                PdfDocument.Page page = document.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                canvas.drawBitmap(composite, 0, 0, null);
                document.finishPage(page);
            }

            String fileName = title + "_" + System.currentTimeMillis() + ".pdf";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = activity.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");

                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (uri != null) {
                    OutputStream os = resolver.openOutputStream(uri);
                    if (os != null) {
                        document.writeTo(os);
                        os.close();
                    }
                }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                document.writeTo(fos);
                fos.close();
            }
            document.close();
        } catch (Exception ignored) {}
    }

    private void saveRealPhotoshopPsdToDownloads(String title, int width, int height, int bgColor) {
        try {
            Bitmap master = getProjectCompositeBitmap(title, width, height, bgColor);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            DataOutputStream out = new DataOutputStream(baos);

            out.writeBytes("8BPS");
            out.writeShort(1);
            out.write(new byte[6]);
            out.writeShort(3);
            out.writeInt(master.getHeight());
            out.writeInt(master.getWidth());
            out.writeShort(8);
            out.writeShort(3);
            out.writeInt(0);
            out.writeInt(0);
            out.writeInt(0);
            out.writeShort(0);

            int len = master.getWidth() * master.getHeight();
            int[] pixels = new int[len];
            master.getPixels(pixels, 0, master.getWidth(), 0, 0, master.getWidth(), master.getHeight());

            byte[] r = new byte[len];
            byte[] g = new byte[len];
            byte[] b = new byte[len];

            for (int i = 0; i < len; i++) {
                r[i] = (byte) Color.red(pixels[i]);
                g[i] = (byte) Color.green(pixels[i]);
                b[i] = (byte) Color.blue(pixels[i]);
            }
            out.write(r);
            out.write(g);
            out.write(b);
            out.flush();

            byte[] psdData = baos.toByteArray();
            out.close();

            String fileName = title + "_" + System.currentTimeMillis() + ".psd";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = activity.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, "image/vnd.adobe.photoshop");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");

                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    OutputStream os = resolver.openOutputStream(uri);
                    if (os != null) {
                        os.write(psdData);
                        os.close();
                    }
                }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(psdData);
                fos.close();
            }
        } catch (Exception ignored) {}
    }

    private void saveBitmapToDownloads(String title, int width, int height, int bgColor, String format) {
        try {
            Bitmap master = getProjectCompositeBitmap(title, width, height, bgColor);
            String ext = format.toLowerCase();
            String fileName = title + "_" + System.currentTimeMillis() + "." + ext;
            String mime = ext.equals("png") ? "image/png" : "image/jpeg";

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = activity.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");

                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    OutputStream os = resolver.openOutputStream(uri);
                    if (os != null) {
                        if (ext.equals("jpg")) master.compress(Bitmap.CompressFormat.JPEG, 95, os);
                        else master.compress(Bitmap.CompressFormat.PNG, 100, os);
                        os.close();
                    }
                }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                if (ext.equals("jpg")) master.compress(Bitmap.CompressFormat.JPEG, 95, fos);
                else master.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
            }
        } catch (Exception ignored) {}
    }

    private void deleteProjectFilesFromDisk(String title) {
        try {
            File dir = getProjectFolder(title);
            if (dir.exists()) {
                deleteRecursive(dir);
            }
        } catch (Exception ignored) {}
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            File[] files = fileOrDirectory.listFiles();
            if (files != null) {
                for (File child : files) {
                    deleteRecursive(child);
                }
            }
        }
        fileOrDirectory.delete();
    }

    private void batchDelete() {
        if (selectedProjectIndices.isEmpty()) return;
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONArray newArr = new JSONArray();

            for (int i = 0; i < arr.length(); i++) {
                if (!selectedProjectIndices.contains(i)) {
                    newArr.put(arr.get(i));
                } else {
                    JSONObject obj = arr.getJSONObject(i);
                    deleteProjectFilesFromDisk(obj.optString("title"));
                }
            }
            sp.edit().putString("saved_projects", newArr.toString()).apply();
            selectedProjectIndices.clear();
            isBatchMode = false;
            renderFilesContent();
            Toast.makeText(activity, "Selected projects deleted", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    private void showRenameDialog(int index, String currentName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        builder.setTitle("Rename Project");
        final EditText input = new EditText(activity);
        input.setText(currentName);
        input.setTextColor(Color.WHITE);
        builder.setView(input);
        builder.setPositiveButton("Rename", (d, w) -> {
            String newName = input.getText().toString().trim();
            if (!newName.isEmpty()) {
                renameProject(index, newName);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void renameProject(int index, String newName) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONObject obj = arr.getJSONObject(index);
            obj.put("title", newName);
            arr.put(index, obj);
            sp.edit().putString("saved_projects", arr.toString()).apply();
            renderFilesContent();
        } catch (Exception ignored) {}
    }

    private void openLink(String url) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) {}
    }

    public void launchDetailsActivity() {
        try {
            Intent intent = new Intent(activity, details.class);
            activity.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent();
                intent.setClassName(activity.getPackageName(), "com.example.ejitor.details");
                activity.startActivity(intent);
            } catch (Exception ex) {
                Toast.makeText(activity, "Please declare details in AndroidManifest.xml", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void openUnifiedFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        String[] mimeTypes = {"image/*", "application/pdf", "image/vnd.adobe.photoshop", "application/octet-stream"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        activity.startActivityForResult(Intent.createChooser(intent, "Open File"), REQ_OPEN_HOME_FILE);
    }

    public void handleFilePickerResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_OPEN_HOME_FILE && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                openFileInEditor(uri);
            }
        }
    }

    private void openFileInEditor(Uri uri) {
        new Thread(() -> {
            try {
                String fileName = "";
                Cursor cursor = activity.getContentResolver().query(uri, null, null, null, null);
                if (cursor != null) {
                    int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        fileName = cursor.getString(nameIndex);
                    }
                    cursor.close();
                }

                String lower = fileName.toLowerCase();
                String baseName = fileName.replaceFirst("[.][^.]+$", "").trim();

                if (baseName.isEmpty() || baseName.equalsIgnoreCase("image") || baseName.equalsIgnoreCase("download") || baseName.equalsIgnoreCase("Imported Project")) {
                    baseName = "Project-" + (System.currentTimeMillis() % 100000);
                } else {
                    baseName = baseName + "_" + (System.currentTimeMillis() % 10000);
                }

                String finalProjectName = baseName;

                File projectDir = getProjectFolder(finalProjectName);
                if (!projectDir.exists()) projectDir.mkdirs();
                File imagesDir = new File(projectDir, "images");
                if (!imagesDir.exists()) imagesDir.mkdirs();
                File layersDir = new File(projectDir, "layers");
                if (!layersDir.exists()) layersDir.mkdirs();

                int w = 1080, h = 1080;

                if (lower.endsWith(".jr") || isZipUri(uri)) {
                    extractZipUri(uri, projectDir);
                    File pJson = new File(projectDir, "project.json");
                    if (!pJson.exists()) pJson = new File(projectDir, "project_data.json");
                    if (pJson.exists()) {
                        JSONObject j = readJsonFile(pJson);
                        w = j.optInt("width", 1080);
                        h = j.optInt("height", 1080);
                        finalProjectName = j.optString("name", finalProjectName);
                    }
                } else if (lower.endsWith(".pdf") || isPdfUri(uri)) {
                    ParcelFileDescriptor pfd = activity.getContentResolver().openFileDescriptor(uri, "r");
                    if (pfd != null) {
                        PdfRenderer renderer = new PdfRenderer(pfd);
                        if (renderer.getPageCount() > 0) {
                            PdfRenderer.Page page = renderer.openPage(0);
                            w = page.getWidth() * 2;
                            h = page.getHeight() * 2;
                            Bitmap pdfBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                            pdfBmp.eraseColor(Color.WHITE);
                            page.render(pdfBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                            page.close();
                            saveBitmapToProject(projectDir, imagesDir, layersDir, finalProjectName, pdfBmp, w, h);
                        }
                        renderer.close();
                        pfd.close();
                    }
                } else if (lower.endsWith(".psd") || isPsdUri(uri)) {
                    Bitmap psdBmp = parsePsdComposite(uri);
                    if (psdBmp != null) {
                        w = psdBmp.getWidth();
                        h = psdBmp.getHeight();
                        saveBitmapToProject(projectDir, imagesDir, layersDir, finalProjectName, psdBmp, w, h);
                    }
                } else {
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
                    InputStream is = activity.getContentResolver().openInputStream(uri);
                    Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
                    if (is != null) is.close();

                    if (bmp != null) {
                        w = bmp.getWidth();
                        h = bmp.getHeight();
                        saveBitmapToProject(projectDir, imagesDir, layersDir, finalProjectName, bmp, w, h);
                    }
                }

                final String pName = finalProjectName;
                final int finalW = w;
                final int finalH = h;

                activity.runOnUiThread(() -> {
                    Intent intent = new Intent(activity, EditorActivity.class);
                    intent.setData(uri);
                    intent.putExtra("file_uri", uri.toString());
                    intent.putExtra("project_name", pName);
                    intent.putExtra("width", finalW);
                    intent.putExtra("height", finalH);
                    intent.putExtra("artboards", 1);
                    intent.putExtra("bg", Color.TRANSPARENT);
                    activity.startActivity(intent);
                });

            } catch (Exception e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Failed to open file: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void saveBitmapToProject(File projectDir, File imagesDir, File layersDir, String projectName, Bitmap bmp, int w, int h) throws Exception {
        String layerFileName = "layer_0.png";
        File fImg = new File(imagesDir, layerFileName);
        File fLay = new File(layersDir, layerFileName);

        FileOutputStream fos1 = new FileOutputStream(fImg);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos1);
        fos1.flush();
        try { fos1.getFD().sync(); } catch (Exception ignored) {}
        fos1.close();

        FileOutputStream fos2 = new FileOutputStream(fLay);
        bmp.compress(Bitmap.CompressFormat.PNG, 100, fos2);
        fos2.flush();
        try { fos2.getFD().sync(); } catch (Exception ignored) {}
        fos2.close();

        File thumb = new File(projectDir, "thumbnail.jpg");
        FileOutputStream fosThumb = new FileOutputStream(thumb);
        Bitmap thumbBmp = Bitmap.createScaledBitmap(bmp, Math.min(240, w), Math.min(240, h), true);
        thumbBmp.compress(Bitmap.CompressFormat.JPEG, 90, fosThumb);
        fosThumb.flush();
        try { fosThumb.getFD().sync(); } catch (Exception ignored) {}
        fosThumb.close();

        JSONObject projectJson = new JSONObject();
        projectJson.put("format_version", 3);
        projectJson.put("name", projectName);
        projectJson.put("title", projectName);
        projectJson.put("width", w);
        projectJson.put("height", h);
        projectJson.put("artboards", 1);
        projectJson.put("bg", Color.TRANSPARENT);

        JSONArray layers = new JSONArray();
        JSONObject layer0 = new JSONObject();
        layer0.put("id", "0");
        layer0.put("name", "Layer 1");
        layer0.put("file", layerFileName);
        layer0.put("x", 0);
        layer0.put("y", 0);
        layer0.put("scaleX", 1f);
        layer0.put("scaleY", 1f);
        layer0.put("rotation", 0f);
        layer0.put("opacity", 1.0);
        layer0.put("visible", true);
        layer0.put("locked", false);
        layer0.put("blend", "Normal");
        layer0.put("isBlank", false);
        layers.put(layer0);

        projectJson.put("layers", layers);

        writeStringToFile(new File(projectDir, "project.json"), projectJson.toString());
        writeStringToFile(new File(projectDir, "project_data.json"), projectJson.toString());

        saveProjectLocally(projectName, w, h, 1, Color.TRANSPARENT);
    }

    private void writeStringToFile(File file, String content) throws Exception {
        FileOutputStream fos = new FileOutputStream(file);
        fos.write(content.getBytes("UTF-8"));
        fos.flush();
        try { fos.getFD().sync(); } catch (Exception ignored) {}
        fos.close();
    }

    private JSONObject readJsonFile(File file) {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l);
            r.close();
            return new JSONObject(sb.toString());
        } catch (Exception e) { return new JSONObject(); }
    }

    private void extractZipUri(Uri uri, File destDir) {
        try (InputStream is = activity.getContentResolver().openInputStream(uri);
             ZipInputStream zis = new ZipInputStream(is)) {
            ZipEntry entry;
            byte[] buf = new byte[8192];
            while ((entry = zis.getNextEntry()) != null) {
                File target = new File(destDir, entry.getName());
                if (entry.isDirectory()) {
                    target.mkdirs();
                } else {
                    if (target.getParentFile() != null) target.getParentFile().mkdirs();
                    try (FileOutputStream fos = new FileOutputStream(target)) {
                        int len;
                        while ((len = zis.read(buf)) > 0) fos.write(buf, 0, len);
                    }
                }
                zis.closeEntry();
            }
        } catch (Exception ignored) {}
    }

    private boolean isZipUri(Uri uri) {
        try (InputStream is = activity.getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[4];
            return is != null && is.read(h) == 4 && h[0] == 0x50 && h[1] == 0x4B;
        } catch (Exception e) { return false; }
    }

    private boolean isPdfUri(Uri uri) {
        try (InputStream is = activity.getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[5];
            return is != null && is.read(h) == 5 && new String(h).startsWith("%PDF");
        } catch (Exception e) { return false; }
    }

    private boolean isPsdUri(Uri uri) {
        try (InputStream is = activity.getContentResolver().openInputStream(uri)) {
            byte[] h = new byte[4];
            return is != null && is.read(h) == 4 && new String(h).equals("8BPS");
        } catch (Exception e) { return false; }
    }

    private Bitmap parsePsdComposite(Uri uri) {
        try (InputStream is = activity.getContentResolver().openInputStream(uri);
             DataInputStream dis = new DataInputStream(is)) {
            byte[] sig = new byte[4];
            dis.readFully(sig);
            if (!new String(sig).equals("8BPS")) return null;
            dis.readShort();
            dis.skipBytes(6);
            dis.readShort();
            int height = dis.readInt();
            int width = dis.readInt();
            dis.readShort();
            dis.readShort();

            Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            return bmp;
        } catch (Exception e) { return null; }
    }

    public void openNewProjectDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout mainLayout = new LinearLayout(activity);
        mainLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.parseColor("#1F1F1F"));

        LinearLayout macHeader = new LinearLayout(activity);
        macHeader.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        macHeader.setBackgroundColor(Color.parseColor("#181818"));
        macHeader.setOrientation(LinearLayout.HORIZONTAL);
        macHeader.setGravity(Gravity.CENTER_VERTICAL);
        macHeader.setPadding(dp(14), 0, dp(14), 0);

        macHeader.addView(createMacDot("#FF5F56"));
        macHeader.addView(createMacDot("#FFBD2E"));
        macHeader.addView(createMacDot("#27C93F"));

        TextView winTitle = new TextView(activity);
        winTitle.setText("New Document");
        winTitle.setTextColor(Color.parseColor("#E0E0E0"));
        winTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        winTitle.setTypeface(null, Typeface.BOLD);
        winTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wtParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wtParams.setMargins(dp(-45), 0, 0, 0);
        winTitle.setLayoutParams(wtParams);
        macHeader.addView(winTitle);
        mainLayout.addView(macHeader);

        HorizontalScrollView catScroll = new HorizontalScrollView(activity);
        catScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        catScroll.setBackgroundColor(Color.parseColor("#181818"));
        catScroll.setHorizontalScrollBarEnabled(false);

        LinearLayout catTabs = new LinearLayout(activity);
        catTabs.setOrientation(LinearLayout.HORIZONTAL);
        catTabs.setPadding(dp(12), 0, dp(12), 0);

        final LinearLayout tplGrid = new LinearLayout(activity);
        tplGrid.setOrientation(LinearLayout.VERTICAL);
        tplGrid.setPadding(0, dp(10), 0, 0);

        final EditText nameInput = createDarkInput("Untitled-1");
        final EditText widthInput = createDarkInput("1080");
        final EditText heightInput = createDarkInput("1080");
        final EditText resInput = createDarkInput("72");
        final EditText artboardsInput = createDarkInput("1");

        currentUnit = "Pixels";
        currentColorMode = "RGB Color";
        currentBitDepth = "8 bit";
        currentDpi = 72;

        String[] cats = {"Recent", "Saved", "Photo", "Print", "Mobile", "Film & Video", "Web"};
        for (String cName : cats) {
            final String catStr = cName;
            TextView t = new TextView(activity);
            t.setText(catStr);
            t.setTextColor(catStr.equals(currentModalCat) ? Color.WHITE : Color.parseColor("#888888"));
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            t.setPadding(dp(14), dp(8), dp(14), dp(8));
            t.setTypeface(null, catStr.equals(currentModalCat) ? Typeface.BOLD : Typeface.NORMAL);

            t.setOnClickListener(v -> {
                currentModalCat = catStr;
                for (int j = 0; j < catTabs.getChildCount(); j++) {
                    TextView child = (TextView) catTabs.getChildAt(j);
                    boolean isSel = child.getText().toString().equals(currentModalCat);
                    child.setTextColor(isSel ? Color.WHITE : Color.parseColor("#888888"));
                    child.setTypeface(null, isSel ? Typeface.BOLD : Typeface.NORMAL);
                }
                populateTemplateGrid(tplGrid, currentModalCat, nameInput, widthInput, heightInput, resInput);
            });
            catTabs.addView(t);
        }
        catScroll.addView(catTabs);
        mainLayout.addView(catScroll);

        LinearLayout bodyLayout = new LinearLayout(activity);
        bodyLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        bodyLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout leftPane = new LinearLayout(activity);
        leftPane.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f));
        leftPane.setOrientation(LinearLayout.VERTICAL);
        leftPane.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView recTitle = new TextView(activity);
        recTitle.setText("YOUR RECENT ITEMS (40)");
        recTitle.setTextColor(Color.parseColor("#777777"));
        recTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        recTitle.setTypeface(null, Typeface.BOLD);
        leftPane.addView(recTitle);

        ScrollView tplScroll = new ScrollView(activity);
        tplScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tplScroll.setFillViewport(true);

        populateTemplateGrid(tplGrid, currentModalCat, nameInput, widthInput, heightInput, resInput);
        tplScroll.addView(tplGrid);
        leftPane.addView(tplScroll);
        bodyLayout.addView(leftPane);

        ScrollView rightScroll = new ScrollView(activity);
        LinearLayout.LayoutParams rpParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f);
        rightScroll.setLayoutParams(rpParams);
        rightScroll.setBackgroundColor(Color.parseColor("#181818"));
        rightScroll.setFillViewport(true);
        rightScroll.setVerticalScrollBarEnabled(true);

        LinearLayout rightPane = new LinearLayout(activity);
        rightPane.setOrientation(LinearLayout.VERTICAL);
        rightPane.setPadding(dp(18), dp(16), dp(18), dp(45));

        TextView psTitle = new TextView(activity);
        psTitle.setText("PRESET DETAILS");
        psTitle.setTextColor(Color.parseColor("#999999"));
        psTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        psTitle.setTypeface(null, Typeface.BOLD);
        rightPane.addView(psTitle);

        rightPane.addView(createFieldLabel("Name"));
        rightPane.addView(nameInput);

        LinearLayout dimRow = new LinearLayout(activity);
        dimRow.setOrientation(LinearLayout.HORIZONTAL);
        dimRow.addView(createFieldWithLabel("Width", widthInput, 1.1f));

        View unitBox = createPhotoshopDropdown("Pixels", new String[]{"Pixels", "Inches", "Centimeters", "Millimeters"}, newUnit -> {
            try {
                int dpi = Integer.parseInt(resInput.getText().toString().trim());
                if (dpi <= 0) dpi = 72;
                float curW = Float.parseFloat(widthInput.getText().toString().trim());
                float curH = Float.parseFloat(heightInput.getText().toString().trim());

                float pixelW = toPixels(curW, currentUnit, dpi);
                float pixelH = toPixels(curH, currentUnit, dpi);

                float newW = fromPixels(pixelW, newUnit, dpi);
                float newH = fromPixels(pixelH, newUnit, dpi);

                widthInput.setText(formatUnitValue(newW, newUnit));
                heightInput.setText(formatUnitValue(newH, newUnit));
                currentUnit = newUnit;
            } catch (Exception ignored) {}
        });
        dimRow.addView(createFieldWithLabel("Unit", unitBox, 1.1f));
        rightPane.addView(dimRow);

        LinearLayout dimRow2 = new LinearLayout(activity);
        dimRow2.setOrientation(LinearLayout.HORIZONTAL);
        dimRow2.addView(createFieldWithLabel("Height", heightInput, 1.1f));

        LinearLayout orientBox = new LinearLayout(activity);
        orientBox.setOrientation(LinearLayout.HORIZONTAL);
        orientBox.setGravity(Gravity.CENTER_VERTICAL);

        final ImageView btnPort = new ImageView(activity);
        btnPort.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(32)));
        final GradientDrawable redBg = new GradientDrawable();
        redBg.setColor(Color.parseColor("#FF1238"));
        redBg.setCornerRadius(dp(3));
        btnPort.setBackground(redBg);
        btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#FFFFFF"));
        btnPort.setScaleType(ImageView.ScaleType.CENTER);

        final ImageView btnLand = new ImageView(activity);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(44), dp(32));
        lp.setMargins(dp(4), 0, 0, 0);
        btnLand.setLayoutParams(lp);
        final GradientDrawable darkBg = new GradientDrawable();
        darkBg.setColor(Color.parseColor("#202020"));
        darkBg.setCornerRadius(dp(3));
        btnLand.setBackground(darkBg);
        btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));
        btnLand.setScaleType(ImageView.ScaleType.CENTER);

        btnPort.setOnClickListener(v -> {
            redBg.setColor(Color.parseColor("#FF1238"));
            btnPort.setBackground(redBg);
            btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#FFFFFF"));
            darkBg.setColor(Color.parseColor("#202020"));
            btnLand.setBackground(darkBg);
            btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));

            try {
                float w = Float.parseFloat(widthInput.getText().toString().trim());
                float h = Float.parseFloat(heightInput.getText().toString().trim());
                if (w > h) { widthInput.setText(formatUnitValue(h, currentUnit)); heightInput.setText(formatUnitValue(w, currentUnit)); }
            } catch (Exception ignored) {}
        });

        btnLand.setOnClickListener(v -> {
            redBg.setColor(Color.parseColor("#202020"));
            btnPort.setBackground(redBg);
            btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#888888"));
            darkBg.setColor(Color.parseColor("#FF1238"));
            btnLand.setBackground(darkBg);
            btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));

            try {
                float w = Float.parseFloat(widthInput.getText().toString().trim());
                float h = Float.parseFloat(heightInput.getText().toString().trim());
                if (h > w) { widthInput.setText(formatUnitValue(h, currentUnit)); heightInput.setText(formatUnitValue(w, currentUnit)); }
            } catch (Exception ignored) {}
        });

        orientBox.addView(btnPort);
        orientBox.addView(btnLand);
        dimRow2.addView(createFieldWithLabel("Orientation", orientBox, 1.1f));
        rightPane.addView(dimRow2);

        LinearLayout dimRow3 = new LinearLayout(activity);
        dimRow3.setOrientation(LinearLayout.HORIZONTAL);
        dimRow3.addView(createFieldWithLabel("Artboards Count", artboardsInput, 1f));
        dimRow3.addView(createFieldWithLabel("Resolution (DPI)", resInput, 1f));
        rightPane.addView(dimRow3);

        LinearLayout colorRow = new LinearLayout(activity);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);

        View colorModeBox = createPhotoshopDropdown("RGB Color", new String[]{"RGB Color", "CMYK Color", "Grayscale", "Bitmap", "Lab Color"}, sel -> {
            currentColorMode = sel;
        });
        colorRow.addView(createFieldWithLabel("Color Mode", colorModeBox, 1.25f));

        View depthBox = createPhotoshopDropdown("8 bit", new String[]{"8 bit", "16 bit", "32 bit", "64 bit", "120 bit"}, sel -> {
            currentBitDepth = sel;
        });
        colorRow.addView(createFieldWithLabel("Depth", depthBox, 0.95f));
        rightPane.addView(colorRow);

        rightPane.addView(createFieldLabel("Background Contents"));
        LinearLayout bgRow = new LinearLayout(activity);
        bgRow.setOrientation(LinearLayout.HORIZONTAL);
        bgRow.setGravity(Gravity.CENTER_VERTICAL);

        View bgContentsBox = createPhotoshopDropdown("White", new String[]{"White", "Black", "Transparent", "Custom Color..."}, sel -> {
            if ("White".equals(sel)) updateSelectedBgColor(Color.WHITE);
            else if ("Black".equals(sel)) updateSelectedBgColor(Color.BLACK);
            else if ("Transparent".equals(sel)) updateSelectedBgColor(Color.TRANSPARENT);
            else if ("Custom Color...".equals(sel)) openCustomColorSpectrumDialog();
        });
        bgRow.addView(bgContentsBox, new LinearLayout.LayoutParams(0, dp(34), 1f));

        liveSwatchPreview = new View(activity);
        liveSwatchPreview.setBackgroundColor(selectedBgColor);
        GradientDrawable sBorder = new GradientDrawable();
        sBorder.setColor(selectedBgColor);
        sBorder.setStroke(dp(1), Color.parseColor("#444444"));
        liveSwatchPreview.setBackground(sBorder);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(34), dp(34));
        sp.setMargins(dp(8), 0, 0, 0);
        liveSwatchPreview.setLayoutParams(sp);

        liveSwatchPreview.setOnClickListener(v -> openCustomColorSpectrumDialog());

        bgRow.addView(liveSwatchPreview);
        rightPane.addView(bgRow);

        LinearLayout actionsRow = new LinearLayout(activity);
        actionsRow.setOrientation(LinearLayout.HORIZONTAL);
        actionsRow.setGravity(Gravity.END);
        actionsRow.setPadding(0, dp(24), 0, dp(16));

        final Button closeBtn = new Button(activity);
        closeBtn.setText("Close");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        final GradientDrawable grayBtn = new GradientDrawable();
        grayBtn.setColor(Color.parseColor("#383838"));
        grayBtn.setCornerRadius(dp(18));
        closeBtn.setBackground(grayBtn);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(95), dp(38)));
        closeBtn.setOnClickListener(v -> dialog.dismiss());
        actionsRow.addView(closeBtn);

        final Button createBtn = new Button(activity);
        createBtn.setText("Create");
        createBtn.setTextColor(Color.WHITE);
        createBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        createBtn.setTypeface(null, Typeface.BOLD);
        final GradientDrawable redBtn = new GradientDrawable();
        redBtn.setColor(Color.parseColor("#FF1238"));
        redBtn.setCornerRadius(dp(18));
        createBtn.setBackground(redBtn);
        LinearLayout.LayoutParams crp = new LinearLayout.LayoutParams(dp(105), dp(38));
        crp.setMargins(dp(10), 0, 0, 0);
        createBtn.setLayoutParams(crp);

        createBtn.setOnClickListener(v -> {
            String pName = nameInput.getText().toString().trim();
            if (pName.isEmpty()) pName = "Untitled-1";

            int dpi = 72;
            try { dpi = Integer.parseInt(resInput.getText().toString().trim()); } catch (Exception ignored) {}
            if (dpi <= 0) dpi = 72;

            float wInputVal = 1080f;
            float hInputVal = 1080f;
            try { wInputVal = Float.parseFloat(widthInput.getText().toString().trim()); } catch (Exception ignored) {}
            try { hInputVal = Float.parseFloat(heightInput.getText().toString().trim()); } catch (Exception ignored) {}

            int finalPixelW = Math.max(50, Math.round(toPixels(wInputVal, currentUnit, dpi)));
            int finalPixelH = Math.max(50, Math.round(toPixels(hInputVal, currentUnit, dpi)));

            int artboards = 1;
            try { artboards = Integer.parseInt(artboardsInput.getText().toString().trim()); } catch (Exception ignored) {}
            if (artboards < 1) artboards = 1;

            saveProjectLocally(pName, finalPixelW, finalPixelH, artboards, selectedBgColor);
            launchEditor(pName, finalPixelW, finalPixelH, artboards, selectedBgColor);
            dialog.dismiss();
        });
        actionsRow.addView(createBtn);

        rightPane.addView(actionsRow);
        rightScroll.addView(rightPane);
        bodyLayout.addView(rightScroll);

        mainLayout.addView(bodyLayout);

        dialog.setContentView(mainLayout);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        }
        dialog.show();
    }

    private void updateSelectedBgColor(int color) {
        selectedBgColor = color;
        if (liveSwatchPreview != null) {
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(color == Color.TRANSPARENT ? Color.parseColor("#181818") : color);
            gd.setStroke(dp(1), Color.parseColor("#555555"));
            liveSwatchPreview.setBackground(gd);
        }
    }

    private void openCustomColorSpectrumDialog() {
        final Dialog colorDialog = new Dialog(activity);
        colorDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(Color.parseColor("#222222"));
        layout.setPadding(dp(18), dp(16), dp(18), dp(16));

        TextView title = new TextView(activity);
        title.setText("Pick Custom Background Color");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(12));
        layout.addView(title);

        final View colorBox = new View(activity);
        colorBox.setLayoutParams(new LinearLayout.LayoutParams(dp(270), dp(130)));
        final GradientDrawable spec = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED});
        colorBox.setBackground(spec);
        layout.addView(colorBox);

        final View preview = new View(activity);
        preview.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        preview.setBackgroundColor(selectedBgColor);
        LinearLayout.LayoutParams pp = (LinearLayout.LayoutParams) preview.getLayoutParams();
        pp.setMargins(0, dp(12), 0, dp(14));
        layout.addView(preview);

        final float[] hsv = new float[]{0, 1, 1};
        colorBox.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_MOVE || event.getAction() == MotionEvent.ACTION_DOWN) {
                float x = Math.max(0, Math.min(v.getWidth(), event.getX()));
                hsv[0] = (x / v.getWidth()) * 360f;
                int c = Color.HSVToColor(hsv);
                preview.setBackgroundColor(c);
                return true;
            }
            return false;
        });

        Button okBtn = new Button(activity);
        okBtn.setText("APPLY COLOR");
        okBtn.setTextColor(Color.WHITE);
        okBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        okBtn.setTypeface(null, Typeface.BOLD);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setColor(Color.parseColor("#FF1238"));
        okBg.setCornerRadius(dp(22));
        okBtn.setBackground(okBg);
        LinearLayout.LayoutParams okP = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44));
        okBtn.setLayoutParams(okP);

        okBtn.setOnClickListener(v -> {
            updateSelectedBgColor(Color.HSVToColor(hsv));
            colorDialog.dismiss();
        });
        layout.addView(okBtn);

        colorDialog.setContentView(layout);
        colorDialog.show();
    }

    private void populateTemplateGrid(LinearLayout grid, String cat, EditText nameInp, EditText wInp, EditText hInp, EditText resInp) {
        grid.removeAllViews();
        ArrayList<String[]> filtered = new ArrayList<>();
        for (String[] t : templates) {
            if (cat.equals("Recent") || t[3].equalsIgnoreCase(cat)) {
                filtered.add(t);
            }
        }

        for (int i = 0; i < filtered.size(); i += 2) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 0, 0, dp(8));

            final String[] t1 = filtered.get(i);
            row.addView(createTemplateCard(t1[0], t1[1] + " × " + t1[2] + " px", v -> {
                nameInp.setText(t1[0]);
                wInp.setText(t1[1]);
                hInp.setText(t1[2]);
                if (t1[3].equalsIgnoreCase("Print")) {
                    resInp.setText("300");
                } else {
                    resInp.setText("72");
                }
            }));

            if (i + 1 < filtered.size()) {
                final String[] t2 = filtered.get(i + 1);
                row.addView(createTemplateCard(t2[0], t2[1] + " × " + t2[2] + " px", v -> {
                    nameInp.setText(t2[0]);
                    wInp.setText(t2[1]);
                    hInp.setText(t2[2]);
                    if (t2[3].equalsIgnoreCase("Print")) {
                        resInp.setText("300");
                    } else {
                        resInp.setText("72");
                    }
                }));
            }
            grid.addView(row);
        }
    }

    private View createTemplateCard(String title, String size, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(activity);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(95), 1f);
        cp.setMargins(0, 0, dp(8), 0);
        card.setLayoutParams(cp);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(4));
        card.setBackground(bg);
        card.setPadding(dp(6), dp(8), dp(6), dp(8));

        ImageView icon = new ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        icon.setImageDrawable(createPhotoshopDocIcon(dp(18), dp(22), "#E0E0E0"));
        card.addView(icon);

        TextView name = new TextView(activity);
        name.setText(title);
        name.setTextColor(Color.WHITE);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        name.setTypeface(null, Typeface.BOLD);
        name.setSingleLine(true);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(4), 0, 0);
        card.addView(name);

        TextView dims = new TextView(activity);
        dims.setText(size);
        dims.setTextColor(Color.parseColor("#888888"));
        dims.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        dims.setGravity(Gravity.CENTER);
        card.addView(dims);

        card.setOnClickListener(click);
        return card;
    }

    private LinearLayout createFieldWithLabel(String labelText, View field, float weight) {
        LinearLayout wrap = new LinearLayout(activity);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        wp.setMargins(0, 0, dp(8), 0);
        wrap.setLayoutParams(wp);
        wrap.setOrientation(LinearLayout.VERTICAL);

        wrap.addView(createFieldLabel(labelText));
        wrap.addView(field);
        return wrap;
    }

    private TextView createFieldLabel(String text) {
        TextView l = new TextView(activity);
        l.setText(text);
        l.setTextColor(Color.parseColor("#888888"));
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        l.setPadding(0, dp(6), 0, dp(2));
        return l;
    }

    private EditText createDarkInput(String defaultText) {
        EditText et = new EditText(activity);
        et.setText(defaultText);
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        et.setPadding(dp(8), dp(4), dp(8), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#121212"));
        bg.setStroke(dp(1), Color.parseColor("#303030"));
        bg.setCornerRadius(dp(2));
        et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        return et;
    }

    public interface OnDropdownSelected {
        void onSelected(String item);
    }

    private View createPhotoshopDropdown(String initialText, final String[] items, final OnDropdownSelected callback) {
        final LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(8), 0, dp(8), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#121212"));
        bg.setStroke(dp(1), Color.parseColor("#303030"));
        bg.setCornerRadius(dp(2));
        box.setBackground(bg);
        box.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        final TextView label = new TextView(activity);
        label.setText(initialText);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        label.setSingleLine(true);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(label);

        TextView arrow = new TextView(activity);
        arrow.setText("▾");
        arrow.setTextColor(Color.parseColor("#888888"));
        arrow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        box.addView(arrow);

        box.setOnClickListener(v -> {
            final PopupWindow popup = new PopupWindow(activity);
            LinearLayout menu = new LinearLayout(activity);
            menu.setOrientation(LinearLayout.VERTICAL);
            menu.setPadding(dp(4), dp(4), dp(4), dp(4));

            GradientDrawable menuBg = new GradientDrawable();
            menuBg.setColor(Color.parseColor("#222222"));
            menuBg.setStroke(dp(1), Color.parseColor("#383838"));
            menuBg.setCornerRadius(dp(3));
            menu.setBackground(menuBg);

            for (final String item : items) {
                final TextView itemTv = new TextView(activity);
                itemTv.setText(item);
                boolean isSelected = item.equals(label.getText().toString());
                itemTv.setTextColor(isSelected ? Color.WHITE : Color.parseColor("#CCCCCC"));
                itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
                itemTv.setTypeface(null, isSelected ? Typeface.BOLD : Typeface.NORMAL);
                itemTv.setPadding(dp(14), dp(8), dp(14), dp(8));

                if (isSelected) {
                    GradientDrawable selBg = new GradientDrawable();
                    selBg.setColor(Color.parseColor("#2E2E2E"));
                    selBg.setCornerRadius(dp(2));
                    itemTv.setBackground(selBg);
                }

                itemTv.setOnClickListener(v1 -> {
                    label.setText(item);
                    popup.dismiss();
                    if (callback != null) callback.onSelected(item);
                });
                menu.addView(itemTv);
            }

            popup.setContentView(menu);
            popup.setWidth(Math.max(box.getWidth(), dp(130)));
            popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            popup.setFocusable(true);
            popup.setOutsideTouchable(true);
            popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            popup.showAsDropDown(box, 0, dp(1));
        });

        return box;
    }

    private BitmapDrawable createPersonVectorIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor(colorHex));
        p.setStyle(Paint.Style.FILL);

        canvas.drawCircle(w / 2f, h * 0.28f, h * 0.22f, p);

        Path body = new Path();
        body.moveTo(w * 0.15f, h * 0.95f);
        body.quadTo(w * 0.15f, h * 0.58f, w * 0.5f, h * 0.58f);
        body.quadTo(w * 0.85f, h * 0.58f, w * 0.85f, h * 0.95f);
        body.close();
        canvas.drawPath(body, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createLandscapeImageVectorIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor(colorHex));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.2f));

        canvas.drawRect(dp(1), dp(1), w - dp(1), h - dp(1), p);

        p.setStyle(Paint.Style.FILL);
        canvas.drawCircle(w * 0.32f, h * 0.35f, h * 0.12f, p);

        Path hill = new Path();
        hill.moveTo(dp(1), h - dp(1));
        hill.lineTo(w * 0.45f, h * 0.45f);
        hill.lineTo(w * 0.7f, h * 0.7f);
        hill.lineTo(w * 0.85f, h * 0.55f);
        hill.lineTo(w - dp(1), h - dp(1));
        hill.close();
        canvas.drawPath(hill, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createPhotoshopDocIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.parseColor(colorHex));
        paint.setStyle(Paint.Style.FILL);

        Path path = new Path();
        path.moveTo(0, 0);
        path.lineTo(w * 0.65f, 0);
        path.lineTo(w, h * 0.35f);
        path.lineTo(w, h);
        path.lineTo(0, h);
        path.close();
        canvas.drawPath(path, paint);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private TextView createMacDot(String colorHex) {
        TextView dot = new TextView(activity);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        shape.setColor(Color.parseColor(colorHex));
        dot.setBackground(shape);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(10), dp(10));
        p.setMargins(0, 0, dp(7), 0);
        dot.setLayoutParams(p);
        return dot;
    }

    private void saveProjectLocally(String title, int w, int h, int artboards, int bg) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONArray newArr = new JSONArray();

            JSONObject currentObj = new JSONObject();
            currentObj.put("title", title);
            currentObj.put("width", w);
            currentObj.put("height", h);
            currentObj.put("artboards", artboards);
            currentObj.put("bg", bg);
            currentObj.put("date", new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date()));
            currentObj.put("unit", currentUnit);
            currentObj.put("color_mode", currentColorMode);
            currentObj.put("bit_depth", currentBitDepth);
            currentObj.put("dpi", currentDpi);

            newArr.put(currentObj);

            String normCurrent = normalizeTitle(title);

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String oldTitle = obj.optString("title", "");
                if (!normalizeTitle(oldTitle).equalsIgnoreCase(normCurrent)) {
                    newArr.put(obj);
                }
            }

            sp.edit().putString("saved_projects", newArr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public JSONArray getSavedProjects() {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONArray cleanArr = new JSONArray();
            Set<String> seenNormalizedTitles = new HashSet<>();

            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                String t = obj.optString("title", "");
                String norm = normalizeTitle(t);
                if (!norm.isEmpty() && !seenNormalizedTitles.contains(norm)) {
                    seenNormalizedTitles.add(norm);
                    cleanArr.put(obj);
                }
            }

            File baseProjectsDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR/ejitor_project");
            if (baseProjectsDir.exists() && baseProjectsDir.isDirectory()) {
                File[] projectFolders = baseProjectsDir.listFiles();
                if (projectFolders != null) {
                    for (File folder : projectFolders) {
                        if (folder.isDirectory()) {
                            String fName = folder.getName();
                            String normFolder = normalizeTitle(fName);

                            File meta = new File(folder, "project.json");
                            if (!meta.exists()) meta = new File(folder, "project_data.json");

                            if (meta.exists() && !seenNormalizedTitles.contains(normFolder)) {
                                seenNormalizedTitles.add(normFolder);
                                int realW = 1080, realH = 1080;
                                String realTitle = fName;
                                try {
                                    BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(meta), "UTF-8"));
                                    StringBuilder sb = new StringBuilder();
                                    String line;
                                    while ((line = r.readLine()) != null) sb.append(line);
                                    r.close();
                                    JSONObject j = new JSONObject(sb.toString());
                                    realW = j.optInt("width", 1080);
                                    realH = j.optInt("height", 1080);
                                    realTitle = j.optString("name", j.optString("title", fName));
                                } catch (Exception ignored) {}

                                JSONObject autoObj = new JSONObject();
                                autoObj.put("title", realTitle);
                                autoObj.put("width", realW);
                                autoObj.put("height", realH);
                                autoObj.put("artboards", 1);
                                autoObj.put("bg", Color.WHITE);
                                autoObj.put("date", new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date(meta.lastModified())));
                                cleanArr.put(autoObj);
                            }
                        }
                    }
                }
            }
            return cleanArr;
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void deleteProject(int index) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONArray newArr = new JSONArray();

            for (int i = 0; i < arr.length(); i++) {
                if (i != index) {
                    newArr.put(arr.get(i));
                } else {
                    JSONObject obj = arr.getJSONObject(i);
                    deleteProjectFilesFromDisk(obj.optString("title"));
                }
            }
            sp.edit().putString("saved_projects", newArr.toString()).apply();
            renderFilesContent();
            Toast.makeText(activity, "Project deleted", Toast.LENGTH_SHORT).show();
        } catch (Exception ignored) {}
    }

    private void launchEditor(String pName, int w, int h, int artboards, int bg) {
        try {
            Intent intent = new Intent(activity, EditorActivity.class);
            intent.putExtra("project_name", pName);
            intent.putExtra("width", w);
            intent.putExtra("height", h);
            intent.putExtra("artboards", artboards);
            intent.putExtra("bg", bg);
            intent.putExtra("unit", currentUnit);
            intent.putExtra("color_mode", currentColorMode);
            intent.putExtra("bit_depth", currentBitDepth);
            intent.putExtra("dpi", currentDpi);
            activity.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent();
                intent.setClassName(activity.getPackageName(), "com.example.ejitor.EditorActivity");
                intent.putExtra("project_name", pName);
                intent.putExtra("width", w);
                intent.putExtra("height", h);
                intent.putExtra("artboards", artboards);
                intent.putExtra("bg", bg);
                activity.startActivity(intent);
            } catch (Exception ex) {
                Toast.makeText(activity, "Error: " + ex.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
