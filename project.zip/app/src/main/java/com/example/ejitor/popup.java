package com.example.ejitor;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class popup {

    public interface OnHueChangeListener {
        void onHueChanged(float hue, float satVal);
    }

    public interface OnSliderChangeListener {
        void onProgressChanged(float progress);
    }

    public interface OnColorPickListener {
        void onColorPicked(int color);
    }

    public interface OnTextInputListener {
        void onTextUpdated(String text);
    }

    public static class StopPointItem {
        public int color;
        public float position;
        public int originalIndex;

        public StopPointItem(int color, float position, int originalIndex) {
            this.color = color;
            this.position = position;
            this.originalIndex = originalIndex;
        }
    }

    // =========================================================================
    // ডিপি কনভার্টার
    // =========================================================================
    public static int dp(Context ctx, float value) {
        if (ctx == null) {
            if (EditorActivity.instance != null) ctx = EditorActivity.instance;
            else return (int) (value * 2.0f);
        }
        DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    public static int dp(float value) {
        if (EditorActivity.instance != null) {
            return dp(EditorActivity.instance, value);
        }
        return (int) (value * 2.0f);
    }

    // =========================================================================
    // চারকোনা কালার বক্স ভিউ
    // =========================================================================
    public static class RectColorBoxView extends View {
        private final Paint rectPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pointerBorder = new Paint(Paint.ANTI_ALIAS_FLAG);

        private float pointerX = 10f;
        private float pointerY = 10f;
        private OnHueChangeListener hueListener;

        public RectColorBoxView(Context context) {
            super(context);
            pointerPaint.setColor(Color.WHITE);
            pointerPaint.setStyle(Paint.Style.FILL);
            pointerBorder.setColor(Color.BLACK);
            pointerBorder.setStyle(Paint.Style.STROKE);
            pointerBorder.setStrokeWidth(dp(context, 1.8f));
            pointerX = dp(context, 10);
            pointerY = dp(context, 10);
        }

        public void setOnHueChangeListener(OnHueChangeListener l) {
            this.hueListener = l;
        }

        public void setColorHSV(float[] hsv) {
            if (getWidth() > 0) {
                pointerX = (hsv[0] / 360f) * getWidth();
                pointerY = (1.0f - hsv[2]) * getHeight();
            }
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            int[] colors = new int[]{Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED};
            LinearGradient lg = new LinearGradient(0, 0, w, 0, colors, null, Shader.TileMode.CLAMP);
            rectPaint.setShader(lg);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            canvas.drawRoundRect(0, 0, w, h, dp(getContext(), 6), dp(getContext(), 6), rectPaint);

            float px = Math.max(dp(getContext(), 6), Math.min(w - dp(getContext(), 6), pointerX));
            float py = Math.max(dp(getContext(), 6), Math.min(h - dp(getContext(), 6), pointerY));
            canvas.drawCircle(px, py, dp(getContext(), 6.5f), pointerPaint);
            canvas.drawCircle(px, py, dp(getContext(), 6.5f), pointerBorder);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);

            float x = Math.max(0, Math.min(getWidth(), event.getX()));
            float y = Math.max(0, Math.min(getHeight(), event.getY()));
            pointerX = x;
            pointerY = y;

            float hue = (x / getWidth()) * 360f;
            float val = 1.0f - (y / getHeight());

            if (hueListener != null) hueListener.onHueChanged(hue, val);
            invalidate();
            return true;
        }
    }

    // =========================================================================
    // গ্রেডিয়েন্ট স্লাইডার ভিউ
    // =========================================================================
    public static class GradientSliderView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint thumbStroke = new Paint(Paint.ANTI_ALIAS_FLAG);

        private float progress = 1.0f;
        private int colorStart = Color.WHITE;
        private int colorEnd = Color.RED;
        private OnSliderChangeListener listener;

        public GradientSliderView(Context context) {
            super(context);
            thumbPaint.setColor(Color.WHITE);
            thumbPaint.setStyle(Paint.Style.FILL);
            thumbStroke.setColor(Color.parseColor("#333333"));
            thumbStroke.setStyle(Paint.Style.STROKE);
            thumbStroke.setStrokeWidth(dp(context, 1.2f));
        }

        public void setProgress(float p) {
            this.progress = Math.max(0f, Math.min(1f, p));
            invalidate();
        }

        public void setGradientColors(int start, int end) {
            this.colorStart = start;
            this.colorEnd = end;
            updateShader();
            invalidate();
        }

        public void setOnSliderChangeListener(OnSliderChangeListener l) {
            this.listener = l;
        }

        private void updateShader() {
            if (getWidth() > 0) {
                LinearGradient lg = new LinearGradient(0, 0, getWidth(), 0, colorStart, colorEnd, Shader.TileMode.CLAMP);
                trackPaint.setShader(lg);
            }
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            updateShader();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            canvas.drawRoundRect(0, 0, w, h, dp(getContext(), 3), dp(getContext(), 3), trackPaint);

            float tx = progress * (w - dp(getContext(), 12)) + dp(getContext(), 6);
            canvas.drawCircle(tx, h / 2f, dp(getContext(), 6), thumbPaint);
            canvas.drawCircle(tx, h / 2f, dp(getContext(), 6), thumbStroke);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            int w = getWidth();
            float x = Math.max(dp(getContext(), 6), Math.min(w - dp(getContext(), 6), event.getX()));
            progress = (x - dp(getContext(), 6)) / (w - dp(getContext(), 12));
            invalidate();
            if (listener != null) listener.onProgressChanged(progress);
            return true;
        }
    }

    // =========================================================================
    // ড্র্যাগেবল গ্রেডিয়েন্ট ট্র্যাক ভিউ
    // =========================================================================
    public static class InteractiveGradientTrackView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pinSelectedPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        public List<Integer> stops;
        public List<Float> positions;
        public int selectedIndex = 0;
        public Runnable onGradientChanged;
        private int activeTouchIndex = -1;

        public InteractiveGradientTrackView(Context context, List<Integer> s, List<Float> p, Runnable changed) {
            super(context);
            this.stops = s;
            this.positions = p;
            this.onGradientChanged = changed;

            pinStrokePaint.setColor(Color.WHITE);
            pinStrokePaint.setStyle(Paint.Style.STROKE);
            pinStrokePaint.setStrokeWidth(dp(context, 2));

            pinSelectedPaint.setColor(Color.parseColor("#FF1238"));
            pinSelectedPaint.setStyle(Paint.Style.STROKE);
            pinSelectedPaint.setStrokeWidth(dp(context, 3));
        }

        private void updateShader() {
            int w = getWidth();
            if (w <= 0 || stops.size() < 2) return;

            List<StopPointItem> sorted = new ArrayList<>();
            for (int i = 0; i < stops.size(); i++) {
                float pos = (i < positions.size()) ? positions.get(i) : (i / (float) (stops.size() - 1));
                sorted.add(new StopPointItem(stops.get(i), pos, i));
            }
            Collections.sort(sorted, (a, b) -> Float.compare(a.position, b.position));

            int[] cArr = new int[sorted.size()];
            float[] pArr = new float[sorted.size()];
            for (int i = 0; i < sorted.size(); i++) {
                cArr[i] = sorted.get(i).color;
                pArr[i] = Math.max(0f, Math.min(1f, sorted.get(i).position));
                if (i > 0 && pArr[i] < pArr[i - 1]) {
                    pArr[i] = pArr[i - 1];
                }
            }

            LinearGradient lg = new LinearGradient(dp(getContext(), 12), 0, w - dp(getContext(), 12), 0, cArr, pArr, Shader.TileMode.CLAMP);
            trackPaint.setShader(lg);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            updateShader();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0) return;

            updateShader();

            float barTop = dp(getContext(), 4);
            float barBottom = h - dp(getContext(), 18);
            canvas.drawRoundRect(dp(getContext(), 12), barTop, w - dp(getContext(), 12), barBottom, dp(getContext(), 6), dp(getContext(), 6), trackPaint);

            float trackWidth = w - dp(getContext(), 24);
            for (int i = 0; i < stops.size(); i++) {
                float px = dp(getContext(), 12) + positions.get(i) * trackWidth;
                float py = barBottom + dp(getContext(), 8);

                pinFillPaint.setColor(stops.get(i));
                canvas.drawCircle(px, py, dp(getContext(), 7), pinFillPaint);

                if (i == selectedIndex) {
                    canvas.drawCircle(px, py, dp(getContext(), 8.5f), pinSelectedPaint);
                } else {
                    canvas.drawCircle(px, py, dp(getContext(), 7), pinStrokePaint);
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            int w = getWidth();
            float trackWidth = w - dp(getContext(), 24);
            float touchX = event.getX();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    activeTouchIndex = -1;
                    float minD = dp(getContext(), 24);
                    for (int i = 0; i < stops.size(); i++) {
                        float px = dp(getContext(), 12) + positions.get(i) * trackWidth;
                        float d = Math.abs(px - touchX);
                        if (d < minD) {
                            minD = d;
                            activeTouchIndex = i;
                            selectedIndex = i;
                        }
                    }
                    invalidate();
                    if (onGradientChanged != null) onGradientChanged.run();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (activeTouchIndex >= 0 && activeTouchIndex < positions.size()) {
                        float newP = (touchX - dp(getContext(), 12)) / trackWidth;
                        newP = Math.max(0f, Math.min(1f, newP));
                        positions.set(activeTouchIndex, newP);
                        invalidate();
                        if (onGradientChanged != null) onGradientChanged.run();
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    activeTouchIndex = -1;
                    invalidate();
                    return true;
            }
            return super.onTouchEvent(event);
        }
    }

    // =========================================================================
    // প্যালেট ও কালার সেভার মেথডসমূহ
    // =========================================================================
    public static void saveSolidColorToUnifiedPalette(Context ctx, int color) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("type", "solid");
            obj.put("color", color);
            obj.put("hex", String.format("#%08X", color));
            arr.put(obj);
            sp.edit().putString("palette_items", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static void saveGradientToUnifiedPalette(Context ctx, List<Integer> colors, List<Float> positions, int angle, int spacing) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("type", "gradient");
            obj.put("angle", angle);
            obj.put("spacing", spacing);
            JSONArray cArr = new JSONArray();
            for (int c : colors) cArr.put(c);
            obj.put("colors", cArr);

            JSONArray pArr = new JSONArray();
            for (float p : positions) pArr.put((double) p);
            obj.put("positions", pArr);

            obj.put("hex", "Grad (" + colors.size() + " stops)");
            arr.put(obj);
            sp.edit().putString("palette_items", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static void showUnifiedSavedPaletteDialog(final Activity activity) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_unified_palette", Context.MODE_PRIVATE);
            final JSONArray arr = new JSONArray(sp.getString("palette_items", "[]"));

            final Dialog d = new Dialog(activity);
            d.requestWindowFeature(Window.FEATURE_NO_TITLE);
            d.setCancelable(false);

            LinearLayout box = new LinearLayout(activity);
            box.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 260), dp(activity, 350)));
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 14));
            box.setBackground(createDialogBg(activity));

            LinearLayout header = new LinearLayout(activity);
            header.setOrientation(LinearLayout.HORIZONTAL);
            header.setGravity(Gravity.CENTER_VERTICAL);
            header.setPadding(0, 0, 0, dp(activity, 8));

            TextView title = new TextView(activity);
            title.setText("Saved Colors Palette");
            title.setTextColor(Color.WHITE);
            title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            title.setTypeface(null, Typeface.BOLD);
            title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            header.addView(title);

            ImageView closeX = new ImageView(activity);
            closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 14), dp(activity, 14)));
            closeX.setImageDrawable(createCloseVectorDrawable(activity));
            closeX.setOnClickListener(v -> d.dismiss());
            header.addView(closeX);
            box.addView(header);

            final TextView searchBox = new TextView(activity);
            searchBox.setHint("Search color / hex...");
            searchBox.setHintTextColor(Color.parseColor("#777777"));
            searchBox.setTextColor(Color.WHITE);
            searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            searchBox.setBackground(createInputBg(activity));
            searchBox.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 6));
            searchBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 32)));
            box.addView(searchBox);

            ScrollView sv = new ScrollView(activity);
            LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            svLp.setMargins(0, dp(activity, 6), 0, dp(activity, 6));
            sv.setLayoutParams(svLp);

            final LinearLayout list = new LinearLayout(activity);
            list.setOrientation(LinearLayout.VERTICAL);
            sv.addView(list);
            box.addView(sv);

            final Runnable renderList = () -> {
                list.removeAllViews();
                String query = searchBox.getText().toString().trim().toLowerCase();

                for (int i = 0; i < arr.length(); i++) {
                    try {
                        final JSONObject item = arr.getJSONObject(i);
                        String hexLabel = item.optString("hex", "#FFFFFF");
                        if (!query.isEmpty() && !hexLabel.toLowerCase().contains(query)) continue;

                        LinearLayout row = new LinearLayout(activity);
                        row.setOrientation(LinearLayout.HORIZONTAL);
                        row.setGravity(Gravity.CENTER_VERTICAL);
                        row.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 6));

                        GradientDrawable rowBg = new GradientDrawable();
                        rowBg.setColor(Color.parseColor("#222222"));
                        rowBg.setCornerRadius(dp(activity, 4));
                        rowBg.setStroke(dp(activity, 1), Color.parseColor("#333333"));
                        row.setBackground(rowBg);

                        LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 36));
                        rLp.setMargins(0, 0, 0, dp(activity, 4));
                        row.setLayoutParams(rLp);

                        View preview = new View(activity);
                        preview.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 24), dp(activity, 24)));

                        if ("gradient".equals(item.optString("type"))) {
                            JSONArray cArr = item.getJSONArray("colors");
                            int[] colors = new int[cArr.length()];
                            for (int c = 0; c < cArr.length(); c++) colors[c] = cArr.getInt(c);
                            GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
                            gd.setCornerRadius(dp(activity, 3));
                            gd.setStroke(dp(activity, 1), Color.WHITE);
                            preview.setBackground(gd);
                        } else {
                            int c = item.optInt("color", Color.WHITE);
                            updateColorPreview(activity, preview, c);
                        }
                        row.addView(preview);

                        TextView labelTv = new TextView(activity);
                        labelTv.setText("  " + hexLabel);
                        labelTv.setTextColor(Color.WHITE);
                        labelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
                        labelTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                        labelTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                        row.addView(labelTv);

                        row.setOnClickListener(v -> {
                            if (activity instanceof EditorActivity) {
                                EditorActivity ea = (EditorActivity) activity;
                                if ("gradient".equals(item.optString("type"))) {
                                    try {
                                        JSONArray cArr = item.getJSONArray("colors");
                                        JSONArray pArr = item.optJSONArray("positions");
                                        List<Integer> cList = new ArrayList<>();
                                        List<Float> pList = new ArrayList<>();
                                        for (int k = 0; k < cArr.length(); k++) {
                                            cList.add(cArr.getInt(k));
                                            if (pArr != null && k < pArr.length()) pList.add((float) pArr.getDouble(k));
                                            else pList.add(k / (float) Math.max(1, cArr.length() - 1));
                                        }
                                        applyCustomGradientToEditorCanvas(ea, cList, pList);
                                    } catch (Exception ignored) {}
                                } else {
                                    int c = item.optInt("color", Color.WHITE);
                                    applyColorToEditorActivity(ea, c, true, false);
                                }
                            }
                            Toast.makeText(activity, "Applied from Palette", Toast.LENGTH_SHORT).show();
                            d.dismiss();
                        });

                        list.addView(row);
                    } catch (Exception ignored) {}
                }
            };
            renderList.run();

            searchBox.setOnClickListener(v -> showVirtualKeyboard(activity, searchBox, searchBox, text -> renderList.run()));

            Button closeBtn = new Button(activity);
            closeBtn.setText("CLOSE");
            closeBtn.setTextColor(Color.WHITE);
            closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
            setButtonBg(activity, closeBtn, "#2C2C2C");
            closeBtn.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 30)));
            closeBtn.setOnClickListener(v -> d.dismiss());
            box.addView(closeBtn);

            d.setContentView(box);
            d.show();
        } catch (Exception ignored) {}
    }

    public static void showStandaloneColorPicker(final Activity activity, int initialColor, OnColorPickListener listener) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 250), ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10));
        box.setBackground(createDialogBg(activity));

        TextView title = new TextView(activity);
        title.setText("Pick Color");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(activity, 6));
        box.addView(title);

        final View preview = new View(activity);
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 22));
        pvLp.setMargins(0, 0, 0, dp(activity, 6));
        preview.setLayoutParams(pvLp);
        updateColorPreview(activity, preview, initialColor);
        box.addView(preview);

        final int[] picked = {initialColor};
        final float[] hsv = new float[3];
        Color.colorToHSV(initialColor, hsv);
        final int[] curAlpha = {Color.alpha(initialColor)};

        final RectColorBoxView rectBox = new RectColorBoxView(activity);
        rectBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 75)));
        rectBox.setColorHSV(hsv);
        box.addView(rectBox);

        final GradientSliderView satSlider = new GradientSliderView(activity);
        final GradientSliderView valSlider = new GradientSliderView(activity);
        final GradientSliderView alphaSlider = new GradientSliderView(activity);

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 13));
        slp.setMargins(0, dp(activity, 2.5f), 0, dp(activity, 2.5f));
        satSlider.setLayoutParams(slp);
        valSlider.setLayoutParams(slp);
        alphaSlider.setLayoutParams(slp);

        satSlider.setProgress(hsv[1]);
        valSlider.setProgress(hsv[2]);
        alphaSlider.setProgress(curAlpha[0] / 255f);

        final Runnable updateSliderColors = () -> {
            float[] tempHSV = new float[]{hsv[0], 0f, hsv[2]};
            int colWhite = Color.HSVToColor(tempHSV);
            tempHSV[1] = 1f;
            int colSat = Color.HSVToColor(tempHSV);
            satSlider.setGradientColors(colWhite, colSat);

            tempHSV[1] = hsv[1];
            tempHSV[2] = 0f;
            int colBlack = Color.HSVToColor(tempHSV);
            tempHSV[2] = 1f;
            int colBright = Color.HSVToColor(tempHSV);
            valSlider.setGradientColors(colBlack, colBright);

            int colOpaque = Color.HSVToColor(255, hsv);
            alphaSlider.setGradientColors(Color.TRANSPARENT, colOpaque);
        };
        updateSliderColors.run();

        rectBox.setOnHueChangeListener((newHue, newSatVal) -> {
            hsv[0] = newHue;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(activity, preview, picked[0]);
            updateSliderColors.run();
        });

        satSlider.setOnSliderChangeListener(prog -> {
            hsv[1] = prog;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(activity, preview, picked[0]);
            updateSliderColors.run();
            rectBox.setColorHSV(hsv);
        });

        valSlider.setOnSliderChangeListener(prog -> {
            hsv[2] = prog;
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(activity, preview, picked[0]);
            updateSliderColors.run();
            rectBox.setColorHSV(hsv);
        });

        alphaSlider.setOnSliderChangeListener(prog -> {
            curAlpha[0] = Math.round(prog * 255f);
            picked[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateColorPreview(activity, preview, picked[0]);
            updateSliderColors.run();
        });

        box.addView(satSlider);
        box.addView(valSlider);
        box.addView(alphaSlider);

        Button ok = new Button(activity);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        ok.setTypeface(null, Typeface.BOLD);
        setButtonBg(activity, ok, "#FF1238");
        LinearLayout.LayoutParams okLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 28));
        okLp.setMargins(0, dp(activity, 6), 0, 0);
        ok.setLayoutParams(okLp);
        ok.setOnClickListener(v -> {
            if (listener != null) listener.onColorPicked(picked[0]);
            d.dismiss();
        });
        box.addView(ok);

        d.setContentView(box);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.show();
    }

    // =========================================================================
    // ১. সম্পূর্ণ কালার ও গ্রেডিয়েন্ট পপআপ
    // =========================================================================
    public static void showColorPicker(final Activity activity, final View anchor, final boolean isForeground, final boolean isStrokeMode) {
        final Dialog cd = new Dialog(activity);
        cd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        cd.setCancelable(false);
        cd.setCanceledOnTouchOutside(false);

        if (cd.getWindow() != null) {
            cd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            cd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            cd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final WindowManager.LayoutParams wmlp = cd.getWindow().getAttributes();
        wmlp.width = dp(activity, 265);
        wmlp.height = dp(activity, 355);

        final FrameLayout rootFrame = new FrameLayout(activity);
        rootFrame.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        final LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 14), dp(activity, 10), dp(activity, 14), dp(activity, 10));
        box.setBackground(createDialogBg(activity));

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(activity, 6));

        final ImageView menuBtn = new ImageView(activity);
        menuBtn.setImageDrawable(createVectorMenuIcon(activity));
        menuBtn.setScaleType(ImageView.ScaleType.CENTER);
        LinearLayout.LayoutParams mLp = new LinearLayout.LayoutParams(dp(activity, 26), dp(activity, 26));
        mLp.setMargins(0, 0, dp(activity, 6), 0);
        menuBtn.setLayoutParams(mLp);
        header.addView(menuBtn);

        TextView titleTv = new TextView(activity);
        titleTv.setText(isStrokeMode ? "Stroke Color" : (isForeground ? "Fill / Foreground" : "Background Color"));
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        final View bigColorPreview = new View(activity);
        bigColorPreview.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 24), dp(activity, 24)));
        header.addView(bigColorPreview);
        box.addView(header);

        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        cd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        int initialCol = Color.parseColor("#FF1238");
        if (activity instanceof EditorActivity) {
            EditorActivity ea = (EditorActivity) activity;
            EditorActivity.ProjectTabSession s = ea.getCurrentSession();
            String activeTool = (String) getField(ea, "activeTool");

            if ("gradient".equals(activeTool) && s != null && s.activeGradStop != null) {
                initialCol = s.activeGradStop.color;
            } else {
                Object sc = getField(ea, isStrokeMode ? "shapeStrokeColor" : (isForeground ? "fgColor" : "bgColor"));
                if (sc instanceof Integer) initialCol = (Integer) sc;
            }
        }

        final float[] hsv = new float[3];
        Color.colorToHSV(initialCol, hsv);
        final int[] curAlpha = {Color.alpha(initialCol)};
        final int[] workingColor = {initialCol};

        final Runnable updatePreviewDrawable = () -> {
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(workingColor[0]);
            d.setStroke(dp(activity, 1.5f), Color.WHITE);
            bigColorPreview.setBackground(d);
        };
        updatePreviewDrawable.run();

        final TextView hexBoxTv = new TextView(activity);
        hexBoxTv.setTextColor(Color.WHITE);
        hexBoxTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        hexBoxTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hexBoxTv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hexLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 26));
        hexLp.setMargins(0, 0, 0, dp(activity, 6));
        hexBoxTv.setLayoutParams(hexLp);

        GradientDrawable hexBg = new GradientDrawable();
        hexBg.setColor(Color.parseColor("#121212"));
        hexBg.setStroke(dp(activity, 1.2f), Color.parseColor("#D4A054"));
        hexBg.setCornerRadius(dp(activity, 4));
        hexBoxTv.setBackground(hexBg);

        final Runnable updateHexText = () -> {
            int c = workingColor[0];
            int a = Color.alpha(c);
            int r = Color.red(c);
            int g = Color.green(c);
            int b = Color.blue(c);
            hexBoxTv.setText(String.format("#%08X - (%d,%d,%d,%d)", c, r, g, b, a));
        };
        updateHexText.run();
        box.addView(hexBoxTv);

        final RectColorBoxView rectColorBox = new RectColorBoxView(activity);
        LinearLayout.LayoutParams rBoxLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 90));
        rBoxLp.setMargins(0, 0, 0, dp(activity, 6));
        rectColorBox.setLayoutParams(rBoxLp);
        rectColorBox.setColorHSV(hsv);
        box.addView(rectColorBox);

        final GradientSliderView satSlider = new GradientSliderView(activity);
        final GradientSliderView valSlider = new GradientSliderView(activity);
        final GradientSliderView alphaSlider = new GradientSliderView(activity);

        satSlider.setProgress(hsv[1]);
        valSlider.setProgress(hsv[2]);
        alphaSlider.setProgress(curAlpha[0] / 255f);

        final Runnable updateSliderGradients = () -> {
            float[] tempHSV = new float[]{hsv[0], 0f, hsv[2]};
            int colWhite = Color.HSVToColor(tempHSV);
            tempHSV[1] = 1f;
            int colSat = Color.HSVToColor(tempHSV);
            satSlider.setGradientColors(colWhite, colSat);

            tempHSV[1] = hsv[1];
            tempHSV[2] = 0f;
            int colBlack = Color.HSVToColor(tempHSV);
            tempHSV[2] = 1f;
            int colBright = Color.HSVToColor(tempHSV);
            valSlider.setGradientColors(colBlack, colBright);

            int colOpaque = Color.HSVToColor(255, hsv);
            alphaSlider.setGradientColors(Color.TRANSPARENT, colOpaque);
        };
        updateSliderGradients.run();

        rectColorBox.setOnHueChangeListener((newHue, newSatVal) -> {
            hsv[0] = newHue;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
        });

        satSlider.setOnSliderChangeListener(prog -> {
            hsv[1] = prog;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
            rectColorBox.setColorHSV(hsv);
        });

        valSlider.setOnSliderChangeListener(prog -> {
            hsv[2] = prog;
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
            rectColorBox.setColorHSV(hsv);
        });

        alphaSlider.setOnSliderChangeListener(prog -> {
            curAlpha[0] = Math.round(prog * 255f);
            workingColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updatePreviewDrawable.run();
            updateHexText.run();
            updateSliderGradients.run();
        });

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 13));
        slp.setMargins(0, dp(activity, 2.5f), 0, dp(activity, 2.5f));
        satSlider.setLayoutParams(slp);
        valSlider.setLayoutParams(slp);
        alphaSlider.setLayoutParams(slp);

        box.addView(satSlider);
        box.addView(valSlider);
        box.addView(alphaSlider);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(activity, 8), 0, 0);

        Button apply = new Button(activity);
        apply.setText("APPLY");
        apply.setTextColor(Color.WHITE);
        apply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        apply.setTypeface(null, Typeface.BOLD);
        setButtonBg(activity, apply, "#FF1238");
        apply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(activity, 32), 1.2f));

        apply.setOnClickListener(v -> {
            int selectedColor = workingColor[0];
            if (activity instanceof EditorActivity) {
                EditorActivity ea = (EditorActivity) activity;
                applyColorToEditorActivity(ea, selectedColor, isForeground, isStrokeMode);
            }
            if (anchor != null) updateColorPreview(activity, anchor, selectedColor);
            Toast.makeText(activity, "Color Applied Live", Toast.LENGTH_SHORT).show();
        });
        btnRow.addView(apply);

        View g = new View(activity); 
        g.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 8), dp(activity, 1))); 
        btnRow.addView(g);

        Button cancel = new Button(activity);
        cancel.setText("CLOSE");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(activity, cancel, "#2C2C2C");
        cancel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(activity, 32), 0.8f));
        cancel.setOnClickListener(v -> cd.dismiss());
        btnRow.addView(cancel);

        box.addView(btnRow);
        rootFrame.addView(box);

        menuBtn.setOnClickListener(v -> {
            final PopupWindow menuPopup = new PopupWindow(activity);
            LinearLayout menuL = new LinearLayout(activity);
            menuL.setOrientation(LinearLayout.VERTICAL);
            menuL.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 6));
            menuL.setBackground(createDialogBg(activity));

            String[] items = {"Save Color", "Open Saved Palette", "Gradient Mode", "Gradient Templates"};
            for (int i = 0; i < items.length; i++) {
                final int idx = i;
                TextView itv = new TextView(activity);
                itv.setText(items[i]);
                itv.setTextColor(Color.WHITE);
                itv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
                itv.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 8));
                itv.setOnClickListener(view -> {
                    menuPopup.dismiss();
                    if (idx == 0) {
                        saveSolidColorToUnifiedPalette(activity, workingColor[0]);
                        Toast.makeText(activity, "Color Saved to Palette!", Toast.LENGTH_SHORT).show();
                    } else if (idx == 1) {
                        showUnifiedSavedPaletteDialog(activity);
                    } else if (idx == 2) {
                        cd.dismiss();
                        showInteractiveGradient(activity);
                    } else if (idx == 3) {
                        showGradientTemplates(activity);
                    }
                });
                menuL.addView(itv);
            }
            menuPopup.setContentView(menuL);
            menuPopup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            menuPopup.setFocusable(true);
            menuPopup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            menuPopup.showAsDropDown(menuBtn, 0, dp(activity, 4));
        });

        final ImageView resizeHandle = new ImageView(activity);
        resizeHandle.setImageDrawable(createVectorResizeIcon(activity));
        resizeHandle.setScaleType(ImageView.ScaleType.CENTER);
        FrameLayout.LayoutParams rzLp = new FrameLayout.LayoutParams(dp(activity, 22), dp(activity, 22), Gravity.BOTTOM | Gravity.END);
        resizeHandle.setLayoutParams(rzLp);

        resizeHandle.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.width, event.getRawY() - wmlp.height});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] tag = (float[]) v.getTag();
                    if (tag != null) {
                        int newW = Math.max(dp(activity, 200), (int) (event.getRawX() - tag[0]));
                        int newH = Math.max(dp(activity, 280), (int) (event.getRawY() - tag[1]));
                        wmlp.width = newW;
                        wmlp.height = newH;
                        cd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });
        rootFrame.addView(resizeHandle);

        cd.setContentView(rootFrame);
        cd.show();
    }

    private static void applyColorToEditorActivity(EditorActivity ea, int color, boolean isForeground, boolean isStrokeMode) {
        try {
            EditorActivity.ProjectTabSession s = ea.getCurrentSession();
            String activeTool = (String) getField(ea, "activeTool");

            if (isStrokeMode) {
                setField(ea, "shapeStrokeColor", color);
                setField(ea, "polyStrokeColor", color);
            } else if (isForeground) {
                setField(ea, "fgColor", color);
                setField(ea, "shapeFillColor", color);
                setField(ea, "polyFillColor", color);
            } else {
                setField(ea, "bgColor", color);
            }

            if (s != null && ("gradient".equals(activeTool) || s.hasGradientLine)) {
                if (s.activeGradStop != null) {
                    s.activeGradStop.color = color;
                } else if (s.gradStops != null && !s.gradStops.isEmpty()) {
                    if (isForeground) {
                        s.gradStops.get(0).color = color;
                        s.activeGradStop = s.gradStops.get(0);
                    } else {
                        s.gradStops.get(s.gradStops.size() - 1).color = color;
                        s.activeGradStop = s.gradStops.get(s.gradStops.size() - 1);
                    }
                }
                invokeMethod(ea, "applyOnCanvasGradientToActiveLayer");
                invokeMethod(ea, "recordHistory");
            }

            Path activeSel = (Path) getField(ea, "activeSelectionPath");
            if (activeSel != null && !isStrokeMode) {
                try {
                    Method fillSel = ea.getClass().getMethod("fillActiveSelectionWithColor", int.class);
                    fillSel.invoke(ea, color);
                } catch (Exception ignored) {}
            }

            invokeMethod(ea, "updateActivePolygonShapeProperties");
            invokeMethod(ea, "reRenderActiveShapeLayer");
            invokeMethod(ea, "updateSwatchPreviews");
            invokeMethod(ea, "updateLayersDockUI");

            try {
                Class<?> ed5 = Class.forName("com.example.ejitor.editor_5");
                Field instF = ed5.getField("instance");
                Object ed5Inst = instF.get(null);
                if (ed5Inst != null) {
                    setField(ed5Inst, "currentTextColor", color);
                    invokeMethod(ed5Inst, "applyActiveTextLayerUpdate");
                }
            } catch (Exception ignored) {}

            if (ea.canvasView != null) ea.canvasView.invalidate();
            invokeMethod(ea, "autoSaveCurrentProject");
        } catch (Exception ignored) {}
    }

    // =========================================================================
    // ২. ইন্টারেক্টিভ গ্রেডিয়েন্ট মোড পিকার
    // =========================================================================
    public static void showInteractiveGradient(final Activity activity) {
        final Dialog gd = new Dialog(activity);
        gd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        gd.setCancelable(false);
        gd.setCanceledOnTouchOutside(false);

        if (gd.getWindow() != null) {
            gd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            gd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            gd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final int dialogWidth = dp(activity, 305);

        final LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dialogWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 14), dp(activity, 12), dp(activity, 14), dp(activity, 12));
        box.setBackground(createDialogBg(activity));

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(activity, 8));

        TextView title = new TextView(activity);
        title.setText("Interactive Gradient");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setSingleLine(true);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(title);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 14), dp(activity, 14)));
        closeX.setImageDrawable(createCloseVectorDrawable(activity));
        closeX.setOnClickListener(v -> gd.dismiss());
        header.addView(closeX);
        box.addView(header);

        final List<Integer> workingStops = new ArrayList<>();
        final List<Float> workingPositions = new ArrayList<>();

        workingStops.add(Color.parseColor("#FF1238"));
        workingStops.add(Color.parseColor("#FFCC00"));
        workingPositions.add(0.0f);
        workingPositions.add(1.0f);

        final int[] gradAngle = {0};
        final int[] gradSpacing = {100};

        final InteractiveGradientTrackView trackView = new InteractiveGradientTrackView(activity, workingStops, workingPositions, null);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 46));
        tlp.setMargins(0, 0, 0, dp(activity, 8));
        trackView.setLayoutParams(tlp);
        box.addView(trackView);

        LinearLayout pointControlRow = new LinearLayout(activity);
        pointControlRow.setOrientation(LinearLayout.HORIZONTAL);
        pointControlRow.setGravity(Gravity.CENTER_VERTICAL);
        pointControlRow.setPadding(0, 0, 0, dp(activity, 8));

        final View activeStopSwatch = new View(activity);
        activeStopSwatch.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 26), dp(activity, 26)));
        updateColorPreview(activity, activeStopSwatch, workingStops.get(trackView.selectedIndex));
        pointControlRow.addView(activeStopSwatch);

        final TextView pointLabelTv = new TextView(activity);
        pointLabelTv.setText(" Point " + (trackView.selectedIndex + 1) + " Color");
        pointLabelTv.setTextColor(Color.WHITE);
        pointLabelTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        pointLabelTv.setTypeface(null, Typeface.BOLD);
        pointLabelTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        pointControlRow.addView(pointLabelTv);

        final TextView delPointBtn = createPillButton(activity, "✕ Delete", "#38191E", null);
        delPointBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 62), dp(activity, 28)));
        delPointBtn.setVisibility(workingStops.size() > 2 ? View.VISIBLE : View.GONE);
        pointControlRow.addView(delPointBtn);

        TextView addPointBtn = createPillButton(activity, "+ Add Point", "#FF1238", null);
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(dp(activity, 78), dp(activity, 28));
        apLp.setMargins(dp(activity, 4), 0, 0, 0);
        addPointBtn.setLayoutParams(apLp);
        pointControlRow.addView(addPointBtn);

        box.addView(pointControlRow);

        final Runnable updateSelectedPointUI = () -> {
            int sel = trackView.selectedIndex;
            if (sel >= 0 && sel < workingStops.size()) {
                updateColorPreview(activity, activeStopSwatch, workingStops.get(sel));
                pointLabelTv.setText(" Point " + (sel + 1) + " Color");
                delPointBtn.setVisibility(workingStops.size() > 2 ? View.VISIBLE : View.GONE);
            }
        };

        trackView.onGradientChanged = updateSelectedPointUI;

        activeStopSwatch.setOnClickListener(v -> {
            int sel = trackView.selectedIndex;
            showStandaloneColorPicker(activity, workingStops.get(sel), col -> {
                workingStops.set(sel, col);
                updateColorPreview(activity, activeStopSwatch, col);
                trackView.invalidate();
            });
        });

        addPointBtn.setOnClickListener(v -> {
            int lastCol = workingStops.get(workingStops.size() - 1);
            workingStops.add(lastCol);
            workingPositions.add(0.5f);
            trackView.selectedIndex = workingStops.size() - 1;
            trackView.invalidate();
            updateSelectedPointUI.run();
        });

        delPointBtn.setOnClickListener(v -> {
            if (workingStops.size() > 2) {
                int sel = trackView.selectedIndex;
                workingStops.remove(sel);
                workingPositions.remove(sel);
                trackView.selectedIndex = Math.max(0, sel - 1);
                trackView.invalidate();
                updateSelectedPointUI.run();
            }
        });

        LinearLayout toolsRow1 = new LinearLayout(activity);
        toolsRow1.setOrientation(LinearLayout.HORIZONTAL);
        toolsRow1.setGravity(Gravity.CENTER_VERTICAL);
        toolsRow1.setPadding(0, 0, 0, dp(activity, 6));

        TextView reverseBtn = createPillButton(activity, "⇄ Reverse", "#2C2C2C", v -> {
            Collections.reverse(workingStops);
            for (int i = 0; i < workingPositions.size(); i++) {
                workingPositions.set(i, 1.0f - workingPositions.get(i));
            }
            trackView.invalidate();
            updateSelectedPointUI.run();
        });
        LinearLayout.LayoutParams rvLp = new LinearLayout.LayoutParams(0, dp(activity, 28), 1f);
        rvLp.setMargins(0, 0, dp(activity, 4), 0);
        reverseBtn.setLayoutParams(rvLp);
        toolsRow1.addView(reverseBtn);

        TextView saveGradBtn = createPillButton(activity, "Save to Palette", "#2C2C2C", v -> {
            saveGradientToUnifiedPalette(activity, workingStops, workingPositions, gradAngle[0], gradSpacing[0]);
            Toast.makeText(activity, "Gradient Saved to Palette!", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams sgLp = new LinearLayout.LayoutParams(0, dp(activity, 28), 1.2f);
        saveGradBtn.setLayoutParams(sgLp);
        toolsRow1.addView(saveGradBtn);

        box.addView(toolsRow1);

        final TextView angleLbl = new TextView(activity);
        angleLbl.setText("Gradient Angle: " + gradAngle[0] + "°");
        angleLbl.setTextColor(Color.WHITE);
        angleLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        angleLbl.setTypeface(null, Typeface.BOLD);
        box.addView(angleLbl);

        final SeekBar angleSeekBar = new SeekBar(activity);
        angleSeekBar.setMax(360);
        angleSeekBar.setProgress(gradAngle[0]);
        applyCustomSeekBarStyle(activity, angleSeekBar);
        box.addView(angleSeekBar);

        angleLbl.setOnClickListener(v -> showNumericKeypad(activity, angleLbl, "Angle", 0, 360, gradAngle[0], val -> {
            gradAngle[0] = (int) val;
            angleSeekBar.setProgress(gradAngle[0]);
            angleLbl.setText("Gradient Angle: " + gradAngle[0] + "°");
        }));

        angleSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    gradAngle[0] = progress;
                    angleLbl.setText("Gradient Angle: " + gradAngle[0] + "°");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        final TextView spacingLbl = new TextView(activity);
        spacingLbl.setText("Gradient Spacing: " + gradSpacing[0] + "%");
        spacingLbl.setTextColor(Color.WHITE);
        spacingLbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        spacingLbl.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams spcLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        spcLp.setMargins(0, dp(activity, 6), 0, dp(activity, 1));
        spacingLbl.setLayoutParams(spcLp);
        box.addView(spacingLbl);

        final SeekBar spacingSeekBar = new SeekBar(activity);
        spacingSeekBar.setMax(290);
        spacingSeekBar.setProgress(Math.max(0, gradSpacing[0] - 10));
        applyCustomSeekBarStyle(activity, spacingSeekBar);
        box.addView(spacingSeekBar);

        spacingLbl.setOnClickListener(v -> showNumericKeypad(activity, spacingLbl, "Gradient Spacing", 10, 300, gradSpacing[0], val -> {
            gradSpacing[0] = (int) val;
            spacingSeekBar.setProgress(Math.max(0, gradSpacing[0] - 10));
            spacingLbl.setText("Gradient Spacing: " + gradSpacing[0] + "%");
        }));

        spacingSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    gradSpacing[0] = progress + 10;
                    spacingLbl.setText("Gradient Spacing: " + gradSpacing[0] + "%");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(activity, 10), 0, 0);

        Button applyGradBtn = new Button(activity);
        applyGradBtn.setText("APPLY");
        applyGradBtn.setTextColor(Color.WHITE);
        applyGradBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        applyGradBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(activity, applyGradBtn, "#FF1238");
        applyGradBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(activity, 32), 1.2f));

        applyGradBtn.setOnClickListener(v -> {
            if (activity instanceof EditorActivity) {
                EditorActivity ea = (EditorActivity) activity;
                applyCustomGradientToEditorCanvas(ea, workingStops, workingPositions);
            }
            Toast.makeText(activity, "Gradient Applied Live", Toast.LENGTH_SHORT).show();
            gd.dismiss();
        });
        btnRow.addView(applyGradBtn);

        View g = new View(activity); 
        g.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 8), dp(activity, 1))); 
        btnRow.addView(g);

        Button closeBtn = new Button(activity);
        closeBtn.setText("CLOSE");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(activity, closeBtn, "#2C2C2C");
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(activity, 32), 0.8f));
        closeBtn.setOnClickListener(v -> gd.dismiss());
        btnRow.addView(closeBtn);

        box.addView(btnRow);
        gd.setContentView(box);
        gd.show();

        if (gd.getWindow() != null) {
            gd.getWindow().setLayout(dialogWidth, ViewGroup.LayoutParams.WRAP_CONTENT);

            final WindowManager.LayoutParams wmlp = gd.getWindow().getAttributes();
            header.setOnTouchListener((v, event) -> {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float[] pos = (float[]) v.getTag();
                        if (pos != null) {
                            wmlp.x = (int) (event.getRawX() - pos[0]);
                            wmlp.y = (int) (event.getRawY() - pos[1]);
                            gd.getWindow().setAttributes(wmlp);
                        }
                        return true;
                }
                return false;
            });
        }
    }

    private static void applyCustomGradientToEditorCanvas(EditorActivity ea, List<Integer> stops, List<Float> positions) {
        try {
            EditorActivity.ProjectTabSession s = ea.getCurrentSession();
            if (s != null) {
                s.hasGradientLine = true;
                s.gradStops.clear();
                List<StopPointItem> sorted = new ArrayList<>();
                for (int i = 0; i < stops.size(); i++) {
                    float pos = (i < positions.size()) ? positions.get(i) : (i / (float) Math.max(1, stops.size() - 1));
                    sorted.add(new StopPointItem(stops.get(i), pos, i));
                }
                Collections.sort(sorted, (a, b) -> Float.compare(a.position, b.position));
                for (StopPointItem item : sorted) {
                    s.gradStops.add(new EditorActivity.GradStop(item.position, item.color));
                }
                if (!s.gradStops.isEmpty()) {
                    s.activeGradStop = s.gradStops.get(0);
                }
                invokeMethod(ea, "applyOnCanvasGradientToActiveLayer");
                invokeMethod(ea, "recordHistory");
                invokeMethod(ea, "updateLayersDockUI");
                if (ea.canvasView != null) ea.canvasView.invalidate();
            }
        } catch (Exception ignored) {}
    }

    // =========================================================================
    // ৩. ড্র্যাগেবল ক্যালকুলেটর কিবোর্ড
    // =========================================================================
    public static void showNumericKeypad(final Activity activity, final View anchorView, String title, final float min, final float max, float initialVal, final EditorActivity.OnNumericInputListener listener) {
        final Dialog kd = new Dialog(activity);
        kd.requestWindowFeature(Window.FEATURE_NO_TITLE);
        kd.setCancelable(false);
        kd.setCanceledOnTouchOutside(false);

        if (kd.getWindow() != null) {
            kd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            kd.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            kd.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final int targetWidth = dp(activity, 215);

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(activity, 10), dp(activity, 8), dp(activity, 10), dp(activity, 10));
        root.setBackground(createDialogBg(activity));

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(activity, 6));

        TextView titleTv = new TextView(activity);
        titleTv.setText(title + " [" + (int)min + ".." + (int)max + "]");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setSingleLine(true);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 14), dp(activity, 14)));
        closeX.setImageDrawable(createCloseVectorDrawable(activity));
        closeX.setOnClickListener(v -> kd.dismiss());
        header.addView(closeX);
        root.addView(header);

        kd.show();
        final WindowManager.LayoutParams wmlp = kd.getWindow().getAttributes();
        wmlp.gravity = Gravity.TOP | Gravity.START;
        wmlp.width = targetWidth;
        wmlp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (anchorView != null) {
            int[] loc = new int[2];
            anchorView.getLocationOnScreen(loc);
            wmlp.x = Math.max(dp(activity, 10), loc[0] - dp(activity, 20));
            wmlp.y = Math.max(dp(activity, 10), loc[1] + anchorView.getHeight() + dp(activity, 4));
        } else {
            wmlp.x = dp(activity, 80);
            wmlp.y = dp(activity, 60);
        }
        kd.getWindow().setAttributes(wmlp);

        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        kd.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        LinearLayout displayRow = new LinearLayout(activity);
        displayRow.setOrientation(LinearLayout.HORIZONTAL);
        displayRow.setGravity(Gravity.CENTER_VERTICAL);
        displayRow.setPadding(0, 0, 0, dp(activity, 6));

        final TextView displayTv = new TextView(activity);
        displayTv.setText(String.valueOf((int) initialVal));
        displayTv.setTextColor(Color.WHITE);
        displayTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        displayTv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        displayTv.setGravity(Gravity.CENTER);

        GradientDrawable dispBg = new GradientDrawable();
        dispBg.setColor(Color.parseColor("#141414"));
        dispBg.setStroke(dp(activity, 1.2f), Color.parseColor("#FF1238"));
        dispBg.setCornerRadius(dp(activity, 3));
        displayTv.setBackground(dispBg);

        LinearLayout.LayoutParams dispLp = new LinearLayout.LayoutParams(0, dp(activity, 34), 1.8f);
        dispLp.setMargins(0, 0, dp(activity, 6), 0);
        displayTv.setLayoutParams(dispLp);
        displayRow.addView(displayTv);

        Button acBtn = new Button(activity);
        acBtn.setText("AC");
        acBtn.setTextColor(Color.WHITE);
        acBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        acBtn.setTypeface(null, Typeface.BOLD);
        setButtonBg(activity, acBtn, "#FF1238");
        acBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dp(activity, 34), 1f));
        acBtn.setOnClickListener(v -> displayTv.setText("0"));
        displayRow.addView(acBtn);

        root.addView(displayRow);

        String[][] keys = {
                {"1", "2", "3"},
                {"4", "5", "6"},
                {"7", "8", "9"},
                {"-", "0", "BKSP"}
        };

        for (String[] row : keys) {
            LinearLayout kRow = new LinearLayout(activity);
            kRow.setOrientation(LinearLayout.HORIZONTAL);
            kRow.setPadding(0, dp(activity, 1.5f), 0, dp(activity, 1.5f));

            for (final String k : row) {
                View keyView;
                if (k.equals("BKSP")) {
                    ImageView iv = new ImageView(activity);
                    iv.setImageDrawable(createVectorBackspaceIcon(activity));
                    iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                    keyView = iv;
                } else {
                    TextView tv = new TextView(activity);
                    tv.setText(k);
                    tv.setTextColor(Color.WHITE);
                    tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
                    tv.setTypeface(null, Typeface.BOLD);
                    tv.setGravity(Gravity.CENTER);
                    keyView = tv;
                }

                GradientDrawable kBg = new GradientDrawable();
                kBg.setColor(Color.parseColor("#262626"));
                kBg.setCornerRadius(dp(activity, 3));
                keyView.setBackground(kBg);

                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(0, dp(activity, 30), 1f);
                kp.setMargins(dp(activity, 1.5f), 0, dp(activity, 1.5f), 0);
                keyView.setLayoutParams(kp);

                keyView.setOnClickListener(v -> {
                    String cur = displayTv.getText().toString();
                    if (k.equals("BKSP")) {
                        if (cur.length() > 1) {
                            displayTv.setText(cur.substring(0, cur.length() - 1));
                        } else {
                            displayTv.setText("0");
                        }
                    } else if (k.equals("-")) {
                        if (cur.startsWith("-")) {
                            displayTv.setText(cur.substring(1));
                        } else {
                            displayTv.setText("-" + (cur.equals("0") ? "" : cur));
                        }
                    } else {
                        if (cur.equals("0") || cur.equals("-0")) {
                            displayTv.setText(cur.startsWith("-") ? "-" + k : k);
                        } else {
                            if (cur.length() < 7) displayTv.setText(cur + k);
                        }
                    }
                });
                kRow.addView(keyView);
            }
            root.addView(kRow);
        }

        LinearLayout actionRow = new LinearLayout(activity);
        actionRow.setOrientation(LinearLayout.HORIZONTAL);
        actionRow.setPadding(0, dp(activity, 6), 0, 0);

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CANCEL");
        cancelBtn.setTextColor(Color.WHITE);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        cancelBtn.setTypeface(null, Typeface.BOLD);
        cancelBtn.setSingleLine(true);
        setButtonBg(activity, cancelBtn, "#2C2C2C");
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(0, dp(activity, 30), 1f);
        cLp.setMargins(0, 0, dp(activity, 4), 0);
        cancelBtn.setLayoutParams(cLp);
        cancelBtn.setOnClickListener(v -> kd.dismiss());
        actionRow.addView(cancelBtn);

        Button okBtn = new Button(activity);
        okBtn.setText("OK");
        okBtn.setTextColor(Color.WHITE);
        okBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        okBtn.setTypeface(null, Typeface.BOLD);
        okBtn.setSingleLine(true);
        setButtonBg(activity, okBtn, "#FF1238");
        LinearLayout.LayoutParams okLp = new LinearLayout.LayoutParams(0, dp(activity, 30), 1f);
        okLp.setMargins(dp(activity, 4), 0, 0, 0);
        okBtn.setLayoutParams(okLp);

        okBtn.setOnClickListener(v -> {
            try {
                String str = displayTv.getText().toString();
                if (str.equals("-") || str.isEmpty()) str = "0";
                float val = Float.parseFloat(str);
                val = Math.max(min, Math.min(max, val));
                if (listener != null) listener.onValueSubmitted(val);
            } catch (Exception ignored) {}
            kd.dismiss();
        });
        actionRow.addView(okBtn);

        root.addView(actionRow);
        kd.setContentView(root);
    }

    // =========================================================================
    // ৪. ড্র্যাগেবল ভার্চুয়াল কীবোর্ড
    // =========================================================================
    public static void showVirtualKeyboard(final Activity activity, final View anchorView, final TextView targetDisplay, final OnTextInputListener listener) {
        final Dialog ed = new Dialog(activity);
        ed.requestWindowFeature(Window.FEATURE_NO_TITLE);
        ed.setCancelable(false);
        ed.setCanceledOnTouchOutside(false);

        if (ed.getWindow() != null) {
            ed.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            ed.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            ed.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        final int targetWidth = dp(activity, 290);

        final LinearLayout board = new LinearLayout(activity);
        board.setLayoutParams(new LinearLayout.LayoutParams(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
        board.setOrientation(LinearLayout.VERTICAL);
        board.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 8));
        board.setBackground(createDialogBg(activity));

        LinearLayout topHeader = new LinearLayout(activity);
        topHeader.setOrientation(LinearLayout.HORIZONTAL);
        topHeader.setGravity(Gravity.CENTER_VERTICAL);
        topHeader.setPadding(0, 0, 0, dp(activity, 4));

        final TextView modeTitle = new TextView(activity);
        modeTitle.setText("English Keyboard [Drag ⤹]");
        modeTitle.setTextColor(Color.parseColor("#AAAAAA"));
        modeTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        modeTitle.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        topHeader.addView(modeTitle);

        ImageView closeIcon = new ImageView(activity);
        closeIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 14), dp(activity, 14)));
        closeIcon.setImageDrawable(createCloseVectorDrawable(activity));
        closeIcon.setOnClickListener(v -> ed.dismiss());
        topHeader.addView(closeIcon);
        board.addView(topHeader);

        ed.show();
        final WindowManager.LayoutParams wmlp = ed.getWindow().getAttributes();
        wmlp.gravity = Gravity.TOP | Gravity.START;
        wmlp.width = targetWidth;
        wmlp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        if (anchorView != null) {
            int[] loc = new int[2];
            anchorView.getLocationOnScreen(loc);
            wmlp.x = Math.max(dp(activity, 10), loc[0] - dp(activity, 10));
            wmlp.y = Math.max(dp(activity, 10), loc[1] + anchorView.getHeight() + dp(activity, 4));
        } else {
            wmlp.x = dp(activity, 80);
            wmlp.y = dp(activity, 60);
        }
        ed.getWindow().setAttributes(wmlp);

        topHeader.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        ed.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final LinearLayout keysContainer = new LinearLayout(activity);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        board.addView(keysContainer);

        final boolean[] isBangla = {false};

        final String[][] englishWithNumbers = {
                {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
                {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"},
                {"A", "S", "D", "F", "G", "H", "J", "K", "L"},
                {"Z", "X", "C", "V", "B", "N", "M", "BKSP"}
        };

        final String[][] completeBanglaKeys = {
                {"া", "ি", "ী", "ু", "ূ", "ৃ", "ে", "ৈ", "ো", "ৌ", "্"},
                {"অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ"},
                {"ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ"},
                {"ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন"},
                {"প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ"},
                {"স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ", "BKSP"}
        };

        final Runnable renderKeyboard = () -> {
            keysContainer.removeAllViews();
            String[][] activeKeys = isBangla[0] ? completeBanglaKeys : englishWithNumbers;
            modeTitle.setText((isBangla[0] ? "বাংলা কীবোর্ড" : "English Keyboard") + " [Drag ⤹]");

            for (String[] row : activeKeys) {
                LinearLayout r = new LinearLayout(activity);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER);
                r.setPadding(0, dp(activity, 1), 0, dp(activity, 1));

                for (final String key : row) {
                    View keyView;
                    if (key.equals("BKSP")) {
                        ImageView iv = new ImageView(activity);
                        iv.setImageDrawable(createVectorBackspaceIcon(activity));
                        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                        keyView = iv;
                    } else {
                        TextView tv = new TextView(activity);
                        tv.setText(key);
                        tv.setTextColor(Color.WHITE);
                        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, isBangla[0] ? 11f : 10f);
                        tv.setTypeface(null, Typeface.BOLD);
                        tv.setGravity(Gravity.CENTER);
                        keyView = tv;
                    }

                    GradientDrawable kBg = new GradientDrawable();
                    kBg.setColor(key.equals("BKSP") ? Color.parseColor("#38191E") : Color.parseColor("#262626"));
                    kBg.setCornerRadius(dp(activity, 3));
                    keyView.setBackground(kBg);

                    int keyW = key.equals("BKSP") ? dp(activity, 30) : dp(activity, 23);
                    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(keyW, dp(activity, 26));
                    p.setMargins(dp(activity, 1), 0, dp(activity, 1), 0);
                    keyView.setLayoutParams(p);

                    keyView.setOnClickListener(v -> {
                        String cur = targetDisplay.getText().toString();
                        if (key.equals("BKSP")) {
                            if (!cur.isEmpty()) {
                                cur = cur.substring(0, cur.length() - 1);
                            }
                        } else {
                            cur = cur + (isBangla[0] ? key : key.toLowerCase());
                        }
                        targetDisplay.setText(cur);
                        if (listener != null) listener.onTextUpdated(cur);
                    });
                    r.addView(keyView);
                }
                keysContainer.addView(r);
            }
        };
        renderKeyboard.run();

        LinearLayout bottomRow = new LinearLayout(activity);
        bottomRow.setOrientation(LinearLayout.HORIZONTAL);
        bottomRow.setGravity(Gravity.CENTER_VERTICAL);
        bottomRow.setPadding(0, dp(activity, 4), 0, 0);

        ImageView globeBtn = new ImageView(activity);
        globeBtn.setImageDrawable(createVectorGlobeIcon(activity));
        globeBtn.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        setButtonBg(activity, globeBtn, "#333333");
        LinearLayout.LayoutParams gLp = new LinearLayout.LayoutParams(dp(activity, 32), dp(activity, 28));
        gLp.setMargins(0, 0, dp(activity, 4), 0);
        globeBtn.setLayoutParams(gLp);
        globeBtn.setOnClickListener(v -> {
            isBangla[0] = !isBangla[0];
            renderKeyboard.run();
        });
        bottomRow.addView(globeBtn);

        Button clearBtn = new Button(activity);
        clearBtn.setText("Clear");
        clearBtn.setTextColor(Color.WHITE);
        clearBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        clearBtn.setSingleLine(true);
        setButtonBg(activity, clearBtn, "#2C2C2C");
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(activity, 50), dp(activity, 28));
        clp.setMargins(0, 0, dp(activity, 4), 0);
        clearBtn.setLayoutParams(clp);
        clearBtn.setOnClickListener(v -> {
            targetDisplay.setText("");
            if (listener != null) listener.onTextUpdated("");
        });
        bottomRow.addView(clearBtn);

        Button spaceBtn = new Button(activity);
        spaceBtn.setText("Space");
        spaceBtn.setTextColor(Color.WHITE);
        spaceBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f);
        spaceBtn.setSingleLine(true);
        setButtonBg(activity, spaceBtn, "#252525");
        LinearLayout.LayoutParams spLp = new LinearLayout.LayoutParams(0, dp(activity, 28), 1f);
        spLp.setMargins(0, 0, dp(activity, 4), 0);
        spaceBtn.setLayoutParams(spLp);
        spaceBtn.setOnClickListener(v -> {
            String cur = targetDisplay.getText().toString() + " ";
            targetDisplay.setText(cur);
            if (listener != null) listener.onTextUpdated(cur);
        });
        bottomRow.addView(spaceBtn);

        Button doneBtn = new Button(activity);
        doneBtn.setText("DONE");
        doneBtn.setTextColor(Color.WHITE);
        doneBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        doneBtn.setTypeface(null, Typeface.BOLD);
        doneBtn.setSingleLine(true);
        setButtonBg(activity, doneBtn, "#FF1238");
        doneBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 56), dp(activity, 28)));
        doneBtn.setOnClickListener(v -> ed.dismiss());
        bottomRow.addView(doneBtn);

        board.addView(bottomRow);
        ed.setContentView(board);
    }

    // =========================================================================
    // ৫. গ্রেডিয়েন্ট টেমপ্লেট ডায়ালগ
    // =========================================================================
    public static void showGradientTemplates(final Activity activity) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            d.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 320), dp(activity, 360)));
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(activity, 14), dp(activity, 12), dp(activity, 14), dp(activity, 12));
        box.setBackground(createDialogBg(activity));

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(activity, 8));

        TextView title = new TextView(activity);
        title.setText("Gradient Templates");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(title);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 16), dp(activity, 16)));
        closeX.setImageDrawable(createCloseVectorDrawable(activity));
        closeX.setOnClickListener(v -> d.dismiss());
        header.addView(closeX);
        box.addView(header);

        final WindowManager.LayoutParams wmlp = d.getWindow().getAttributes();
        header.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setTag(new float[]{event.getRawX() - wmlp.x, event.getRawY() - wmlp.y});
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float[] pos = (float[]) v.getTag();
                    if (pos != null) {
                        wmlp.x = (int) (event.getRawX() - pos[0]);
                        wmlp.y = (int) (event.getRawY() - pos[1]);
                        d.getWindow().setAttributes(wmlp);
                    }
                    return true;
            }
            return false;
        });

        final TextView searchBox = new TextView(activity);
        searchBox.setHint("Search by name (e.g. Gold, Sunset, Neon)...");
        searchBox.setHintTextColor(Color.parseColor("#777777"));
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        searchBox.setBackground(createInputBg(activity));
        searchBox.setPadding(dp(activity, 8), dp(activity, 6), dp(activity, 8), dp(activity, 6));
        searchBox.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 32)));
        box.addView(searchBox);

        ScrollView sv = new ScrollView(activity);
        LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        svLp.setMargins(0, dp(activity, 6), 0, dp(activity, 6));
        sv.setLayoutParams(svLp);

        final LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        box.addView(sv);

        final List<editor_5.TemplateViewModel> templates = loadGradientTemplatesFromClass();

        final Runnable renderTemplates = () -> {
            list.removeAllViews();
            String query = searchBox.getText().toString().trim().toLowerCase();

            for (int i = 0; i < templates.size(); i++) {
                final editor_5.TemplateViewModel item = templates.get(i);
                if (!query.isEmpty() && !item.name.toLowerCase().contains(query)) continue;

                LinearLayout row = new LinearLayout(activity);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(0, dp(activity, 3), 0, dp(activity, 3));

                TextView nameTv = new TextView(activity);
                nameTv.setText(item.name);
                nameTv.setTextColor(Color.WHITE);
                nameTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
                nameTv.setTypeface(null, Typeface.BOLD);
                nameTv.setSingleLine(true);
                nameTv.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams nLp = new LinearLayout.LayoutParams(dp(activity, 105), ViewGroup.LayoutParams.WRAP_CONTENT);
                nLp.setMargins(0, 0, dp(activity, 6), 0);
                nameTv.setLayoutParams(nLp);
                row.addView(nameTv);

                View gradView = new View(activity);
                LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(0, dp(activity, 26), 1f);
                glp.setMargins(0, 0, dp(activity, 6), 0);
                gradView.setLayoutParams(glp);

                GradientDrawable gdDrawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, item.colors);
                gdDrawable.setCornerRadius(dp(activity, 3));
                gdDrawable.setStroke(dp(activity, 1), Color.parseColor("#444444"));
                gradView.setBackground(gdDrawable);
                row.addView(gradView);

                TextView useBtn = createPillButton(activity, "Apply", "#2A2A2A", v -> {
                    if (activity instanceof EditorActivity) {
                        EditorActivity ea = (EditorActivity) activity;
                        List<Integer> cList = new ArrayList<>();
                        List<Float> pList = new ArrayList<>();
                        for (int k = 0; k < item.colors.length; k++) {
                            cList.add(item.colors[k]);
                            pList.add(k / (float) Math.max(1, item.colors.length - 1));
                        }
                        applyCustomGradientToEditorCanvas(ea, cList, pList);
                    }
                    Toast.makeText(activity, item.name + " Applied Live!", Toast.LENGTH_SHORT).show();
                    d.dismiss();
                });
                useBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(activity, 60), dp(activity, 28)));
                row.addView(useBtn);
                list.addView(row);
            }
        };
        renderTemplates.run();

        searchBox.setOnClickListener(v -> showVirtualKeyboard(activity, searchBox, searchBox, text -> renderTemplates.run()));

        Button cancelBtn = new Button(activity);
        cancelBtn.setText("CLOSE");
        cancelBtn.setTextColor(Color.WHITE);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        setButtonBg(activity, cancelBtn, "#2C2C2C");
        LinearLayout.LayoutParams cLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 30));
        cancelBtn.setLayoutParams(cLp);
        cancelBtn.setOnClickListener(v -> d.dismiss());
        box.addView(cancelBtn);

        d.setContentView(box);
        d.show();

        if (d.getWindow() != null) {
            d.getWindow().setLayout(dp(activity, 320), dp(activity, 360));
        }
    }

    private static List<editor_5.TemplateViewModel> loadGradientTemplatesFromClass() {
        List<editor_5.TemplateViewModel> list = new ArrayList<>();
        try {
            Class<?> gClass = Class.forName("com.example.ejitor.gradient");
            try {
                Method m = gClass.getMethod("getNamedTemplates");
                Object res = m.invoke(null);
                if (res instanceof List) {
                    List<?> l = (List<?>) res;
                    for (Object o : l) {
                        Field nameF = o.getClass().getField("name");
                        Field colF = o.getClass().getField("colors");
                        String n = (String) nameF.get(o);
                        int[] c = (int[]) colF.get(o);
                        list.add(new editor_5.TemplateViewModel(n, c));
                    }
                }
            } catch (Exception ignored) {
                Method mOld = gClass.getMethod("getTemplates");
                Object resOld = mOld.invoke(null);
                if (resOld instanceof List) {
                    List<int[]> l = (List<int[]>) resOld;
                    for (int i = 0; i < l.size(); i++) {
                        list.add(new editor_5.TemplateViewModel("Template " + (i + 1), l.get(i)));
                    }
                }
            }
        } catch (Exception ignored) {}
        return list;
    }

    // =========================================================================
    // সহায়ক মেথডসমূহ
    // =========================================================================
    private static Object getField(Object target, String name) {
        try {
            Field f = target.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(target);
        } catch (Exception e) {
            try {
                Field f = target.getClass().getField(name);
                return f.get(target);
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static void setField(Object target, String name, Object val) {
        try {
            Field f = target.getClass().getDeclaredField(name);
            f.setAccessible(true);
            f.set(target, val);
        } catch (Exception ignored) {}
    }

    private static void invokeMethod(Object target, String name) {
        try {
            Method m = target.getClass().getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(target);
        } catch (Exception ignored) {}
    }

    private static Drawable createDialogBg(Context ctx) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(ctx, 1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(ctx, 10));
        return bg;
    }

    private static Drawable createInputBg(Context ctx) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor("#121212"));
        d.setStroke(dp(ctx, 1), Color.parseColor("#2A2A2A"));
        d.setCornerRadius(dp(ctx, 4));
        return d;
    }

    private static void updateColorPreview(Context ctx, View v, int color) {
        if (v == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setStroke(dp(ctx, 1), Color.WHITE);
        gd.setCornerRadius(dp(ctx, 3));
        v.setBackground(gd);
    }

    private static void setButtonBg(Context ctx, View v, String hex) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.parseColor(hex));
        gd.setCornerRadius(dp(ctx, 4));
        v.setBackground(gd);
    }

    private static TextView createPillButton(Context ctx, String text, String bgHex, View.OnClickListener l) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(ctx, 6), dp(ctx, 2), dp(ctx, 6), dp(ctx, 2));
        setButtonBg(ctx, tv, bgHex);
        if (l != null) tv.setOnClickListener(l);
        return tv;
    }

    private static Drawable createCloseVectorDrawable(Context ctx) {
        Bitmap bmp = Bitmap.createBitmap(dp(ctx, 16), dp(ctx, 16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(ctx, 1.5f));
        c.drawLine(dp(ctx, 3), dp(ctx, 3), dp(ctx, 13), dp(ctx, 13), p);
        c.drawLine(dp(ctx, 13), dp(ctx, 3), dp(ctx, 3), dp(ctx, 13), p);
        return new BitmapDrawable(ctx.getResources(), bmp);
    }

    private static Drawable createVectorMenuIcon(Context ctx) {
        Bitmap bmp = Bitmap.createBitmap(dp(ctx, 18), dp(ctx, 18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(ctx, 2f));
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(dp(ctx, 2), dp(ctx, 4), dp(ctx, 16), dp(ctx, 4), p);
        c.drawLine(dp(ctx, 2), dp(ctx, 9), dp(ctx, 16), dp(ctx, 9), p);
        c.drawLine(dp(ctx, 2), dp(ctx, 14), dp(ctx, 16), dp(ctx, 14), p);
        return new BitmapDrawable(ctx.getResources(), bmp);
    }

    private static Drawable createVectorResizeIcon(Context ctx) {
        Bitmap bmp = Bitmap.createBitmap(dp(ctx, 16), dp(ctx, 16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#AAAAAA"));
        p.setStrokeWidth(dp(ctx, 1.5f));
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(dp(ctx, 12), dp(ctx, 4), dp(ctx, 4), dp(ctx, 12), p);
        c.drawLine(dp(ctx, 13), dp(ctx, 8), dp(ctx, 8), dp(ctx, 13), p);
        c.drawLine(dp(ctx, 13), dp(ctx, 12), dp(ctx, 12), dp(ctx, 13), p);
        return new BitmapDrawable(ctx.getResources(), bmp);
    }

    private static Drawable createVectorGlobeIcon(Context ctx) {
        Bitmap bmp = Bitmap.createBitmap(dp(ctx, 18), dp(ctx, 18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(ctx, 1.3f));

        c.drawCircle(dp(ctx, 9), dp(ctx, 9), dp(ctx, 7.5f), p);
        c.drawLine(dp(ctx, 1.5f), dp(ctx, 9), dp(ctx, 16.5f), dp(ctx, 9), p);
        c.drawLine(dp(ctx, 9), dp(ctx, 1.5f), dp(ctx, 9), dp(ctx, 16.5f), p);
        RectF oval = new RectF(dp(ctx, 5f), dp(ctx, 1.5f), dp(ctx, 13f), dp(ctx, 16.5f));
        c.drawOval(oval, p);

        return new BitmapDrawable(ctx.getResources(), bmp);
    }

    private static Drawable createVectorBackspaceIcon(Context ctx) {
        Bitmap bmp = Bitmap.createBitmap(dp(ctx, 20), dp(ctx, 16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(ctx, 1.3f));
        p.setStrokeJoin(Paint.Join.ROUND);

        Path path = new Path();
        path.moveTo(dp(ctx, 6), dp(ctx, 2));
        path.lineTo(dp(ctx, 17), dp(ctx, 2));
        path.lineTo(dp(ctx, 17), dp(ctx, 14));
        path.lineTo(dp(ctx, 6), dp(ctx, 14));
        path.lineTo(dp(ctx, 1.5f), dp(ctx, 8));
        path.close();
        c.drawPath(path, p);

        c.drawLine(dp(ctx, 9), dp(ctx, 5), dp(ctx, 14), dp(ctx, 11), p);
        c.drawLine(dp(ctx, 14), dp(ctx, 5), dp(ctx, 9), dp(ctx, 11), p);

        return new BitmapDrawable(ctx.getResources(), bmp);
    }

    // =========================================================================
    // ২য় ইমেজের মতো স্লাইডার ডিজাইন (আসল ক্যাপসুল স্টাইল অবিকল ফিরিয়ে আনা হয়েছে)
    // =========================================================================
    private static void applyCustomSeekBarStyle(Context ctx, SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(ctx, 6), dp(ctx, 8), dp(ctx, 6), dp(ctx, 10));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(ctx, 2));
        bgTrack.setSize(-1, dp(ctx, 3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(ctx, 2));
        progressTrack.setSize(-1, dp(ctx, 3));
        android.graphics.drawable.ClipDrawable clipProgress = new android.graphics.drawable.ClipDrawable(progressTrack, Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        android.graphics.drawable.LayerDrawable layerDrawable = new android.graphics.drawable.LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(ctx, 16), dp(ctx, 16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(ctx, 0));
    }
}
