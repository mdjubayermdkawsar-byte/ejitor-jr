package com.example.ejitor;

import android.app.Dialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

class editor_1 implements EditorActivity.EditorModule {

    public editor_1() {}

    private EditorActivity activity;

    // টেমপ্লেট ক্যাটাগরি ও স্টেট
    private String currentModalCat = "Recent";
    private int selectedBgColor = Color.WHITE;
    private View liveSwatchPreview;
    
    // ইউনিট কনভার্সনের জন্য স্টেট
    private String currentUnit = "Pixels";

    // ১২০টি ফটোশপ স্ট্যান্ডার্ড প্রিসেট টেমপ্লেট
    private final String[][] templates = {
            // Social Media & Recent (1-20)
            {"YouTube Thumbnail", "1280", "720", "Recent"},
            {"Instagram Square Post", "1080", "1080", "Recent"},
            {"Instagram Story / Reel", "1080", "1920", "Recent"},
            {"Facebook Post", "1200", "630", "Recent"},
            {"Twitter / X Post", "1200", "675", "Recent"},
            {"Pinterest Pin", "1000", "1500", "Recent"},
            {"LinkedIn Banner", "1584", "396", "Recent"},
            {"YouTube Channel Banner", "2560", "1440", "Recent"},
            {"Twitch Stream Overlay", "1920", "1080", "Recent"},
            {"Facebook Cover Photo", "851", "315", "Recent"},
            {"Twitter Header Graphic", "1500", "500", "Recent"},
            {"TikTok Video Canvas", "1080", "1920", "Recent"},
            {"Instagram Portrait Post", "1080", "1350", "Recent"},
            {"Discord Server Banner", "960", "540", "Recent"},
            {"Snapchat Geofilter", "1080", "2340", "Recent"},
            {"Etsy Shop Banner", "1200", "300", "Recent"},
            {"SoundCloud Header", "2480", "520", "Recent"},
            {"Twitch Profile Banner", "1200", "480", "Recent"},
            {"Spotify Playlist Cover", "1000", "1000", "Recent"},
            {"Weibo Standard Post", "1200", "675", "Recent"},

            // Film & Video (21-40)
            {"Full HD 1080p", "1920", "1080", "Film & Video"},
            {"4K Ultra HD Display", "3840", "2160", "Film & Video"},
            {"720p HD Video Screen", "1280", "720", "Film & Video"},
            {"DCI 4K Cinema Scope", "4096", "2160", "Film & Video"},
            {"8K Super Ultra HD", "7680", "4320", "Film & Video"},
            {"Cinemascope 21:9", "2560", "1080", "Film & Video"},
            {"Anamorphic 2.39:1", "3840", "1606", "Film & Video"},
            {"IMAX Digital Aspect", "1920", "1440", "Film & Video"},
            {"Vertical Shorts 2K", "1440", "2560", "Film & Video"},
            {"Broadcast NTSC D1", "720", "486", "Film & Video"},
            {"Broadcast PAL D1", "720", "576", "Film & Video"},
            {"HDV 1080 Anamorphic", "1440", "1080", "Film & Video"},
            {"UHDTV 4K Video", "3840", "2160", "Film & Video"},
            {"YouTube Shorts 4K", "2160", "3840", "Film & Video"},
            {"GoPro Hero 4:3", "4000", "3000", "Film & Video"},
            {"Drone 4K Aerial", "4000", "2250", "Film & Video"},
            {"Retro CRT Monitor 4:3", "1024", "768", "Film & Video"},
            {"VGA Standard Display", "640", "480", "Film & Video"},
            {"SVGA Retro Frame", "800", "600", "Film & Video"},
            {"Ultrawide QHD", "3440", "1440", "Film & Video"},

            // Print & Paper (41-60)
            {"A4 Paper (300 DPI)", "2480", "3508", "Print"},
            {"A3 Poster (300 DPI)", "3508", "4960", "Print"},
            {"A5 Booklet (300 DPI)", "1748", "2480", "Print"},
            {"US Letter Standard", "2550", "3300", "Print"},
            {"US Legal Document", "2550", "4200", "Print"},
            {"Tabloid Newspaper", "3300", "5100", "Print"},
            {"Business Card (Standard)", "1050", "600", "Print"},
            {"Square Business Card", "750", "750", "Print"},
            {"Poster Architectural D", "2400", "3600", "Print"},
            {"Poster Architectural C", "1800", "2400", "Print"},
            {"Flyer US Half Letter", "1650", "2550", "Print"},
            {"Postcard International", "1800", "1200", "Print"},
            {"Trifold Brochure Page", "2550", "3300", "Print"},
            {"Magazine Cover Full", "2550", "3300", "Print"},
            {"Book Cover Standard", "1800", "2700", "Print"},
            {"B5 Journal Sheet", "2079", "2953", "Print"},
            {"A6 Postcard Print", "1240", "1748", "Print"},
            {"Letterhead Corporate", "2550", "3300", "Print"},
            {"Gift Certificate", "2400", "1200", "Print"},
            {"Event Ticket Stub", "1650", "600", "Print"},

            // Mobile & Devices (61-80)
            {"iPhone 15 Pro", "1179", "2556", "Mobile"},
            {"iPhone 15 Pro Max", "1290", "2796", "Mobile"},
            {"iPhone 14 / 13", "1170", "2532", "Mobile"},
            {"iPhone SE 3rd Gen", "750", "1334", "Mobile"},
            {"Android Flagship 2K", "1440", "3200", "Mobile"},
            {"Android FHD+ Screen", "1080", "2400", "Mobile"},
            {"iPad Pro 12.9 Retina", "2048", "2732", "Mobile"},
            {"iPad Air 10.9", "1640", "2360", "Mobile"},
            {"iPad Mini 8.3", "1488", "2266", "Mobile"},
            {"Samsung Galaxy S24 Ultra", "1440", "3120", "Mobile"},
            {"Google Pixel 8 Pro", "1344", "2992", "Mobile"},
            {"Apple Watch Ultra", "410", "502", "Mobile"},
            {"Apple Watch 45mm", "396", "484", "Mobile"},
            {"Android Wear Square", "450", "450", "Mobile"},
            {"Tablet 10 Inch Display", "1920", "1200", "Mobile"},
            {"Foldable Inner Screen", "1812", "2176", "Mobile"},
            {"Foldable Outer Cover", "904", "2316", "Mobile"},
            {"Surface Pro 13 Inch", "2880", "1920", "Mobile"},
            {"Kindle Paperwhite Display", "1236", "1648", "Mobile"},
            {"Steam Deck Portable", "1280", "800", "Mobile"},

            // Web & UI/UX (81-100)
            {"Web Large Desktop", "1920", "1080", "Web"},
            {"Web Medium Desktop", "1440", "900", "Web"},
            {"Web Small Laptop", "1366", "768", "Web"},
            {"MacBook Pro 16 Inch", "3456", "2234", "Web"},
            {"MacBook Air 13 Inch", "2560", "1664", "Web"},
            {"iMac 24 Inch 4.5K", "4480", "2520", "Web"},
            {"Web Header Standard", "1200", "400", "Web"},
            {"Blog Post Header", "1200", "800", "Web"},
            {"Dribbble Portfolio Shot", "1600", "1200", "Web"},
            {"Dribbble HD Video", "1920", "1440", "Web"},
            {"Behance Project Cover", "1600", "1200", "Web"},
            {"Behance Full Width Strip", "1400", "3000", "Web"},
            {"Leaderboard Banner Ad", "728", "90", "Web"},
            {"Medium Rectangle Ad", "300", "250", "Web"},
            {"Skyscraper Banner Ad", "160", "600", "Web"},
            {"Billboard Web Ad", "970", "250", "Web"},
            {"Email Newsletter Header", "600", "300", "Web"},
            {"Hero Image Web Strip", "1920", "700", "Web"},
            {"Landing Page Section", "1920", "1200", "Web"},
            {"Favicon / App Icon HD", "1024", "1024", "Web"},

            // Photo Studio & Art (101-120)
            {"Photo 4x6 Small Print", "1800", "1200", "Photo"},
            {"Photo 5x7 Classic Print", "2100", "1500", "Photo"},
            {"Photo 8x10 Gallery Print", "2400", "3000", "Photo"},
            {"Photo 11x14 Master Print", "3300", "4200", "Photo"},
            {"Photo 16x20 Exhibition", "4800", "6000", "Photo"},
            {"Square Photo Print 8x8", "2400", "2400", "Photo"},
            {"Square Photo Print 12x12", "3600", "3600", "Photo"},
            {"Wallet Prints (Pair)", "1500", "1050", "Photo"},
            {"Panoramic Photo Landscape", "5400", "1800", "Photo"},
            {"Canvas Wrap 20x30", "6000", "9000", "Photo"},
            {"Square Album Cover", "3000", "3000", "Saved"},
            {"Icon Master 512x512", "512", "512", "Saved"},
            {"Master Canvas 4K Square", "4096", "4096", "Saved"},
            {"Pixel Art Workspace", "256", "256", "Saved"},
            {"Vector Icon 128x128", "128", "128", "Saved"},
            {"High Quality Logo Canvas", "2000", "2000", "Saved"},
            {"NFT Collectible Frame", "3000", "3000", "Saved"},
            {"Merchandise T-Shirt Art", "4500", "5400", "Saved"},
            {"Coffee Mug Wrap Canvas", "2625", "1050", "Saved"},
            {"Ultra Hi-Res Master 8K", "8192", "8192", "Saved"}
    };

    @Override
    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        hookFileMenuWithNewProject();
        hookAppIcon();
    }

    @Override
    public void onCommand(String command, Object... args) {
        if ("open_new_project_dialog".equalsIgnoreCase(command)) {
            openNewDocumentDialog();
        }
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    // =========================================================================
    // ইঞ্চি/পিক্সেল/সেমি কনভার্সনের রিয়েল ম্যাথমেটিক্স মেথডসমূহ
    // =========================================================================
    private float toPixels(float value, String unit, int dpi) {
        if ("Inches".equalsIgnoreCase(unit)) return value * dpi;
        else if ("Centimeters".equalsIgnoreCase(unit)) return (value / 2.54f) * dpi;
        else if ("Millimeters".equalsIgnoreCase(unit)) return (value / 25.4f) * dpi;
        return value; // Pixels
    }

    private float fromPixels(float pixels, String unit, int dpi) {
        if ("Inches".equalsIgnoreCase(unit)) return pixels / (float) dpi;
        else if ("Centimeters".equalsIgnoreCase(unit)) return (pixels * 2.54f) / (float) dpi;
        else if ("Millimeters".equalsIgnoreCase(unit)) return (pixels * 25.4f) / (float) dpi;
        return pixels; // Pixels
    }

    private String formatUnitValue(float val, String unit) {
        if ("Pixels".equalsIgnoreCase(unit)) return String.valueOf(Math.round(val));
        else if ("Millimeters".equalsIgnoreCase(unit)) return String.format(Locale.US, "%.1f", val);
        else return String.format(Locale.US, "%.2f", val);
    }

    private Bitmap loadEjitorIconSafely() {
        String[] paths = {"ejitor.png", "assets/ejitor.png", "ejitor.PNG", "images/ejitor.png"};
        for (String p : paths) {
            try (InputStream is = activity.getAssets().open(p)) {
                Bitmap b = BitmapFactory.decodeStream(is);
                if (b != null) return b;
            } catch (Exception ignored) {}
        }
        return null;
    }

    private void hookAppIcon() {
        if (activity == null || activity.menuContainer == null) return;
        activity.runOnUiThread(() -> {
            activity.menuContainer.post(() -> {
                try {
                    ViewGroup topBar = (ViewGroup) activity.menuContainer.getParent().getParent();
                    if (topBar == null) return;

                    if (topBar.getChildCount() > 0) {
                        View firstChild = topBar.getChildAt(0);
                        if (firstChild instanceof TextView || firstChild instanceof ImageView) {
                            topBar.removeViewAt(0);
                        }
                    }

                    Bitmap appIconBmp = loadEjitorIconSafely();
                    ImageView appIconIv = new ImageView(activity);
                    appIconIv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(22), dp(22));
                    iconParams.setMargins(dp(2), 0, dp(4), 0);
                    appIconIv.setLayoutParams(iconParams);

                    GradientDrawable iconBg = new GradientDrawable();
                    iconBg.setCornerRadius(dp(4));
                    appIconIv.setBackground(iconBg);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        appIconIv.setClipToOutline(true);
                    }

                    if (appIconBmp != null) {
                        appIconIv.setImageBitmap(appIconBmp);
                    } else {
                        Bitmap fallbackBmp = Bitmap.createBitmap(dp(22), dp(22), Bitmap.Config.ARGB_8888);
                        Canvas c = new Canvas(fallbackBmp);
                        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                        p.setColor(Color.parseColor("#FF1238"));
                        c.drawRoundRect(0, 0, dp(22), dp(22), dp(4), dp(4), p);
                        appIconIv.setImageBitmap(fallbackBmp);
                    }

                    topBar.addView(appIconIv, 0);
                } catch (Exception ignored) {}
            });
        });
    }

    private void hookFileMenuWithNewProject() {
        if (activity == null || activity.menuContainer == null) return;
        activity.runOnUiThread(() -> {
            activity.menuContainer.post(() -> {
                for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
                    View child = activity.menuContainer.getChildAt(i);
                    if (child instanceof TextView) {
                        TextView tv = (TextView) child;
                        if ("File".equalsIgnoreCase(tv.getText().toString().trim())) {
                            tv.setOnClickListener(this::showEnhancedFileMenu);
                            break;
                        }
                    }
                }
            });
        });
    }

    // একটিমাত্র সম্পূর্ণ ফাইল মেনু: সবগুলো অপশন একসাথে থাকবে এবং ২ নম্বরে "Project Add"
    private void showEnhancedFileMenu(View anchor) {
        final PopupWindow popup = new PopupWindow(activity);

        LinearLayout rootMenuLayout = new LinearLayout(activity);
        rootMenuLayout.setOrientation(LinearLayout.VERTICAL);
        rootMenuLayout.setPadding(dp(6), dp(6), dp(6), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        rootMenuLayout.setBackground(bg);

        ScrollView sv = new ScrollView(activity);
        sv.setVerticalScrollBarEnabled(true);
        sv.setScrollbarFadingEnabled(false);

        LinearLayout inner = new LinearLayout(activity);
        inner.setOrientation(LinearLayout.VERTICAL);

        // সবগুলো অপশন একসাথে ফুল সিঙ্গেল লিস্ট
        String[] fileItems = {
                "+ New Project",
                "Project Add", // <--- ঠিক ২ নম্বরে
                "Open File",
                "Open Image",
                "Save PNG",
                "Save JPG",
                "Save PDF",
                "Save PSD",
                "Save Project jr",
                "Save Artboards Separately",
                "Save PDF Pages Separately",
                "Back (Exit to Home)"
        };

        for (int i = 0; i < fileItems.length; i++) {
            final int index = i;
            TextView itemTv = new TextView(activity);
            itemTv.setText(fileItems[i]);
            itemTv.setTextColor(Color.WHITE);
            itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);

            if (index == 0 || index == 1) {
                itemTv.setTypeface(null, Typeface.BOLD);
            }

            itemTv.setPadding(dp(12), dp(8), dp(12), dp(8));

            itemTv.setOnClickListener(v -> {
                popup.dismiss();
                handleFileAction(index);
            });
            inner.addView(itemTv);

            if (index == 1) {
                View sep = new View(activity);
                sep.setBackgroundColor(Color.parseColor("#2C2C2C"));
                LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                sp.setMargins(dp(6), dp(2), dp(6), dp(2));
                sep.setLayoutParams(sp);
                inner.addView(sep);
            }
        }

        sv.addView(inner);
        rootMenuLayout.addView(sv);

        popup.setContentView(rootMenuLayout);

        int screenH = activity.getResources().getDisplayMetrics().heightPixels;
        int maxAllowedHeight = (int) (screenH * 0.70f);

        inner.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                      View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int measuredW = inner.getMeasuredWidth() + dp(24);
        int measuredH = inner.getMeasuredHeight() + dp(14);

        popup.setWidth(Math.max(measuredW, dp(190)));
        popup.setHeight(Math.min(measuredH, maxAllowedHeight));

        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    // সরাসরি সব ফাইল অ্যাকশন এবং Project Add বাইপাস হ্যান্ডলার
    private void handleFileAction(int index) {
        if (activity == null) return;
        switch (index) {
            case 0:
                openNewDocumentDialog(); // + New Project
                break;
            case 1:
                openHomeToPickProjectBypass(); // Project Add
                break;
            case 2:
                invokePrivateVoidMethod("openProjectFileChooser");
                break;
            case 3:
                invokePrivateVoidMethod("showInAppMultiImagePicker");
                break;
            case 4:
                invokePrivateFormatMethod("exportMedia", "png");
                break;
            case 5:
                invokePrivateFormatMethod("exportMedia", "jpg");
                break;
            case 6:
                invokePrivateVoidMethod("exportPdf");
                break;
            case 7:
                invokePrivateVoidMethod("exportPsd");
                break;
            case 8:
                invokePrivateVoidMethod("exportJrProject");
                break;
            case 9:
                exportArtboardsSeparately("PNG");
                break;
            case 10:
                exportPdfSeparately();
                break;
            case 11:
                activity.exitWithoutLoading();
                break;
        }
    }

    // ডিরেক্ট মেমোরি ব্রিজ: HomeStudioManager এর ফ্লোটিং পিকার কল করা
    private void openHomeToPickProjectBypass() {
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            try {
                HomeStudioManager.showProjectPickerDialog(activity);
            } catch (Exception e) {
                Toast.makeText(activity, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void invokePrivateVoidMethod(String methodName) {
        if (activity == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(methodName);
            m.setAccessible(true);
            m.invoke(activity);
        } catch (Exception ignored) {}
    }

    private void invokePrivateFormatMethod(String methodName, String format) {
        if (activity == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(methodName, String.class);
            m.setAccessible(true);
            m.invoke(activity, format);
        } catch (Exception ignored) {}
    }

    public void openNewDocumentDialog() {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        final FrameLayout rootFrame = new FrameLayout(activity);
        rootFrame.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        int sW = activity.getResources().getDisplayMetrics().widthPixels;
        int sH = activity.getResources().getDisplayMetrics().heightPixels;
        final int initW = Math.min(sW - dp(24), dp(580));
        final int initH = Math.min(sH - dp(24), dp(440));

        final FrameLayout windowContainer = new FrameLayout(activity);
        FrameLayout.LayoutParams winParams = new FrameLayout.LayoutParams(initW, initH);
        winParams.gravity = Gravity.TOP | Gravity.START;
        winParams.leftMargin = Math.max(0, (sW - initW) / 2);
        winParams.topMargin = Math.max(0, (sH - initH) / 2);
        windowContainer.setLayoutParams(winParams);

        final LinearLayout mainLayout = new LinearLayout(activity);
        mainLayout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mainLayout.setOrientation(LinearLayout.VERTICAL);

        GradientDrawable winBg = new GradientDrawable();
        winBg.setColor(Color.parseColor("#1F1F1F"));
        winBg.setStroke(dp(1), Color.parseColor("#383838"));
        winBg.setCornerRadius(dp(8));
        mainLayout.setBackground(winBg);

        LinearLayout macHeader = new LinearLayout(activity);
        macHeader.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        macHeader.setBackgroundColor(Color.parseColor("#181818"));
        macHeader.setOrientation(LinearLayout.HORIZONTAL);
        macHeader.setGravity(Gravity.CENTER_VERTICAL);
        macHeader.setPadding(dp(14), 0, dp(14), 0);

        macHeader.addView(createMacDot("#FF5F56"));
        macHeader.addView(createMacDot("#FFBD2E"));
        macHeader.addView(createMacDot("#27C93F"));

        TextView winTitle = new TextView(activity);
        winTitle.setText("New Document");
        winTitle.setTextColor(Color.parseColor("#E0E0E0"));
        winTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        winTitle.setTypeface(null, Typeface.BOLD);
        winTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wtParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wtParams.setMargins(dp(-45), 0, 0, 0);
        winTitle.setLayoutParams(wtParams);
        macHeader.addView(winTitle);
        mainLayout.addView(macHeader);

        HorizontalScrollView catScroll = new HorizontalScrollView(activity);
        catScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)));
        catScroll.setBackgroundColor(Color.parseColor("#181818"));
        catScroll.setHorizontalScrollBarEnabled(false);

        final LinearLayout catTabs = new LinearLayout(activity);
        catTabs.setOrientation(LinearLayout.HORIZONTAL);
        catTabs.setPadding(dp(12), 0, dp(12), 0);

        final LinearLayout tplGrid = new LinearLayout(activity);
        tplGrid.setOrientation(LinearLayout.VERTICAL);
        tplGrid.setPadding(0, dp(10), 0, 0);

        currentUnit = "Pixels"; // ডিফল্ট পিক্সেল
        
        final EditText nameInput = createDarkInput("Untitled-" + (System.currentTimeMillis() % 1000));
        final EditText widthInput = createDarkInput("1080");
        final EditText heightInput = createDarkInput("1080");
        final EditText artboardsInput = createDarkInput("1");
        final EditText resInput = createDarkInput("72");

        String[] cats = {"Recent", "Saved", "Photo", "Print", "Mobile", "Film & Video", "Web"};
        for (String cName : cats) {
            final String catStr = cName;
            TextView t = new TextView(activity);
            t.setText(catStr);
            t.setTextColor(catStr.equals(currentModalCat) ? Color.WHITE : Color.parseColor("#888888"));
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
            t.setPadding(dp(14), dp(8), dp(14), dp(8));
            t.setTypeface(null, catStr.equals(currentModalCat) ? Typeface.BOLD : Typeface.NORMAL);

            t.setOnClickListener(v -> {
                currentModalCat = catStr;
                for (int j = 0; j < catTabs.getChildCount(); j++) {
                    TextView child = (TextView) catTabs.getChildAt(j);
                    boolean isSel = child.getText().toString().equals(currentModalCat);
                    child.setTextColor(isSel ? Color.WHITE : Color.parseColor("#888888"));
                    child.setTypeface(null, isSel ? Typeface.BOLD : Typeface.NORMAL);
                }
                populateTemplateGrid(tplGrid, currentModalCat, nameInput, widthInput, heightInput, resInput);
            });
            catTabs.addView(t);
        }
        catScroll.addView(catTabs);
        mainLayout.addView(catScroll);

        LinearLayout bodyLayout = new LinearLayout(activity);
        bodyLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        bodyLayout.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout leftPane = new LinearLayout(activity);
        leftPane.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.4f));
        leftPane.setOrientation(LinearLayout.VERTICAL);
        leftPane.setPadding(dp(16), dp(14), dp(16), dp(14));

        TextView recTitle = new TextView(activity);
        recTitle.setText("PRESET TEMPLATES");
        recTitle.setTextColor(Color.parseColor("#777777"));
        recTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        recTitle.setTypeface(null, Typeface.BOLD);
        leftPane.addView(recTitle);

        ScrollView tplScroll = new ScrollView(activity);
        tplScroll.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        tplScroll.setFillViewport(true);

        populateTemplateGrid(tplGrid, currentModalCat, nameInput, widthInput, heightInput, resInput);
        tplScroll.addView(tplGrid);
        leftPane.addView(tplScroll);
        bodyLayout.addView(leftPane);

        ScrollView rightScroll = new ScrollView(activity);
        LinearLayout.LayoutParams rpParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.2f);
        rightScroll.setLayoutParams(rpParams);
        rightScroll.setBackgroundColor(Color.parseColor("#181818"));
        rightScroll.setFillViewport(true);
        rightScroll.setVerticalScrollBarEnabled(true);

        LinearLayout rightPane = new LinearLayout(activity);
        rightPane.setOrientation(LinearLayout.VERTICAL);
        rightPane.setPadding(dp(18), dp(16), dp(18), dp(45));

        TextView psTitle = new TextView(activity);
        psTitle.setText("PRESET DETAILS");
        psTitle.setTextColor(Color.parseColor("#999999"));
        psTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        psTitle.setTypeface(null, Typeface.BOLD);
        rightPane.addView(psTitle);

        rightPane.addView(createFieldLabel("Name"));
        rightPane.addView(nameInput);

        LinearLayout dimRow = new LinearLayout(activity);
        dimRow.setOrientation(LinearLayout.HORIZONTAL);
        dimRow.addView(createFieldWithLabel("Width", widthInput, 1.1f));

        // ইউনিট কনভার্সন সিস্টেম সংযুক্ত করা হলো
        View unitBox = createPhotoshopDropdown("Pixels", new String[]{"Pixels", "Inches", "Centimeters", "Millimeters"}, newUnit -> {
            try {
                int dpi = 72;
                try { dpi = Integer.parseInt(resInput.getText().toString().trim()); } catch (Exception ignored) {}
                if (dpi <= 0) dpi = 72;

                float curW = Float.parseFloat(widthInput.getText().toString().trim());
                float curH = Float.parseFloat(heightInput.getText().toString().trim());

                float pixelW = toPixels(curW, currentUnit, dpi);
                float pixelH = toPixels(curH, currentUnit, dpi);

                float newW = fromPixels(pixelW, newUnit, dpi);
                float newH = fromPixels(pixelH, newUnit, dpi);

                widthInput.setText(formatUnitValue(newW, newUnit));
                heightInput.setText(formatUnitValue(newH, newUnit));
                currentUnit = newUnit;
            } catch (Exception ignored) {}
        });
        dimRow.addView(createFieldWithLabel("Unit", unitBox, 1.1f));
        rightPane.addView(dimRow);

        LinearLayout dimRow2 = new LinearLayout(activity);
        dimRow2.setOrientation(LinearLayout.HORIZONTAL);
        dimRow2.addView(createFieldWithLabel("Height", heightInput, 1.1f));

        LinearLayout orientBox = new LinearLayout(activity);
        orientBox.setOrientation(LinearLayout.HORIZONTAL);
        orientBox.setGravity(Gravity.CENTER_VERTICAL);

        final ImageView btnPort = new ImageView(activity);
        btnPort.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(32)));
        final GradientDrawable redBg = new GradientDrawable();
        redBg.setColor(Color.parseColor("#FF1238"));
        redBg.setCornerRadius(dp(3));
        btnPort.setBackground(redBg);
        btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#FFFFFF"));
        btnPort.setScaleType(ImageView.ScaleType.CENTER);

        final ImageView btnLand = new ImageView(activity);
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(dp(44), dp(32));
        btnLp.setMargins(dp(4), 0, 0, 0);
        btnLand.setLayoutParams(btnLp);
        final GradientDrawable darkBg = new GradientDrawable();
        darkBg.setColor(Color.parseColor("#202020"));
        darkBg.setCornerRadius(dp(3));
        btnLand.setBackground(darkBg);
        btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));
        btnLand.setScaleType(ImageView.ScaleType.CENTER);

        // পোর্ট্রেট ক্লিক: ফ্লোট হিসেবে সোয়াপ
        btnPort.setOnClickListener(v -> {
            redBg.setColor(Color.parseColor("#FF1238"));
            btnPort.setBackground(redBg);
            btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#FFFFFF"));
            darkBg.setColor(Color.parseColor("#202020"));
            btnLand.setBackground(darkBg);
            btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));

            try {
                float w = Float.parseFloat(widthInput.getText().toString().trim());
                float h = Float.parseFloat(heightInput.getText().toString().trim());
                if (w > h) { 
                    widthInput.setText(formatUnitValue(h, currentUnit)); 
                    heightInput.setText(formatUnitValue(w, currentUnit)); 
                }
            } catch (Exception ignored) {}
        });

        // ল্যান্ডস্কেপ ক্লিক: ফ্লোট হিসেবে সোয়াপ
        btnLand.setOnClickListener(v -> {
            redBg.setColor(Color.parseColor("#202020"));
            btnPort.setBackground(redBg);
            btnPort.setImageDrawable(createPersonVectorIcon(dp(16), dp(16), "#888888"));
            darkBg.setColor(Color.parseColor("#FF1238"));
            btnLand.setBackground(darkBg);
            btnLand.setImageDrawable(createLandscapeImageVectorIcon(dp(18), dp(14), "#888888"));

            try {
                float w = Float.parseFloat(widthInput.getText().toString().trim());
                float h = Float.parseFloat(heightInput.getText().toString().trim());
                if (h > w) { 
                    widthInput.setText(formatUnitValue(h, currentUnit)); 
                    heightInput.setText(formatUnitValue(w, currentUnit)); 
                }
            } catch (Exception ignored) {}
        });

        orientBox.addView(btnPort);
        orientBox.addView(btnLand);
        dimRow2.addView(createFieldWithLabel("Orientation", orientBox, 1.1f));
        rightPane.addView(dimRow2);

        LinearLayout dimRow3 = new LinearLayout(activity);
        dimRow3.setOrientation(LinearLayout.HORIZONTAL);
        dimRow3.addView(createFieldWithLabel("Artboards Count", artboardsInput, 1f));
        dimRow3.addView(createFieldWithLabel("Resolution (DPI)", resInput, 1f));
        rightPane.addView(dimRow3);

        LinearLayout colorRow = new LinearLayout(activity);
        colorRow.setOrientation(LinearLayout.HORIZONTAL);

        View colorModeBox = createPhotoshopDropdown("RGB Color", new String[]{"RGB Color", "CMYK Color", "Grayscale", "Bitmap", "Lab Color"}, null);
        colorRow.addView(createFieldWithLabel("Color Mode", colorModeBox, 1.25f));

        View depthBox = createPhotoshopDropdown("8 bit", new String[]{"8 bit", "16 bit", "32 bit"}, null);
        colorRow.addView(createFieldWithLabel("Depth", depthBox, 0.95f));
        rightPane.addView(colorRow);

        rightPane.addView(createFieldLabel("Background Contents"));
        LinearLayout bgRow = new LinearLayout(activity);
        bgRow.setOrientation(LinearLayout.HORIZONTAL);
        bgRow.setGravity(Gravity.CENTER_VERTICAL);

        View bgContentsBox = createPhotoshopDropdown("White", new String[]{"White", "Black", "Transparent", "Custom Color..."}, sel -> {
            if ("White".equals(sel)) updateSelectedBgColor(Color.WHITE);
            else if ("Black".equals(sel)) updateSelectedBgColor(Color.BLACK);
            else if ("Transparent".equals(sel)) updateSelectedBgColor(Color.TRANSPARENT);
            else if ("Custom Color...".equals(sel)) openCustomColorSpectrumDialog();
        });
        bgRow.addView(bgContentsBox, new LinearLayout.LayoutParams(0, dp(34), 1f));

        liveSwatchPreview = new View(activity);
        liveSwatchPreview.setBackgroundColor(selectedBgColor);
        GradientDrawable sBorder = new GradientDrawable();
        sBorder.setColor(selectedBgColor);
        sBorder.setStroke(dp(1), Color.parseColor("#444444"));
        liveSwatchPreview.setBackground(sBorder);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(34), dp(34));
        sp.setMargins(dp(8), 0, 0, 0);
        liveSwatchPreview.setLayoutParams(sp);
        liveSwatchPreview.setOnClickListener(v -> openCustomColorSpectrumDialog());

        bgRow.addView(liveSwatchPreview);
        rightPane.addView(bgRow);

        LinearLayout actionsRow = new LinearLayout(activity);
        actionsRow.setOrientation(LinearLayout.HORIZONTAL);
        actionsRow.setGravity(Gravity.END);
        actionsRow.setPadding(0, dp(24), 0, dp(16));

        final Button closeBtn = new Button(activity);
        closeBtn.setText("Close");
        closeBtn.setTextColor(Color.WHITE);
        closeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        final GradientDrawable grayBtn = new GradientDrawable();
        grayBtn.setColor(Color.parseColor("#383838"));
        grayBtn.setCornerRadius(dp(18));
        closeBtn.setBackground(grayBtn);
        closeBtn.setLayoutParams(new LinearLayout.LayoutParams(dp(95), dp(38)));
        closeBtn.setOnClickListener(v -> dialog.dismiss());
        actionsRow.addView(closeBtn);

        final Button createBtn = new Button(activity);
        createBtn.setText("Create");
        createBtn.setTextColor(Color.WHITE);
        createBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        createBtn.setTypeface(null, Typeface.BOLD);
        final GradientDrawable redBtnStyle = new GradientDrawable();
        redBtnStyle.setColor(Color.parseColor("#FF1238"));
        redBtnStyle.setCornerRadius(dp(18));
        createBtn.setBackground(redBtnStyle);
        LinearLayout.LayoutParams crp = new LinearLayout.LayoutParams(dp(105), dp(38));
        crp.setMargins(dp(10), 0, 0, 0);
        createBtn.setLayoutParams(crp);

        // রিয়েল পিক্সেল এক্সট্রাকশন (Create)
        createBtn.setOnClickListener(v -> {
            String pName = nameInput.getText().toString().trim();
            if (pName.isEmpty()) pName = "Untitled-1";
            
            int dpi = 72;
            try { dpi = Integer.parseInt(resInput.getText().toString().trim()); } catch (Exception ignored) {}
            if (dpi <= 0) dpi = 72;

            float wInputVal = 1080f;
            float hInputVal = 1080f;
            try { wInputVal = Float.parseFloat(widthInput.getText().toString().trim()); } catch (Exception ignored) {}
            try { hInputVal = Float.parseFloat(heightInput.getText().toString().trim()); } catch (Exception ignored) {}

            int finalPixelW = Math.max(50, Math.round(toPixels(wInputVal, currentUnit, dpi)));
            int finalPixelH = Math.max(50, Math.round(toPixels(hInputVal, currentUnit, dpi)));

            int artboards = 1;
            try { artboards = Integer.parseInt(artboardsInput.getText().toString().trim()); } catch (Exception ignored) {}
            if (artboards < 1) artboards = 1;

            saveProjectToRecent(pName, finalPixelW, finalPixelH, artboards, selectedBgColor);
            openNewProjectTabInCurrentStudio(pName, finalPixelW, finalPixelH, artboards, selectedBgColor);

            dialog.dismiss();
            Toast.makeText(activity, "Created & Opened in New Tab!", Toast.LENGTH_SHORT).show();
        });
        actionsRow.addView(createBtn);

        rightPane.addView(actionsRow);
        rightScroll.addView(rightPane);
        bodyLayout.addView(rightScroll);
        mainLayout.addView(bodyLayout);

        windowContainer.addView(mainLayout);

        ImageView resizeGrip = new ImageView(activity);
        FrameLayout.LayoutParams rgp = new FrameLayout.LayoutParams(dp(26), dp(26));
        rgp.gravity = Gravity.BOTTOM | Gravity.END;
        rgp.setMargins(0, 0, dp(4), dp(4));
        resizeGrip.setLayoutParams(rgp);
        resizeGrip.setImageDrawable(createResizeGripIcon());
        resizeGrip.setScaleType(ImageView.ScaleType.CENTER);
        windowContainer.addView(resizeGrip);

        rootFrame.addView(windowContainer);
        dialog.setContentView(rootFrame);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

            macHeader.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY;
                float startTransX, startTransY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = event.getRawX();
                            downY = event.getRawY();
                            startTransX = windowContainer.getTranslationX();
                            startTransY = windowContainer.getTranslationY();
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dX = event.getRawX() - downX;
                            float dY = event.getRawY() - downY;
                            windowContainer.setTranslationX(startTransX + dX);
                            windowContainer.setTranslationY(startTransY + dY);
                            return true;
                    }
                    return false;
                }
            });

            resizeGrip.setOnTouchListener(new View.OnTouchListener() {
                float downX, downY;
                int startW, startH;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            downX = event.getRawX();
                            downY = event.getRawY();
                            startW = windowContainer.getWidth();
                            startH = windowContainer.getHeight();
                            if (v.getParent() != null) {
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            return true;
                        case MotionEvent.ACTION_MOVE:
                            float dX = event.getRawX() - downX;
                            float dY = event.getRawY() - downY;
                            int screenW = activity.getResources().getDisplayMetrics().widthPixels;
                            int screenH = activity.getResources().getDisplayMetrics().heightPixels;
                            int minW = dp(320);
                            int minH = dp(240);
                            int newW = Math.max(minW, Math.min(screenW - dp(10), (int) (startW + dX)));
                            int newH = Math.max(minH, Math.min(screenH - dp(10), (int) (startH + dY)));

                            ViewGroup.LayoutParams p = windowContainer.getLayoutParams();
                            p.width = newW;
                            p.height = newH;
                            windowContainer.setLayoutParams(p);
                            return true;
                    }
                    return false;
                }
            });

            View redDot = macHeader.getChildAt(0);
            if (redDot != null) redDot.setOnClickListener(v -> dialog.dismiss());

            View greenDot = macHeader.getChildAt(2);
            final boolean[] isMaximized = {false};
            final int[] savedBounds = new int[]{initW, initH, winParams.leftMargin, winParams.topMargin};
            final float[] savedTrans = new float[]{0, 0};

            if (greenDot != null) {
                greenDot.setOnClickListener(v -> {
                    int scrW = activity.getResources().getDisplayMetrics().widthPixels;
                    int scrH = activity.getResources().getDisplayMetrics().heightPixels;
                    FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) windowContainer.getLayoutParams();
                    if (!isMaximized[0]) {
                        savedBounds[0] = windowContainer.getWidth();
                        savedBounds[1] = windowContainer.getHeight();
                        savedBounds[2] = p.leftMargin;
                        savedBounds[3] = p.topMargin;
                        savedTrans[0] = windowContainer.getTranslationX();
                        savedTrans[1] = windowContainer.getTranslationY();

                        windowContainer.setTranslationX(0);
                        windowContainer.setTranslationY(0);
                        p.leftMargin = 0;
                        p.topMargin = 0;
                        p.width = scrW;
                        p.height = scrH;
                        windowContainer.setLayoutParams(p);
                        isMaximized[0] = true;
                    } else {
                        windowContainer.setTranslationX(savedTrans[0]);
                        windowContainer.setTranslationY(savedTrans[1]);
                        p.leftMargin = savedBounds[2];
                        p.topMargin = savedBounds[3];
                        p.width = savedBounds[0];
                        p.height = savedBounds[1];
                        windowContainer.setLayoutParams(p);
                        isMaximized[0] = false;
                    }
                });
            }
        }
        dialog.show();
    }

    private BitmapDrawable createResizeGripIcon() {
        Bitmap bmp = Bitmap.createBitmap(dp(18), dp(18), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#999999"));
        p.setStrokeWidth(dp(1.4f));
        c.drawLine(dp(15), dp(5), dp(5), dp(15), p);
        c.drawLine(dp(15), dp(9), dp(9), dp(15), p);
        c.drawLine(dp(15), dp(13), dp(13), dp(15), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private void openNewProjectTabInCurrentStudio(String pName, int w, int h, int artboards, int bg) {
        EditorActivity.ProjectTabSession newTab = new EditorActivity.ProjectTabSession(pName, w, h, artboards, bg);
        newTab.layers.clear();

        Bitmap bgBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bgBmp);
        c.drawColor(bg == Color.TRANSPARENT ? Color.TRANSPARENT : bg);

        EditorActivity.LayerItem bgLayer = new EditorActivity.LayerItem("Background", bgBmp, 0, 0, false);
        bgLayer.isBlank = false;
        newTab.layers.add(bgLayer);
        newTab.activeLayerIndex = 0;

        activity.openNewTabWithSession(newTab);
    }

    private void saveProjectToRecent(String title, int w, int h, int artboards, int bg) {
        try {
            SharedPreferences sp = activity.getSharedPreferences("ejitor_prefs", Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString("saved_projects", "[]"));
            JSONObject obj = new JSONObject();
            obj.put("title", title);
            obj.put("width", w);
            obj.put("height", h);
            obj.put("artboards", artboards);
            obj.put("bg", bg);
            obj.put("date", new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date()));

            JSONArray newArr = new JSONArray();
            newArr.put(obj);
            for (int i = 0; i < arr.length(); i++) {
                newArr.put(arr.get(i));
            }
            sp.edit().putString("saved_projects", newArr.toString()).apply();
        } catch (Exception ignored) {}
    }

    private void exportArtboardsSeparately(final String format) {
        final EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null) return;

        final int totalArtboards = s.artboardCount;
        Toast.makeText(activity, "Exporting " + totalArtboards + " artboard(s) separately...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            int savedCount = 0;
            long timestamp = System.currentTimeMillis();

            try {
                Method renderMethod = EditorActivity.class.getDeclaredMethod("renderCompositeCanvasForArtboard", int.class, boolean.class);
                renderMethod.setAccessible(true);

                for (int i = 0; i < totalArtboards; i++) {
                    Bitmap abBmp = (Bitmap) renderMethod.invoke(activity, i, format.equalsIgnoreCase("png"));
                    if (abBmp != null) {
                        String cleanName = s.projectName.replaceAll("[^a-zA-Z0-9._-]", "_");
                        String fileName = cleanName + "_Artboard_" + (i + 1) + "_" + timestamp + "." + format.toLowerCase();
                        String mime = format.equalsIgnoreCase("png") ? "image/png" : "image/jpeg";

                        OutputStream os = getDownloadsFileOutputStream(fileName, mime);
                        if (os != null) {
                            if (format.equalsIgnoreCase("png")) abBmp.compress(Bitmap.CompressFormat.PNG, 100, os);
                            else abBmp.compress(Bitmap.CompressFormat.JPEG, 95, os);
                            os.close();
                            savedCount++;
                        }
                    }
                }
            } catch (Exception ignored) {}

            final int finalSaved = savedCount;
            activity.runOnUiThread(() -> {
                Toast.makeText(activity, "Saved " + finalSaved + " Artboard(s) separately to Downloads/EJITOR!", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void exportPdfSeparately() {
        final EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null) return;

        final int totalPages = s.artboardCount;
        Toast.makeText(activity, "Exporting " + totalPages + " individual PDF file(s)...", Toast.LENGTH_SHORT).show();

        new Thread(() -> {
            int savedPdfCount = 0;
            long timestamp = System.currentTimeMillis();

            try {
                Method renderMethod = EditorActivity.class.getDeclaredMethod("renderCompositeCanvasForArtboard", int.class, boolean.class);
                renderMethod.setAccessible(true);

                for (int i = 0; i < totalPages; i++) {
                    Bitmap abBmp = (Bitmap) renderMethod.invoke(activity, i, false);
                    if (abBmp != null) {
                        PdfDocument singleDoc = new PdfDocument();
                        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(s.canvasWidth, s.canvasHeight, 1).create();
                        PdfDocument.Page page = singleDoc.startPage(pageInfo);
                        Canvas c = page.getCanvas();
                        c.drawBitmap(abBmp, 0, 0, null);
                        singleDoc.finishPage(page);

                        String cleanName = s.projectName.replaceAll("[^a-zA-Z0-9._-]", "_");
                        String fileName = cleanName + "_Page_" + (i + 1) + "_" + timestamp + ".pdf";

                        OutputStream os = getDownloadsFileOutputStream(fileName, "application/pdf");
                        if (os != null) {
                            singleDoc.writeTo(os);
                            os.close();
                            savedPdfCount++;
                        }
                        singleDoc.close();
                    }
                }
            } catch (Exception ignored) {}

            final int finalPdfCount = savedPdfCount;
            activity.runOnUiThread(() -> {
                Toast.makeText(activity, "Saved " + finalPdfCount + " separate PDF file(s) to Downloads/EJITOR!", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private OutputStream getDownloadsFileOutputStream(String fileName, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = activity.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/EJITOR");
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            return uri != null ? resolver.openOutputStream(uri) : null;
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "EJITOR");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, fileName);
            return new FileOutputStream(f);
        }
    }

    private void updateSelectedBgColor(int color) {
        selectedBgColor = color;
        if (liveSwatchPreview != null) {
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(color == Color.TRANSPARENT ? Color.parseColor("#181818") : color);
            gd.setStroke(dp(1), Color.parseColor("#555555"));
            liveSwatchPreview.setBackground(gd);
        }
    }

    private void openCustomColorSpectrumDialog() {
        final Dialog colorDialog = new Dialog(activity);
        colorDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        if (colorDialog.getWindow() != null) {
            colorDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            colorDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            colorDialog.getWindow().setGravity(Gravity.CENTER);
        }

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(290), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable rBg = new GradientDrawable();
        rBg.setColor(Color.parseColor("#1E1E1E"));
        rBg.setStroke(dp(1), Color.parseColor("#333333"));
        rBg.setCornerRadius(dp(16));
        root.setBackground(rBg);

        TextView title = new TextView(activity);
        title.setText("Fill / Foreground");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(6));
        root.addView(title);

        final float[] hsv = new float[3];
        Color.colorToHSV(selectedBgColor, hsv);
        final int[] curAlpha = new int[]{Color.alpha(selectedBgColor)};
        final int[] curColor = new int[]{selectedBgColor};

        final View topPreviewCircle = new View(activity);
        LinearLayout.LayoutParams circleLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        circleLp.gravity = Gravity.CENTER_HORIZONTAL;
        circleLp.setMargins(0, dp(2), 0, dp(8));
        topPreviewCircle.setLayoutParams(circleLp);

        final GradientDrawable circleBg = new GradientDrawable();
        circleBg.setShape(GradientDrawable.OVAL);
        circleBg.setColor(selectedBgColor);
        circleBg.setStroke(dp(2), Color.parseColor("#444444"));
        topPreviewCircle.setBackground(circleBg);
        root.addView(topPreviewCircle);

        final TextView hexRgbText = new TextView(activity);
        hexRgbText.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        hexRgbText.setGravity(Gravity.CENTER);
        hexRgbText.setTextColor(Color.WHITE);
        hexRgbText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        hexRgbText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);

        GradientDrawable hexBoxBg = new GradientDrawable();
        hexBoxBg.setColor(Color.parseColor("#2A2A2A"));
        hexBoxBg.setStroke(dp(1), Color.parseColor("#F5A623"));
        hexBoxBg.setCornerRadius(dp(4));
        hexRgbText.setBackground(hexBoxBg);
        root.addView(hexRgbText);

        final Runnable updateDisplay = () -> {
            int c = curColor[0];
            int a = curAlpha[0];
            int r = Color.red(c);
            int g = Color.green(c);
            int b = Color.blue(c);
            String hex = String.format("#%02X%02X%02X%02X", a, r, g, b);
            hexRgbText.setText(hex + " - (" + r + "," + g + "," + b + "," + a + ")");
            circleBg.setColor(Color.argb(a, r, g, b));
        };
        updateDisplay.run();

        final View colorWheelView = new View(activity) {
            private final Paint wheelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Paint satPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Paint thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            private final Paint thumbStroke = new Paint(Paint.ANTI_ALIAS_FLAG);

            {
                thumbPaint.setStyle(Paint.Style.FILL);
                thumbStroke.setStyle(Paint.Style.STROKE);
                thumbStroke.setStrokeWidth(dp(2));
                thumbStroke.setColor(Color.WHITE);
            }

            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                float cx = getWidth() / 2f;
                float cy = getHeight() / 2f;
                float r = Math.min(cx, cy) - dp(8);
                if (r <= 0) return;

                int[] colors = new int[]{Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED};
                wheelPaint.setShader(new SweepGradient(cx, cy, colors, null));
                canvas.drawCircle(cx, cy, r, wheelPaint);

                satPaint.setShader(new RadialGradient(cx, cy, r, Color.WHITE, Color.TRANSPARENT, Shader.TileMode.CLAMP));
                canvas.drawCircle(cx, cy, r, satPaint);

                float angle = (float) Math.toRadians(hsv[0]);
                float dist = hsv[1] * r;
                float selX = cx + (float) Math.cos(angle) * dist;
                float selY = cy + (float) Math.sin(angle) * dist;

                thumbPaint.setColor(curColor[0]);
                canvas.drawCircle(selX, selY, dp(7), thumbPaint);
                canvas.drawCircle(selX, selY, dp(7), thumbStroke);
            }
        };

        LinearLayout.LayoutParams wheelLp = new LinearLayout.LayoutParams(dp(190), dp(190));
        wheelLp.gravity = Gravity.CENTER_HORIZONTAL;
        wheelLp.setMargins(0, dp(10), 0, dp(10));
        colorWheelView.setLayoutParams(wheelLp);
        root.addView(colorWheelView);

        final SeekBar satBar = new SeekBar(activity);
        final SeekBar valBar = new SeekBar(activity);
        final SeekBar alphaBar = new SeekBar(activity);

        final Runnable[] updateSliders = new Runnable[1];

        colorWheelView.setOnTouchListener((v, event) -> {
            float cx = v.getWidth() / 2f;
            float cy = v.getHeight() / 2f;
            float r = Math.min(cx, cy) - dp(8);

            float dx = event.getX() - cx;
            float dy = event.getY() - cy;
            float dist = (float) Math.hypot(dx, dy);

            double angle = Math.toDegrees(Math.atan2(dy, dx));
            if (angle < 0) angle += 360;

            hsv[0] = (float) angle;
            hsv[1] = Math.max(0f, Math.min(1f, dist / r));

            curColor[0] = Color.HSVToColor(curAlpha[0], hsv);
            updateDisplay.run();
            if (updateSliders[0] != null) updateSliders[0].run();
            v.invalidate();
            return true;
        });

        Drawable whiteThumb = new GradientDrawable();
        ((GradientDrawable) whiteThumb).setShape(GradientDrawable.OVAL);
        ((GradientDrawable) whiteThumb).setColor(Color.WHITE);
        ((GradientDrawable) whiteThumb).setStroke(dp(1), Color.parseColor("#999999"));
        ((GradientDrawable) whiteThumb).setSize(dp(16), dp(16));

        satBar.setThumb(whiteThumb);
        valBar.setThumb(whiteThumb.getConstantState().newDrawable().mutate());
        alphaBar.setThumb(whiteThumb.getConstantState().newDrawable().mutate());

        satBar.setSplitTrack(false);
        valBar.setSplitTrack(false);
        alphaBar.setSplitTrack(false);

        satBar.setMax(100);
        satBar.setProgress((int) (hsv[1] * 100));
        valBar.setMax(100);
        valBar.setProgress((int) (hsv[2] * 100));
        alphaBar.setMax(255);
        alphaBar.setProgress(curAlpha[0]);

        updateSliders[0] = () -> {
            float[] hsvTemp = new float[]{hsv[0], 0f, hsv[2]};
            int colWhite = Color.HSVToColor(hsvTemp);
            hsvTemp[1] = 1f;
            int colFullSat = Color.HSVToColor(hsvTemp);
            GradientDrawable satBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{colWhite, colFullSat});
            satBg.setCornerRadius(dp(3));
            satBar.setProgressDrawable(satBg);

            hsvTemp[1] = hsv[1];
            hsvTemp[2] = 0f;
            int colBlack = Color.HSVToColor(hsvTemp);
            hsvTemp[2] = 1f;
            int colBright = Color.HSVToColor(hsvTemp);
            GradientDrawable valBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{colBlack, colBright});
            valBg.setCornerRadius(dp(3));
            valBar.setProgressDrawable(valBg);

            int colOpaque = Color.HSVToColor(255, hsv);
            GradientDrawable aBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Color.TRANSPARENT, colOpaque});
            aBg.setCornerRadius(dp(3));
            alphaBar.setProgressDrawable(aBg);
        };
        updateSliders[0].run();

        SeekBar.OnSeekBarChangeListener sliderListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    if (seekBar == satBar) hsv[1] = progress / 100f;
                    else if (seekBar == valBar) hsv[2] = progress / 100f;
                    else if (seekBar == alphaBar) curAlpha[0] = progress;

                    curColor[0] = Color.HSVToColor(curAlpha[0], hsv);
                    updateDisplay.run();
                    colorWheelView.invalidate();
                    if (updateSliders[0] != null) updateSliders[0].run();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        satBar.setOnSeekBarChangeListener(sliderListener);
        valBar.setOnSeekBarChangeListener(sliderListener);
        alphaBar.setOnSeekBarChangeListener(sliderListener);

        LinearLayout.LayoutParams sliderLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20));
        sliderLp.setMargins(0, dp(4), 0, dp(4));
        satBar.setLayoutParams(sliderLp);
        valBar.setLayoutParams(sliderLp);
        alphaBar.setLayoutParams(sliderLp);

        root.addView(satBar);
        root.addView(valBar);
        root.addView(alphaBar);

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, 0);

        Button apply = new Button(activity);
        apply.setText("APPLY");
        apply.setTextColor(Color.WHITE);
        apply.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        apply.setTypeface(null, Typeface.BOLD);
        GradientDrawable applyBg = new GradientDrawable();
        applyBg.setColor(Color.parseColor("#FF1238"));
        applyBg.setCornerRadius(dp(4));
        apply.setBackground(applyBg);
        apply.setLayoutParams(new LinearLayout.LayoutParams(0, dp(36), 1.2f));

        apply.setOnClickListener(v -> {
            int finalColor = Color.argb(curAlpha[0], Color.red(curColor[0]), Color.green(curColor[0]), Color.blue(curColor[0]));
            updateSelectedBgColor(finalColor);
            colorDialog.dismiss();
        });
        btnRow.addView(apply);

        View spacer = new View(activity);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(dp(8), dp(1)));
        btnRow.addView(spacer);

        Button cancel = new Button(activity);
        cancel.setText("CLOSE");
        cancel.setTextColor(Color.WHITE);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setColor(Color.parseColor("#333333"));
        cancelBg.setCornerRadius(dp(4));
        cancel.setBackground(cancelBg);
        cancel.setLayoutParams(new LinearLayout.LayoutParams(0, dp(36), 0.8f));
        cancel.setOnClickListener(v -> colorDialog.dismiss());
        btnRow.addView(cancel);

        root.addView(btnRow);
        colorDialog.setContentView(root);
        colorDialog.show();
    }

    private void populateTemplateGrid(LinearLayout grid, String cat, EditText nameInp, EditText wInp, EditText hInp, EditText resInp) {
        grid.removeAllViews();
        ArrayList<String[]> filtered = new ArrayList<>();
        for (String[] t : templates) {
            if (cat.equals("Recent") || t[3].equalsIgnoreCase(cat)) {
                filtered.add(t);
            }
        }

        for (int i = 0; i < filtered.size(); i += 2) {
            LinearLayout row = new LinearLayout(activity);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 0, 0, dp(8));

            final String[] t1 = filtered.get(i);
            row.addView(createTemplateCard(t1[0], t1[1] + " × " + t1[2] + " px", v -> {
                nameInp.setText(t1[0]);
                try {
                    int dpi = 72;
                    try { dpi = Integer.parseInt(resInp.getText().toString().trim()); } catch (Exception ignored) {}
                    if (t1[3].equalsIgnoreCase("Print")) dpi = 300;
                    resInp.setText(String.valueOf(dpi));

                    float pW = Float.parseFloat(t1[1]);
                    float pH = Float.parseFloat(t1[2]);
                    wInp.setText(formatUnitValue(fromPixels(pW, currentUnit, dpi), currentUnit));
                    hInp.setText(formatUnitValue(fromPixels(pH, currentUnit, dpi), currentUnit));
                } catch (Exception ignored) {}
            }));

            if (i + 1 < filtered.size()) {
                final String[] t2 = filtered.get(i + 1);
                row.addView(createTemplateCard(t2[0], t2[1] + " × " + t2[2] + " px", v -> {
                    nameInp.setText(t2[0]);
                    try {
                        int dpi = 72;
                        try { dpi = Integer.parseInt(resInp.getText().toString().trim()); } catch (Exception ignored) {}
                        if (t2[3].equalsIgnoreCase("Print")) dpi = 300;
                        resInp.setText(String.valueOf(dpi));

                        float pW = Float.parseFloat(t2[1]);
                        float pH = Float.parseFloat(t2[2]);
                        wInp.setText(formatUnitValue(fromPixels(pW, currentUnit, dpi), currentUnit));
                        hInp.setText(formatUnitValue(fromPixels(pH, currentUnit, dpi), currentUnit));
                    } catch (Exception ignored) {}
                }));
            }
            grid.addView(row);
        }
    }

    private View createTemplateCard(String title, String size, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(activity);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(95), 1f);
        cp.setMargins(0, 0, dp(8), 0);
        card.setLayoutParams(cp);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1A1A1A"));
        bg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        bg.setCornerRadius(dp(4));
        card.setBackground(bg);
        card.setPadding(dp(6), dp(8), dp(6), dp(8));

        ImageView icon = new ImageView(activity);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(22), dp(22)));
        icon.setImageDrawable(createPhotoshopDocIcon(dp(18), dp(22), "#E0E0E0"));
        card.addView(icon);

        TextView name = new TextView(activity);
        name.setText(title);
        name.setTextColor(Color.WHITE);
        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        name.setTypeface(null, Typeface.BOLD);
        name.setSingleLine(true);
        name.setGravity(Gravity.CENTER);
        name.setPadding(0, dp(4), 0, 0);
        card.addView(name);

        TextView dims = new TextView(activity);
        dims.setText(size);
        dims.setTextColor(Color.parseColor("#888888"));
        dims.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        dims.setGravity(Gravity.CENTER);
        card.addView(dims);

        card.setOnClickListener(click);
        return card;
    }

    private LinearLayout createFieldWithLabel(String labelText, View field, float weight) {
        LinearLayout wrap = new LinearLayout(activity);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight);
        wp.setMargins(0, 0, dp(8), 0);
        wrap.setLayoutParams(wp);
        wrap.setOrientation(LinearLayout.VERTICAL);

        wrap.addView(createFieldLabel(labelText));
        wrap.addView(field);
        return wrap;
    }

    private TextView createFieldLabel(String text) {
        TextView l = new TextView(activity);
        l.setText(text);
        l.setTextColor(Color.parseColor("#888888"));
        l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        l.setPadding(0, dp(6), 0, dp(2));
        return l;
    }

    private EditText createDarkInput(String defaultText) {
        EditText et = new EditText(activity);
        et.setText(defaultText);
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        et.setPadding(dp(8), dp(4), dp(8), dp(4));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#121212"));
        bg.setStroke(dp(1), Color.parseColor("#303030"));
        bg.setCornerRadius(dp(2));
        et.setBackground(bg);
        et.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));
        return et;
    }

    public interface OnDropdownSelected {
        void onSelected(String item);
    }

    private View createPhotoshopDropdown(String initialText, final String[] items, final OnDropdownSelected callback) {
        final LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(8), 0, dp(8), 0);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#121212"));
        bg.setStroke(dp(1), Color.parseColor("#303030"));
        bg.setCornerRadius(dp(2));
        box.setBackground(bg);
        box.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)));

        final TextView label = new TextView(activity);
        label.setText(initialText);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        label.setSingleLine(true);
        label.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(label);

        TextView arrow = new TextView(activity);
        arrow.setText("▾");
        arrow.setTextColor(Color.parseColor("#888888"));
        arrow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        box.addView(arrow);

        box.setOnClickListener(v -> {
            final PopupWindow popup = new PopupWindow(activity);
            LinearLayout menu = new LinearLayout(activity);
            menu.setOrientation(LinearLayout.VERTICAL);
            menu.setPadding(dp(4), dp(4), dp(4), dp(4));

            GradientDrawable menuBg = new GradientDrawable();
            menuBg.setColor(Color.parseColor("#222222"));
            menuBg.setStroke(dp(1), Color.parseColor("#383838"));
            menuBg.setCornerRadius(dp(3));
            menu.setBackground(menuBg);

            for (final String item : items) {
                final TextView itemTv = new TextView(activity);
                itemTv.setText(item);
                boolean isSelected = item.equals(label.getText().toString());
                itemTv.setTextColor(isSelected ? Color.WHITE : Color.parseColor("#CCCCCC"));
                itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
                itemTv.setTypeface(null, isSelected ? Typeface.BOLD : Typeface.NORMAL);
                itemTv.setPadding(dp(14), dp(8), dp(14), dp(8));

                if (isSelected) {
                    GradientDrawable selBg = new GradientDrawable();
                    selBg.setColor(Color.parseColor("#2E2E2E"));
                    selBg.setCornerRadius(dp(2));
                    itemTv.setBackground(selBg);
                }

                itemTv.setOnClickListener(v1 -> {
                    label.setText(item);
                    popup.dismiss();
                    if (callback != null) callback.onSelected(item);
                });
                menu.addView(itemTv);
            }

            popup.setContentView(menu);
            popup.setWidth(Math.max(box.getWidth(), dp(130)));
            popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
            popup.setFocusable(true);
            popup.setOutsideTouchable(true);
            popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            popup.showAsDropDown(box, 0, dp(1));
        });

        return box;
    }

    private BitmapDrawable createPersonVectorIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor(colorHex));
        p.setStyle(Paint.Style.FILL);

        canvas.drawCircle(w / 2f, h * 0.28f, h * 0.22f, p);

        Path body = new Path();
        body.moveTo(w * 0.15f, h * 0.95f);
        body.quadTo(w * 0.15f, h * 0.58f, w * 0.5f, h * 0.58f);
        body.quadTo(w * 0.85f, h * 0.58f, w * 0.85f, h * 0.95f);
        body.close();
        canvas.drawPath(body, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createLandscapeImageVectorIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor(colorHex));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.2f));

        canvas.drawRect(dp(1), dp(1), w - dp(1), h - dp(1), p);

        p.setStyle(Paint.Style.FILL);
        canvas.drawCircle(w * 0.32f, h * 0.35f, h * 0.12f, p);

        Path hill = new Path();
        hill.moveTo(dp(1), h - dp(1));
        hill.lineTo(w * 0.45f, h * 0.45f);
        hill.lineTo(w * 0.7f, h * 0.7f);
        hill.lineTo(w * 0.85f, h * 0.55f);
        hill.lineTo(w - dp(1), h - dp(1));
        hill.close();
        canvas.drawPath(hill, p);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createPhotoshopDocIcon(int w, int h, String colorHex) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.parseColor(colorHex));
        paint.setStyle(Paint.Style.FILL);

        Path path = new Path();
        path.moveTo(0, 0);
        path.lineTo(w * 0.65f, 0);
        path.lineTo(w, h * 0.35f);
        path.lineTo(w, h);
        path.lineTo(0, h);
        path.close();
        canvas.drawPath(path, paint);

        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private TextView createMacDot(String colorHex) {
        TextView dot = new TextView(activity);
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);
        shape.setColor(Color.parseColor(colorHex));
        dot.setBackground(shape);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(10), dp(10));
        p.setMargins(0, 0, dp(7), 0);
        dot.setLayoutParams(p);
        return dot;
    }
}