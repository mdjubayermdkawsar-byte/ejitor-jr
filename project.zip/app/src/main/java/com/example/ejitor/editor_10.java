package com.example.ejitor;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Method;

public class editor_10 implements EditorActivity.EditorModule {

    public static editor_10 instance;
    private EditorActivity activity;

    // অ্যাপের নিজস্ব সিগনেচার ব্র্যান্ড কালার
    private final int BRAND_COLOR = Color.parseColor("#FF1238");

    // অ্যাক্টিভ ডায়ালগ রেফারেন্স
    private Dialog activeAlignDialog = null;

    @Override
    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        instance = this;
        hookAlignMenu();
    }

    @Override
    public void onCommand(String command, Object... args) {
        if ("openRelativePosition".equalsIgnoreCase(command) || "openAlignment".equalsIgnoreCase(command)) {
            showRelativePositionDialog();
        }
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    // --- রিফ্লেকশন মেথডসমূহ ---
    private void invokePrivateMethod(EditorActivity act, String name) {
        if (act == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(name);
            m.setAccessible(true);
            m.invoke(act);
        } catch (Exception ignored) {}
    }

    // Align মেনু হুক (ক্লিক করলেই সরাসরি অ্যালাইনমেন্ট পপ-আপ ওপেন হবে)
    private void hookAlignMenu() {
        if (activity == null || activity.menuContainer == null) return;

        activity.canvasView.post(() -> {
            for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
                View child = activity.menuContainer.getChildAt(i);
                if (child instanceof TextView) {
                    TextView tv = (TextView) child;
                    if ("Align".equalsIgnoreCase(tv.getText().toString().trim())) {
                        tv.setOnClickListener(v -> {
                            activity.triggerClickFeedback(v);
                            showRelativePositionDialog();
                        });
                        break;
                    }
                }
            }
        });
    }

    // =========================================================================
    // ড্র্যাগেবল ও নন-মডাল Relative Position (Alignment) ডায়ালগ
    // =========================================================================
    public void showRelativePositionDialog() {
        if (activity == null) return;

        // অলরেডি ওপেন থাকলে সামনে নিয়ে আসবে
        if (activeAlignDialog != null && activeAlignDialog.isShowing()) {
            return;
        }

        final EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.layers.isEmpty() || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) {
            Toast.makeText(activity, "Please select an active layer first", Toast.LENGTH_SHORT).show();
            return;
        }

        final Dialog d = new Dialog(activity);
        this.activeAlignDialog = d;
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setCancelable(false);
        d.setCanceledOnTouchOutside(false);

        // ক্যানভাসে জুম/প্যান করলেও যাতে ডায়ালগ বন্ধ না হয় (NOT_TOUCH_MODAL)
        Window window = d.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            window.addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
            window.addFlags(WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH);
            window.setGravity(Gravity.CENTER);
        }

        final WindowManager.LayoutParams lp = (window != null) ? window.getAttributes() : null;

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(16));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#181818"));
        bg.setStroke(dp(1), Color.parseColor("#2C2C2C"));
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);

        // হেডার (মুভ হ্যান্ডেল + টাইটেল + ক্লোজ বাটন)
        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(14));

        TextView titleTv = new TextView(activity);
        titleTv.setText("Relative Position");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorIcon());
        closeX.setOnClickListener(v -> d.dismiss());
        header.addView(closeX);
        box.addView(header);

        // হেডার ধরে স্ক্রিনের যেকোনো জায়গায় টেনে মুভ (Draggable) করার লিসেনার
        header.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY;
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (d.getWindow() == null || lp == null) return false;
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = event.getRawX() - lp.x;
                        startY = event.getRawY() - lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = (int) (event.getRawX() - startX);
                        lp.y = (int) (event.getRawY() - startY);
                        d.getWindow().setAttributes(lp);
                        return true;
                }
                return false;
            }
        });

        // রো ১: Left, Center, Right
        LinearLayout row1 = new LinearLayout(activity);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setPadding(0, 0, 0, dp(8));

        row1.addView(createAlignCell("Left", createAlignLeftIcon(), v -> alignCurrentLayer(0)));
        row1.addView(createHGap(dp(8)));
        row1.addView(createAlignCell("Center", createAlignCenterIcon(), v -> alignCurrentLayer(1)));
        row1.addView(createHGap(dp(8)));
        row1.addView(createAlignCell("Right", createAlignRightIcon(), v -> alignCurrentLayer(2)));
        box.addView(row1);

        // রো ২: Top, Middle, Bottom
        LinearLayout row2 = new LinearLayout(activity);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setPadding(0, 0, 0, dp(12));

        row2.addView(createAlignCell("Top", createAlignTopIcon(), v -> alignCurrentLayer(3)));
        row2.addView(createHGap(dp(8)));
        row2.addView(createAlignCell("Middle", createAlignMiddleIcon(), v -> alignCurrentLayer(4)));
        row2.addView(createHGap(dp(8)));
        row2.addView(createAlignCell("Bottom", createAlignBottomIcon(), v -> alignCurrentLayer(5)));
        box.addView(row2);

        // নিচে বড় বাটন: Center Both
        LinearLayout centerBothBtn = new LinearLayout(activity);
        centerBothBtn.setOrientation(LinearLayout.HORIZONTAL);
        centerBothBtn.setGravity(Gravity.CENTER);
        centerBothBtn.setPadding(0, dp(10), 0, dp(10));

        GradientDrawable cbBg = new GradientDrawable();
        cbBg.setColor(BRAND_COLOR);
        cbBg.setCornerRadius(dp(6));
        centerBothBtn.setBackground(cbBg);

        ImageView cbIcon = new ImageView(activity);
        cbIcon.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        cbIcon.setImageDrawable(createCenterBothIcon());
        centerBothBtn.addView(cbIcon);

        TextView cbText = new TextView(activity);
        cbText.setText("  Center Both");
        cbText.setTextColor(Color.WHITE);
        cbText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        cbText.setTypeface(null, Typeface.BOLD);
        centerBothBtn.addView(cbText);

        centerBothBtn.setOnClickListener(v -> {
            activity.triggerClickFeedback(v);
            alignCurrentLayer(6);
        });
        box.addView(centerBothBtn);

        d.setContentView(box);
        d.show();

        if (d.getWindow() != null) {
            d.getWindow().setLayout(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    // অ্যাক্টিভ লেয়ার অ্যালাইনমেন্ট মেথড
    private void alignCurrentLayer(int mode) {
        EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null || s.layers.isEmpty() || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return;

        EditorActivity.LayerItem li = s.layers.get(s.activeLayerIndex);
        if (li.bitmap == null) return;

        float w = li.bitmap.getWidth() * li.scaleX;
        float h = li.bitmap.getHeight() * li.scaleY;

        switch (mode) {
            case 0: // Left
                li.x = 0;
                break;
            case 1: // Center (H-Center)
                li.x = (s.canvasWidth - w) / 2f;
                break;
            case 2: // Right
                li.x = s.canvasWidth - w;
                break;
            case 3: // Top
                li.y = 0;
                break;
            case 4: // Middle (V-Center)
                li.y = (s.canvasHeight - h) / 2f;
                break;
            case 5: // Bottom
                li.y = s.canvasHeight - h;
                break;
            case 6: // Center Both
                li.x = (s.canvasWidth - w) / 2f;
                li.y = (s.canvasHeight - h) / 2f;
                break;
        }

        li.isDirty = true;
        activity.recordHistory();
        invokePrivateMethod(activity, "updateLayersDockUI");
        if (activity.canvasView != null) activity.canvasView.invalidate();
    }

    private View createHGap(int width) {
        View v = new View(activity);
        v.setLayoutParams(new LinearLayout.LayoutParams(width, dp(1)));
        return v;
    }

    private LinearLayout createAlignCell(String title, Drawable icon, View.OnClickListener l) {
        LinearLayout cell = new LinearLayout(activity);
        cell.setOrientation(LinearLayout.HORIZONTAL);
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(dp(6), dp(10), dp(6), dp(10));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#262626"));
        bg.setCornerRadius(dp(6));
        cell.setBackground(bg);
        cell.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (icon != null) {
            ImageView iv = new ImageView(activity);
            iv.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
            iv.setImageDrawable(icon);
            cell.addView(iv);
        }

        TextView tv = new TextView(activity);
        tv.setText(" " + title);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        tv.setTypeface(null, Typeface.BOLD);
        cell.addView(tv);

        cell.setOnClickListener(v -> {
            activity.triggerClickFeedback(v);
            if (l != null) l.onClick(v);
        });
        return cell;
    }

    // =========================================================================
    // অ্যালাইনমেন্ট আইকনসমূহ
    // =========================================================================
    private BitmapDrawable createAlignLeftIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(1.5f), dp(2), dp(3.2f), dp(14), p);
        c.drawRect(dp(5.5f), dp(5.5f), dp(13.5f), dp(10.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createAlignCenterIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(BRAND_COLOR);
        p.setStrokeWidth(dp(1.2f));
        c.drawLine(dp(8), dp(1.5f), dp(8), dp(14.5f), p);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(3), dp(5.5f), dp(13), dp(10.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createAlignRightIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(12.8f), dp(2), dp(14.5f), dp(14), p);
        c.drawRect(dp(2.5f), dp(5.5f), dp(10.5f), dp(10.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createAlignTopIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(2), dp(1.5f), dp(14), dp(3.2f), p);
        c.drawRect(dp(5.5f), dp(5.5f), dp(10.5f), dp(13.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createAlignMiddleIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(BRAND_COLOR);
        p.setStrokeWidth(dp(1.2f));
        c.drawLine(dp(1.5f), dp(8), dp(14.5f), dp(8), p);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(5.5f), dp(3), dp(10.5f), dp(13), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createAlignBottomIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.FILL);
        c.drawRect(dp(2), dp(12.8f), dp(14), dp(14.5f), p);
        c.drawRect(dp(5.5f), dp(2.5f), dp(10.5f), dp(10.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createCenterBothIcon() {
        int s = dp(16);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(dp(1.3f));
        c.drawCircle(dp(8), dp(8), dp(4.5f), p);
        c.drawLine(dp(8), dp(1.5f), dp(8), dp(14.5f), p);
        c.drawLine(dp(1.5f), dp(8), dp(14.5f), dp(8), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }

    private BitmapDrawable createCloseVectorIcon() {
        int s = dp(14);
        Bitmap bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.4f));
        c.drawLine(dp(2.5f), dp(2.5f), dp(11.5f), dp(11.5f), p);
        c.drawLine(dp(11.5f), dp(2.5f), dp(2.5f), dp(11.5f), p);
        return new BitmapDrawable(activity.getResources(), bmp);
    }
}