package com.example.ejitor;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class editor_3 {

    private EditorActivity activity;

    // থ্রেড-সেফ ব্যাকগ্রাউন্ড এক্সিকিউটর
    private final ExecutorService selectionExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger selectionTaskCounter = new AtomicInteger(0);

    // স্মার্ট অবজেক্ট ক্যাশ
    private static final Map<EditorActivity.LayerItem, Bitmap> smartOriginalBitmaps = new HashMap<>();

    // সিলেকশন ট্রান্সফর্ম সিঙ্কিং
    private static Path layerLocalSelectionPath = null;
    private static EditorActivity.LayerItem trackedSelectionLayer = null;
    private static float lastLayerX = 0f, lastLayerY = 0f;
    private static float lastLayerScaleX = 1f, lastLayerScaleY = 1f;

    public void init(EditorActivity editorActivity) {
        this.activity = editorActivity;
        hookTopSelectMenu(); 
        hookLayersDockForSmartObjects();
        hookOpacityControl();
        hookCanvasTouchForSelectionSync();
    }

    private int dp(float value) {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, dm);
    }

    private void setEditorSelectionPath(Path path) {
        if (activity == null) return;
        try {
            Field fPath = EditorActivity.class.getDeclaredField("activeSelectionPath");
            fPath.setAccessible(true);
            fPath.set(activity, path);

            Field fBounds = EditorActivity.class.getDeclaredField("selectionBounds");
            fBounds.setAccessible(true);
            if (path != null) {
                RectF r = new RectF();
                path.computeBounds(r, true);
                fBounds.set(activity, r);
            } else {
                fBounds.set(activity, null);
            }
        } catch (Exception ignored) {}
    }

    private Path getEditorSelectionPath() {
        if (activity == null) return null;
        try {
            Field fPath = EditorActivity.class.getDeclaredField("activeSelectionPath");
            fPath.setAccessible(true);
            return (Path) fPath.get(activity);
        } catch (Exception e) {
            return null;
        }
    }

    private void invokePrivateVoidMethod(String methodName) {
        if (activity == null) return;
        try {
            Method m = EditorActivity.class.getDeclaredMethod(methodName);
            m.setAccessible(true);
            m.invoke(activity);
        } catch (Exception ignored) {}
    }

    // ১. মেনুবারে Select Pixels ও আনডু-সমর্থিত Clear Option
    private void hookTopSelectMenu() {
        if (activity == null || activity.menuContainer == null) return;

        for (int i = 0; i < activity.menuContainer.getChildCount(); i++) {
            View child = activity.menuContainer.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if ("Select".equalsIgnoreCase(tv.getText().toString().trim())) {
                    tv.setOnClickListener(this::showFullSelectMenu);
                    break;
                }
            }
        }
    }

    private void showFullSelectMenu(View anchor) {
        final PopupWindow popup = new PopupWindow(activity);
        LinearLayout l = new LinearLayout(activity);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(8), dp(6), dp(8), dp(6));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        l.setBackground(bg);

        String[] items = {
                "Select All",
                "Fill Selection (Color)",
                "Clear",
                "Inverse",
                "Deselect",
                "Select Pixels"
        };

        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            TextView itemTv = new TextView(activity);
            itemTv.setText(items[i]);
            itemTv.setTextColor(Color.WHITE);
            itemTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
            itemTv.setPadding(dp(12), dp(8), dp(12), dp(8));

            itemTv.setOnClickListener(v -> {
                popup.dismiss();
                EditorActivity.ProjectTabSession s = activity.getCurrentSession();
                if (s == null) return;

                if (idx == 0) { 
                    float totalW = s.artboardCount * s.canvasWidth + (s.artboardCount - 1) * dp(16f);
                    Path p = new Path();
                    p.addRect(0, 0, totalW, s.canvasHeight, Path.Direction.CW);
                    setEditorSelectionPath(p);
                    trackedSelectionLayer = null;
                    layerLocalSelectionPath = null;
                    activity.recordHistory();
                    activity.canvasView.invalidate();
                } else if (idx == 1) { 
                    try {
                        Field fgF = EditorActivity.class.getDeclaredField("fgColor");
                        fgF.setAccessible(true);
                        int fg = fgF.getInt(activity);
                        activity.fillActiveSelectionWithColor(fg);
                    } catch (Exception ignored) {}
                } else if (idx == 2) { 
                    // [FIXED]: সম্পূর্ণ কার্যকর ও আনডু-সমর্থিত ক্লিয়ার
                    executeClearAction(s);
                } else if (idx == 3) { 
                    Path cur = getEditorSelectionPath();
                    float totalW = s.artboardCount * s.canvasWidth + (s.artboardCount - 1) * dp(16f);
                    Path full = new Path();
                    full.addRect(0, 0, totalW, s.canvasHeight, Path.Direction.CW);
                    if (cur == null) {
                        setEditorSelectionPath(full);
                    } else {
                        Path inv = new Path();
                        inv.op(full, cur, Path.Op.DIFFERENCE);
                        setEditorSelectionPath(inv);
                    }
                    trackedSelectionLayer = null;
                    layerLocalSelectionPath = null;
                    activity.recordHistory();
                    activity.canvasView.invalidate();
                } else if (idx == 4) { 
                    activity.canvasView.clearLassoSelection();
                    trackedSelectionLayer = null;
                    layerLocalSelectionPath = null;
                } else if (idx == 5) { 
                    if (s.activeLayerIndex >= 0 && s.activeLayerIndex < s.layers.size()) {
                        showSelectPixelsDialog(s, s.layers.get(s.activeLayerIndex));
                    } else {
                        Toast.makeText(activity, "Please select a layer first", Toast.LENGTH_SHORT).show();
                    }
                }
            });
            l.addView(itemTv);
        }

        popup.setContentView(l);
        popup.setWidth(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, 0, dp(4));
    }

    /**
     * EditorActivity-র Undo/Redo ইঞ্জিনের সাথে শতভাগ সামঞ্জস্যপূর্ণ Clear ইঞ্জিন
     */
    private void executeClearAction(EditorActivity.ProjectTabSession s) {
        if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) {
            Toast.makeText(activity, "No active layer to clear!", Toast.LENGTH_SHORT).show();
            return;
        }

        EditorActivity.LayerItem activeLayer = s.layers.get(s.activeLayerIndex);
        if (activeLayer == null || activeLayer.bitmap == null || activeLayer.bitmap.isRecycled()) {
            Toast.makeText(activity, "Layer has no image data!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (activeLayer.isLocked) {
            Toast.makeText(activity, "Layer is locked!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // ১. আনডু যাতে কাজ করে সেজন্য পূর্বের রেফারেন্স অক্ষত রেখে পৃথক মিউটেবল বিটম্যাপ কপি তৈরি
            activeLayer.bitmap = activeLayer.bitmap.copy(Bitmap.Config.ARGB_8888, true);

            Path selPath = getEditorSelectionPath();
            if (selPath != null) {
                Matrix layerMatrix = new Matrix();
                layerMatrix.postScale(activeLayer.scaleX, activeLayer.scaleY);
                layerMatrix.postRotate(activeLayer.rotation,
                        (activeLayer.bitmap.getWidth() * activeLayer.scaleX) / 2f,
                        (activeLayer.bitmap.getHeight() * activeLayer.scaleY) / 2f);
                layerMatrix.postTranslate(activeLayer.x, activeLayer.y);

                Matrix invMatrix = new Matrix();
                layerMatrix.invert(invMatrix);

                Path localPath = new Path();
                selPath.transform(invMatrix, localPath);

                Canvas c = new Canvas(activeLayer.bitmap);
                Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
                clearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                c.drawPath(localPath, clearPaint);
            } else {
                activeLayer.bitmap.eraseColor(Color.TRANSPARENT);
            }

            activeLayer.isShape = false;
            activeLayer.isBlank = false;
            activeLayer.isDirty = true;

            // ২. হিস্ট্রি স্ট্যাকে সেভ করা (Undo / Redo পারফেক্ট কাজ করার জন্য)
            activity.recordHistory();
            invokePrivateVoidMethod("updateLayersDockUI");
            if (activity.canvasView != null) activity.canvasView.invalidate();
            activity.saveProjectToDiskImmediate(s);

            Toast.makeText(activity, "Cleared", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(activity, "Clear failed: " + t.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ২. অপাসিটি কন্ট্রোল
    private TextView findOpacityTextView() {
        if (activity == null || activity.rightLayersDock == null) return null;
        if (activity.rightLayersDock.getChildCount() > 1) {
            View child = activity.rightLayersDock.getChildAt(1);
            if (child instanceof LinearLayout) {
                LinearLayout blendRow = (LinearLayout) child;
                for (int i = 0; i < blendRow.getChildCount(); i++) {
                    View v = blendRow.getChildAt(i);
                    if (v instanceof TextView) {
                        TextView tv = (TextView) v;
                        if (tv.getText().toString().contains("Op:")) return tv;
                    }
                }
            }
        }
        return null;
    }

    private void hookOpacityControl() {
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            final TextView opTv = findOpacityTextView();
            if (opTv == null) return;

            opTv.setPadding(dp(6), dp(3), dp(6), dp(3));
            GradientDrawable opBg = new GradientDrawable();
            opBg.setColor(Color.parseColor("#121212"));
            opBg.setStroke(dp(1), Color.parseColor("#333333"));
            opBg.setCornerRadius(dp(3));
            opTv.setBackground(opBg);

            opTv.setOnTouchListener(new View.OnTouchListener() {
                float startX;
                float initialOp = 1f;
                boolean isDragging = false;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    EditorActivity.ProjectTabSession s = activity.getCurrentSession();
                    if (s == null || s.activeLayerIndex < 0 || s.activeLayerIndex >= s.layers.size()) return false;
                    EditorActivity.LayerItem al = s.layers.get(s.activeLayerIndex);

                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = event.getRawX();
                            initialOp = al.opacity;
                            isDragging = false;
                            return true;

                        case MotionEvent.ACTION_MOVE:
                            float dX = event.getRawX() - startX;
                            if (Math.abs(dX) > dp(3) || isDragging) {
                                isDragging = true;
                                float newOp = Math.max(0.0f, Math.min(1.0f, initialOp + (dX / dp(110f))));
                                al.opacity = newOp;
                                opTv.setText(" Op: " + Math.round(newOp * 100) + "%");
                                if (activity.canvasView != null) activity.canvasView.invalidate();
                            }
                            return true;

                        case MotionEvent.ACTION_UP:
                            if (!isDragging) {
                                showOpacityInputDialog(opTv, al);
                            } else {
                                activity.recordHistory();
                            }
                            isDragging = false;
                            return true;
                    }
                    return false;
                }
            });
        });
    }

    private void showOpacityInputDialog(final TextView opTv, final EditorActivity.LayerItem layer) {
        final Dialog d = new Dialog(activity);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }

        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(16), dp(18), dp(16));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1C1C1C"));
        bg.setStroke(dp(1), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(12));
        box.setBackground(bg);

        TextView title = new TextView(activity);
        title.setText("Layer Opacity");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        title.setTypeface(null, Typeface.BOLD);
        box.addView(title);

        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        TextView lbl = new TextView(activity);
        lbl.setText("Enter Opacity (0-100%): ");
        lbl.setTextColor(Color.parseColor("#AAAAAA"));
        lbl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        row.addView(lbl);

        final EditText et = new EditText(activity);
        et.setText(String.valueOf(Math.round(layer.opacity * 100)));
        et.setTextColor(Color.WHITE);
        et.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setGravity(Gravity.CENTER);
        et.setLayoutParams(new LinearLayout.LayoutParams(dp(50), dp(28)));

        GradientDrawable etBg = new GradientDrawable();
        etBg.setColor(Color.parseColor("#121212"));
        etBg.setStroke(dp(1), Color.parseColor("#2C2C2C"));
        etBg.setCornerRadius(dp(3));
        et.setBackground(etBg);
        row.addView(et);
        box.addView(row);

        final SeekBar sb = new SeekBar(activity);
        sb.setMax(100);
        sb.setProgress(Math.round(layer.opacity * 100));
        applyCustomSeekBarStyle(sb);
        box.addView(sb);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    et.setText(String.valueOf(progress));
                    layer.opacity = progress / 100f;
                    opTv.setText(" Op: " + progress + "%");
                    if (activity.canvasView != null) activity.canvasView.invalidate();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    int val = Integer.parseInt(cs.toString().trim());
                    val = Math.max(0, Math.min(100, val));
                    layer.opacity = val / 100f;
                    sb.setProgress(val);
                    opTv.setText(" Op: " + val + "%");
                    if (activity.canvasView != null) activity.canvasView.invalidate();
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        Button ok = new Button(activity);
        ok.setText("APPLY");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        ok.setTypeface(null, Typeface.BOLD);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setColor(Color.parseColor("#FF1238"));
        okBg.setCornerRadius(dp(16));
        ok.setBackground(okBg);
        ok.setLayoutParams(new LinearLayout.LayoutParams(dp(80), dp(34)));
        ok.setOnClickListener(v -> {
            activity.recordHistory();
            d.dismiss();
        });
        box.addView(ok);

        d.setContentView(box);
        d.show();
    }

    // ৩. স্মার্ট অবজেক্ট ও লেয়ার ডক
    private LinearLayout findLayersListContainer() {
        if (activity == null || activity.rightLayersDock == null) return null;
        for (int i = 0; i < activity.rightLayersDock.getChildCount(); i++) {
            View child = activity.rightLayersDock.getChildAt(i);
            if (child instanceof ScrollView) {
                ScrollView sv = (ScrollView) child;
                if (sv.getChildCount() > 0 && sv.getChildAt(0) instanceof LinearLayout) {
                    return (LinearLayout) sv.getChildAt(0);
                }
            }
        }
        return null;
    }

    private void hookLayersDockForSmartObjects() {
        if (activity == null) return;
        activity.runOnUiThread(() -> {
            LinearLayout container = findLayersListContainer();
            if (container != null) {
                container.setOnHierarchyChangeListener(new ViewGroup.OnHierarchyChangeListener() {
                    @Override public void onChildViewAdded(View parent, View child) { enhanceLayerRowView(child); }
                    @Override public void onChildViewRemoved(View parent, View child) {}
                });
                for (int i = 0; i < container.getChildCount(); i++) {
                    enhanceLayerRowView(container.getChildAt(i));
                }
            }
        });
    }

    private void enhanceLayerRowView(View rowView) {
        if (!(rowView instanceof LinearLayout)) return;
        final LinearLayout row = (LinearLayout) rowView;
        final EditorActivity.ProjectTabSession s = activity.getCurrentSession();
        if (s == null) return;

        int foundIndex = -1;
        LinearLayout container = findLayersListContainer();
        if (container != null) {
            int childCount = container.getChildCount();
            int rowPos = container.indexOfChild(row);
            foundIndex = (s.layers.size() - 1) - rowPos;
        }

        if (foundIndex < 0 || foundIndex >= s.layers.size()) return;
        final int layerIdx = foundIndex;
        final EditorActivity.LayerItem layer = s.layers.get(layerIdx);

        if (layer.isSmartObject && row.findViewWithTag("smart_badge_tag") == null) {
            ImageView smartBadge = new ImageView(activity);
            smartBadge.setTag("smart_badge_tag");
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(15), dp(15));
            bp.setMargins(0, 0, dp(4), 0);
            smartBadge.setLayoutParams(bp);

            Bitmap bmp = Bitmap.createBitmap(dp(14), dp(14), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(1.2f));
            c.drawRect(dp(1.5f), dp(1.5f), dp(12.5f), dp(12.5f), p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.parseColor("#007AFF"));
            c.drawRect(dp(7), dp(7), dp(12), dp(12), p);

            smartBadge.setImageBitmap(bmp);
            smartBadge.setOnClickListener(v -> openSmartObjectInNewTab(layer));
            row.addView(smartBadge, 3);
        }

        row.setOnLongClickListener(v -> {
            s.activeLayerIndex = layerIdx;
            showAdvancedLayerMenu(row, layer, layerIdx);
            return true;
        });
    }

    // ৪. লেয়ার অ্যাকশন মেনু
    private void showAdvancedLayerMenu(View anchor, final EditorActivity.LayerItem layer, final int index) {
        final PopupWindow popup = new PopupWindow(activity);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(8), dp(8), dp(8), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#1E1E1E"));
        bg.setStroke(dp(1f), Color.parseColor("#333333"));
        bg.setCornerRadius(dp(4));
        root.setBackground(bg);

        TextView head = new TextView(activity);
        head.setText("Layer: " + layer.name);
        head.setTextColor(Color.WHITE);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        head.setTypeface(null, Typeface.BOLD);
        head.setPadding(dp(4), dp(2), dp(4), dp(6));
        root.addView(head);

        ScrollView sv = new ScrollView(activity);
        sv.setVerticalScrollBarEnabled(true);
        sv.setScrollbarFadingEnabled(false);

        LinearLayout inner = new LinearLayout(activity);
        inner.setOrientation(LinearLayout.VERTICAL);

        final EditorActivity.ProjectTabSession s = activity.getCurrentSession();

        inner.addView(createMenuItem("Duplicate Layer", v -> { popup.dismiss(); invokePrivateVoidMethod("duplicateActiveLayer"); }));
        inner.addView(createMenuItem("Delete Layer", v -> { 
            popup.dismiss(); 
            invokePrivateVoidMethod("deleteActiveLayer");
        }));

        inner.addView(createMenuItem("Select Pixels", v -> {
            popup.dismiss();
            showSelectPixelsDialog(s, layer);
        }));

        if (index > 0) {
            inner.addView(createMenuItem("Merge Down", v -> {
                popup.dismiss();
                implementMergeDown(s, index);
            }));

            if (layer.isClippingMask) {
                inner.addView(createMenuItem("Release Clipping Mask", v -> {
                    popup.dismiss();
                    implementReleaseClippingMask(layer);
                }));
            } else {
                inner.addView(createMenuItem("Create Clipping Mask", v -> {
                    popup.dismiss();
                    implementClippingMask(layer);
                }));
            }
        } else if (layer.isClippingMask) {
            inner.addView(createMenuItem("Release Clipping Mask", v -> {
                popup.dismiss();
                implementReleaseClippingMask(layer);
            }));
        }

        if (!layer.isSmartObject) {
            inner.addView(createMenuItem("Convert to Smart Object", v -> {
                popup.dismiss();
                convertToSmartObject(layer);
            }));
        } else {
            inner.addView(createMenuItem("Edit Smart Object (New Tab)", v -> {
                popup.dismiss();
                openSmartObjectInNewTab(layer);
            }));
        }

        if (s.isSmartObjectChild && s.parentSmartLayerRef != null) {
            inner.addView(createMenuItem("Save Smart Object", v -> {
                popup.dismiss();
                saveSmartObjectChanges(s);
            }));
        }

        inner.addView(createMenuItem("Rasterize Layer", v -> {
            popup.dismiss();
            rasterizeLayer(layer);
        }));

        inner.addView(createMenuItem("Move Layer UP", v -> { popup.dismiss(); invokeMoveLayerOrder(index, true); }));
        inner.addView(createMenuItem("Move Layer DOWN", v -> { popup.dismiss(); invokeMoveLayerOrder(index, false); }));

        sv.addView(inner);
        root.addView(sv);

        popup.setContentView(root);
        int menuWidth = dp(195);
        popup.setWidth(menuWidth);

        int screenH = activity.getResources().getDisplayMetrics().heightPixels;
        int maxH = (int) (screenH * 0.60f);

        root.measure(View.MeasureSpec.makeMeasureSpec(menuWidth, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        int measuredH = root.getMeasuredHeight();
        popup.setHeight(Math.min(measuredH, maxH));

        popup.setFocusable(true);
        popup.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popup.showAsDropDown(anchor, dp(10), dp(-10));
    }

    private TextView createMenuItem(String text, View.OnClickListener listener) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tv.setPadding(dp(8), dp(6), dp(8), dp(6));
        tv.setOnClickListener(listener);
        return tv;
    }

    private void implementClippingMask(EditorActivity.LayerItem layer) {
        if (layer == null) return;
        layer.isClippingMask = true;
        layer.isDirty = true;
        activity.recordHistory();
        invokePrivateVoidMethod("updateLayersDockUI");
        if (activity.canvasView != null) activity.canvasView.invalidate();
        Toast.makeText(activity, "Clipping Mask Created!", Toast.LENGTH_SHORT).show();
    }

    private void implementReleaseClippingMask(EditorActivity.LayerItem layer) {
        if (layer == null) return;
        layer.isClippingMask = false;
        layer.isDirty = true;
        activity.recordHistory();
        invokePrivateVoidMethod("updateLayersDockUI");
        if (activity.canvasView != null) activity.canvasView.invalidate();
        Toast.makeText(activity, "Clipping Mask Released!", Toast.LENGTH_SHORT).show();
    }

    private void applyBlendModeToPaint(Paint p, String mode) {
        if (mode == null || "Normal".equalsIgnoreCase(mode)) {
            p.setXfermode(null);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            BlendMode bm = BlendMode.SRC_OVER;
            if ("Multiply".equalsIgnoreCase(mode)) bm = BlendMode.MULTIPLY;
            else if ("Screen".equalsIgnoreCase(mode)) bm = BlendMode.SCREEN;
            else if ("Overlay".equalsIgnoreCase(mode)) bm = BlendMode.OVERLAY;
            else if ("Darken".equalsIgnoreCase(mode)) bm = BlendMode.DARKEN;
            else if ("Lighten".equalsIgnoreCase(mode)) bm = BlendMode.LIGHTEN;
            else if ("Color Dodge".equalsIgnoreCase(mode)) bm = BlendMode.COLOR_DODGE;
            else if ("Color Burn".equalsIgnoreCase(mode)) bm = BlendMode.COLOR_BURN;
            else if ("Hard Light".equalsIgnoreCase(mode)) bm = BlendMode.HARD_LIGHT;
            else if ("Soft Light".equalsIgnoreCase(mode)) bm = BlendMode.SOFT_LIGHT;
            else if ("Difference".equalsIgnoreCase(mode)) bm = BlendMode.DIFFERENCE;
            else if ("Exclusion".equalsIgnoreCase(mode)) bm = BlendMode.EXCLUSION;
            else if ("Hue".equalsIgnoreCase(mode)) bm = BlendMode.HUE;
            else if ("Saturation".equalsIgnoreCase(mode)) bm = BlendMode.SATURATION;
            else if ("Add".equalsIgnoreCase(mode) || "Linear Dodge".equalsIgnoreCase(mode)) bm = BlendMode.PLUS;
            else if ("Linear Burn".equalsIgnoreCase(mode)) bm = BlendMode.DARKEN;
            else if ("Vivid Light".equalsIgnoreCase(mode)) bm = BlendMode.OVERLAY;
            else if ("Dissolve".equalsIgnoreCase(mode)) bm = BlendMode.SRC_OVER;
            else if ("Clear".equalsIgnoreCase(mode)) bm = BlendMode.CLEAR;
            p.setBlendMode(bm);
        } else {
            PorterDuff.Mode pd = PorterDuff.Mode.SRC_OVER;
            if ("Multiply".equalsIgnoreCase(mode) || "Linear Burn".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.MULTIPLY;
            else if ("Screen".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.SCREEN;
            else if ("Overlay".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.OVERLAY;
            else if ("Darken".equalsIgnoreCase(mode) || "Color Burn".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.DARKEN;
            else if ("Lighten".equalsIgnoreCase(mode) || "Color Dodge".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.LIGHTEN;
            else if ("Add".equalsIgnoreCase(mode) || "Linear Dodge".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.ADD;
            else if ("Difference".equalsIgnoreCase(mode) || "Exclusion".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.XOR;
            else if ("Clear".equalsIgnoreCase(mode)) pd = PorterDuff.Mode.CLEAR;
            p.setXfermode(new PorterDuffXfermode(pd));
        }
    }

    private void implementMergeDown(EditorActivity.ProjectTabSession s, int topIndex) {
        if (s == null || topIndex <= 0 || topIndex >= s.layers.size()) return;
        EditorActivity.LayerItem topLayer = s.layers.get(topIndex);
        EditorActivity.LayerItem bottomLayer = s.layers.get(topIndex - 1);

        if (topLayer == null || bottomLayer == null || topLayer.bitmap == null || bottomLayer.bitmap == null) return;
        if (topLayer.bitmap.isRecycled() || bottomLayer.bitmap.isRecycled()) return;

        try {
            int bW = bottomLayer.bitmap.getWidth();
            int bH = bottomLayer.bitmap.getHeight();

            if (topLayer.isClippingMask) {
                Bitmap mergedBmp = Bitmap.createBitmap(bW, bH, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(mergedBmp);

                c.drawBitmap(bottomLayer.bitmap, 0, 0, null);

                Matrix mBottom = new Matrix();
                mBottom.postScale(bottomLayer.scaleX, bottomLayer.scaleY);
                mBottom.postRotate(bottomLayer.rotation, (bW * bottomLayer.scaleX) / 2f, (bH * bottomLayer.scaleY) / 2f);
                mBottom.postTranslate(bottomLayer.x, bottomLayer.y);

                Matrix mTop = new Matrix();
                mTop.postScale(topLayer.scaleX, topLayer.scaleY);
                mTop.postRotate(topLayer.rotation, (topLayer.bitmap.getWidth() * topLayer.scaleX) / 2f, (topLayer.bitmap.getHeight() * topLayer.scaleY) / 2f);
                mTop.postTranslate(topLayer.x, topLayer.y);

                Matrix invBottom = new Matrix();
                mBottom.invert(invBottom);

                Matrix topInBottom = new Matrix();
                topInBottom.setConcat(invBottom, mTop);

                Paint blendCompositePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                blendCompositePaint.setAlpha((int) (topLayer.opacity * 255));
                applyBlendModeToPaint(blendCompositePaint, topLayer.blendMode);

                int clipSave = c.saveLayer(0, 0, bW, bH, blendCompositePaint);

                Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                c.drawBitmap(bottomLayer.bitmap, 0, 0, maskPaint);

                Paint contentPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                contentPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
                c.drawBitmap(topLayer.bitmap, topInBottom, contentPaint);

                c.restoreToCount(clipSave);

                bottomLayer.bitmap = mergedBmp;
                bottomLayer.name = bottomLayer.name + " (Merged)";
                bottomLayer.isDirty = true;

            } else {
                Bitmap mergedBmp = Bitmap.createBitmap(s.canvasWidth, s.canvasHeight, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(mergedBmp);

                Matrix mb = new Matrix();
                mb.postScale(bottomLayer.scaleX, bottomLayer.scaleY);
                mb.postRotate(bottomLayer.rotation, (bW * bottomLayer.scaleX) / 2f, (bH * bottomLayer.scaleY) / 2f);
                mb.postTranslate(bottomLayer.x, bottomLayer.y);
                Paint pb = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                pb.setAlpha((int) (bottomLayer.opacity * 255));
                applyBlendModeToPaint(pb, bottomLayer.blendMode);
                c.drawBitmap(bottomLayer.bitmap, mb, pb);

                Matrix mt = new Matrix();
                mt.postScale(topLayer.scaleX, topLayer.scaleY);
                mt.postRotate(topLayer.rotation, (topLayer.bitmap.getWidth() * topLayer.scaleX) / 2f, (topLayer.bitmap.getHeight() * topLayer.scaleY) / 2f);
                mt.postTranslate(topLayer.x, topLayer.y);
                Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
                pt.setAlpha((int) (topLayer.opacity * 255));
                applyBlendModeToPaint(pt, topLayer.blendMode);
                c.drawBitmap(topLayer.bitmap, mt, pt);

                bottomLayer.bitmap = mergedBmp;
                bottomLayer.x = 0; bottomLayer.y = 0;
                bottomLayer.scaleX = 1f; bottomLayer.scaleY = 1f;
                bottomLayer.rotation = 0f;
                bottomLayer.opacity = 1f;
                bottomLayer.blendMode = "Normal";
                bottomLayer.name = bottomLayer.name + " (Merged)";
                bottomLayer.isDirty = true;
            }

            s.layers.remove(topIndex);
            s.activeLayerIndex = topIndex - 1;

            activity.recordHistory();
            invokePrivateVoidMethod("updateLayersDockUI");
            if (activity.canvasView != null) activity.canvasView.invalidate();
            activity.autoSaveCurrentProject();
            Toast.makeText(activity, "Layers Merged", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(activity, "Merge failed", Toast.LENGTH_SHORT).show();
        }
    }

    // ৫. SELECT PIXELS ডায়ালগ
    private void showSelectPixelsDialog(final EditorActivity.ProjectTabSession s, final EditorActivity.LayerItem layer) {
        if (layer == null || layer.bitmap == null || layer.bitmap.isRecycled()) {
            Toast.makeText(activity, "Layer has no pixel content!", Toast.LENGTH_SHORT).show();
            return;
        }

        final Path backupSelectionPath = getEditorSelectionPath();
        final boolean[] hasApplied = {false}; 

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL); 
            dialog.getWindow().setGravity(Gravity.CENTER);
        }

        LinearLayout root = new LinearLayout(activity);
        root.setLayoutParams(new LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(18));

        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setColor(Color.parseColor("#1C1C1C"));
        rootBg.setStroke(dp(1), Color.parseColor("#2E2E2E"));
        rootBg.setCornerRadius(dp(12));
        root.setBackground(rootBg);

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(12));

        TextView titleTv = new TextView(activity);
        titleTv.setText("Select Pixels Modifier");
        titleTv.setTextColor(Color.WHITE);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        titleTv.setTypeface(null, Typeface.BOLD);
        titleTv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        header.addView(titleTv);

        ImageView closeX = new ImageView(activity);
        closeX.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        closeX.setImageDrawable(createCloseVectorDrawable());
        header.addView(closeX);
        root.addView(header);

        header.setOnTouchListener(new View.OnTouchListener() {
            float downRawX, downRawY;
            int startX, startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (dialog.getWindow() == null) return false;
                WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        startX = params.x;
                        startY = params.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + (int) (event.getRawX() - downRawX);
                        params.y = startY + (int) (event.getRawY() - downRawY);
                        dialog.getWindow().setAttributes(params);
                        return true;
                }
                return false;
            }
        });

        final int[] expandVal = {0};
        final int[] smoothVal = {0};

        LinearLayout expRow = new LinearLayout(activity);
        expRow.setOrientation(LinearLayout.HORIZONTAL);
        expRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView expLabel = new TextView(activity);
        expLabel.setText("Expand / Contract:");
        expLabel.setTextColor(Color.parseColor("#AAAAAA"));
        expLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        expLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        expRow.addView(expLabel);

        final EditText expEt = new EditText(activity);
        expEt.setText("0");
        expEt.setTextColor(Color.WHITE);
        expEt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        expEt.setGravity(Gravity.CENTER);
        expEt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        expEt.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(28)));
        expEt.setBackground(createInputBg());
        expRow.addView(expEt);

        TextView expPx = new TextView(activity);
        expPx.setText(" px");
        expPx.setTextColor(Color.parseColor("#888888"));
        expPx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        expRow.addView(expPx);
        root.addView(expRow);

        final SeekBar expSb = new SeekBar(activity);
        expSb.setMax(1000);
        expSb.setProgress(500);
        applyCustomSeekBarStyle(expSb);
        root.addView(expSb);

        LinearLayout smRow = new LinearLayout(activity);
        smRow.setOrientation(LinearLayout.HORIZONTAL);
        smRow.setGravity(Gravity.CENTER_VERTICAL);
        smRow.setPadding(0, dp(10), 0, dp(0));

        TextView smLabel = new TextView(activity);
        smLabel.setText("Smooth:");
        smLabel.setTextColor(Color.parseColor("#AAAAAA"));
        smLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        smLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        smRow.addView(smLabel);

        final EditText smEt = new EditText(activity);
        smEt.setText("0");
        smEt.setTextColor(Color.WHITE);
        smEt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        smEt.setGravity(Gravity.CENTER);
        smEt.setInputType(InputType.TYPE_CLASS_NUMBER);
        smEt.setLayoutParams(new LinearLayout.LayoutParams(dp(65), dp(28)));
        smEt.setBackground(createInputBg());
        smRow.addView(smEt);

        TextView smPx = new TextView(activity);
        smPx.setText(" px");
        smPx.setTextColor(Color.parseColor("#888888"));
        smPx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        smRow.addView(smPx);
        root.addView(smRow);

        final SeekBar smSb = new SeekBar(activity);
        smSb.setMax(500);
        smSb.setProgress(0);
        applyCustomSeekBarStyle(smSb);
        root.addView(smSb);

        final Runnable triggerUpdate = () -> {
            final int taskId = selectionTaskCounter.incrementAndGet();
            selectionExecutor.execute(() -> {
                if (taskId != selectionTaskCounter.get()) return;
                if (layer.bitmap == null || layer.bitmap.isRecycled()) return;

                final Path localPath = computeChamferSelectionPath(layer, expandVal[0], smoothVal[0]);

                if (taskId != selectionTaskCounter.get()) return;

                activity.runOnUiThread(() -> {
                    if (taskId != selectionTaskCounter.get()) return;
                    if (!dialog.isShowing()) return;

                    layerLocalSelectionPath = localPath;
                    trackedSelectionLayer = layer;
                    lastLayerX = layer.x;
                    lastLayerY = layer.y;
                    lastLayerScaleX = layer.scaleX;
                    lastLayerScaleY = layer.scaleY;

                    Matrix m = new Matrix();
                    m.postScale(layer.scaleX, layer.scaleY);
                    m.postTranslate(layer.x, layer.y);
                    Path canvasPath = new Path();
                    if (localPath != null) {
                        localPath.transform(m, canvasPath);
                    }
                    setEditorSelectionPath(canvasPath);
                    if (activity.canvasView != null) activity.canvasView.invalidate();
                });
            });
        };

        expSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    int val = progress - 500;
                    expandVal[0] = val;
                    expEt.setText(String.valueOf(val));
                    triggerUpdate.run();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        expEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s1, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    String str = cs.toString().trim();
                    if (!str.isEmpty() && !str.equals("-")) {
                        int v = Integer.parseInt(str);
                        v = Math.max(-500, Math.min(500, v));
                        if (expandVal[0] != v) {
                            expandVal[0] = v;
                            expSb.setProgress(v + 500);
                            triggerUpdate.run();
                        }
                    }
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s1) {}
        });

        smSb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser) {
                    smoothVal[0] = progress;
                    smEt.setText(String.valueOf(progress));
                    triggerUpdate.run();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        smEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s1, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence cs, int start, int before, int count) {
                try {
                    String str = cs.toString().trim();
                    if (!str.isEmpty()) {
                        int v = Integer.parseInt(str);
                        v = Math.max(0, Math.min(500, v));
                        if (smoothVal[0] != v) {
                            smoothVal[0] = v;
                            smSb.setProgress(v);
                            triggerUpdate.run();
                        }
                    }
                } catch (Exception ignored) {}
            }
            @Override public void afterTextChanged(Editable s1) {}
        });

        LinearLayout btnRow = new LinearLayout(activity);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btnRow.setPadding(0, dp(14), 0, 0);

        Button btnCancel = new Button(activity);
        btnCancel.setText("Cancel");
        btnCancel.setTextColor(Color.parseColor("#E0E0E0"));
        btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        GradientDrawable canBg = new GradientDrawable();
        canBg.setColor(Color.parseColor("#262626"));
        canBg.setStroke(dp(1), Color.parseColor("#383838"));
        canBg.setCornerRadius(dp(4));
        btnCancel.setBackground(canBg);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(70), dp(32));
        cp.setMargins(0, 0, dp(8), 0);
        btnCancel.setLayoutParams(cp);

        btnCancel.setOnClickListener(v -> {
            setEditorSelectionPath(backupSelectionPath);
            layerLocalSelectionPath = null;
            trackedSelectionLayer = null;
            if (activity.canvasView != null) activity.canvasView.invalidate();
            dialog.dismiss();
        });

        closeX.setOnClickListener(v -> {
            if (!hasApplied[0]) {
                setEditorSelectionPath(backupSelectionPath);
                layerLocalSelectionPath = null;
                trackedSelectionLayer = null;
                if (activity.canvasView != null) activity.canvasView.invalidate();
            }
            dialog.dismiss();
        });
        btnRow.addView(btnCancel);

        Button btnOk = new Button(activity);
        btnOk.setText("APPLY");
        btnOk.setTextColor(Color.WHITE);
        btnOk.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f);
        btnOk.setTypeface(null, Typeface.BOLD);
        GradientDrawable okBg = new GradientDrawable();
        okBg.setColor(Color.parseColor("#FF1238"));
        okBg.setCornerRadius(dp(4));
        btnOk.setBackground(okBg);
        btnOk.setLayoutParams(new LinearLayout.LayoutParams(dp(70), dp(32)));

        btnOk.setOnClickListener(v -> {
            hasApplied[0] = true;
            ensureLayerCanHoldExpandedSelection(layer, expandVal[0]);
            activity.recordHistory();
            Toast.makeText(activity, "Selection Applied!", Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });
        btnRow.addView(btnOk);

        root.addView(btnRow);
        dialog.setContentView(root);
        dialog.show();

        triggerUpdate.run();
    }

    // ৬. নিখুঁত, সাব-পিক্সেল আইসোকনট্যুর ক্যালকুলেটর
    private Path computeChamferSelectionPath(EditorActivity.LayerItem layer, int expand, int smooth) {
        if (layer == null || layer.bitmap == null || layer.bitmap.isRecycled()) return null;

        Bitmap srcBmp = layer.bitmap;
        int origW = srcBmp.getWidth();
        int origH = srcBmp.getHeight();
        if (origW <= 0 || origH <= 0) return null;

        int pad = Math.abs(expand) + 40;
        int paddedW = origW + pad * 2;
        int paddedH = origH + pad * 2;

        int maxDim = 950;
        float downScale = Math.max(1f, Math.max(paddedW, paddedH) / (float) maxDim);
        int w = Math.max(10, (int) (paddedW / downScale));
        int h = Math.max(10, (int) (paddedH / downScale));

        Bitmap paddedMask = null;
        try {
            paddedMask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        } catch (OutOfMemoryError oom) {
            System.gc();
            return null;
        }

        Canvas pc = new Canvas(paddedMask);
        Matrix pm = new Matrix();
        pm.postScale(1f / downScale, 1f / downScale);
        pm.postTranslate(pad / downScale, pad / downScale);
        Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        pc.drawBitmap(srcBmp, pm, bmpPaint);

        int[] pixels = new int[w * h];
        paddedMask.getPixels(pixels, 0, w, 0, 0, w, h);
        paddedMask.recycle();

        int[][] alpha = new int[h][w];
        boolean[][] binary = new boolean[h][w];

        final int ALPHA_THRESHOLD = 110;
        for (int y = 0; y < h; y++) {
            int yw = y * w;
            for (int x = 0; x < w; x++) {
                int a = (pixels[yw + x] >>> 24);
                alpha[y][x] = a;
                binary[y][x] = (a >= ALPHA_THRESHOLD);
            }
        }

        float[][] scalarField = new float[h][w];
        float fieldThreshold = 0f;

        if (expand == 0) {
            fieldThreshold = ALPHA_THRESHOLD;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    scalarField[y][x] = alpha[y][x];
                }
            }
        } else {
            boolean isExpand = expand > 0;
            float effExpand = Math.abs(expand) / downScale;
            float targetDist = effExpand * 10f;
            int[][] dist = runChamferDistance(binary, w, h, isExpand);

            fieldThreshold = targetDist;
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    if (isExpand) {
                        scalarField[y][x] = dist[y][x];
                    } else {
                        scalarField[y][x] = binary[y][x] ? dist[y][x] : -1f;
                    }
                }
            }
        }

        List<PointF> contour = traceSubpixelContour(scalarField, w, h, fieldThreshold, expand <= 0, downScale, pad);
        if (contour == null || contour.isEmpty()) return null;

        int smoothRadius = (int) (smooth / downScale);
        List<PointF> finalPoints = smoothContourPoints(contour, smoothRadius);
        if (finalPoints == null || finalPoints.isEmpty()) return null;

        Path localPath = new Path();
        localPath.moveTo(finalPoints.get(0).x, finalPoints.get(0).y);
        for (int i = 1; i < finalPoints.size(); i++) {
            localPath.lineTo(finalPoints.get(i).x, finalPoints.get(i).y);
        }
        localPath.close();

        return localPath;
    }

    private static int[][] runChamferDistance(boolean[][] src, int w, int h, boolean isExpand) {
        int[][] dist = new int[h][w];
        final int INF = 1000000;

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                boolean isSource = isExpand ? src[y][x] : !src[y][x];
                dist[y][x] = isSource ? 0 : INF;
            }
        }

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (dist[y][x] > 0) {
                    int min = dist[y][x];
                    if (x > 0) min = Math.min(min, dist[y][x - 1] + 10);
                    if (y > 0) {
                        min = Math.min(min, dist[y - 1][x] + 10);
                        if (x > 0) min = Math.min(min, dist[y - 1][x - 1] + 14);
                        if (x < w - 1) min = Math.min(min, dist[y - 1][x + 1] + 14);
                    }
                    dist[y][x] = min;
                }
            }
        }

        for (int y = h - 1; y >= 0; y--) {
            for (int x = w - 1; x >= 0; x--) {
                int min = dist[y][x];
                if (x < w - 1) min = Math.min(min, dist[y][x + 1] + 10);
                if (y < h - 1) {
                    min = Math.min(min, dist[y + 1][x] + 10);
                    if (x < w - 1) min = Math.min(min, dist[y + 1][x + 1] + 14);
                    if (x > 0) min = Math.min(min, dist[y + 1][x - 1] + 14);
                }
                dist[y][x] = min;
            }
        }
        return dist;
    }

    private static List<PointF> traceSubpixelContour(float[][] field, int w, int h, float threshold, boolean greaterEqual, float downScale, int pad) {
        List<PointF> points = new ArrayList<>();
        if (field == null || w < 2 || h < 2) return points;

        boolean[][] inside = new boolean[h][w];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                inside[y][x] = greaterEqual ? (field[y][x] >= threshold) : (field[y][x] <= threshold);
            }
        }

        int startX = -1, startY = -1;
        for (int y = 0; y < h - 1; y++) {
            for (int x = 0; x < w - 1; x++) {
                if (!inside[y][x] && inside[y][x + 1]) {
                    startX = x;
                    startY = y;
                    break;
                }
            }
            if (startX != -1) break;
        }

        if (startX == -1) {
            for (int y = 0; y < h - 1; y++) {
                for (int x = 0; x < w - 1; x++) {
                    int state = (inside[y][x] ? 8 : 0) | (inside[y][x + 1] ? 4 : 0)
                              | (inside[y + 1][x + 1] ? 2 : 0) | (inside[y + 1][x] ? 1 : 0);
                    if (state > 0 && state < 15) {
                        startX = x;
                        startY = y;
                        break;
                    }
                }
                if (startX != -1) break;
            }
        }

        if (startX == -1) return points;

        int curX = startX;
        int curY = startY;
        int inEdge = 0;

        int maxSteps = w * h * 4;
        int steps = 0;

        while (steps++ < maxSteps) {
            int state = (inside[curY][curX] ? 8 : 0)
                      | (inside[curY][curX + 1] ? 4 : 0)
                      | (inside[curY + 1][curX + 1] ? 2 : 0)
                      | (inside[curY + 1][curX] ? 1 : 0);

            int outEdge = getMarchingSquaresExitEdge(state, inEdge);
            if (outEdge == -1) break;

            float px = curX, py = curY;
            float vTL = field[curY][curX];
            float vTR = field[curY][curX + 1];
            float vBR = field[curY + 1][curX + 1];
            float vBL = field[curY + 1][curX];

            switch (outEdge) {
                case 0:
                    float t0 = (threshold - vTL) / (vTR - vTL == 0 ? 1f : (vTR - vTL));
                    t0 = Math.max(0.01f, Math.min(0.99f, Math.abs(t0)));
                    px = curX + t0;
                    py = curY;
                    break;
                case 1:
                    float t1 = (threshold - vTR) / (vBR - vTR == 0 ? 1f : (vBR - vTR));
                    t1 = Math.max(0.01f, Math.min(0.99f, Math.abs(t1)));
                    px = curX + 1.0f;
                    py = curY + t1;
                    break;
                case 2:
                    float t2 = (threshold - vBL) / (vBR - vBL == 0 ? 1f : (vBR - vBL));
                    t2 = Math.max(0.01f, Math.min(0.99f, Math.abs(t2)));
                    px = curX + t2;
                    py = curY + 1.0f;
                    break;
                case 3:
                default:
                    float t3 = (threshold - vTL) / (vBL - vTL == 0 ? 1f : (vBL - vTL));
                    t3 = Math.max(0.01f, Math.min(0.99f, Math.abs(t3)));
                    px = curX;
                    py = curY + t3;
                    break;
            }

            points.add(new PointF(px * downScale - pad, py * downScale - pad));

            int nextX = curX;
            int nextY = curY;
            int nextInEdge;

            switch (outEdge) {
                case 0:
                    nextY--;
                    nextInEdge = 2;
                    break;
                case 1:
                    nextX++;
                    nextInEdge = 3;
                    break;
                case 2:
                    nextY++;
                    nextInEdge = 0;
                    break;
                case 3:
                default:
                    nextX--;
                    nextInEdge = 1;
                    break;
            }

            if (nextX < 0 || nextX >= w - 1 || nextY < 0 || nextY >= h - 1) {
                break;
            }

            if (nextX == startX && nextY == startY && nextInEdge == 0) {
                break;
            }

            curX = nextX;
            curY = nextY;
            inEdge = nextInEdge;
        }

        return points;
    }

    private static int getMarchingSquaresExitEdge(int state, int inEdge) {
        switch (state) {
            case 1: return (inEdge == 3) ? 2 : 3;
            case 2: return (inEdge == 2) ? 1 : 2;
            case 3: return (inEdge == 3) ? 1 : 3;
            case 4: return (inEdge == 0) ? 1 : 0;
            case 5:
                if (inEdge == 0) return 1;
                if (inEdge == 1) return 0;
                if (inEdge == 2) return 3;
                return 2;
            case 6: return (inEdge == 0) ? 2 : 0;
            case 7: return (inEdge == 0) ? 3 : 0;
            case 8: return (inEdge == 0) ? 3 : 0;
            case 9: return (inEdge == 0) ? 2 : 0;
            case 10:
                if (inEdge == 0) return 3;
                if (inEdge == 3) return 0;
                if (inEdge == 2) return 1;
                return 2;
            case 11: return (inEdge == 0) ? 1 : 0;
            case 12: return (inEdge == 3) ? 1 : 3;
            case 13: return (inEdge == 2) ? 1 : 2;
            case 14: return (inEdge == 2) ? 3 : 2;
            default: return -1;
        }
    }

    private static List<PointF> smoothContourPoints(List<PointF> pts, int smoothRadius) {
        if (pts == null || pts.isEmpty()) return pts;
        if (smoothRadius <= 0) return pts;
        int n = pts.size();
        if (n < 4) return pts;

        int window = Math.min(Math.min(12, n / 2), Math.max(1, smoothRadius / 2));
        List<PointF> result = new ArrayList<>(n);

        for (int i = 0; i < n; i++) {
            float sumX = 0, sumY = 0;
            int count = 0;

            for (int k = -window; k <= window; k++) {
                int idx = ((i + k) % n + n) % n;
                sumX += pts.get(idx).x;
                sumY += pts.get(idx).y;
                count++;
            }

            if (count > 0) {
                result.add(new PointF(sumX / count, sumY / count));
            }
        }

        return result;
    }

    private void ensureLayerCanHoldExpandedSelection(EditorActivity.LayerItem layer, int expand) {
        if (layer == null || layer.bitmap == null || expand <= 0) return;

        int extra = expand + 20;
        int newW = layer.bitmap.getWidth() + extra * 2;
        int newH = layer.bitmap.getHeight() + extra * 2;

        try {
            Bitmap biggerBmp = Bitmap.createBitmap(newW, newH, Bitmap.Config.ARGB_8888);
            Canvas bc = new Canvas(biggerBmp);
            bc.drawBitmap(layer.bitmap, extra, extra, null);

            layer.bitmap = biggerBmp;
            layer.x -= extra * layer.scaleX;
            layer.y -= extra * layer.scaleY;
            layer.isDirty = true;

            if (layerLocalSelectionPath != null) {
                Matrix shift = new Matrix();
                shift.postTranslate(extra, extra);
                layerLocalSelectionPath.transform(shift);
            }
        } catch (Throwable ignored) {}
    }

    // ৭. শুধুমাত্র সিলেকশন পাথ সিঙ্ক রাখা
    private void hookCanvasTouchForSelectionSync() {
        if (activity == null || activity.canvasView == null) return;
        final View.OnTouchListener original = getOnClickListenerTouch(activity.canvasView);

        activity.canvasView.setOnTouchListener((v, event) -> {
            boolean res = false;
            if (original != null) {
                res = original.onTouch(v, event);
            }

            if (trackedSelectionLayer != null && layerLocalSelectionPath != null) {
                float curX = trackedSelectionLayer.x;
                float curY = trackedSelectionLayer.y;
                float curScaleX = trackedSelectionLayer.scaleX;
                float curScaleY = trackedSelectionLayer.scaleY;

                if (curX != lastLayerX || curY != lastLayerY || curScaleX != lastLayerScaleX || curScaleY != lastLayerScaleY) {
                    Matrix m = new Matrix();
                    m.postScale(curScaleX, curScaleY);
                    m.postTranslate(curX, curY);

                    Path updatedCanvasPath = new Path();
                    layerLocalSelectionPath.transform(m, updatedCanvasPath);
                    setEditorSelectionPath(updatedCanvasPath);

                    lastLayerX = curX;
                    lastLayerY = curY;
                    lastLayerScaleX = curScaleX;
                    lastLayerScaleY = curScaleY;

                    activity.canvasView.invalidate();
                }
            }

            return res;
        });
    }

    private View.OnTouchListener getOnClickListenerTouch(View view) {
        try {
            Method getListenerInfo = View.class.getDeclaredMethod("getListenerInfo");
            getListenerInfo.setAccessible(true);
            Object listenerInfo = getListenerInfo.invoke(view);
            Field f = listenerInfo.getClass().getDeclaredField("mOnTouchListener");
            f.setAccessible(true);
            return (View.OnTouchListener) f.get(listenerInfo);
        } catch (Exception e) {
            return null;
        }
    }

    private void invokeMoveLayerOrder(int index, boolean moveUp) {
        try {
            Method m = EditorActivity.class.getDeclaredMethod("moveLayerOrder", int.class, boolean.class);
            m.setAccessible(true);
            m.invoke(activity, index, moveUp);
        } catch (Exception ignored) {}
    }

    private void convertToSmartObject(EditorActivity.LayerItem layer) {
        if (layer == null || layer.bitmap == null) return;
        layer.isSmartObject = true;
        layer.isDirty = true;
        smartOriginalBitmaps.put(layer, layer.bitmap.copy(Bitmap.Config.ARGB_8888, true));
        activity.recordHistory();
        invokePrivateVoidMethod("updateLayersDockUI");
        hookLayersDockForSmartObjects();
        Toast.makeText(activity, "Converted to Smart Object", Toast.LENGTH_SHORT).show();
    }

    private void openSmartObjectInNewTab(EditorActivity.LayerItem layer) {
        if (layer == null) return;
        Bitmap pristineBmp = smartOriginalBitmaps.get(layer);
        if (pristineBmp == null || pristineBmp.isRecycled()) {
            pristineBmp = layer.bitmap.copy(Bitmap.Config.ARGB_8888, true);
            smartOriginalBitmaps.put(layer, pristineBmp);
        }

        EditorActivity.ProjectTabSession smartTab = new EditorActivity.ProjectTabSession(
                layer.name + " (Smart Object)", pristineBmp.getWidth(), pristineBmp.getHeight(), 1, Color.TRANSPARENT);
        smartTab.isSmartObjectChild = true;
        smartTab.parentSmartLayerRef = layer;

        EditorActivity.LayerItem innerLayer = new EditorActivity.LayerItem("Content", pristineBmp.copy(Bitmap.Config.ARGB_8888, true), 0, 0, false);
        innerLayer.isBlank = false;
        smartTab.layers.clear();
        smartTab.layers.add(innerLayer);
        smartTab.activeLayerIndex = 0;

        activity.openNewTabWithSession(smartTab);
        Toast.makeText(activity, "Smart Object Opened in New Tab", Toast.LENGTH_SHORT).show();
    }

    private void saveSmartObjectChanges(EditorActivity.ProjectTabSession childSession) {
        if (childSession == null || childSession.parentSmartLayerRef == null) return;
        if (childSession.layers.isEmpty()) return;

        EditorActivity.LayerItem parentLayer = childSession.parentSmartLayerRef;
        Bitmap compositedContent = compositeAllLayersOfSession(childSession);

        smartOriginalBitmaps.put(parentLayer, compositedContent.copy(Bitmap.Config.ARGB_8888, true));
        parentLayer.bitmap = compositedContent;
        parentLayer.isDirty = true;

        activity.recordHistory();
        invokePrivateVoidMethod("updateLayersDockUI");
        if (activity.canvasView != null) activity.canvasView.invalidate();
        Toast.makeText(activity, "Smart Object Saved and Updated!", Toast.LENGTH_SHORT).show();
    }

    private Bitmap compositeAllLayersOfSession(EditorActivity.ProjectTabSession session) {
        int w = session.canvasWidth;
        int h = session.canvasHeight;
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);

        synchronized (session.layers) {
            for (EditorActivity.LayerItem l : session.layers) {
                if (l.isVisible && l.bitmap != null && !l.isBlank) {
                    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                    p.setAlpha((int) (l.opacity * 255));
                    applyBlendModeToPaint(p, l.blendMode);
                    Matrix m = new Matrix();
                    m.postScale(l.scaleX, l.scaleY);
                    m.postTranslate(l.x, l.y);
                    canvas.drawBitmap(l.bitmap, m, p);
                }
            }
        }
        return result;
    }

    private void rasterizeLayer(EditorActivity.LayerItem layer) {
        if (layer == null || layer.bitmap == null || layer.bitmap.isRecycled()) return;

        int scaledW = Math.max(1, (int) (layer.bitmap.getWidth() * Math.abs(layer.scaleX)));
        int scaledH = Math.max(1, (int) (layer.bitmap.getHeight() * Math.abs(layer.scaleY)));

        Bitmap fullRaster = Bitmap.createBitmap(scaledW, scaledH, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(fullRaster);
        Matrix m = new Matrix();
        m.postScale(layer.scaleX, layer.scaleY);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        c.drawBitmap(layer.bitmap, m, p);

        int minX = scaledW, minY = scaledH, maxX = -1, maxY = -1;
        int[] rowPixels = new int[scaledW];

        for (int y = 0; y < scaledH; y++) {
            fullRaster.getPixels(rowPixels, 0, scaledW, 0, y, scaledW, 1);
            for (int x = 0; x < scaledW; x++) {
                if ((rowPixels[x] >>> 24) > 5) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }

        Bitmap finalRaster;
        if (maxX >= minX && maxY >= minY) {
            int cropW = maxX - minX + 1;
            int cropH = maxY - minY + 1;
            finalRaster = Bitmap.createBitmap(fullRaster, minX, minY, cropW, cropH);
            layer.x += minX;
            layer.y += minY;
            if (finalRaster != fullRaster) fullRaster.recycle();
        } else {
            finalRaster = fullRaster;
        }

        layer.bitmap = finalRaster;
        layer.scaleX = 1f;
        layer.scaleY = 1f;
        layer.isShape = false;
        layer.isSmartObject = false;
        layer.isDirty = true;

        activity.recordHistory();
        invokePrivateVoidMethod("updateLayersDockUI");
        if (activity.canvasView != null) activity.canvasView.invalidate();
        Toast.makeText(activity, "Layer Rasterized", Toast.LENGTH_SHORT).show();
    }

    private Drawable createCloseVectorDrawable() {
        Bitmap bmp = Bitmap.createBitmap(dp(16), dp(16), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setStrokeWidth(dp(1.5f));
        c.drawLine(dp(3), dp(3), dp(13), dp(13), p);
        c.drawLine(dp(13), dp(3), dp(3), dp(13), p);
        return new android.graphics.drawable.BitmapDrawable(activity.getResources(), bmp);
    }

    private Drawable createInputBg() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor("#121212"));
        d.setStroke(dp(1), Color.parseColor("#2A2A2A"));
        d.setCornerRadius(dp(3));
        return d;
    }

    private void applyCustomSeekBarStyle(SeekBar sb) {
        sb.setSplitTrack(false);
        sb.setPadding(dp(6), dp(8), dp(6), dp(12));

        GradientDrawable bgTrack = new GradientDrawable();
        bgTrack.setColor(Color.parseColor("#FFFFFF"));
        bgTrack.setCornerRadius(dp(2));
        bgTrack.setSize(-1, dp(3));

        GradientDrawable progressTrack = new GradientDrawable();
        progressTrack.setColor(Color.parseColor("#FF1238"));
        progressTrack.setCornerRadius(dp(2));
        progressTrack.setSize(-1, dp(3));
        ClipDrawable clipProgress = new ClipDrawable(progressTrack, Gravity.START, ClipDrawable.HORIZONTAL);

        Drawable[] layers = new Drawable[]{bgTrack, clipProgress};
        LayerDrawable layerDrawable = new LayerDrawable(layers);
        layerDrawable.setId(0, android.R.id.background);
        layerDrawable.setId(1, android.R.id.progress);
        sb.setProgressDrawable(layerDrawable);

        GradientDrawable thumb = new GradientDrawable();
        thumb.setShape(GradientDrawable.OVAL);
        thumb.setColor(Color.parseColor("#FF1238"));
        thumb.setSize(dp(16), dp(16));
        sb.setThumb(thumb);
        sb.setThumbOffset(dp(0));
    }
}